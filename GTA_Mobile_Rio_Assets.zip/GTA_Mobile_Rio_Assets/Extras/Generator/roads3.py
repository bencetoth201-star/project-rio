"""Straßenbaukasten Teil 3: Tunnel-Mittelstück, Serpentinen, sanfte Steigung, Brücke (Segment, Steigung,
Brückenkopf, Pfeiler zum Stapeln), Schnellstraße (gerade, Bögen, Ab-/Auffahrt, Viadukt), Stützmauer 2 m, Mauerabschluss.

Konventionen wie Teil 1/2. Bögen + Serpentinen: Pivot = Start-Anschluss, Fahrtrichtung -Z.
Brücke: Fahrbahn-Oberfläche y = 0, Träger-Unterkante y = -2,6. Pfeiler: Pivot unten Mitte, Y oben.
    Deckhöhe über Grund = 5 + 2·(Schäfte 2 m) + 8·(Schäfte 8 m)   (Fundament 1 m + Kopf 1,4 m + Träger 2,6 m)
Brückensegment 12 m = eine Richtungsfahrbahn mit 2 Spuren. Zwei nebeneinander = 24 m, Spuren exakt wie Schnellstraße.
Schnellstraße 24 m: je Richtung Mittelleitwand | 2,1 Seitenstreifen innen | 2 × 3,5 Spuren | 1,5 Standstreifen | 1 m Bankett.
"""
import numpy as np
import trimesh
from shapely.geometry import Polygon, LineString, box as sbox
from shapely.ops import unary_union, substring
from lib import B, PALETTE
import roads
from roads import ext, lamp, tree, paint, streets, rua_markings, L, RUA, connector, tile_box, embankment, shear_z, Q
from roads2 import arc_pos, _wall_face, _top_ground, _shift, mauer

PALETTE.update({
    "guardrail": "#A7ADB2", "nj_barrier": "#C9C4B8", "sign_green": "#1E6B3C", "tunnel_tile": "#D8D2C2",
    "hazard_black": "#1E1E1E", "bridge_white": "#E2DED4", "water_line": "#4E6A6E",
})


# ------------------------------------------------------------------ path sweep toolkit
class Path:
    """Centre line of a road: P(s, d) -> (x, z). s = distance from the start, d = offset to the right."""

    def __init__(s, fn, length, res=None):
        s.fn, s.L, s.res = fn, length, res

    def xz(s, t, d=0.0):
        return np.asarray(s.fn(t, d), float)

    def samples(s, s0=0.0, s1=None):
        s1 = s.L if s1 is None else s1
        n = 2 if not s.res else max(2, int(np.ceil((s1 - s0) / s.res)) + 1)
        return np.linspace(s0, s1, n)

    def heading(s, t):
        """yaw (deg, 0 = +Z) of the driving direction at t"""
        v = s.xz(min(t + 0.05, s.L)) - s.xz(max(t - 0.05, 0))
        return np.degrees(np.arctan2(v[0], v[1]))


def straight(D):
    return Path(lambda t, d: (d, D / 2 - t), D)


def arcpath(R, deg, turn):
    return Path(lambda t, d: arc_pos(R, t / R, d, turn), R * np.radians(deg), R * np.radians(2.0))


def sweep(b, mat, P, sec, s0=0.0, s1=None, lift=None):
    """Sweep a convex cross-section [(d, y, lifted), ...] along P. lift(s) raises the 'lifted' points."""
    ss = P.samples(s0, s1)
    n = len(sec)
    V = []
    for t in ss:
        dy = lift(t) if lift else 0.0
        for d, y, up in sec:
            x, z = P.xz(t, d)
            V.append((x, y + (dy if up else 0.0), z))
    F = []
    for i in range(len(ss) - 1):
        for j in range(n):
            a, c = i * n + j, i * n + (j + 1) % n
            F += [(a, c, c + n), (a, c + n, a + n)]
    last = (len(ss) - 1) * n
    for j in range(1, n - 1):
        F += [(0, j + 1, j), (last, last + j, last + j + 1)]
    m = trimesh.Trimesh(np.array(V), np.array(F), process=True)
    m.update_faces(m.nondegenerate_faces())
    trimesh.repair.fix_normals(m)
    b.add(mat, m)


def band(b, mat, P, d0, d1, y0, y1, s0=0.0, s1=None, lift=None, lift_bottom=True):
    sweep(b, mat, P, [(d0, y0, lift_bottom), (d1, y0, lift_bottom), (d1, y1, True), (d0, y1, True)], s0, s1, lift)


def dash_ranges(Ls, dash, gap, phase=0.0):
    out, s = [], phase
    while s < Ls - 0.2:
        out.append((s, min(s + dash, Ls)))
        s += dash + gap
    return out


def line(b, mat, P, d, w=0.12, lift=None, dashed=None, s0=0.0, s1=None):
    s1 = P.L if s1 is None else s1
    rngs = [(s0, s1)] if not dashed else [(s0 + a, s0 + c) for a, c in dash_ranges(s1 - s0, *dashed)]
    for a, c in rngs:
        band(b, mat, P, d - w / 2, d + w / 2, 0.0, 0.012, a, c, lift)


def nj_barrier(b, P, c, lift=None, y=0.0, mat="nj_barrier", s0=0.0, s1=None):
    """New-Jersey concrete barrier centred at offset c, height 0.85."""
    sec = [(c - 0.3, y, True), (c + 0.3, y, True), (c + 0.3, y + 0.08, True), (c + 0.12, y + 0.3, True),
           (c + 0.1, y + 0.85, True), (c - 0.1, y + 0.85, True), (c - 0.12, y + 0.3, True), (c - 0.3, y + 0.08, True)]
    sweep(b, mat, P, sec, s0, s1, lift)


def guardrail(b, P, d, lift=None, y=0.0, s0=0.0, s1=None, every=2.0):
    s1 = P.L if s1 is None else s1
    for t in np.arange(s0 + 0.5, s1, every):
        x, z = P.xz(t, d)
        dy = lift(t) if lift else 0.0
        b.box("guardrail", (0.1, 0.75, 0.1), (x, y + dy + 0.375, z))
    band(b, "guardrail", P, d - 0.04, d + 0.04, y + 0.45, y + 0.78, s0, s1, lift)


def post_rail(b, P, d, y, lift=None, every=2.0, h=1.0):
    """Metal railing on top of a bridge barrier."""
    for t in np.arange(0.6, P.L, every):
        x, z = P.xz(t, d)
        dy = lift(t) if lift else 0.0
        b.box("metal", (0.06, h, 0.06), (x, y + dy + h / 2, z))
    band(b, "metal", P, d - 0.04, d + 0.04, y + h - 0.06, y + h, lift=lift)
    band(b, "metal", P, d - 0.03, d + 0.03, y + h * 0.55, y + h * 0.55 + 0.05, lift=lift)


def lamp_at(b, P, t, d, y, side, h=8.0, lift=None):
    """Street lamp on the path; arm points across the road (side = -1 → towards -d, +1 → +d)."""
    x, z = P.xz(t, d)
    n = P.xz(t, d + side) - P.xz(t, d)
    face = np.degrees(np.arctan2(n[0], n[1]))
    lamp(b, x, z, face, y=y + (lift(t) if lift else 0.0), h=h)


def median_lamp(b, P, t, y, h=10.0, lift=None):
    x, z = P.xz(t, 0)
    y = y + (lift(t) if lift else 0.0)
    b.cyl("frame_black", 0.12, h, (x, y + h / 2, z), 6)
    top = np.array([x, y + h, z])
    for side in (-1, 1):
        n = P.xz(t, side) - P.xz(t, 0)
        d3 = np.array([n[0], 0, n[1]])
        face = np.degrees(np.arctan2(n[0], n[1]))
        b.beam("frame_black", top, top + d3 * 2.4 + np.array([0, 0.35, 0]), 0.09)
        hp = top + d3 * 2.5 + np.array([0, 0.27, 0])
        b.box("frame_black", (0.6, 0.14, 0.3), tuple(hp), rot_y=face)
        b.box("lamp", (0.52, 0.04, 0.24), tuple(hp + np.array([0, -0.08, 0])), rot_y=face)


def merge(b, src, M=None, dy=0.0):
    for key, ms in src.parts.items():
        for m in ms:
            m2 = m.copy()
            if M is not None:
                m2.apply_transform(M)
            m2.apply_translation((0, dy, 0))
            b.add(key, m2)


# ================================================================== 1  TUNNEL-MITTELSTÜCK
def tunnel_mitte():
    """12 x 24 m straight tube, same cross-section as the portal (walls ±5.4..6.0, ceiling 6.4..6.8)."""
    b = B(1001)
    W, D = 12, 24
    ln = [L((0, -14), (0, 14))]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    for sx in (-1, 1):
        b.box("tunnel_dark", (0.6, 6.8, D), (sx * 5.7, 3.4, 0))                      # walls
        b.box("tunnel_tile", (0.04, 2.7, D), (sx * 5.38, 0.15 + 1.45, 0))             # light wall cladding
        b.box("paint_white", (0.05, 0.12, D), (sx * 5.37, 2.95, 0))
        b.box("hazard_black", (0.05, 0.25, D), (sx * 5.37, 0.28, 0))
        for z in np.arange(-11.0, 12, 4.0):                                           # cable tray
            b.box("metal", (0.12, 0.04, 0.4), (sx * 5.33, 5.2, z))
        b.box("metal", (0.06, 0.06, D), (sx * 5.3, 5.25, 0))
    b.box("tunnel_dark", (W, 0.4, D), (0, 6.6, 0))                                    # ceiling
    for z in np.arange(-10.0, 12, 4.0):                                               # 2 rows of ceiling lights
        for x in (-2.2, 2.2):
            b.box("lamp", (0.3, 0.06, 1.4), (x, 6.37, z))
    for x in (-3.2, 3.2):                                                             # jet fans
        b.box("metal", (0.08, 0.35, 0.08), (x, 6.2, 0))
        cyl = trimesh.creation.cylinder(radius=0.5, height=3.2, sections=10)
        b.add("concrete_dk", cyl.apply_translation((x, 5.6, 0)))
        for zz in (-1.62, 1.62):
            c2 = trimesh.creation.cylinder(radius=0.42, height=0.04, sections=10)
            b.add("tunnel_dark", c2.apply_translation((x, 5.6, zz)))
    # emergency niche (east wall) with SOS cabinet + exit sign
    b.box("tunnel_tile", (0.05, 2.4, 2.4), (5.35, 1.35, 6.0))
    b.box("plaster_blue" if "plaster_blue" in PALETTE else "metal", (0.12, 1.0, 0.7), (5.3, 1.3, 6.0))
    b.box("led_orange", (0.1, 0.2, 0.2), (5.3, 2.4, 6.0))
    b.box("led_green", (0.06, 0.35, 1.0), (5.33, 3.3, -6.0))
    b.box("paint_white", (0.07, 0.12, 0.3), (5.31, 3.3, -6.25))
    # outer shell so it can sit inside terrain without gaps
    b.box("rock", (W, 0.6, D), (0, 7.1, 0))
    b.anchor("Tunnel_Innen", (0, 0, 0), 0)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    return b


# ================================================================== 2  SERPENTINE
def rua_serpentine(turn):
    """90° Rua curve that climbs +3 m. turn=+1 left, -1 right. Pivot = lower start, heading -Z."""
    def f():
        b = B(1010 + turn)
        R, deg, rise = 16.0, 90, 3.0
        P = arcpath(R, deg, turn)
        lift = lambda t: rise * t / P.L
        band(b, "stone", P, -6.0, 6.0, -0.4, -0.1, lift=lift, lift_bottom=False)    # body / fill wall
        band(b, "road_asphalt", P, -3.5, 3.5, -0.1, 0.0, lift=lift)
        for s in (-1, 1):
            lo, hi = sorted((s * 3.5, s * 3.72))
            band(b, "curb", P, lo, hi, -0.1, 0.17, lift=lift)
            lo, hi = sorted((s * 3.72, s * 6.0))
            band(b, "sidewalk", P, lo, hi, -0.1, 0.15, lift=lift)
            line(b, "paint_white", P, s * 3.15, lift=lift)
        line(b, "paint_yellow", P, 0.0, 0.15, lift=lift, dashed=(3.0, 3.0))
        outer = -turn                                                                 # outside of the bend (right for a left turn)
        guardrail(b, P, outer * 5.75, lift=lift, y=0.15)
        # chevron boards on the outside, facing the driver
        for fr in (0.3, 0.55, 0.8):
            t = fr * P.L
            x, z = P.xz(t, outer * 5.3)
            y = 0.15 + lift(t)
            hd = np.radians(P.heading(t))
            ang = np.degrees(np.arctan2(-np.cos(hd), np.sin(hd)))                     # board x-axis = driving dir
            b.box("frame_black", (0.07, 1.4, 0.07), (x, y + 0.7, z))
            b.box("paint_yellow", (0.9, 0.6, 0.05), (x, y + 1.55, z), rot_y=ang)
            nv = P.xz(t, 0) - P.xz(t, outer)
            for k, rz in ((-0.14, 40 * turn), (0.14, -40 * turn)):
                c = np.array([x, y + 1.55 + k, z]) + np.array([nv[0], 0, nv[1]]) * 0.04
                b.box("hazard_black", (0.42, 0.11, 0.03), tuple(c), rot_z=rz, rot_y=ang)
        for fr in (0.25, 0.75):                                                       # lamps on the inside
            lamp_at(b, P, fr * P.L, turn * -5.4, 0.15, turn, h=6.5, lift=lift)
        b.anchor("Anschluss_Rua_S", (0, 0, 0), 0)
        e = P.xz(P.L)
        b.anchor("Anschluss_Rua_Ende", (e[0], rise, e[1]), 180 + turn * deg)
        return b
    return f


# ================================================================== 3  SANFTE STEIGUNG
def rua_steigung_sanft():
    b = B(1020)
    W, D = 12, 24
    ln = [L((0, -14), (0, 14))]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    lamp(b, -5.4, -8, 90)
    lamp(b, 5.4, 8, -90)
    tree(b, 4.8, -2.0, r=1.1)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    embankment(b, W, D, 1.5)
    shear_z(b, 1.5, D)
    return b


# ================================================================== 4-6  BRÜCKE
GIRDER = 2.6     # deck surface -> girder underside


def bridge_deck(b, P, lift=None, lamps=True):
    """12 m deck: NJ barriers + railing both sides, 2 lanes (7 m) + shoulders, box girder."""
    band(b, "road_asphalt", P, -6.0, 6.0, -0.1, 0.0, lift=lift)
    band(b, "bridge_white", P, -6.0, 6.0, -0.45, -0.1, lift=lift)                    # deck slab
    for s in (-1, 1):
        lo, hi = sorted((s * 5.9, s * 6.05))
        band(b, "bridge_white", P, lo, hi, -0.75, 0.0, lift=lift)                     # cornice / drip edge
    sweep(b, "concrete", P, [(-3.5, -0.45, True), (3.5, -0.45, True), (2.5, -GIRDER, True), (-2.5, -GIRDER, True)], lift=lift)
    for s in (-1, 1):
        nj_barrier(b, P, s * 5.7, lift=lift)
        post_rail(b, P, s * 5.85, 0.85, lift=lift, h=0.55)
        line(b, "paint_white", P, s * 3.4, 0.15, lift=lift)
    line(b, "paint_white", P, 0.0, 0.15, lift=lift, dashed=(4.0, 8.0, 2.0))
    band(b, "metal", P, -5.4, 5.4, 0.0, 0.01, 0.1, 0.35, lift=lift)                   # expansion joint (start only)
    if lamps:
        lamp_at(b, P, P.L * 0.25, -5.7, 0.85, +1, h=9, lift=lift)
        lamp_at(b, P, P.L * 0.75, 5.7, 0.85, -1, h=9, lift=lift)


def bruecke_segment(rise=0.0):
    def f():
        b = B(1030 + int(rise))
        D = 24
        bridge_deck(b, straight(D))
        for s, z in (("S", D / 2), ("N", -D / 2)):
            b.anchor(f"Anschluss_Bruecke_{s}", (0, 0, z), 0 if s == "S" else 180)
            b.anchor(f"Pfeiler_{s}", (0, -GIRDER, z), 0)
        if rise:
            shear_z(b, rise, D)
        return b
    return f


def bruecke_kopf():
    """48 m earth ramp with stone walls: ground (south, y 0) → deck height +5 m (north) + abutment."""
    b = B(1040)
    W, D, H = 12, 48, 5.0
    P = straight(D)
    band(b, "road_asphalt", P, -6.0, 6.0, -0.1, 0.0)
    for s in (-1, 1):
        nj_barrier(b, P, s * 5.7)
        line(b, "paint_white", P, s * 3.4, 0.15)
    line(b, "paint_white", P, 0.0, 0.15, dashed=(4.0, 8.0, 2.0))
    embankment(b, W, D, H, "stone")
    lamp(b, -5.7, 0.0, 90, y=0.85, h=9)
    shear_z(b, H, D)
    for z in np.arange(-20.0, 24, 4.0):
        top = (D / 2 - z) / D * H - 0.15
        if top > 0.3:
            for sx in (-1, 1):
                b.box("concrete_dk", (0.03, top, 0.05), (sx * 6.005, top / 2, z))
    # abutment (Widerlager) at the north end – girder of the next segment rests on the shelf
    seat = H - GIRDER                                                                 # girder underside of the next segment
    b.box("concrete", (W, seat - 0.1, 2.4), (0, (seat - 0.1) / 2, -D / 2 + 0.4))      # seat reaches 0.8 m under the next girder
    b.box("concrete", (W, GIRDER - 0.1, 0.5), (0, seat + (GIRDER - 0.1) / 2, -D / 2 + 0.25))
    for sx in (-1, 1):
        b.box("metal", (0.8, 0.1, 0.6), (sx * 1.6, seat - 0.05, -D / 2 - 0.4))
    b.anchor("Anschluss_Bruecke_S", (0, 0, D / 2), 0)
    b.anchor("Anschluss_Bruecke_N", (0, H, -D / 2), 180)
    return b


def _oct(w, d, c):
    return [(sx * (w / 2 - c * (k == 1)), sz * (d / 2 - c * (k == 0))) for sx, sz in ((1, 1), (-1, 1), (-1, -1), (1, -1)) for k in (0, 1)]


def pfeiler_fundament():
    b = B(1050)
    b.box("concrete_dk", (8.0, 0.4, 5.0), (0, 0.2, 0))
    b.hull("concrete", [(x, 0.4, z) for x, z in _oct(7.2, 4.2, 0.6)] + [(x, 1.0, z) for x, z in _oct(6.0, 3.6, 0.6)])
    b.box("water_line", (8.02, 0.12, 5.02), (0, 0.32, 0))
    b.anchor("Unten", (0, 0, 0), 0)
    b.anchor("Oben", (0, 1.0, 0), 0)
    return b


def pfeiler_schaft(h):
    def f():
        b = B(1060 + h)
        b.hull("bridge_white", [(x, 0, z) for x, z in _oct(4.0, 2.2, 0.4)] + [(x, h - 0.06, z) for x, z in _oct(4.0, 2.2, 0.4)])
        b.hull("concrete", [(x, h - 0.06, z) for x, z in _oct(4.0, 2.2, 0.4)] + [(x, h, z) for x, z in _oct(4.0, 2.2, 0.4)])
        b.anchor("Unten", (0, 0, 0), 0)
        b.anchor("Oben", (0, h, 0), 0)
        return b
    return f


def pfeiler_kopf():
    b = B(1070)
    b.hull("bridge_white", [(x, 0, z) for x, z in _oct(4.0, 2.2, 0.4)] + [(x, 1.25, z) for x, z in _oct(6.6, 2.9, 0.3)])
    for sx in (-1, 1):
        b.box("metal", (0.8, 0.15, 0.8), (sx * 1.6, 1.325, 0))
    b.anchor("Unten", (0, 0, 0), 0)
    b.anchor("Traeger_Unterkante", (0, 1.4, 0), 0)
    return b


# ================================================================== 7-10  SCHNELLSTRASSE
def expressway(b, P, lift=None, ground=True, lamps_every=24.0):
    """24 m: asphalt ±11 (ground) / ±11.4 (viaduct), median NJ, markings, guard rails or edge barriers."""
    half = 11.0 if ground else 11.4
    band(b, "road_asphalt", P, -half, half, -0.1, 0.0, lift=lift)
    if ground:
        for s in (-1, 1):
            lo, hi = sorted((s * 11.0, s * 12.0))
            band(b, "grass", P, lo, hi, -0.1, 0.03, lift=lift)
            guardrail(b, P, s * 11.3, lift=lift)
    else:
        for s in (-1, 1):
            nj_barrier(b, P, s * 11.7, lift=lift)
            post_rail(b, P, s * 11.85, 0.85, lift=lift, h=0.55)
    nj_barrier(b, P, 0.0, lift=lift)
    for s in (-1, 1):
        line(b, "paint_yellow", P, s * 2.6, 0.15, lift=lift)       # Brazil: left edge line yellow
        line(b, "paint_white", P, s * 9.4, 0.15, lift=lift)
        line(b, "paint_white", P, s * 6.0, 0.15, lift=lift, dashed=(4.0, 8.0, 2.0))
    n = max(1, int(round(P.L / lamps_every)))
    for k in range(n):
        median_lamp(b, P, (k + 0.5) * P.L / n, 0.85, lift=lift)


def schnell_gerade():
    b = B(1100)
    D = 24
    expressway(b, straight(D))
    for s in "NS":
        connector(b, "Schnellstrasse", s, 24, D)
    return b


def schnell_bogen(deg):
    def f():
        b = B(1110 + deg)
        R, turn = 100.0, +1
        P = arcpath(R, deg, turn)
        expressway(b, P, lamps_every=26.0)
        b.anchor("Anschluss_Schnellstrasse_S", (0, 0, 0), 0)
        e = P.xz(P.L)
        b.anchor("Anschluss_Schnellstrasse_Ende", (e[0], 0, e[1]), 180 + turn * deg)
        return b
    return f


def schnell_rampe(exit_=True):
    """36 x 48 tile. Expressway axis x = -6 (N-S). Abfahrt: slip lane leaves the northbound (east) carriageway
    to the right and ends as a Rua connector at the north edge (x = +12). Auffahrt: the same mirrored in Z –
    Rua connector on the south edge, the ramp merges into the northbound carriageway."""
    def f():
        b = B(1130 + exit_)
        W, D, XE = 36, 48, -6.0
        sz = 1.0 if exit_ else -1.0
        T = tile_box(W, D)
        Z = lambda z: sz * z
        P = Path(lambda t, d: (XE + d, Z(D / 2 - t)), D)
        # --- ramp centre line (in exit coordinates: traffic heading -Z)
        zz = np.linspace(10, -10, 21)
        curve = [(7.0 + 5.0 * (1 - np.cos(np.pi * (10 - z) / 20)) / 2, z) for z in zz]
        C = LineString([(7.0, 24.5)] + curve + [(12.0, -24.5)])
        C = LineString([(x, Z(z)) for x, z in C.coords])
        express = sbox(XE - 11, -24, XE + 11, 24)
        rua_end = sbox(6, -24, 18, -16) if exit_ else sbox(6, 16, 18, 24)
        ramp = C.buffer(3.5, cap_style=2).intersection(T)
        asphalt = unary_union([express, ramp]).intersection(T)
        ext(b, "road_asphalt", asphalt, -0.1, 0.0)
        walk = rua_end.difference(ramp.buffer(0.0)).difference(sbox(8.5, -24, 15.5, 24))
        curb = sbox(8.28, -24, 8.5, 24).union(sbox(15.5, -24, 15.72, 24)).intersection(rua_end)
        ext(b, "sidewalk", walk.difference(curb), -0.1, 0.15)
        ext(b, "curb", curb, -0.1, 0.17)
        grass = T.difference(asphalt).difference(rua_end)
        ext(b, "grass", grass, -0.1, 0.03)
        # --- expressway furniture
        nj_barrier(b, P, 0.0)
        for s in (-1, 1):
            line(b, "paint_yellow", P, s * 2.6, 0.15)
            line(b, "paint_white", P, s * 6.0, 0.15, dashed=(4.0, 8.0, 2.0))
        line(b, "paint_white", P, -9.4, 0.15)
        # right edge (northbound): broken where the slip lane runs alongside, solid after the nose
        line(b, "paint_white", P, 9.4, 0.25, dashed=(1.0, 1.0), s0=0.0, s1=14.0)       # slip lane alongside (z 24..10)
        line(b, "paint_white", P, 9.4, 0.15, s0=14.0)
        guardrail(b, P, -11.3)
        guardrail(b, P, 11.3, s0=25.0)                                                # after the gore nose (z < -1)
        for t in (12.0, 36.0):
            median_lamp(b, P, t, 0.85)
        # --- ramp edge lines + guard rails (along the shapely centre line)
        def offs(dist, z_from, z_to):
            g = C.offset_curve(dist).intersection(sbox(-18, min(Z(z_from), Z(z_to)), 18, max(Z(z_from), Z(z_to))))
            return [p for p in getattr(g, "geoms", [g]) if p.geom_type == "LineString" and p.length > 0.5]
        side = 1 if exit_ else -1          # offset_curve sign flips with the line direction
        paint(b, offs(side * 3.25, 24, -16), "paint_white", 0.15, T)
        paint(b, offs(-side * 3.25, 4, -16), "paint_white", 0.15, T)
        cx = lambda z: 7.0 + 5.0 * (1 - np.cos(np.pi * np.clip(10 - z, 0, 20) / 20)) / 2
        zs = np.linspace(9.0, 2.6, 9)
        gore = Polygon([(3.5, Z(z)) for z in zs] + [(cx(z) - 3.3, Z(z)) for z in zs[::-1]]).buffer(0)
        hatch = [LineString([(3.0, Z(z0)), (6.5, Z(z0 - 2.0))]) for z0 in np.arange(10.0, 3.0, 1.4)]
        paint(b, hatch, "paint_white", 0.22, gore)
        for ls in offs(side * 3.8, 24, -16) + offs(-side * 3.8, -1, -16):
            pts = [ls.interpolate(u) for u in np.arange(0.3, ls.length, 2.0)]
            for p in pts:
                b.box("guardrail", (0.1, 0.75, 0.1), (p.x, 0.375, p.y))
            for a, c in zip(np.arange(0, ls.length, 2.0)[:-1], np.arange(0, ls.length, 2.0)[1:]):
                pa, pc = ls.interpolate(a), ls.interpolate(c)
                for yy in (0.52, 0.7):
                    b.beam("guardrail", (pa.x, yy, pa.y), (pc.x, yy, pc.y), 0.09)
        lamp(b, 16.5, Z(-4.0), -90, h=8)
        # --- overhead exit sign (Abfahrt only) / merge sign (Auffahrt)
        if exit_:
            zg = 20.0
            for x in (-17.4, 11.8):
                b.box("frame_black", (0.35, 8.8, 0.35), (x, 4.4, zg))
            for y in (7.0, 8.6):
                b.box("frame_black", (29.2, 0.3, 0.3), (-2.8, y, zg))
            b.box("sign_green", (6.6, 2.4, 0.12), (0.0, 7.8, zg + 0.25))               # through lanes
            b.text("Niterói", "paint_white", (0.0, 8.2, zg + 0.31), 0.65, 0.04)
            b.text("Ponte", "paint_white", (0.0, 7.3, zg + 0.31), 0.5, 0.04)
            b.box("sign_green", (6.4, 2.4, 0.12), (7.0, 7.8, zg + 0.25))               # exit lane
            b.box("paint_white", (6.1, 0.05, 0.13), (7.0, 6.75, zg + 0.26))
            b.text("SAÍDA 3", "paint_white", (7.0, 8.3, zg + 0.31), 0.6, 0.04)
            b.text("Centro", "paint_white", (7.0, 7.4, zg + 0.31), 0.55, 0.04)
        else:
            x, z = 16.0, Z(10.0)
            b.box("frame_black", (0.08, 2.4, 0.08), (x, 1.2, z))
            b.box("plaster_blue" if "plaster_blue" in PALETTE else "sign_green", (0.9, 0.9, 0.05), (x, 2.5, z), rot_y=180)
        # --- anchors
        b.anchor("Anschluss_Schnellstrasse_S", (XE, 0, D / 2), 0)
        b.anchor("Anschluss_Schnellstrasse_N", (XE, 0, -D / 2), 180)
        if exit_:
            b.anchor("Anschluss_Rua_N", (12.0, 0, -D / 2), 180)
        else:
            b.anchor("Anschluss_Rua_S", (12.0, 0, D / 2), 0)
        return b
    return f


def schnell_viadukt():
    """24 x 24 expressway at +9 m (= 5 + 2·2, same height grid as the bridge), hammerhead pier mid-tile."""
    b = B(1150)
    D, H = 24, 9.0
    P = straight(D)
    sub = B(0)
    expressway(sub, P, ground=False)
    band(sub, "bridge_white", P, -12.0, 12.0, -0.45, -0.1)
    for s in (-1, 1):
        lo, hi = sorted((s * 11.9, s * 12.05))
        band(sub, "bridge_white", P, lo, hi, -0.75, 0.0)
        sweep(sub, "concrete", P, [(s * 6 - 3.5, -0.45, True), (s * 6 + 3.5, -0.45, True), (s * 6 + 2.5, -GIRDER, True), (s * 6 - 2.5, -GIRDER, True)])
    merge(b, sub, dy=H)
    cap_top = H - GIRDER
    ct = cap_top - 0.12
    b.hull("bridge_white", [(x, ct, z) for x in (-10, 10) for z in (-1.4, 1.4)] + [(x, ct - 1.7, z) for x in (-3.0, 3.0) for z in (-1.4, 1.4)]
           + [(x, ct - 0.6, z) for x in (-10, 10) for z in (-1.4, 1.4)])
    b.hull("bridge_white", [(x, 0.6, z) for x, z in _oct(2.8, 2.4, 0.4)] + [(x, cap_top - 1.6, z) for x, z in _oct(2.8, 2.4, 0.4)])
    b.box("concrete_dk", (4.0, 0.6, 3.6), (0, 0.3, 0))
    for sx in (-6.0, 6.0):
        for dx in (-1.6, 1.6):
            b.box("metal", (0.7, 0.12, 0.7), (sx + dx, cap_top + 0.06, 0))
    for s in "NS":
        connector(b, "Schnellstrasse", s, 24, D, y=H)
    b.anchor("Unterfahrt_West", (-7.0, 0, 0), 90)
    b.anchor("Unterfahrt_Ost", (7.0, 0, 0), -90)
    return b


# ================================================================== 11-12  STÜTZMAUER 2 m + MAUERABSCHLUSS
def mauerabschluss(H, rechts=True):
    """12 x 4 m wall end: full height H on one side, runs out to 0 where the hill meets the road.
    rechts: full height at -X (connects to a straight wall on the left), 0 at +X. links = mirrored."""
    def f():
        b = B(1200 + int(H) * 2 + rechts)
        x0, x1 = -6.0, 6.0
        h = lambda x: H * (x1 - x) / (x1 - x0)
        b.hull("concrete", [(x, 0, z) for x in (x0, x1) for z in (0.0, -0.8)] + [(x0, H, -0.25), (x0, H, -0.8), (x1, 0.05, -0.05), (x1, 0.05, -0.8)])
        for x in np.arange(x0 + 3.0, x1 - 2.0, 3.0):                                  # joints
            hx = h(x)
            if hx > 0.4:
                b.beam("concrete_dk", (x, 0.0, 0.01), (x, hx, -0.25 * hx / H + 0.0), 0.05)
        for x in np.arange(x0 + 1.5, x1, 3.0):                                        # weep holes + moss
            hx = h(x)
            if hx > 1.0:
                y = hx * 0.45
                b.box("tunnel_dark", (0.12, 0.12, 0.04), (x, y, -0.25 * y / H + 0.01))
                b.box("hedge", (0.18, y * 0.3, 0.02), (x, y - y * 0.15 - 0.1, -0.25 * (y - y * 0.15) / H + 0.02))
        # earth wedge + grass skin behind
        b.hull("rock", [(x, 0, z) for x in (x0, x1) for z in (-0.6, -4.0)] + [(x0, H - 0.3, -0.6), (x0, H - 0.3, -4.0)])
        b.hull("grass", [(x0, H, z) for z in (-0.6, -4.0)] + [(x0, H - 0.3, z) for z in (-0.6, -4.0)]
               + [(x1, 0.03, z) for z in (-0.6, -4.0)] + [(x1, 0.0, z) for z in (-0.6, -4.0)])
        b.hull("concrete", [(x0, H, -0.25), (x0, H, -0.65), (x0, H + 0.2, -0.25), (x0, H + 0.2, -0.65),
                            (x1, 0.02, -0.25), (x1, 0.02, -0.65), (x1, 0.18, -0.25), (x1, 0.18, -0.65)])
        xe = x0 + (H - 0.6) / H * (x1 - x0)
        for x in np.arange(x0 + 0.2, xe, 1.5):
            b.beam("metal", (x, h(x) + 0.2, -0.45), (x, h(x) + 1.1, -0.45), 0.05)
        b.beam("metal", (x0, H + 1.1, -0.45), (xe, h(xe) + 1.1, -0.45), 0.05)
        b.beam("metal", (x0, H + 0.65, -0.45), (xe, h(xe) + 0.65, -0.45), 0.04)
        r = b.rng
        for k in range(4):
            x = r.uniform(x0 + 1, x1 - 1)
            b.rock("hedge" if k % 2 else "plant", r.uniform(0.4, 0.7), (x, h(x) + 0.15, r.uniform(-3.4, -1.2)), 0.7)
        b.anchor("Anschluss_Mauer", (x0, 0, 0), -90)
        b.anchor("Oben", (x0 + 1.0, h(x0 + 1.0), -2.0), 180)
        _shift(b, 2.0)
        if not rechts:
            M = np.diag([-1.0, 1, 1, 1])
            for ms in b.parts.values():
                for m in ms:
                    m.apply_transform(M)
            b.anchors = {k: (p * np.array([-1, 1, 1]), -yaw) for k, (p, yaw) in b.anchors.items()}
        return b
    return f


ROADS3 = [
    ("34_tunnel_mitte", "Tunnel – Mittelstück", "Spezial", tunnel_mitte, (12, 24)),
    ("35_rua_serpentine_links", "Rua – Serpentine 90° links +3 m", "Rua", rua_serpentine(+1), None),
    ("36_rua_serpentine_rechts", "Rua – Serpentine 90° rechts +3 m", "Rua", rua_serpentine(-1), None),
    ("37_rua_steigung_sanft", "Rua – Steigung sanft +1,5 m", "Rua", rua_steigung_sanft, (12, 24)),
    ("38_bruecke_segment", "Brücke – Segment gerade", "Brücke", bruecke_segment(0.0), (12, 24)),
    ("39_bruecke_steigung", "Brücke – Segment +2 m", "Brücke", bruecke_segment(2.0), (12, 24)),
    ("40_brueckenkopf", "Brückenkopf – Rampe +5 m", "Brücke", bruecke_kopf, (12, 48)),
    ("41_pfeiler_fundament", "Pfeiler – Fundament 1 m", "Brücke", pfeiler_fundament, (8, 6)),
    ("42_pfeiler_schaft_2m", "Pfeiler – Schaft 2 m", "Brücke", pfeiler_schaft(2), (4, 4)),
    ("43_pfeiler_schaft_8m", "Pfeiler – Schaft 8 m", "Brücke", pfeiler_schaft(8), (4, 4)),
    ("44_pfeiler_kopf", "Pfeiler – Kopf 1,4 m", "Brücke", pfeiler_kopf, (8, 4)),
    ("45_schnellstrasse_gerade", "Schnellstraße – Gerade", "Schnellstraße", schnell_gerade, (24, 24)),
    ("46_schnellstrasse_bogen_15", "Schnellstraße – Bogen 15°", "Schnellstraße", schnell_bogen(15), None),
    ("47_schnellstrasse_bogen_30", "Schnellstraße – Bogen 30°", "Schnellstraße", schnell_bogen(30), None),
    ("48_schnellstrasse_abfahrt", "Schnellstraße – Abfahrt → Rua", "Schnellstraße", schnell_rampe(True), (36, 48)),
    ("49_schnellstrasse_auffahrt", "Schnellstraße – Auffahrt ← Rua", "Schnellstraße", schnell_rampe(False), (36, 48)),
    ("50_schnellstrasse_viadukt", "Schnellstraße – Viadukt +9 m", "Schnellstraße", schnell_viadukt, (24, 24)),
    ("51_stuetzmauer_2m", "Stützmauer 2 m", "Gelände", mauer(2), (12, 4)),
    ("52_mauerabschluss_4m_rechts", "Mauerabschluss 4 m rechts", "Gelände", mauerabschluss(4.0, True), (12, 4)),
    ("53_mauerabschluss_4m_links", "Mauerabschluss 4 m links", "Gelände", mauerabschluss(4.0, False), (12, 4)),
    ("54_mauerabschluss_2m_rechts", "Mauerabschluss 2 m rechts", "Gelände", mauerabschluss(2.0, True), (12, 4)),
    ("55_mauerabschluss_2m_links", "Mauerabschluss 2 m links", "Gelände", mauerabschluss(2.0, False), (12, 4)),
]
