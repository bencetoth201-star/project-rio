"""Tankstelle 257 – Supermarkt mit begehbarem Innenraum + Tankdach (nach Skizze/Plan).
Front (Eingang, Schild) zeigt nach +Z. Dach-Materialien beginnen mit "dach" (im Spiel ausblendbar)."""
import numpy as np
import trimesh
from lib import B

GREEN, BROWN = "brand_green", "brand_brown"


def tankstelle():
    b = B(257)
    BX0, BX1, BZ0, BZ1, H, T = -14.0, 2.0, -7.0, 3.0, 4.2, 0.25
    FL = 0.14                                       # shop floor height (= sidewalk)

    def wall(x0, x1, z0, z1, y0, y1, mat="concrete_white"):
        b.box(mat, (x1 - x0, y1 - y0, z1 - z0), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2))

    # ---------------- lot ----------------
    LX0, LX1, LZ0, LZ1 = -15.0, 15.0, -11.0, 11.0
    b.box("asphalt", (LX1 - LX0, 0.05, LZ1 - LZ0), (0, 0.025, 0))
    b.box("concrete_light", (11.0, 0.03, 12.0), (8.75, 0.065, 0.5))                  # under the canopy
    for (x0, x1, z0, z1) in [(LX0, LX1, LZ0, LZ0 + 0.4), (LX0, LX0 + 0.4, LZ0, LZ1), (LX1 - 0.4, LX1, LZ0, LZ1),
                             (LX0, -1.0, LZ1 - 0.4, LZ1), (5.0, 8.0, LZ1 - 0.4, LZ1), (14.0, LX1, LZ1 - 0.4, LZ1)]:
        wall(x0, x1, z0, z1, 0, 0.14, "concrete_light")
    wall(BX0 - 0.5, BX1 + 0.5, BZ1, BZ1 + 1.6, 0, FL, "concrete_light")             # sidewalk in front of the shop
    for x in np.arange(-13.5, -2.0, 2.6):                                            # parking lines
        b.box("paint_white", (0.12, 0.01, 4.5), (x, 0.055, 7.2))
    for x in (-1.0, 5.0):                                                            # arrows-ish lane marks
        b.box("paint_white", (0.12, 0.01, 3.0), (x + 3.0, 0.055, 8.8))

    # ---------------- shop shell ----------------
    b.box("tile_floor", (BX1 - BX0 - 2 * T, FL, BZ1 - BZ0 - 2 * T), ((BX0 + BX1) / 2, FL / 2, (BZ0 + BZ1) / 2))
    fz0, fz1 = BZ1 - T, BZ1
    W1, W2 = (-13.2, -8.6), (-4.4, -0.9)
    WY0, WY1 = 0.35, 3.3
    wall(BX0, W1[0], fz0, fz1, 0, H)
    wall(W1[1], -8.0, fz0, fz1, 0, H)
    wall(-5.0, W2[0], fz0, fz1, 0, H)
    wall(W2[1], BX1, fz0, fz1, 0, H)
    for (x0, x1) in (W1, W2):
        wall(x0, x1, fz0, fz1, 0, WY0)
        wall(x0, x1, fz0, fz1, WY1, H)
        b.box("glass_shop", (x1 - x0, WY1 - WY0, 0.04), ((x0 + x1) / 2, (WY0 + WY1) / 2, BZ1 - 0.12))
        for (fx, fy, sx, sy) in [((x0 + x1) / 2, WY0 + 0.04, x1 - x0, 0.08), ((x0 + x1) / 2, WY1 - 0.04, x1 - x0, 0.08),
                                 (x0 + 0.04, (WY0 + WY1) / 2, 0.08, WY1 - WY0), (x1 - 0.04, (WY0 + WY1) / 2, 0.08, WY1 - WY0)]:
            b.box("frame_black", (sx, sy, 0.1), (fx, fy, BZ1 - 0.12))
    # promo poster "-20%" in the left window
    b.box("promo_red", (2.4, 1.1, 0.03), (-11.6, 1.95, BZ1 - 0.07))
    b.text("-20%", "sign_white", (-11.6, 1.95, BZ1 - 0.055), 0.62, 0.025)
    # recessed entrance
    wall(-8.0, -5.0, fz0, fz1, WY1, H)
    RZ = 2.2
    wall(-8.0, -7.85, RZ, BZ1, 0, WY1, "concrete")
    wall(-5.15, -5.0, RZ, BZ1, 0, WY1, "concrete")
    wall(-7.85, -7.3, RZ - 0.2, RZ, 0, WY1, "concrete")
    wall(-5.7, -5.15, RZ - 0.2, RZ, 0, WY1, "concrete")
    wall(-7.3, -5.7, RZ - 0.2, RZ, 2.75, WY1, "concrete")
    wall(-8.0, -5.0, RZ, BZ1, WY1 - 0.05, WY1, "concrete")                          # soffit
    b.box("tile_floor", (3.0, FL, BZ1 - RZ + 0.2), (-6.5, FL / 2, (RZ + BZ1) / 2 - 0.1))
    for sx in (-1, 1):                                                               # double glass door
        cx = -6.5 + sx * 0.4
        b.box("glass_shop", (0.78, 2.55, 0.03), (cx, FL + 1.3, RZ - 0.1))
        for (fx, fy, sxz, sy) in [(cx, FL + 0.05, 0.8, 0.1), (cx, FL + 2.58, 0.8, 0.08),
                                  (cx - 0.37, FL + 1.3, 0.06, 2.6), (cx + 0.37, FL + 1.3, 0.06, 2.6)]:
            b.box("frame_black", (sxz, sy, 0.08), (fx, fy, RZ - 0.1))
        b.box("metal", (0.04, 0.5, 0.06), (cx - sx * 0.25, FL + 1.1, RZ - 0.02))
    b.box("concrete_light", (3.4, 0.08, 1.0), (-6.5, FL + 0.04, BZ1 + 0.5))          # entry step
    # side + back walls with the storage bump and back door
    wall(BX0, BX0 + T, BZ0, BZ1, 0, H)
    wall(BX1 - T, BX1, BZ0, BZ1, 0, H)
    wall(BX0, -8.0, BZ0, BZ0 + T, 0, H)
    wall(-5.0, BX1, BZ0, BZ0 + T, 0, H)
    KZ = BZ0 - 1.1                                                                   # bump back face
    wall(-8.0, -7.75, KZ, BZ0 + T, 0, H)
    wall(-5.25, -5.0, KZ, BZ0 + T, 0, H)
    wall(-7.75, -7.0, KZ, KZ + T, 0, H)
    wall(-6.0, -5.25, KZ, KZ + T, 0, H)
    wall(-7.0, -6.0, KZ, KZ + T, 2.3, H)
    b.box("tile_floor", (2.5, FL, 1.1), (-6.5, FL / 2, BZ0 - 0.55 + T / 2))
    b.box("door_metal", (0.98, 2.15, 0.06), (-6.5, 1.08 + FL / 2, KZ + 0.12))
    b.box("metal", (0.05, 0.4, 0.06), (-6.15, 1.1, KZ + 0.2))
    b.box("metal", (0.05, 0.4, 0.06), (-6.15, 1.1, KZ + 0.04))
    b.anchor("Hintertuer", (-6.5, 0, KZ - 0.6), 180)

    # green band + white trims (outside only, per side)
    for (cx, cz, sx, sz) in [((BX0 + BX1) / 2, BZ1 + 0.06, BX1 - BX0 + 0.24, 0.12),
                             ((BX0 - 0.12 - 8.0) / 2, BZ0 - 0.06, -8.0 - BX0 + 0.12, 0.12),
                             ((-5.0 + BX1 + 0.12) / 2, BZ0 - 0.06, BX1 + 0.12 + 5.0, 0.12),
                             (-6.5, KZ - 0.06, 3.0, 0.12),
                             (BX0 - 0.06, (BZ0 + BZ1) / 2, 0.12, BZ1 - BZ0), (BX1 + 0.06, (BZ0 + BZ1) / 2, 0.12, BZ1 - BZ0)]:
        b.box("paint_white", (sx + 0.02, 0.14, sz + 0.02), (cx, H - 1.05, cz))
        b.box(GREEN, (sx, 0.72, sz), (cx, H - 0.62, cz))
        b.box("paint_white", (sx + 0.02, 0.24, sz + 0.02), (cx, H - 0.14, cz))
    # roof (hideable) + roof technology
    b.box("dach", (BX1 - BX0 - 0.1, 0.2, BZ1 - BZ0 - 0.1), ((BX0 + BX1) / 2, H - 0.1, (BZ0 + BZ1) / 2))
    b.box("dach", (3.0, 0.2, 1.2), (-6.5, H - 0.1, BZ0 - 0.5))
    b.box("dach_technik", (2.2, 0.9, 1.4), (-1.5, H + 0.45, -4.5))
    b.box("dach_technik", (1.2, 0.5, 1.0), (-10.0, H + 0.25, -3.0))
    for k in range(4):
        b.box("frame_black", (2.0, 0.04, 0.04), (-1.5, H + 0.3 + k * 0.15, -3.78))
    # big "257" sign box on the roof front
    SW, SH, SD = 4.6, 1.8, 0.5
    scx, scz = -6.5, BZ1 - SD / 2 + 0.05
    b.box("sign_light", (SW, SH, SD), (scx, H + SH / 2, scz))
    b.box("dach_technik", (SW + 0.1, 0.08, SD + 0.1), (scx, H + SH + 0.04, scz))
    b.text("257", [GREEN, GREEN, BROWN], (scx, H + SH / 2, scz + SD / 2), 1.15, 0.08)

    # ---------------- interior ----------------
    IX0, IX1, IZ0, IZ1 = BX0 + T, BX1 - T, BZ0 + T, BZ1 - T
    PX = -0.8                                                                        # partition to lager/safe strip
    PT = 0.15
    pz = [(IZ0, -4.6), (-3.6, 0.6), (1.6, IZ1)]
    for z0, z1 in pz:
        wall(PX - PT / 2, PX + PT / 2, z0, z1, 0, H - 0.2, "paint_white")
    for z0, z1 in ((-4.6, -3.6), (0.6, 1.6)):
        wall(PX - PT / 2, PX + PT / 2, z0, z1, 2.3, H - 0.2, "paint_white")
    wall(PX + PT / 2, IX1, -1.1, -0.95, 0, H - 0.2, "paint_white")                   # lager | safe room
    # safe-room door with keypad (code needed)
    b.box("safe", (0.08, 2.15, 0.98), (PX, FL + 1.08, 1.1))
    b.box("metal", (0.06, 0.06, 0.3), (PX - 0.07, 1.2, 0.8))
    b.box("keypad", (0.04, 0.32, 0.22), (PX - PT / 2 - 0.02, 1.35, 0.35))
    b.box("led_green", (0.02, 0.05, 0.05), (PX - PT / 2 - 0.045, 1.46, 0.35))
    b.anchor("Safe_Tuer", (PX - 0.6, FL, 1.1), -90)
    # lager door (normal)
    b.box("door_wood", (0.06, 2.15, 0.98), (PX, FL + 1.08, -4.1))
    b.box("metal", (0.1, 0.06, 0.06), (PX - 0.06, 1.2, -4.45))
    b.anchor("Lager_Tuer", (PX - 0.6, FL, -4.1), -90)
    # safe room: safe, desk, CCTV monitor
    sx, sz = IX1 - 0.5, 0.2
    b.box("safe", (0.85, 1.3, 0.85), (sx, FL + 0.65, sz))
    dial = trimesh.creation.cylinder(radius=0.11, height=0.06, sections=10)
    dial.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    dial.apply_translation((sx - 0.45, FL + 0.85, sz + 0.1))
    b.add("metal", dial)
    for dy in (-0.05, 0.05):
        b.box("metal", (0.06, 0.04, 0.25), (sx - 0.45, FL + 0.5 + dy, sz - 0.2))
    b.box("tile_blue", (0.9, 0.1, 0.9), (sx, FL + 0.05, sz))
    b.anchor("Safe", (sx - 0.9, FL, sz), -90)
    b.box("wood_dark", (1.2, 0.05, 0.6), (IX1 - 0.4, FL + 0.75, 2.2))
    for dx in (-0.55, 0.55):
        b.box("metal", (0.05, 0.75, 0.55), (IX1 - 0.4 + dx * 0.95, FL + 0.37, 2.2))
    b.box("keypad", (0.5, 0.35, 0.05), (IX1 - 0.4, FL + 1.0, 2.4))
    b.box("led_green", (0.44, 0.29, 0.01), (IX1 - 0.4, FL + 1.0, 2.37))
    # lager: shelves with cardboard boxes
    for zc in (-6.2, -2.0):
        b.box("shelf", (2.2, 2.2, 0.5), (0.45, FL + 1.1, zc))
        for lv in range(3):
            for k in range(3):
                b.box("cardboard", (0.55, 0.45, 0.4), (-0.25 + k * 0.7, FL + 0.3 + lv * 0.72, zc + (0.3 if zc < -4 else -0.3)))
    for k in range(3):
        b.box("cardboard", (0.6, 0.5, 0.6), (0.6 + 0.05 * k, FL + 0.25 + 0.5 * k, -4.3))
    # kasse (counter) left of the entrance with code panel
    kx = -9.2
    b.box("counter", (0.8, 1.0, 2.4), (kx, FL + 0.5, 0.75))
    b.box("wood_dark", (0.9, 0.05, 2.5), (kx, FL + 1.02, 0.75))
    b.box("keypad", (0.35, 0.3, 0.05), (kx, FL + 1.25, 1.2), rot_y=0)
    b.box("keypad", (0.4, 0.1, 0.3), (kx, FL + 1.1, 1.2))
    b.box("keypad", (0.22, 0.04, 0.16), (kx, FL + 1.065, 0.4))
    b.box("led_green", (0.18, 0.01, 0.12), (kx, FL + 1.09, 0.4))
    b.anchor("Kasse", (kx + 0.8, FL, 0.75), 90)
    b.box("shelf", (0.4, 2.0, 2.4), (-11.0, FL + 1.0, 0.75))                         # cigarettes etc behind counter
    goods = ["cloth_red", "cloth_yellow", "cloth_green", "cloth_white", "tank", "gas", "sign_red", "plastic_white"]
    for lv in range(4):
        for k in range(4):
            b.box(goods[(lv * 3 + k) % 8], (0.3, 0.3, 0.5), (-10.75, FL + 0.35 + lv * 0.45, -0.15 + k * 0.6))
    # gondolas (double sided)
    for i, gx in enumerate((-6.6, -4.4, -2.2)):
        z0, z1 = -5.2, -0.2
        b.box("shelf", (0.5, 1.6, z1 - z0), (gx, FL + 0.8, (z0 + z1) / 2))
        for lv in range(3):
            y = FL + 0.35 + lv * 0.48
            b.box("shelf", (1.0, 0.04, z1 - z0), (gx, y - 0.14, (z0 + z1) / 2))
            for k in range(5):
                for sxs in (-1, 1):
                    b.box(goods[(i * 5 + lv * 2 + k + (sxs > 0)) % 8], (0.22, 0.24, 0.9),
                          (gx + sxs * 0.37, y, z0 + 0.5 + k * 1.0))
    # fridges along the back wall
    b.box("fridge", (5.0, 2.2, 0.8), (-11.0, FL + 1.1, IZ0 + 0.4))
    for k in range(5):
        b.box("glass_big", (0.9, 1.8, 0.02), (-13.0 + k * 1.0, FL + 1.15, IZ0 + 0.81))
        for lv in range(4):
            b.box(goods[(k + lv) % 8], (0.8, 0.25, 0.02), (-13.0 + k * 1.0, FL + 0.45 + lv * 0.42, IZ0 + 0.83))
    # wall shelf on the left wall
    b.box("shelf", (0.5, 2.0, 4.5), (IX0 + 0.25, FL + 1.0, -3.3))
    for lv in range(4):
        for k in range(4):
            b.box(goods[(lv + k * 2) % 8], (0.3, 0.3, 1.0), (IX0 + 0.45, FL + 0.35 + lv * 0.45, -5.0 + k * 1.15))
    # ceiling lights
    for x in (-11.5, -8.0, -4.5):
        for z in (-4.5, -1.0):
            b.box("dach_licht", (1.2, 0.04, 0.3), (x, H - 0.22, z))
    b.box("dach_licht", (0.8, 0.04, 0.3), (0.5, H - 0.22, 1.0))
    b.box("dach_licht", (0.8, 0.04, 0.3), (0.5, H - 0.22, -4.0))
    # outside the shop: ice freezer, trash bin
    b.box("paint_white", (1.4, 0.9, 0.7), (-3.0, FL + 0.45, BZ1 + 0.6))
    b.box("tank", (1.42, 0.12, 0.72), (-3.0, FL + 0.96, BZ1 + 0.6))
    b.cyl("frame_black", 0.25, 0.9, (-9.0, FL + 0.45, BZ1 + 0.8), 8)
    b.anchor("Eingang", (-6.5, 0, BZ1 + 1.3), 0)

    # ---------------- fuel canopy + pumps ----------------
    CX0, CX1, CZ0, CZ1, CY = 3.5, 14.0, -5.0, 6.0, 5.2
    ccx, ccz, cw, cd = (CX0 + CX1) / 2, (CZ0 + CZ1) / 2, CX1 - CX0, CZ1 - CZ0
    b.box("paint_white", (cw, 0.8, cd), (ccx, CY + 0.4, ccz))
    for (cx, cz, sx, sz) in [(ccx, CZ1 + 0.03, cw + 0.08, 0.06), (ccx, CZ0 - 0.03, cw + 0.08, 0.06),
                             (CX0 - 0.03, ccz, 0.06, cd), (CX1 + 0.03, ccz, 0.06, cd)]:
        b.box(GREEN, (sx, 0.45, sz), (cx, CY + 0.42, cz))
    b.box("dach_technik", (cw - 0.2, 0.04, cd - 0.2), (ccx, CY + 0.82, ccz))
    for x in (5.5, 8.75, 12.0):
        for z in (-3.0, 1.0, 4.5):
            b.box("lamp", (1.0, 0.03, 0.6), (x, CY - 0.015, z))
    for i, px in enumerate((6.4, 11.1)):
        b.box("concrete_light", (1.4, 0.22, 4.8), (px, 0.11, 0.6))                    # island
        b.box("paint_white", (0.6, CY, 0.6), (px, CY / 2, -0.4))                       # pillar
        for z in (-1.75, 2.95):
            b.cyl("led_orange", 0.08, 0.8, (px, 0.62, z), 6)                            # bollards
        pz = 1.5                                                                       # pump
        b.box("paint_white", (0.9, 1.75, 0.55), (px, 0.22 + 0.875, pz))
        b.box(GREEN, (0.92, 0.55, 0.57), (px, 0.22 + 0.275, pz))
        b.box(GREEN, (0.92, 0.22, 0.57), (px, 0.22 + 1.75 - 0.11, pz))
        for zz in (pz + 0.285, pz - 0.285):
            b.box("keypad", (0.5, 0.32, 0.02), (px, 1.45, zz))
            b.box("led_green", (0.42, 0.2, 0.01), (px, 1.47, zz + (0.012 if zz > pz else -0.012)))
        for sxs in (-1, 1):
            b.box("keypad", (0.1, 0.32, 0.18), (px + sxs * 0.5, 1.05, pz))
            hx = px + sxs * 0.56
            b.wire((hx, 1.2, pz - 0.05), (hx, 0.6, pz - 0.15), 0.0, 1, 0.04, "keypad")
            b.wire((hx, 0.6, pz - 0.15), (px + sxs * 0.47, 0.9, pz - 0.27), 0.0, 1, 0.04, "keypad")
        b.anchor(f"Zapfsaeule_{i + 1}", (px, 0.22, pz + 0.9), 0)
        b.cyl("frame_black", 0.2, 0.7, (px, 0.22 + 0.35, 2.75), 8)                       # bin
    # price pylon with "257"
    PXp, PZp = 13.6, 9.6
    b.box("paint_white", (1.8, 6.0, 0.45), (PXp, 3.0, PZp))
    b.box(GREEN, (1.84, 0.5, 0.49), (PXp, 5.45, PZp))
    b.box("sign_light", (1.6, 0.8, 0.5), (PXp, 4.75, PZp))
    b.text("257", [GREEN, GREEN, BROWN], (PXp, 4.75, PZp + 0.25), 0.5, 0.04)
    b.box("keypad", (1.5, 2.1, 0.5), (PXp, 2.95, PZp))
    for k, price in enumerate(("5,89", "6,19", "4,99")):
        b.text(price, "led_orange", (PXp, 3.65 - k * 0.62, PZp + 0.25), 0.36, 0.02)
    b.box("concrete_light", (2.2, 0.3, 0.9), (PXp, 0.15, PZp))
    return b
