"""Builds all road tiles + an example district (roads ring + houses) into out_roads/."""
import json, os
import numpy as np
import trimesh
import roads
import roads2
import roads3
import trimesh as _tm
import houses
from lib import B, export, PALETTE, SLOT_PALETTES

OUT = "out_roads"


def rot_y(deg):
    return trimesh.transformations.rotation_matrix(np.radians(deg), [0, 1, 0])


def place(target, src, x, z, deg, recolor_rng=None):
    """Copy all meshes of builder `src` into `target`, rotated about Y and moved to (x, z)."""
    M = rot_y(deg)
    M[:3, 3] = (x, 0, z)
    for key, meshes in src.parts.items():
        mat = key[1] if isinstance(key, tuple) else key
        if mat.startswith("slot_") and recolor_rng is not None:
            kind = mat.split("_")[1]
            hexc = recolor_rng.choice(SLOT_PALETTES[kind])
            mat = "c_" + hexc[1:].lower()
            PALETTE[mat] = hexc
        for m in meshes:
            m2 = m.copy()
            m2.apply_transform(M)
            target.add(mat, m2)


def beispiel_viertel():
    """5 x 5 ring of 12 m Rua tiles around a 36 x 36 m block of houses, T + bus stop to the south."""
    v = B(9000)
    rng = np.random.default_rng(7)
    tiles = [
        (roads.rua_kurve, -24, -24, 0), (roads.rua_kurve, 24, -24, -90),
        (roads.rua_kurve, -24, 24, 90), (roads.rua_kurve, 24, 24, 180),
    ]
    for x in (-12, 0, 12):
        tiles.append((roads.rua_gerade, x, -24, 90))
        if x != 0:
            tiles.append((roads.rua_gerade, x, 24, 90))
    tiles.append((roads.rua_t, 0, 24, -90))
    for z in (-12, 0, 12):
        tiles.append((roads.rua_gerade, -24, z, 0))
        tiles.append((roads.rua_gerade, 24, z, 0))
    tiles.append((roads.rua_bushaltestelle, 0, 42, 0))
    for fn, x, z, deg in tiles:
        place(v, fn(), x, z, deg)
    H = {h[0]: h[3] for h in houses.HOUSES}

    def house(slug, side, pos):
        b = H[slug]()
        lw, ld = b.normalize()
        if side == "S":
            place(v, b, pos, 18 - ld / 2, 0, rng)
        elif side == "N":
            place(v, b, pos, -18 + ld / 2, 180, rng)
        elif side == "E":
            place(v, b, 18 - ld / 2, pos, 90, rng)
        else:
            place(v, b, -18 + ld / 2, pos, -90, rng)
        return lw
    x = -17.0
    for slug in ("06_casa_rio", "07_boteco", "04_favela_reihe", "08_sobrado"):
        b = H[slug]()
        lw, ld = b.normalize()
        place(v, b, x + lw / 2, 18 - ld / 2, 0, rng)
        x += lw
    x = 16.0
    for slug in ("03_puxadinho", "05_cortico", "09_mercadinho", "01_barraco"):
        b = H[slug]()
        lw, ld = b.normalize()
        place(v, b, x - lw / 2, -18 + ld / 2, 180, rng)
        x -= lw
    z = 7.0
    for slug in ("06_casa_rio", "01_barraco"):
        b = H[slug]()
        lw, ld = b.normalize()
        place(v, b, 18 - ld / 2, z - lw / 2, 90, rng)
        z -= lw
    z = -7.0
    for slug in ("03_puxadinho", "06_casa_rio"):
        b = H[slug]()
        lw, ld = b.normalize()
        place(v, b, -18 + ld / 2, z + lw / 2, -90, rng)
        z += lw
    for ms in v.parts.values():                      # centre the district on the origin
        for m in ms:
            m.apply_translation((0, 0, -12.0))
    return v


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    meta = []
    for slug, name, cls, fn, tile in list(roads.ROADS) + list(roads2.ROADS2) + list(roads3.ROADS3):
        b = fn()
        tris, mats, bnd, slots = export(b, f"{OUT}/{slug}", name)
        g = _tm.util.concatenate([m for ms in b.parts.values() for m in ms]).bounds
        item = dict(slug=slug, name=name, cls=cls, tris=tris, mats=mats, slots=[], combos=1,
                    size=[round(float(v), 1) for v in g[1] - g[0]],
                    anchors={k: [round(float(c), 3) for c in p] + [yaw] for k, (p, yaw) in b.anchors.items()})
        if tile is None:   # arcs: pivot = start connector, footprint = bounding box
            item["lot"] = [round(float(g[1][0] - g[0][0]), 1), round(float(g[1][2] - g[0][2]), 1)]
            item["offset"] = [round(float(-(g[0][0] + g[1][0]) / 2), 2), round(float(-(g[0][2] + g[1][2]) / 2), 2)]
            item["noOutline"] = True
        else:
            item["lot"] = list(tile)
        meta.append(item)
        print(f"{slug:28s} tris={tris:5d} lot={item['lot']}")
    v = beispiel_viertel()
    tris, mats, bnd, _ = export(v, f"{OUT}/00_beispiel_viertel", "Beispiel-Viertel")
    meta.insert(0, dict(slug="00_beispiel_viertel", name="Beispiel-Viertel", cls="Beispiel", tris=tris, mats=mats, slots=[],
                        combos=1, lot=[60, 84], size=[round(float(x), 1) for x in bnd[1] - bnd[0]], anchors={}))
    print("beispiel", tris)
    json.dump(dict(houses=meta, palettes=SLOT_PALETTES,
                   rows={"Beispiel": 0, "Rua": 1, "Avenida": 2, "Schnellstraße": 3, "Favela": 4, "Spezial": 5, "Brücke": 6, "Gelände": 7}, gap=4,
                   lotLabel="Kachel", allLabel="Straßenteile", allHint="nach Typ sortiert, mit 4 m Abstand",
                   title="Rio-Straßennetz", subtitle="55 Straßen-, Brücken- und Geländeteile + Beispiel-Viertel · Bögen 15°/30° · Kacheln im 2-m-Raster"),
              open(f"{OUT}/meta.json", "w"), indent=1, ensure_ascii=False)
