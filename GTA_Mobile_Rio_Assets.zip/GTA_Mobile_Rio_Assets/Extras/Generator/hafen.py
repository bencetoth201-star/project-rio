"""Rio-Hafen: Containerhafen-Baukasten im Stil der Rio-Häuser.
Konventionen: Y oben, Meter. **Wasserspiegel y = 0**, Kai-Oberkante y = +3.
Kaikanten-Kacheln: Wasserseite +Z, Pivot Kachelmitte auf Wasserhöhe (y 0).
Alles, was AUF dem Kai steht (Kräne, Container, Gebäude …): Pivot unten Mitte (y 0 = Boden) → auf y = +3 setzen.
Schiffe: Pivot Mitte auf der Wasserlinie, Bug +X."""
import numpy as np
import trimesh
from shapely.geometry import Polygon, Point
from lib import B, PALETTE, SLOT_PALETTES

SLOT_PALETTES["container"] = ["#C8372D", "#2E5FA8", "#3E7D4F", "#E8893A", "#8C8F94", "#EBC03F",
                              "#6B2E2A", "#1F4E79", "#EDEDE8", "#2C9FA8"]
SLOT_PALETTES["hull"] = ["#1F3A5F", "#22252A", "#2F5D3A", "#8E2A26", "#5A6670", "#2B5FA8"]
CONT = [f"cont_{i}" for i in range(10)]
PALETTE.update(dict(zip(CONT, SLOT_PALETTES["container"])))
PALETTE.update({
    "hull_red": "#9E2B25", "hull_white": "#EDEDE8", "deck_green": "#4F6E4A", "hatch": "#5D7A54", "ship_white": "#ECEAE4",
    "funnel": "#1F3A5F", "crane_red": "#D2462B", "crane_white": "#EDEDE8", "rail_steel": "#6E7378", "quay": "#B9B4A8",
    "quay_dark": "#8E8A80", "fender": "#1E1E1E", "bollard": "#2B2B2E", "rope_hemp": "#C9B48A", "rock_grey": "#8C8C88",
    "lifeboat": "#F26A1B", "lighthouse_red": "#C8372D", "stacker_yellow": "#F2B31F", "rtg_blue": "#2B5FA8",
    "warn_yellow": "#F2C230", "water_dark": "#2A4B55", "ship_deck": "#7A7F76",
    "dach_mast": "#EDEDE8", "dach_radar": "#2B2B2E",
})
for k, v in {"screen": "#2FE0F0", "fence_net": "#C8CCD0", "glass_shop": "#9FC3D6"}.items():
    PALETTE.setdefault(k, v)

QY = 3.0          # quay top


def box(b, mat, x0, x1, y0, y1, z0, z1, **kw):
    b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)


def cyl_axis(b, mat, r, length, c, axis, sections=10):
    m = trimesh.creation.cylinder(radius=r, height=length, sections=sections)
    if axis == "x":
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    elif axis == "y":
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    b.add(mat, m.apply_translation(c))


def bollard(b, x, z, y=QY):
    b.cyl("bollard", 0.28, 0.6, (x, y + 0.3, z), 10)
    b.cyl("bollard", 0.4, 0.12, (x, y + 0.66, z), 10)
    box(b, "bollard", x - 0.5, x + 0.5, y, y + 0.08, z - 0.5, z + 0.5)


def railing(b, pts, y, h=1.1, mat="metal", post=2.0):
    for (a, c) in zip(pts[:-1], pts[1:]):
        a3, c3 = np.array([a[0], y + h, a[1]]), np.array([c[0], y + h, c[1]])
        b.beam(mat, a3, c3, 0.04)
        b.beam(mat, a3 - [0, h / 2, 0], c3 - [0, h / 2, 0], 0.03)
        L = np.linalg.norm(c3 - a3)
        for t in np.arange(0, L, post):
            p = a3 + (c3 - a3) * t / max(L, 1e-6)
            b.beam(mat, (p[0], y, p[2]), (p[0], y + h, p[2]), 0.035)


def ladder(b, x0, z, y0, y1, mat="metal", w=0.5, axis="x"):
    for s in (-w / 2, w / 2):
        p = (x0 + s, z) if axis == "x" else (x0, z + s)
        b.beam(mat, (p[0], y0, p[1]), (p[0], y1, p[1]), 0.03)
    for y in np.arange(y0 + 0.3, y1, 0.3):
        a = (x0 - w / 2, z) if axis == "x" else (x0, z - w / 2)
        c = (x0 + w / 2, z) if axis == "x" else (x0, z + w / 2)
        b.beam(mat, (a[0], y, a[1]), (c[0], y, c[1]), 0.02)


def container_block(b, x, y, z, length, mat, yaw=0.0, detail=False):
    """Container with its long side along X (yaw 0). length 6.06 or 12.19."""
    W, H = 2.44, 2.59
    b.box(mat, (length, H, W), (x, y + H / 2, z), rot_y=yaw)
    if detail:
        c, s = np.cos(np.radians(yaw)), np.sin(np.radians(yaw))
        for k in np.arange(-length / 2 + 0.6, length / 2 - 0.5, 0.55):
            for side in (-1, 1):
                dz = side * (W / 2 + 0.015)
                b.box(mat, (0.12, H - 0.25, 0.03), (x + k * c + dz * s, y + H / 2, z - k * s + dz * c), rot_y=yaw)
        for side in (-1, 1):                                               # corner castings
            for sx in (-1, 1):
                for yy in (0.08, H - 0.08):
                    kx, kz = sx * (length / 2 - 0.1), side * (W / 2 - 0.1)
                    b.box("bollard", (0.2, 0.16, 0.2), (x + kx * c + kz * s, y + yy, z - kx * s + kz * c), rot_y=yaw)


# =====================================================================================  SCHIFFE
def containerschiff():
    """300 m container ship, bow +X, water line y = 0, main deck y = 10. Walkable side decks, accommodation
    with exterior stairs, enterable bridge (layer OG), bridge roof + radar mast (layer Dach), cargo (layer Ladung)."""
    b = B(4001)
    rng = np.random.default_rng(4001)
    hullc = b.slot("hull", 1, "#1F3A5F")
    LEN2, W2, DECK, KEEL = 150.0, 20.0, 10.0, -13.0

    def halfwidths(x):
        f = 1.0
        if x > 85:
            f = np.sqrt(max(0.0, 1 - ((x - 85) / 65.5) ** 2))
        if x < -138:
            f = 0.95
        wd = W2 * f
        g = 1.0
        if x > 70:
            g = np.sqrt(max(0.0, 1 - ((x - 70) / 81) ** 2))
        if x < -110:
            g = max(0.25, 1 - ((-110 - x) / 42) ** 1.5)
        return wd, W2 * g * 0.98

    xs = [-150, -148, -144, -138, -130, -120, -110, -90, -60, -20, 20, 60, 85, 95, 105, 115, 125, 133, 140, 145, 148, 150]
    secs = []
    for x in xs:
        wd, ww = halfwidths(x)
        keel = KEEL if x > -128 else KEEL + (-128 - x) / 22 * 7.0
        keel = keel if x < 140 else KEEL + (x - 140) / 10 * 6.0
        wb = max(ww * 0.86, 0.15) if -120 < x < 120 else max(ww * 0.4, 0.1)
        pts = [(wd, DECK), (wd, 8.6), (max(ww, 0.12) + (wd - ww) * 0.3, 0.6), (max(ww, 0.12), -0.6), (wb + (ww - wb) * 0.6, keel + 1.4), (wb, keel)]
        sec = pts + [(-z, y) for (z, y) in pts[::-1]]
        secs.append([(x, y, z) for (z, y) in sec])
    V = np.array([p for s in secs for p in s])
    n = len(secs[0])
    F = []
    for i in range(len(secs) - 1):
        for j in range(n - 1):
            a, c = i * n + j, i * n + j + 1
            F += [(a, c, c + n), (a, c + n, a + n)]
    for j in range(1, n - 2):                                              # transom (stern cap)
        F.append((0, j, j + 1))
    hull = trimesh.Trimesh(V, np.array(F), process=False)
    cent = hull.triangles_center
    nrm = hull.face_normals
    out = np.c_[np.zeros(len(cent)), cent[:, 1] + 1.0, cent[:, 2]]
    out[cent[:, 0] < -149.5] = [-1, 0, 0]
    flip = (nrm * out).sum(1) < 0
    Fa = np.array(F)
    Fa[flip] = Fa[flip][:, ::-1]
    hull = trimesh.Trimesh(V, Fa, process=False)
    cy = hull.triangles_center[:, 1]
    for mat, sel in (("hull_red", cy < 0.0), (hullc, (cy >= 0.0) & (cy < 8.6)), ("hull_white", cy >= 8.6)):
        if sel.any():
            m = hull.copy()
            m.update_faces(sel)
            m.remove_unreferenced_vertices()
            b.add(("Aussen", mat), m)
    b.layer = "Aussen"
    bulb = trimesh.creation.icosphere(subdivisions=2, radius=1.0)
    bulb.apply_scale((9.0, 3.6, 3.0))
    b.add("hull_red", bulb.apply_translation((144.0, -8.5, 0)))
    # deck plate following the deck edge
    edge = [(x, halfwidths(x)[0]) for x in xs]
    poly = Polygon([(x, w) for x, w in edge] + [(x, -w) for x, w in edge[::-1]]).buffer(0)
    dk = trimesh.creation.extrude_polygon(poly, 0.3)
    dk.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
    b.add("ship_deck", dk.apply_translation((0, DECK - 0.3, 0)))
    # bulwark / railing along the deck edge (walkable side decks)
    for s in (-1, 1):
        pts = [(x, s * (w - 0.15)) for x, w in edge if -148 <= x <= 147]
        railing(b, pts, DECK, 1.1, "hull_white", 3.0)
    # forecastle (raised bow deck) + breakwater
    fx0 = 128.0
    fpoly = poly.intersection(Polygon([(fx0, -30), (160, -30), (160, 30), (fx0, 30)]))
    fk = trimesh.creation.extrude_polygon(fpoly, 2.5)
    fk.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
    b.add("ship_deck", fk.apply_translation((0, DECK, 0)))
    w128 = halfwidths(fx0)[0]
    b.hull("hull_white", [(fx0 - 0.5, DECK, s * w128) for s in (-1, 1)] + [(fx0 - 0.5, DECK + 2.5, s * w128) for s in (-1, 1)] + [(fx0 - 3.5, DECK + 4.5, s * 0.5) for s in (-1, 1)]
           + [(fx0 + 0.0, DECK, s * w128) for s in (-1, 1)])
    for (x, z) in [(136, 5), (136, -5), (142, 3), (142, -3)]:
        bollard(b, x, z, DECK + 2.5)
    for s in (-1, 1):                                                      # windlasses + anchors
        cyl_axis(b, "bollard", 0.9, 1.6, (133.0, DECK + 3.4, s * 4.0), "z")
        box(b, "bollard", 131.5, 134.5, DECK + 2.5, DECK + 3.0, s * 4.0 - 1.2, s * 4.0 + 1.2)
        b.box("bollard", (3.0, 2.2, 0.5), (138.0, 6.0, s * (halfwidths(138)[0] + 0.1)), rot_x=s * 8)
    b.beam("hull_white", (146.0, DECK + 2.5, 0), (146.0, DECK + 12.0, 0), 0.25)         # fore mast
    b.cyl("led_red", 0.25, 0.4, (146.0, DECK + 12.3, 0), 8)

    # hatch covers + lashing bridges + cargo
    bays = np.arange(-104.0, 124.0, 12.8)
    for i, x in enumerate(bays):
        box(b, "hatch", x - 6.2, x + 6.2, DECK, DECK + 1.4, -15.9, 15.9)
        for z in np.arange(-15.5, 16, 5.3):
            box(b, "hatch", x - 6.15, x + 6.15, DECK + 1.4, DECK + 1.45, z - 0.06, z + 0.06)
        if i < len(bays) - 1:
            xl = x + 6.4
            for y in (DECK + 1.4, DECK + 4.0, DECK + 6.6):
                box(b, "rail_steel", xl - 0.2, xl + 0.2, y - 0.12, y, -16.0, 16.0)
            for z in np.arange(-16.0, 16.5, 2.65):
                box(b, "rail_steel", xl - 0.12, xl + 0.12, DECK, DECK + 6.6, z - 0.08, z + 0.08)
    b.layer = "Ladung"
    rows = np.arange(-14.64, 14.7, 2.44)
    for i, x in enumerate(bays):
        if i in (3, 10):                                                  # two empty bays show the hatch covers
            continue
        for zi, z in enumerate(rows):
            edge_drop = int(abs(zi - 6) > 4) + int(abs(zi - 6) > 5)
            tiers = 7 - edge_drop - (1 if i > 14 else 0) - int(rng.integers(0, 3) == 0)
            if i == len(bays) - 1:
                tiers = min(tiers, 4)
            for t in range(max(tiers, 0)):
                mat = CONT[int(rng.integers(0, len(CONT)))]
                if rng.random() < 0.12 and t == tiers - 1:
                    for dx in (-3.05, 3.05):
                        container_block(b, x + dx, DECK + 1.45 + t * 2.6, z, 6.06, CONT[int(rng.integers(0, len(CONT)))])
                else:
                    container_block(b, x, DECK + 1.45 + t * 2.6, z, 12.19, mat)

    # accommodation block (aft) with exterior stairs + bridge
    b.layer = "Aufbau"
    AX0, AX1, AZ = -126.0, -112.0, 15.0
    levels = [DECK + 3.0 * k for k in range(8)]                           # 8 decks, bridge deck at DECK+21 (sees over the cargo)
    BR = DECK + 21.0
    box(b, "ship_white", AX0, AX1, DECK, BR, -AZ, AZ)
    for y in levels[1:]:
        box(b, "hull_white", AX0 - 1.2, AX1 + 1.2, y - 0.15, y, -AZ - 1.2, AZ + 1.2)        # deck overhangs (walkable balconies)
        railing(b, [(AX0 - 1.1, -AZ - 1.1), (AX0 - 1.1, AZ + 1.1)], y, 1.0, "hull_white", 2.5)
        for s in (-1, 1):
            railing(b, [(AX0 - 1.1, s * (AZ + 1.1)), (AX1 + 1.1, s * (AZ + 1.1))], y, 1.0, "hull_white", 2.5)
        for x in np.arange(AX0 + 1.5, AX1 - 0.5, 2.2):
            for s in (-1, 1):
                box(b, "glass", x - 0.45, x + 0.45, y + 0.9, y + 1.9, s * AZ - 0.03, s * AZ + 0.03)
        for z in np.arange(-AZ + 1.5, AZ - 0.5, 2.2):
            box(b, "glass", AX1 - 0.03, AX1 + 0.03, y + 0.9, y + 1.9, z - 0.45, z + 0.45)
            box(b, "glass", AX0 - 0.03, AX0 + 0.03, y + 0.9, y + 1.9, z - 0.45, z + 0.45)
    for k in range(7):                                                    # zig-zag exterior stairs on the aft face
        y0, y1 = levels[k], levels[k + 1]
        za, zb = (-12.0, -6.0) if k % 2 == 0 else (-6.0, -12.0)
        b.hull("rail_steel", [(AX0 - 1.1 - dx, y, z) for dx in (0.0, 1.0) for (y, z) in ((y0 + 0.05, za), (y1 - 0.15, zb), (y0 - 0.1, za), (y1 - 0.3, zb))])
        b.beam("metal", (AX0 - 2.1, y0 + 1.0, za), (AX0 - 2.1, y1 + 1.0, zb), 0.03)
    for y in levels[:-1]:
        box(b, "door_metal", AX0 - 0.05, AX0, y + 0.1, y + 2.1, -9.5, -8.5)
    # funnel
    b.hull("funnel", [(x, DECK + 12.0, z) for x in (-140.0, -129.0) for z in (-5.0, 5.0)] + [(x, DECK + 33.0, z) for x in (-141.5, -132.0) for z in (-4.0, 4.0)])
    b.hull("hull_red", [(x, DECK + 31.5, z) for x in (-141.3, -131.8) for z in (-4.05, 4.05)] + [(x, DECK + 33.05, z) for x in (-141.6, -131.9) for z in (-4.05, 4.05)])
    box(b, "ship_white", -142.0, -127.0, DECK, DECK + 12.0, -8.0, 8.0)                          # engine casing
    for z in (-1.5, 1.5):
        b.cyl("bollard", 0.7, 2.0, (-136.5, DECK + 34.0, z), 10)
    # lifeboat (free-fall) on the stern + rescue boat with davit
    b.hull("lifeboat", [(x, y, z) for x in (-148.0, -140.0) for y in (DECK + 3.0, DECK + 5.6) for z in (-1.5, 1.5)] + [(-138.5, DECK + 5.2, 0.0)])
    b.box("rail_steel", (9.0, 0.3, 3.4), (-144.0, DECK + 2.8, 0.0), rot_z=-10)
    for s in (-1, 1):
        b.beam("rail_steel", (-146.0, DECK, s * 1.7), (-146.0, DECK + 3.2, s * 1.7), 0.15)
        b.beam("rail_steel", (-141.0, DECK, s * 1.7), (-141.0, DECK + 2.3, s * 1.7), 0.15)
    b.hull("lifeboat", [(x, y, z) for x in (-118.0, -112.0) for y in (DECK + 2.0, DECK + 3.2) for z in (-17.2, -15.4)])
    # gangway (port side = -Z, quay side) down to quay level y = 3
    gx0, gx1 = -100.0, -86.0
    b.hull("rail_steel", [(x, y, z) for (x, y) in ((gx0, DECK), (gx1, QY + 0.1)) for z in (-20.6, -21.6)] + [(x, y - 0.2, z) for (x, y) in ((gx0, DECK), (gx1, QY + 0.1)) for z in (-20.6, -21.6)])
    for z in (-20.6, -21.6):
        b.beam("metal", (gx0, DECK + 1.0, z), (gx1, QY + 1.1, z), 0.03)
    # name + port of registry
    for s in (-1, 1):
        b.text("RIOMAR ATLÂNTICO", ["hull_white"] * 16, (66.0, 5.8, s * 19.98), 2.2, 0.08, rot_y=0 if s > 0 else 180, simplify=0.03)
    b.text("RIOMAR ATLÂNTICO", ["hull_white"] * 16, (-150.05, 6.8, 0.0), 1.6, 0.08, rot_y=-90, simplify=0.03)
    b.text("RIO DE JANEIRO", ["hull_white"] * 14, (-150.05, 4.6, 0.0), 1.1, 0.08, rot_y=-90, simplify=0.03)
    for s in (-1, 1):                                                      # draft marks
        for y in np.arange(-4.0, 1.0, 1.0):
            box(b, "hull_white", 146.0, 146.6, y, y + 0.12, s * halfwidths(146)[1] * 0.99 - 0.02, s * halfwidths(146)[1] * 0.99 + 0.02)
    # propeller + rudder (under water)
    for k in range(5):
        b.box("bollard", (0.4, 3.0, 1.2), (-146.5, -7.0, 0.0), rot_x=k * 72)
    box(b, "hull_red", -149.8, -148.6, -10.0, -2.0, -0.5, 0.5)

    # BRIDGE (layer OG) – enterable wheelhouse with wings
    b.layer = "OG"
    box(b, "ship_deck", AX0 - 1.0, AX1 + 1.5, BR, BR + 0.2, -W2, W2)
    for z in (-W2 + 0.1, W2 - 0.1):
        railing(b, [(AX0 - 1.0, z), (AX1 + 1.5, z)], BR + 0.2, 1.1, "hull_white", 2.0)
    box(b, "ship_white", AX0, AX0 + 0.25, BR + 0.2, BR + 3.2, -12.0, 12.0)                       # back wall
    box(b, "glass", AX1 - 0.05, AX1 + 0.05, BR + 1.2, BR + 3.0, -12.0, 12.0)                      # front glass
    box(b, "ship_white", AX1 - 0.1, AX1 + 0.1, BR + 0.2, BR + 1.2, -12.0, 12.0)
    for s in (-1, 1):
        box(b, "glass", AX0 + 0.25, AX1, BR + 1.2, BR + 3.0, s * 12.0 - 0.05, s * 12.0 + 0.05)
        box(b, "ship_white", AX0 + 0.25, AX1, BR + 0.2, BR + 1.2, s * 12.0 - 0.1, s * 12.0 + 0.1)
        box(b, "door_metal", AX0 + 1.0, AX0 + 2.0, BR + 0.2, BR + 2.3, s * 12.0 - 0.12, s * 12.0 + 0.12)
    for z in np.arange(-11.0, 11.5, 2.4):                                                        # window mullions
        box(b, "frame_black", AX1 - 0.08, AX1 + 0.08, BR + 1.2, BR + 3.0, z - 0.05, z + 0.05)
    box(b, "frame_black", AX1 - 1.6, AX1 - 0.6, BR + 0.2, BR + 1.15, -6.0, 6.0)                   # console
    for z in np.arange(-5.5, 6.0, 1.4):
        b.box("screen", (0.05, 0.4, 0.6), (AX1 - 1.0, BR + 1.35, z), rot_z=-20)
    b.cyl("frame_black", 0.3, 0.9, (AX1 - 2.6, BR + 0.65, 0.0), 10)                               # helm
    cyl_axis(b, "wood_dark", 0.35, 0.05, (AX1 - 2.3, BR + 1.25, 0.0), "x", 12)
    for z in (-2.0, 2.0):
        box(b, "frame_black", AX1 - 3.6, AX1 - 3.0, BR + 0.2, BR + 0.7, z - 0.3, z + 0.3)
        box(b, "frame_black", AX1 - 3.75, AX1 - 3.6, BR + 0.7, BR + 1.4, z - 0.3, z + 0.3)
    box(b, "wood_a", AX0 + 1.0, AX0 + 3.0, BR + 0.2, BR + 1.0, -9.0, -6.0)                        # chart table
    box(b, "frame_black", AX0 + 0.3, AX0 + 0.8, BR + 0.2, BR + 2.0, 4.0, 8.0)                     # radio/gear rack
    b.anchor("Bruecke", (AX1 - 2.6, BR + 0.2, 0.0), 90)

    # DACH – bridge roof + radar mast (hide to look into the bridge)
    b.layer = "Dach"
    box(b, "dach", AX0 - 0.5, AX1 + 1.0, BR + 3.2, BR + 3.45, -12.6, 12.6)
    b.hull("dach_mast", [(x, BR + 3.45, z) for x in (AX0 + 3.0, AX0 + 5.0) for z in (-1.0, 1.0)] + [(x, BR + 12.0, z) for x in (AX0 + 3.6, AX0 + 4.4) for z in (-0.4, 0.4)])
    for y, w in ((BR + 9.0, 4.0), (BR + 6.5, 3.2)):
        box(b, "dach_mast", AX0 + 3.6, AX0 + 4.4, y, y + 0.3, -w, w)
        b.box("dach_radar", (0.4, 0.3, w * 1.4), (AX0 + 5.2, y + 0.6, 0.0), rot_y=25)
    b.cyl("dach_licht", 0.25, 0.4, (AX0 + 4.0, BR + 12.3, 0.0), 8)

    b.layer = None
    b.anchor("Gangway_Unten", (gx1, QY, -21.1), 90)
    b.anchor("Gangway_Oben", (gx0, DECK, -19.5), 90)
    b.anchor("Deck_Achtern", (-108.0, DECK, -18.5), 0)
    b.anchor("Back_Bug", (138.0, DECK + 2.5, 0.0), 90)
    b.anchor("Festmachen_Bug", (136.0, DECK + 2.5, -5.0), 0)
    b.anchor("Festmachen_Heck", (-146.0, DECK, -10.0), 0)
    return b


def schlepper():
    b = B(4002)
    L2, W2, DK = 16.0, 5.5, 2.4
    xs = [-16.0, -15.0, -12.0, -6.0, 0.0, 6.0, 10.0, 13.0, 15.0, 16.0]
    secs = []
    for x in xs:
        f = 1.0 if x < 6 else np.sqrt(max(0.0, 1 - ((x - 6) / 10.2) ** 2))
        f = f if x > -14 else 0.85
        w = W2 * f
        keel = -3.0 if -12 < x < 12 else -1.8
        pts = [(w, DK), (w * 0.98, 0.3), (w * 0.8, keel + 0.8), (w * 0.3, keel)]
        secs.append([(x, y, z) for (z, y) in pts + [(-z, y) for (z, y) in pts[::-1]]])
    V = np.array([p for s in secs for p in s])
    n = len(secs[0])
    F = []
    for i in range(len(secs) - 1):
        for j in range(n - 1):
            a, c = i * n + j, i * n + j + 1
            F += [(a, c, c + n), (a, c + n, a + n)]
    for j in range(1, n - 2):
        F.append((0, j, j + 1))
    hull = trimesh.Trimesh(V, np.array(F), process=False)
    cent, nrm = hull.triangles_center, hull.face_normals
    out = np.c_[np.zeros(len(cent)), cent[:, 1] + 0.5, cent[:, 2]]
    out[cent[:, 0] < -15.9] = [-1, 0, 0]
    Fa = np.array(F)
    flip = (nrm * out).sum(1) < 0
    Fa[flip] = Fa[flip][:, ::-1]
    hull = trimesh.Trimesh(V, Fa, process=False)
    cy = hull.triangles_center[:, 1]
    for mat, sel in (("hull_red", cy < 0.3), ("lighthouse_red", cy >= 0.3)):
        m = hull.copy(); m.update_faces(sel); m.remove_unreferenced_vertices()
        b.add(mat, m)
    edge = [(x, W2 * (1.0 if x < 6 else np.sqrt(max(0.0, 1 - ((x - 6) / 10.2) ** 2))) * (1 if x > -14 else 0.85)) for x in xs]
    poly = Polygon([(x, w) for x, w in edge] + [(x, -w) for x, w in edge[::-1]]).buffer(0)
    dk = trimesh.creation.extrude_polygon(poly, 0.25)
    dk.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
    b.add("ship_deck", dk.apply_translation((0, DK - 0.25, 0)))
    for x, w in edge[1:-1]:                                                                     # tyre fenders
        for s in (-1, 1):
            cyl_axis(b, "fender", 0.45, 0.35, (x, DK - 0.6, s * (w + 0.1)), "z", 10)
    b.hull("fender", [(16.0 + dx, y, z) for dx in (0, 0.8) for y in (0.5, DK + 0.3) for z in (-1.5, 1.5)])
    box(b, "ship_white", -4.0, 5.0, DK, DK + 2.6, -3.8, 3.8)
    box(b, "ship_white", -1.0, 4.0, DK + 2.6, DK + 5.0, -3.0, 3.0)
    box(b, "glass", 3.95, 4.05, DK + 3.3, DK + 4.6, -2.8, 2.8)
    for s in (-1, 1):
        box(b, "glass", -0.8, 3.8, DK + 3.3, DK + 4.6, s * 3.0 - 0.05, s * 3.0 + 0.05)
    box(b, "dach", -1.3, 4.4, DK + 5.0, DK + 5.25, -3.4, 3.4)
    b.beam("hull_white", (1.0, DK + 5.25, 0), (1.0, DK + 10.0, 0), 0.12)
    b.cyl("led_red", 0.15, 0.3, (1.0, DK + 10.2, 0), 8)
    for z in (-1.6, 1.6):
        b.hull("funnel", [(x, DK + 2.6, z + dz) for x in (-3.5, -2.0) for dz in (-0.45, 0.45)] + [(x, DK + 6.0, z + dz) for x in (-3.9, -2.6) for dz in (-0.4, 0.4)])
    cyl_axis(b, "bollard", 1.0, 2.2, (-8.5, DK + 1.0, 0.0), "z", 12)                             # towing winch
    for z in (-2.5, 2.5):
        box(b, "bollard", -9.5, -7.5, DK, DK + 0.6, z - 0.3, z + 0.3)
    b.beam("rail_steel", (-12.0, DK + 2.0, -3.5), (-12.0, DK + 2.0, 3.5), 0.15)
    for z in (-3.5, 3.5):
        b.beam("rail_steel", (-12.0, DK, z), (-12.0, DK + 2.0, z), 0.12)
    for (x, z) in [(-14.0, 3.5), (-14.0, -3.5), (12.0, 2.5), (12.0, -2.5)]:
        bollard(b, x, z, DK)
    b.anchor("Steuer", (2.0, DK + 2.6, 0.0), 90)
    b.anchor("Schlepphaken", (-12.0, DK + 2.0, 0.0), -90)
    return b


# =====================================================================================  KAIKANTE
def kai_tile(L, D=36.0, corner=False):
    """Quay tile: L along X; water side +Z (z = +6); land to -Z. Pivot centre on water level, top y = 3.
    Crane rails: waterside z = +3.5, landside z = -27 (gauge 30.5 m)."""
    def f():
        b = B(4100 + int(L) + (50 if corner else 0))
        z0, z1 = 6.0 - D, 6.0
        x0, x1 = -L / 2, L / 2
        box(b, "quay", x0, x1, -6.0, QY, z0, z1)
        box(b, "quay_dark", x0, x1, -6.0, 0.4, z1 - 0.01, z1 + 0.01)                           # wet band / algae
        box(b, "warn_yellow", x0, x1, QY, QY + 0.02, z1 - 0.3, z1)
        sides = [("z", z1)] + ([("x", x1)] if corner else [])
        if corner:
            box(b, "quay_dark", x1 - 0.01, x1 + 0.01, -6.0, 0.4, z0, z1)
            box(b, "warn_yellow", x1 - 0.3, x1, QY, QY + 0.02, z0, z1)
        for ax, e in sides:
            span = (x0, x1) if ax == "z" else (z0, z1)
            for t in np.arange(span[0] + 6.0, span[1] - 1.0, 12.0):
                if ax == "z":
                    b.hull("fender", [(t + dx, y, e + dz) for dx in (-1.0, 1.0) for y in (-1.0, 2.4) for dz in (0.0, 0.5)])
                    box(b, "fender", t - 1.6, t + 1.6, -0.6, 2.6, e + 0.5, e + 0.75)
                    bollard(b, t + 6.0 if t + 6.0 < x1 else t - 3.0, e - 1.2)
                else:
                    b.hull("fender", [(e + dz, y, t + dx) for dx in (-1.0, 1.0) for y in (-1.0, 2.4) for dz in (0.0, 0.5)])
                    box(b, "fender", e + 0.5, e + 0.75, -0.6, 2.6, t - 1.6, t + 1.6)
                    bollard(b, e - 1.2, t + 6.0 if t + 6.0 < z1 else t - 3.0)
        # recessed ladder
        lx = x0 + 2.5
        box(b, "quay_dark", lx - 0.5, lx + 0.5, -2.0, QY, z1 - 0.3, z1 + 0.01)
        ladder(b, lx, z1 - 0.15, -2.0, QY + 1.0)
        # crane rails + cable trench
        rx1 = x1 - (14.0 if corner else 0.0)
        for rz in (3.5, -27.0):
            box(b, "quay_dark", x0, rx1, QY - 0.02, QY + 0.01, rz - 0.6, rz + 0.6)
            box(b, "rail_steel", x0, rx1, QY, QY + 0.12, rz - 0.08, rz + 0.08)
            if corner:
                box(b, "warn_yellow", rx1 - 0.6, rx1, QY, QY + 1.0, rz - 0.6, rz + 0.6)          # buffer stop
        box(b, "quay_dark", x0, rx1, QY, QY + 0.02, 1.4, 2.0)
        for x in np.arange(x0 + 1.5, rx1, 3.0):
            box(b, "rail_steel", x - 0.05, x + 0.05, QY + 0.02, QY + 0.025, 1.4, 2.0)
        # lane markings
        for lz in (-2.0, -8.0, -14.0, -20.0):
            for x in np.arange(x0 + 1.0, x1 - (6.0 if corner else 0.5), 6.0):
                box(b, "warn_yellow", x, x + 3.0, QY, QY + 0.012, lz - 0.08, lz + 0.08)
        b.anchor("Kran_Mitte", (0.0, QY, -11.75), 0)
        b.anchor("Liegeplatz", (0.0, 0.0, 6.0 + 2.0 + 20.0), 0)
        b.anchor("Anschluss_Kai_W", (x0, QY, 0.0), -90)
        b.anchor("Anschluss_Kai_O", (x1, QY, 0.0), 90)
        return b
    return f


def molenkopf():
    """Breakwater/pier end: 12 m wide mole, 24 m straight + round head with lighthouse. Water on three sides."""
    b = B(4140)
    W = 6.0
    # polygon y = -z (the extrusion is rotated so that polygon y maps to -z)
    shape = Polygon([(-W, 24.0), (W, 24.0), (W, 0.0), (-W, 0.0)]).union(Point(0, 0).buffer(W, 16))
    m = trimesh.creation.extrude_polygon(shape, QY + 5.0)
    m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
    b.add("quay", m.apply_translation((0, -5.0, 0)))
    edge = shape.exterior
    for t in np.arange(0, edge.length, 1.3):                                                  # rocks at the waterline
        p = edge.interpolate(t)
        x, z = p.x, -p.y
        if z < -23.5:
            continue
        nx, nz = (np.sign(x), 0.0) if z < 0 else (x / W, z / W)
        b.rock("rock_grey", 1.0 + 0.4 * np.sin(t), (x + nx * 1.4, 0.2, z + nz * 1.4), 0.8)
    railing(b, [(-W + 0.4, -24.0), (-W + 0.4, 0.0)], QY, 1.0, "rail_steel", 3.0)
    railing(b, [(W - 0.4, -24.0), (W - 0.4, 0.0)], QY, 1.0, "rail_steel", 3.0)
    arc = [((W - 0.4) * np.cos(a), (W - 0.4) * np.sin(a)) for a in np.linspace(0, np.pi, 9)]
    railing(b, arc, QY, 1.0, "rail_steel", 3.0)
    for z in (-18.0, -6.0):
        for x in (-W + 1.2, W - 1.2):
            bollard(b, x, z)
    # lighthouse
    for k in range(6):
        y0 = QY + k * 2.6
        r0, r1 = 2.0 - k * 0.15, 2.0 - (k + 1) * 0.15
        b.hull("lighthouse_red" if k % 2 == 0 else "hull_white", [(r * np.cos(a), y, r * np.sin(a)) for (r, y) in ((r0, y0), (r1, y0 + 2.6)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]])
    top = QY + 15.6
    b.cyl("hull_white", 1.6, 0.25, (0, top + 0.12, 0), 12)
    railing(b, [(1.55 * np.cos(a), 1.55 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)], top + 0.25, 0.9, "rail_steel", 2.0)
    b.cyl("glass", 0.9, 1.6, (0, top + 1.05, 0), 10)
    b.cyl("lamp", 0.5, 0.7, (0, top + 1.0, 0), 8)
    b.hull("lighthouse_red", [(1.05 * np.cos(a), top + 1.85, 1.05 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] + [(0, top + 3.0, 0)])
    box(b, "door_metal", -0.5, 0.5, QY, QY + 2.1, -2.0, -1.9)
    b.anchor("Anschluss_Mole", (0.0, QY, -24.0), 180)
    b.anchor("Leuchtturm", (0.0, QY, 0.0), 0)
    return b


def hafenflaeche():
    b = B(4150)
    box(b, "quay", -12.0, 12.0, QY - 0.3, QY, -12.0, 12.0)
    for z0 in (-11.5, 0.8):
        for k in range(4):
            z = z0 + k * 2.6
            for x0 in (-11.5, -0.6):
                for (a, c, za, zc) in [(x0, x0 + 12.4, z, z + 0.08), (x0, x0 + 12.4, z + 2.52, z + 2.6), (x0, x0 + 0.08, z, z + 2.6), (x0 + 12.32, x0 + 12.4, z, z + 2.6)]:
                    box(b, "paint_white", a, c, QY, QY + 0.012, za, zc)
    box(b, "warn_yellow", -12.0, 12.0, QY, QY + 0.012, -0.12, 0.12)
    b.anchor("Stapelplatz_1", (-5.3, QY, -5.3), 0)
    b.anchor("Stapelplatz_2", (5.6, QY, 6.4), 0)
    return b


# =====================================================================================  KRÄNE + FAHRZEUGE
def containerkran():
    """Ship-to-shore gantry crane. Pivot = centre between the rails on the ground (place on 'Kran_Mitte').
    Waterside legs at z = +15.25, boom reaches 55 m over the water. Nodes: Laufkatze (moves along Z), Spreader (moves in Y)."""
    b = B(4200)
    G = 15.25
    LX = 9.0
    for x in (-LX, LX):
        for z in (-G, G):
            box(b, "crane_red", x - 0.9, x + 0.9, 3.0, 44.0, z - 0.9, z + 0.9)               # legs
            box(b, "warn_yellow", x - 2.2, x + 2.2, 0.4, 3.0, z - 1.1, z + 1.1)              # bogie
            for dx in (-1.6, -0.55, 0.55, 1.6):
                cyl_axis(b, "rail_steel", 0.4, 0.5, (x + dx, 0.4, z), "z", 10)
            for k in range(6):
                box(b, "frame_black" if k % 2 else "warn_yellow", x - 2.21 + k * 0.73, x - 2.21 + (k + 1) * 0.73, 2.4, 3.0, z - 1.12, z + 1.12)
        box(b, "crane_red", x - 0.8, x + 0.8, 12.0, 13.6, -G, G)                               # sill beam
        b.beam("crane_red", (x, 13.6, -G), (x, 42.0, G), 0.5)
        b.beam("crane_red", (x, 13.6, G), (x, 42.0, -G), 0.5)
    for z in (-G, G):
        box(b, "crane_red", -LX - 0.9, LX + 0.9, 42.0, 44.0, z - 0.9, z + 0.9)               # portal beams
        box(b, "crane_red", -LX - 0.8, LX + 0.8, 12.0, 13.4, z - 0.8, z + 0.8)
    # boom (2 box girders) z -40 … +70, raised hinge at waterside
    BY = 44.0
    for x in (-3.5, 3.5):
        box(b, "crane_white", x - 1.0, x + 1.0, BY, BY + 3.0, -40.0, 70.0)
    for z in np.arange(-38.0, 70.0, 6.0):
        box(b, "crane_white", -3.5, 3.5, BY + 2.6, BY + 3.0, z - 0.3, z + 0.3)
    box(b, "warn_yellow", -4.6, 4.6, BY, BY + 3.0, 69.0, 70.2)
    # A-frame + stays
    for x in (-4.0, 4.0):
        b.beam("crane_red", (x, BY + 3.0, -G), (x * 0.5, 75.0, -2.0), 0.6)
        b.beam("crane_red", (x, BY + 3.0, G), (x * 0.5, 75.0, -2.0), 0.6)
        b.beam("crane_white", (x * 0.5, 75.0, -2.0), (x, BY + 3.0, 69.0), 0.18)
        b.beam("crane_white", (x * 0.5, 75.0, -2.0), (x, BY + 3.0, 40.0), 0.18)
        b.beam("crane_white", (x * 0.5, 75.0, -2.0), (x, BY + 3.0, -38.0), 0.18)
    box(b, "crane_red", -2.6, 2.6, 74.0, 76.0, -3.0, -1.0)
    b.cyl("led_red", 0.3, 0.5, (0.0, 76.3, -2.0), 8)
    # machinery house on the backreach
    box(b, "crane_white", -5.0, 5.0, BY + 3.0, BY + 9.0, -36.0, -22.0)
    box(b, "crane_red", -5.05, 5.05, BY + 8.2, BY + 9.0, -36.05, -21.95)
    b.text("RIOMAR", ["crane_red"] * 6, (5.06, BY + 5.8, -29.0), 2.0, 0.06, rot_y=90, simplify=0.02)
    b.text("RIOMAR", ["crane_red"] * 6, (-5.06, BY + 5.8, -29.0), 2.0, 0.06, rot_y=-90, simplify=0.02)
    # stairs tower on one leg
    for k in range(13):
        y0 = 3.0 + k * 3.2
        z0 = -G - 1.0
        b.hull("rail_steel", [(LX + 1.0 + dx, y, z) for dx in (0.0, 1.0) for (y, z) in ((y0, z0), (y0 + 3.2, z0 - 3.0), (y0 - 0.2, z0), (y0 + 3.0, z0 - 3.0))]) if k % 2 == 0 else \
            b.hull("rail_steel", [(LX + 1.0 + dx, y, z) for dx in (0.0, 1.0) for (y, z) in ((y0, z0 - 3.0), (y0 + 3.2, z0), (y0 - 0.2, z0 - 3.0), (y0 + 3.0, z0))])
    for x in (-3.5, 3.5):                                                                     # boom lights
        for z in (10.0, 40.0, 65.0):
            b.box("lamp", (0.8, 0.2, 0.5), (x, BY - 0.15, z))
    # trolley + operator cab (own node) and spreader (own node)
    b.layer = "Laufkatze"
    TZ = 40.0
    b.pivots["Laufkatze"] = (0.0, BY + 3.0, TZ)
    box(b, "crane_white", -4.6, 4.6, BY + 3.0, BY + 4.4, TZ - 3.0, TZ + 3.0)
    box(b, "frame_black", -2.0, 2.0, BY - 3.2, BY - 0.2, TZ - 1.8, TZ + 0.2)
    box(b, "glass", -1.95, 1.95, BY - 3.1, BY - 0.6, TZ + 0.2, TZ + 0.25)
    box(b, "glass", -1.95, 1.95, BY - 3.22, BY - 3.18, TZ - 1.7, TZ + 0.2)
    b.beam("crane_white", (0.0, BY, TZ - 0.8), (0.0, BY - 0.2, TZ - 0.8), 0.4)
    for x in (-2.5, 2.5):
        for dz in (-1.5, 1.5):
            b.beam("frame_black", (x, BY, TZ + dz), (x * 1.6, 27.0, TZ + dz * 0.7), 0.04)
    b.layer = "Spreader"
    b.pivots["Spreader"] = (0.0, 26.0, TZ)
    box(b, "warn_yellow", -6.1, 6.1, 25.6, 26.4, TZ - 1.2, TZ + 1.2)
    box(b, "warn_yellow", -1.5, 1.5, 26.4, 27.2, TZ - 1.0, TZ + 1.0)
    for x in (-6.1, 6.1):
        for z in (TZ - 1.2, TZ + 1.2):
            box(b, "frame_black", x - 0.2, x + 0.2, 25.2, 25.6, z - 0.2, z + 0.2)
    b.layer = None
    b.anchor("Kabine", (0.0, BY - 3.0, TZ - 0.8), 0)
    b.anchor("Rad_Wasserseite", (0.0, 0.0, G), 0)
    b.anchor("Rad_Landseite", (0.0, 0.0, -G), 0)
    return b


def portalkran():
    """Rubber-tyred gantry (RTG) spanning 6 container rows + truck lane (23.5 m). Pivot centre on the ground."""
    b = B(4210)
    S = 11.75
    for z in (-S, S):
        for x in (-6.0, 6.0):
            box(b, "rtg_blue", x - 0.6, x + 0.6, 1.6, 19.0, z - 0.6, z + 0.6)
            for dx in (-0.9, 0.9):
                cyl_axis(b, "fender", 0.8, 0.6, (x + dx, 0.8, z), "z", 12)
            box(b, "rtg_blue", x - 1.8, x + 1.8, 1.0, 1.8, z - 0.5, z + 0.5)
        box(b, "rtg_blue", -6.6, 6.6, 1.6, 2.6, z - 0.6, z + 0.6)
        box(b, "rtg_blue", -6.6, 6.6, 18.0, 19.5, z - 0.6, z + 0.6)
        b.beam("rtg_blue", (-6.0, 2.6, z), (6.0, 18.0, z), 0.25)
    for x in (-6.0, 6.0):
        box(b, "crane_white", x - 0.8, x + 0.8, 19.5, 21.0, -S - 1.0, S + 1.0)
    box(b, "crane_white", -3.0, 3.0, 21.0, 23.0, S - 3.5, S + 0.5)                                # diesel house
    box(b, "frame_black", -2.9, 2.9, 22.0, 22.6, S + 0.51, S + 0.52)
    b.layer = "Laufkatze"
    b.pivots["Laufkatze"] = (0.0, 21.0, 0.0)
    box(b, "warn_yellow", -6.5, 6.5, 21.0, 22.0, -1.8, 1.8)
    box(b, "frame_black", 2.0, 4.0, 17.8, 20.3, -2.8, -1.0)
    box(b, "glass", 1.95, 4.05, 18.2, 20.0, -2.85, -2.8)
    for x in (-2.5, 2.5):
        b.beam("frame_black", (x, 21.0, 0.0), (x, 14.0, 0.0), 0.04)
    box(b, "warn_yellow", -6.1, 6.1, 13.4, 14.0, -1.2, 1.2)
    b.layer = None
    b.anchor("Fahrspur", (0.0, 0.0, S - 3.0), 0)
    return b


def containerstapler():
    """Reach stacker vehicle. Pivot centre on the ground, front (spreader) +X."""
    b = B(4220)
    box(b, "stacker_yellow", -5.0, 3.0, 0.9, 2.6, -1.9, 1.9)
    box(b, "stacker_yellow", -5.6, -3.5, 2.6, 3.8, -1.8, 1.8)                               # engine + counterweight
    box(b, "frame_black", -5.65, -5.6, 2.8, 3.6, -1.5, 1.5)
    for (x, r) in ((1.6, 0.95), (-3.8, 0.8)):
        for s in (-1, 1):
            for dz in ((0.0,) if x < 0 else (0.0, 0.85)):
                cyl_axis(b, "fender", r, 0.7, (x, r, s * (1.9 + 0.35 + dz)), "z", 12)
    box(b, "frame_black", -1.8, 0.4, 2.6, 5.4, 0.2, 1.9)                                    # cab
    box(b, "glass", -1.75, 0.35, 3.4, 5.2, 1.88, 1.92)
    box(b, "glass", 0.38, 0.42, 3.4, 5.2, 0.25, 1.85)
    box(b, "stacker_yellow", -1.9, 0.5, 5.4, 5.6, 0.1, 2.0)
    b.beam("stacker_yellow", (-4.5, 3.6, -0.6), (6.5, 9.5, -0.6), 0.55)                       # boom
    b.beam("stacker_yellow", (-4.5, 3.6, 0.6), (6.5, 9.5, 0.6), 0.55)
    b.beam("rail_steel", (-0.5, 2.6, 0.0), (2.0, 7.0, 0.0), 0.3)                              # lift cylinder
    box(b, "warn_yellow", 4.8, 8.2, 8.4, 9.2, -6.1, 6.1)                                     # spreader across Z
    for z in (-6.1, 6.1):
        box(b, "frame_black", 6.3, 6.7, 7.9, 8.4, z - 0.2, z + 0.2)
    b.cyl("buoy_orange" if "buoy_orange" in PALETTE else "lamp", 0.12, 0.2, (-1.0, 5.7, 1.0), 8)
    b.anchor("Fahrer", (-0.7, 2.6, 1.0), 90)
    return b


# =====================================================================================  CONTAINER
def container(length):
    def f():
        b = B(4300 + int(length))
        col = b.slot("container", 1, "#C8372D")
        container_block(b, 0.0, 0.0, 0.0, length, col, detail=True)
        x = length / 2 + 0.01                                                                   # door end (+X)
        box(b, col, x - 0.02, x + 0.03, 0.1, 2.49, -1.2, 1.2)
        box(b, "frame_black", x + 0.03, x + 0.04, 0.1, 2.49, -0.01, 0.01)
        for z in (-0.9, -0.45, 0.45, 0.9):
            b.beam("rail_steel", (x + 0.06, 0.2, z), (x + 0.06, 2.4, z), 0.03)
            box(b, "rail_steel", x + 0.04, x + 0.1, 1.15, 1.25, z - 0.12, z + 0.12)
        b.anchor("Tuer", (x + 0.5, 0.0, 0.0), 90)
        b.anchor("Oben", (0.0, 2.59, 0.0), 0)
        return b
    return f


def containerstapel():
    b = B(4320)
    rng = np.random.default_rng(4320)
    for zi in range(5):
        z = -4.88 + zi * 2.44
        h = [3, 4, 2, 4, 3][zi]
        for t in range(h):
            if rng.random() < 0.3:
                for dx in (-3.05, 3.05):
                    container_block(b, dx, t * 2.6, z, 6.06, CONT[int(rng.integers(0, 10))])
            else:
                container_block(b, 0.0, t * 2.6, z, 12.19, CONT[int(rng.integers(0, 10))])
    b.anchor("Oben_Mitte", (0.0, 10.4, 0.0), 0)
    return b


# =====================================================================================  GEBÄUDE + AUSSTATTUNG
def hafenbuero():
    b = B(4400)
    box(b, "concrete_light", -8.5, 8.5, 0, 0.2, -5.5, 5.5)
    box(b, "ship_white", -8.0, 8.0, 0.2, 3.4, -5.0, 5.0)
    box(b, "rtg_blue", -8.05, 8.05, 3.4, 6.6, -5.05, 5.05)
    for x in np.arange(-7.0, 7.5, 2.0):
        box(b, "glass", x - 0.7, x + 0.7, 1.0, 2.8, 5.0, 5.05)
        box(b, "glass", x - 0.7, x + 0.7, 4.2, 5.9, 5.05, 5.1)
    box(b, "glass_shop", -1.2, 1.2, 0.2, 2.8, 5.0, 5.06)
    box(b, "dach", -8.3, 8.3, 6.6, 6.9, -5.3, 5.3)
    for x in (-5.0, -1.0, 3.0):
        box(b, "ac", x - 0.6, x + 0.6, 6.9, 7.7, -2.0, -1.0)
    b.beam("metal", (6.5, 6.9, -3.0), (6.5, 14.0, -3.0), 0.06)
    for k in range(8):                                                                       # exterior stair to the 1st floor
        y = 0.2 + k * 0.4
        box(b, "rail_steel", 8.0, 9.2, y, y + 0.08, 4.0 - k * 0.5, 4.5 - k * 0.5)
    box(b, "rail_steel", 8.0, 9.2, 3.4, 3.5, -1.0, 0.0)
    box(b, "frame_black", -6.5, 6.5, 6.9, 8.4, 4.6, 4.8)
    b.text("TERMINAL RIOMAR", ["paint_white"] * 15, (0.0, 7.65, 4.8), 0.75, 0.04, simplify=0.012)
    b.anchor("Eingang", (0.0, 0.2, 6.0), 0)
    return b


def hafentor():
    b = B(4410)
    box(b, "concrete_light", -1.2, 1.2, 0, 0.25, -4.0, 4.0)                                  # middle island
    box(b, "ship_white", -1.0, 1.0, 0.25, 2.9, -1.5, 1.5)                                    # guard booth
    for s in (-1, 1):
        box(b, "glass", s * 1.0 - 0.03, s * 1.0 + 0.03, 1.1, 2.4, -1.3, 1.3)
    box(b, "dach", -1.3, 1.3, 2.9, 3.1, -1.8, 1.8)
    box(b, "rtg_blue", -12.5, 12.5, 6.0, 6.8, -3.0, 3.0)                                     # canopy over both lanes
    for x in (-12.0, -1.0, 1.0, 12.0):
        box(b, "rail_steel", x - 0.2, x + 0.2, 0.0, 6.0, -0.2, 0.2)
    for x in (-9.0, -4.0, 4.0, 9.0):
        box(b, "lamp", x - 1.0, x + 1.0, 5.95, 6.0, -0.3, 0.3)
    box(b, "frame_black", -6.0, 6.0, 6.8, 8.0, 2.9, 3.0)
    b.text("PORTÃO 1 · TERMINAL RIOMAR", ["paint_white"] * 26, (0.0, 7.4, 3.0), 0.5, 0.03, simplify=0.01)
    for s in (-1, 1):                                                                        # barrier arms (own nodes)
        name = f"Schranke_{1 if s < 0 else 2}"
        b.layer = name
        b.pivots[name] = (s * 1.3, 1.0, s * 1.8)
        box(b, "ship_white", s * 1.3 - 0.2, s * 1.3 + 0.2, 0.25, 1.2, s * 1.8 - 0.2, s * 1.8 + 0.2)
        for k in range(8):
            box(b, "lighthouse_red" if k % 2 == 0 else "hull_white", s * (1.5 + k * 1.2), s * (1.5 + (k + 1) * 1.2), 1.0, 1.15, s * 1.8 - 0.06, s * 1.8 + 0.06)
        b.layer = None
    for s in (-1, 1):
        box(b, "concrete_light", s * 12.0 - 0.3, s * 12.0 + 0.3, 0, 0.8, -4.0, 4.0)
        box(b, "warn_yellow", s * 12.0 - 0.31, s * 12.0 + 0.31, 0.3, 0.6, -4.0, 4.0)
    b.anchor("Wachmann", (0.0, 0.25, 0.0), 0)
    b.anchor("Spur_Rein", (-6.0, 0.0, 0.0), 0)
    b.anchor("Spur_Raus", (6.0, 0.0, 0.0), 180)
    b.anchor("Zaun_W", (-12.3, 0.0, 0.0), -90)
    b.anchor("Zaun_O", (12.3, 0.0, 0.0), 90)
    return b


def zaun():
    b = B(4420)
    box(b, "concrete_light", -12.0, 12.0, 0, 0.3, -0.15, 0.15)
    for x in np.arange(-12.0, 12.01, 3.0):
        b.beam("rail_steel", (x, 0.0, 0.0), (x, 3.0, 0.0), 0.06)
        b.beam("rail_steel", (x, 3.0, 0.0), (x, 3.5, -0.35), 0.04)
    box(b, "fence_net", -12.0, 12.0, 0.3, 3.0, -0.01, 0.01)
    for y in (0.3, 1.6, 3.0):
        b.beam("rail_steel", (-12.0, y, 0.0), (12.0, y, 0.0), 0.03)
    for k in range(3):
        y, z = 3.15 + k * 0.17, -0.12 - k * 0.11
        b.beam("frame_black", (-12.0, y, z), (12.0, y, z), 0.012)
    box(b, "cloth_white", -0.6, 0.6, 1.6, 2.3, 0.02, 0.04)
    box(b, "lighthouse_red", -0.6, 0.6, 2.1, 2.3, 0.04, 0.05)
    b.text("ÁREA RESTRITA", ["lighthouse_red"] * 13, (0.0, 1.85, 0.04), 0.13, 0.01, simplify=0.004)
    b.anchor("Anschluss_W", (-12.0, 0.0, 0.0), -90)
    b.anchor("Anschluss_O", (12.0, 0.0, 0.0), 90)
    return b


def flutlichtmast():
    b = B(4430)
    box(b, "concrete_light", -1.2, 1.2, 0, 0.6, -1.2, 1.2)
    b.hull("rail_steel", [(0.6 * np.cos(a), 0.6, 0.6 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] + [(0.3 * np.cos(a), 34.0, 0.3 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]])
    box(b, "rail_steel", -2.2, 2.2, 34.0, 34.3, -2.2, 2.2)
    railing(b, [(-2.1, -2.1), (2.1, -2.1), (2.1, 2.1), (-2.1, 2.1), (-2.1, -2.1)], 34.3, 1.0, "rail_steel", 2.1)
    for k in range(8):
        a = k * np.pi / 4
        x, z = 1.8 * np.cos(a), 1.8 * np.sin(a)
        yaw = np.degrees(np.arctan2(np.cos(a), np.sin(a)))
        b.box("frame_black", (1.0, 0.7, 0.3), (x, 35.6, z), rot_y=yaw, rot_x=30)
        b.box("lamp", (0.9, 0.6, 0.04), (x * 1.08, 35.5, z * 1.08), rot_y=yaw, rot_x=30)
    ladder(b, 0.0, 0.65, 0.6, 34.3, "rail_steel", 0.45)
    b.cyl("led_red", 0.15, 0.3, (0.0, 37.0, 0.0), 8)
    b.beam("rail_steel", (0.0, 34.3, 0.0), (0.0, 36.85, 0.0), 0.04)
    return b


HAFEN = [
    ("01_containerschiff", "Containerschiff RIOMAR ATLÂNTICO (300 m)", "Schiffe", containerschiff),
    ("02_schlepper", "Schlepper", "Schiffe", schlepper),
    ("03_kaikante_24", "Kaikante 24 m", "Kai", kai_tile(24.0)),
    ("04_kaikante_12", "Kaikante 12 m", "Kai", kai_tile(12.0)),
    ("05_kaikante_ecke", "Kaikante Ecke (außen)", "Kai", kai_tile(36.0, corner=True)),
    ("06_molenkopf", "Molenkopf mit Leuchtturm", "Kai", molenkopf),
    ("07_hafenflaeche", "Hafenfläche / Stellplätze", "Kai", hafenflaeche),
    ("08_containerkran", "Containerbrücke (STS-Kran)", "Kräne", containerkran),
    ("09_portalkran", "Portalkran (RTG)", "Kräne", portalkran),
    ("10_containerstapler", "Containerstapler", "Kräne", containerstapler),
    ("11_container_20", "Container 20 Fuß", "Container", container(6.06)),
    ("12_container_40", "Container 40 Fuß", "Container", container(12.19)),
    ("13_containerstapel", "Containerstapel", "Container", containerstapel),
    ("14_hafenbuero", "Hafenbüro", "Gebäude", hafenbuero),
    ("15_hafentor", "Hafentor mit Wachhaus", "Gebäude", hafentor),
    ("16_zaun", "Hafenzaun 24 m", "Gebäude", zaun),
    ("17_flutlichtmast", "Flutlichtmast 35 m", "Gebäude", flutlichtmast),
]
# Megayacht SOBERANA: jetzt im Heist-Paket (build_heists.py)
