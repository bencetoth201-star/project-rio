"""20 Strandobjekte für Copacabana/Ipanema im Stil der Rio-Häuser.
Konvention: Y oben, Meter, Pivot = Mitte am Boden (Sand y = 0), Vorderseite +Z (zum Meer hin bzw. zum Spieler).
Farb-Slots slot_accent_* (Schirme, Tücher) lassen sich würfeln."""
import numpy as np
import trimesh
from lib import B, PALETTE

PALETTE.update({
    "beach_sand": "#E9D4A4", "sand_wet": "#C9AE7C", "coconut": "#6B4423", "coconut_green": "#5E8C2E",
    "lifeguard_red": "#D7322B", "lifeguard_yellow": "#F4C430", "buoy_orange": "#F26A1B", "wood_bleached": "#C9B08A",
    "ice_pink": "#F4A6C1", "ice_choc": "#6B3E26", "ice_vanilla": "#F6E7C1", "cone": "#C98A3E", "cooler_white": "#F2F2EE",
    "boat_blue": "#2F6DB5", "boat_red": "#C8372D", "net_rope": "#D9CFB8", "mat_green": "#2F5E3A", "bike_orange": "#F07A22",
    "canvas": "#F3EBD8", "sunscreen": "#F6B73C", "ball_white": "#F5F5F5", "ball_yellow": "#F2D23C", "kiosk_green": "#2E8B57",
})


def box(b, mat, x0, x1, y0, y1, z0, z1, **kw):
    b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)


def sphere(b, mat, r, c, sub=1, scale=(1, 1, 1)):
    m = trimesh.creation.icosphere(subdivisions=sub, radius=r)
    m.apply_scale(scale)
    b.add(mat, m.apply_translation(c))


def ring(b, mat, R, r, c, axis="y", sections=12):
    m = trimesh.creation.torus(major_radius=R, minor_radius=r, major_sections=sections, minor_sections=5)
    if axis == "x":
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    elif axis == "y":
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    b.add(mat, m.apply_translation(c))


def umbrella(b, x, z, mat_a, mat_b="cloth_white", h=2.3, r=1.4, tilt=0.0):
    b.beam("metal", (x, 0.0, z), (x + tilt, h, z), 0.03)
    top = np.array([x + tilt, h + 0.35, z])
    for k in range(8):
        a0, a1 = k * np.pi / 4, (k + 1) * np.pi / 4
        p0 = np.array([x + tilt + r * np.cos(a0), h - 0.05, z + r * np.sin(a0)])
        p1 = np.array([x + tilt + r * np.cos(a1), h - 0.05, z + r * np.sin(a1)])
        b.hull(mat_a if k % 2 == 0 else mat_b, [top, p0, p1, top + [0, -0.03, 0], p0 + [0, -0.03, 0], p1 + [0, -0.03, 0]])


def beach_chair(b, x, z, rot, mat):
    """Folding aluminium beach chair (cadeira de praia)."""
    r = np.radians(rot)
    def P(dx, y, dz):
        return (x + dx * np.cos(r) + dz * np.sin(r), y, z - dx * np.sin(r) + dz * np.cos(r))
    for sx in (-0.25, 0.25):
        b.beam("metal", P(sx, 0.0, 0.25), P(sx, 0.35, -0.15), 0.015)
        b.beam("metal", P(sx, 0.0, -0.2), P(sx, 0.8, -0.45), 0.015)
    b.hull(mat, [P(sx, 0.33, dz) for sx in (-0.24, 0.24) for dz in (0.2, -0.2)] + [P(sx, 0.31, dz) for sx in (-0.24, 0.24) for dz in (0.2, -0.2)])
    b.hull(mat, [P(sx, y, dz) for sx in (-0.24, 0.24) for (y, dz) in ((0.33, -0.2), (0.82, -0.42))] + [P(sx, 0.8, -0.44) for sx in (-0.24, 0.24)])


def cooler(b, x, z, w=0.55, h=0.4, d=0.35, mat="cooler_white", rot=0.0):
    b.box(mat, (w, h, d), (x, h / 2, z), rot_y=rot)
    b.box("boat_blue", (w + 0.02, 0.06, d + 0.02), (x, h + 0.03, z), rot_y=rot)


# ===================================================================== NATUR
def kokospalme():
    b = B(3001)
    b.palm(0, 0, 9.0, (0.9, 0.3))
    for k in range(4):
        a = k * np.pi / 2 + 0.4
        sphere(b, "coconut" if k % 2 else "coconut_green", 0.16, (0.9 + 0.3 * np.cos(a), 8.75, 0.3 + 0.3 * np.sin(a)), 1)
    sphere(b, "coconut", 0.15, (0.6, 0.12, 0.9), 1, (1, 0.8, 1))
    b.rock("beach_sand", 0.7, (0, 0.0, 0), 0.25)
    return b


def palmengruppe():
    b = B(3002)
    for (x, z, h, lean) in [(-1.6, -0.8, 10.5, (-1.2, -0.4)), (0.9, -1.2, 8.0, (1.0, -0.6)), (0.2, 1.3, 6.5, (0.5, 1.1))]:
        b.palm(x, z, h, lean)
        for k in range(3):
            a = k * 2.1
            sphere(b, "coconut", 0.15, (x + lean[0] + 0.28 * np.cos(a), h - 0.25, z + lean[1] + 0.28 * np.sin(a)), 1)
    for (x, z, r) in [(-0.5, 0.2, 0.6), (1.6, 0.6, 0.45), (-1.9, 1.0, 0.4)]:
        b.rock("hedge", r, (x, r * 0.3, z), 0.6)
    return b


def haengematte():
    b = B(3019)
    for x, lean in ((-2.2, (-0.7, 0.2)), (2.2, (0.8, -0.2))):
        b.palm(x, 0, 7.0, lean)
    acc = b.slot("accent", 1, "#E8893A")
    pts = []
    for i in range(9):
        f = i / 8
        x = -2.0 + 4.0 * f
        y = 1.5 - 0.75 * np.sin(np.pi * f)
        pts.append((x, y))
    for i in range(8):
        (x0, y0), (x1, y1) = pts[i], pts[i + 1]
        mat = acc if i % 2 == 0 else "cloth_white"
        b.hull(mat, [(x, y + dy, z) for (x, y) in ((x0, y0), (x1, y1)) for dy in (0, 0.04) for z in (-0.45 + 0.15 * abs(np.sin(np.pi * i / 8)), 0.45 - 0.15 * abs(np.sin(np.pi * i / 8)))])
    for s in (-1, 1):
        b.beam("net_rope", (s * 2.0, 1.5, 0.0), (s * 2.2, 1.9, 0.0), 0.03)
    b.anchor("Liegen", (0, 0.8, 0), 0)
    return b


# ===================================================================== RETTUNG
def rettungsturm():
    """Wooden lifeguard tower on stilts, ramp to the front, red hut, flags."""
    b = B(3003)
    PH = 2.4                                                                       # platform height
    for x in (-1.4, 1.4):
        for z in (-1.4, 1.4):
            b.beam("wood_bleached", (x * 1.1, 0, z * 1.1), (x, PH, z), 0.16)
    for (a, c) in [((-1.4, -1.4), (1.4, 1.4)), ((1.4, -1.4), (-1.4, 1.4))]:
        b.beam("wood_bleached", (a[0] * 1.05, 0.3, a[1] * 1.05), (c[0], PH - 0.2, c[1]), 0.07)
    box(b, "wood_bleached", -1.9, 1.9, PH, PH + 0.15, -1.9, 1.9)                    # deck
    for k, x in enumerate(np.arange(-1.85, 1.9, 0.3)):
        box(b, "wood_dark", x, x + 0.02, PH + 0.15, PH + 0.152, -1.9, 1.9)
    # hut
    HW, HD, HH = 1.3, 1.1, 2.3
    y0 = PH + 0.15
    box(b, "lifeguard_red", -HW, HW, y0, y0 + 0.9, -HD, HD)
    box(b, "lifeguard_red", -HW, HW, y0 + 0.9, y0 + HH, -HD, -HD + 0.1)
    box(b, "glass", -HW + 0.1, HW - 0.1, y0 + 0.95, y0 + HH - 0.15, HD - 0.06, HD - 0.02)  # sea-facing window
    for x in (-HW, HW):
        box(b, "glass", x - 0.03, x + 0.03, y0 + 0.95, y0 + HH - 0.15, -HD + 0.1, HD - 0.1)
    for (x, z) in [(-HW, -HD), (HW, -HD), (-HW, HD), (HW, HD)]:
        box(b, "lifeguard_red", x - 0.07, x + 0.07, y0 + 0.9, y0 + HH, z - 0.07, z + 0.07)
    box(b, "lifeguard_red", -HW, HW, y0 + HH - 0.15, y0 + HH, HD - 0.08, HD)
    b.hull("lifeguard_yellow", [(x, y0 + HH, z) for x in (-HW - 0.5, HW + 0.5) for z in (-HD - 0.5, HD + 0.6)] +
           [(x, y0 + HH + 0.12, z) for x in (-HW - 0.5, HW + 0.5) for z in (-HD - 0.5, HD + 0.6)] + [(0, y0 + HH + 0.7, 0)])
    # SALVA-VIDAS sign + red cross
    box(b, "cloth_white", -1.2, 1.2, y0 + 0.3, y0 + 0.75, HD + 0.01, HD + 0.03)
    b.text("SALVA-VIDAS", ["lifeguard_red"] * 11, (0.0, y0 + 0.53, HD + 0.03), 0.2, 0.02, simplify=0.008)
    # deck railing
    for (a, c) in [((-1.9, 1.9), (1.9, 1.9)), ((-1.9, -1.9), (-1.9, 1.9)), ((1.9, -1.9), (1.9, 1.9)), ((-1.9, -1.9), (-0.6, -1.9)), ((0.6, -1.9), (1.9, -1.9))]:
        for y in (y0 + 0.5, y0 + 1.0):
            b.beam("wood_bleached", (a[0], y, a[1]), (c[0], y, c[1]), 0.05)
    for (x, z) in [(-1.9, 1.9), (1.9, 1.9), (-1.9, -1.9), (1.9, -1.9), (0, 1.9), (-0.6, -1.9), (0.6, -1.9)]:
        b.beam("wood_bleached", (x, y0, z), (x, y0 + 1.05, z), 0.06)
    # ramp to the back (land side, -Z) – the hut faces the sea (+Z)
    b.hull("wood_bleached", [(x, y, z) for x in (-0.55, 0.55) for (y, z) in ((PH + 0.15, -1.9), (0.0, -7.0), (PH, -1.9), (-0.05, -7.0))])
    for z in np.arange(-6.6, -2.0, 0.45):
        y = (PH + 0.15) * (1 - (-z - 1.9) / 5.1)
        box(b, "wood_dark", -0.55, 0.55, y, y + 0.04, z - 0.03, z + 0.03)
    for s in (-1, 1):
        b.beam("wood_bleached", (s * 0.6, PH + 1.15, -1.9), (s * 0.6, 1.0, -7.0), 0.05)
        b.beam("wood_bleached", (s * 0.6, 0.0, -7.0), (s * 0.6, 1.0, -7.0), 0.06)
    # flag pole with red/yellow flags, life ring, rescue board, buoy
    b.beam("metal", (1.75, y0, 1.75), (1.75, y0 + 5.0, 1.75), 0.04)
    box(b, "lifeguard_red", 1.78, 2.9, y0 + 4.2, y0 + 4.95, 1.74, 1.76)
    box(b, "lifeguard_yellow", 1.78, 2.9, y0 + 3.4, y0 + 4.15, 1.74, 1.76)
    ring(b, "buoy_orange", 0.32, 0.07, (-HW - 0.06, y0 + 1.3, 0.0), axis="x")
    b.box("lifeguard_red", (0.55, 0.08, 3.0), (2.25, 1.3, -0.5), rot_x=-60, rot_z=-12)        # rescue board leaning
    b.box("buoy_orange", (0.25, 0.15, 0.8), (-2.3, 0.6, 0.4), rot_z=70)                    # rescue tube
    b.box("frame_black", (0.12, 0.12, 0.22), (0.6, y0 + 1.0, HD + 0.1))                    # binoculars on the sill
    b.anchor("Rettungsschwimmer", (0, y0, 0), 0)
    b.anchor("Rampe_Unten", (0, 0, -7.0), 180)
    return b


def duschen():
    b = B(3013)
    box(b, "tile_blue" if "tile_blue" in PALETTE else "concrete_light", -1.6, 1.6, 0, 0.08, -1.0, 1.0)
    box(b, "frame_black", -0.4, 0.4, 0.08, 0.09, -0.15, 0.15)
    for x in (-0.9, 0.9):
        b.cyl("metal", 0.06, 2.4, (x, 1.28, -0.6), 8)
        b.beam("metal", (x, 2.45, -0.6), (x, 2.45, -0.15), 0.035)
        b.cyl("metal", 0.12, 0.06, (x, 2.4, -0.12), 10)
        box(b, "metal", x - 0.08, x + 0.08, 1.0, 1.15, -0.55, -0.48)
    b.cyl("metal", 0.05, 0.6, (0.0, 0.38, 0.75), 8)                                  # foot tap
    b.beam("metal", (0.0, 0.62, 0.75), (0.0, 0.62, 0.55), 0.025)
    b.beam("metal", (-0.9, 2.45, -0.66), (0.9, 2.45, -0.66), 0.035)
    box(b, "cloth_white", -0.5, 0.5, 2.0, 2.4, -0.68, -0.64)
    b.text("DUCHA", ["boat_blue"] * 5, (0.0, 2.2, -0.64), 0.22, 0.01, simplify=0.006)
    b.anchor("Duschen", (0, 0.08, 0), 0)
    return b


def muell_flagge():
    b = B(3017)
    b.cyl("metal", 0.05, 1.0, (-0.6, 0.5, 0), 8)
    b.cyl("buoy_orange", 0.3, 0.7, (-0.6, 0.65, 0.33), 12)
    b.cyl("frame_black", 0.32, 0.06, (-0.6, 1.03, 0.33), 12)
    b.cyl("metal", 0.04, 5.0, (0.8, 2.5, 0), 8)                                      # red flag = dangerous currents
    box(b, "lifeguard_red", 0.84, 1.9, 4.2, 4.9, -0.01, 0.01)
    b.beam("metal", (0.0, 0.0, -0.3), (0.0, 2.2, -0.3), 0.04)
    box(b, "cloth_white", -0.55, 0.55, 1.6, 2.4, -0.27, -0.24)
    box(b, "lifeguard_red", -0.55, 0.55, 2.25, 2.4, -0.24, -0.23)
    b.text("PERIGO", ["lifeguard_red"] * 6, (0.0, 2.0, -0.24), 0.2, 0.01, simplify=0.006)
    b.text("CORRENTEZA", ["frame_black"] * 10, (0.0, 1.75, -0.24), 0.12, 0.01, simplify=0.004)
    b.anchor("Muell", (-0.6, 0, 0.8), 0)
    return b


# ===================================================================== ESSEN & TRINKEN
def strandkiosk():
    """Copacabana-style quiosque: octagonal glass kiosk, round roof, tables with umbrellas."""
    b = B(3004)
    R = 1.8
    sides = 8
    th = np.linspace(0, 2 * np.pi, sides + 1)
    b.hull("concrete_light", [(1.3 * R * np.cos(t), y, 1.3 * R * np.sin(t)) for t in th[:-1] for y in (0, 0.12)])
    for k in range(sides):
        a, c = th[k], th[k + 1]
        p0, p1 = np.array([R * np.cos(a), 0, R * np.sin(a)]), np.array([R * np.cos(c), 0, R * np.sin(c)])
        mid = (p0 + p1) / 2
        yaw = np.degrees(np.arctan2(mid[0], mid[2]))
        w = np.linalg.norm(p1 - p0)
        b.box("kiosk_green", (w, 1.0, 0.1), tuple(mid + [0, 0.62, 0]), rot_y=yaw)
        b.box("bar_top" if "bar_top" in PALETTE else "counter", (w + 0.05, 0.06, 0.4), tuple(mid * 1.05 + [0, 1.15, 0]), rot_y=yaw)
        b.box("glass_shop", (w, 1.2, 0.04), tuple(mid + [0, 1.8, 0]), rot_y=yaw)
        b.beam("frame_black", tuple(p0 + [0, 0.12, 0]), tuple(p0 + [0, 2.45, 0]), 0.05)
    b.hull("plastic_white", [(2.6 * np.cos(t), y, 2.6 * np.sin(t)) for t in np.linspace(0, 2 * np.pi, 17)[:-1] for y in (2.45, 2.65)] + [(0, 2.9, 0)])
    box(b, "kiosk_green", -1.5, 1.5, 2.9, 3.5, -0.05, 0.05)
    b.text("QUIOSQUE", ["cloth_white"] * 8, (0.0, 3.2, 0.05), 0.35, 0.02, simplify=0.01)
    b.text("QUIOSQUE", ["cloth_white"] * 8, (0.0, 3.2, -0.05), 0.35, 0.02, rot_y=180, simplify=0.01)
    box(b, "fridge", -0.6, 0.6, 0.12, 1.5, -1.1, -0.7)
    for (x, z) in [(-3.6, 1.5), (3.6, 1.5), (0.0, 3.6)]:
        b.cyl("plastic_white", 0.4, 0.04, (x, 0.72, z), 10)
        b.cyl("plastic_white", 0.04, 0.72, (x, 0.36, z), 6)
        for a in (0, 2.1, 4.2):
            beach_chair(b, x + 0.75 * np.cos(a), z + 0.75 * np.sin(a), np.degrees(-a) - 90, "plastic_white")
        umbrella(b, x, z, b.slot("accent", 2, "#C8372D"), "cloth_white", h=2.2, r=1.2)
    b.anchor("Kaufen", (0, 0.12, 2.6), 0)
    return b


def eisladen():
    b = B(3005)
    box(b, "concrete_light", -1.5, 1.5, 0, 0.1, -1.2, 1.6)
    box(b, "ice_pink", -1.3, 1.3, 0.1, 1.0, -1.0, 1.0)
    box(b, "cloth_white", -1.3, 1.3, 1.0, 2.5, -1.0, -0.9)
    for x in (-1.3, 1.3):
        box(b, "cloth_white", x - 0.05, x + 0.05, 1.0, 2.5, -1.0, 1.0)
    box(b, "glass_shop", -1.2, 1.2, 1.0, 1.35, 0.6, 1.0)                              # freezer with tubs
    for k, x in enumerate(np.arange(-1.0, 1.1, 0.4)):
        box(b, ["ice_pink", "ice_choc", "ice_vanilla", "kiosk_green", "lifeguard_yellow", "boat_blue"][k], x - 0.15, x + 0.15, 1.0, 1.08, 0.7, 0.9)
    box(b, "cloth_white", -1.35, 1.35, 1.0, 1.05, 0.55, 1.05)
    for k in range(8):                                                                # striped awning
        x0 = -1.5 + k * 3.0 / 8
        b.hull("ice_pink" if k % 2 == 0 else "cloth_white", [(x, y, z) for x in (x0, x0 + 3.0 / 8) for (y, z) in ((2.5, 0.9), (2.2, 1.7), (2.53, 0.9), (2.23, 1.7))])
    box(b, "ice_pink", -1.4, 1.4, 2.5, 2.7, -1.05, 1.0)
    b.text("SORVETES", ["cloth_white"] * 8, (0.0, 2.95, 0.4), 0.4, 0.06, simplify=0.01)
    box(b, "ice_pink", -1.0, 1.0, 2.7, 3.2, 0.3, 0.4)
    # giant cone on the roof
    b.hull("cone", [(0.0, 2.7, -0.4)] + [(0.45 * np.cos(a), 3.9, -0.4 + 0.45 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]])
    for (y, m, r) in [(4.1, "ice_vanilla", 0.5), (4.6, "ice_pink", 0.45), (5.05, "ice_choc", 0.38)]:
        sphere(b, m, r, (0.0, y, -0.4), 1)
    sphere(b, "lifeguard_red", 0.1, (0.0, 5.45, -0.4), 1)
    for x in (-2.4, 2.4):                                                             # bench seats
        box(b, "wood_a", x - 0.6, x + 0.6, 0.42, 0.48, 0.9, 1.3)
        for dx in (-0.5, 0.5):
            box(b, "metal", x + dx - 0.03, x + dx + 0.03, 0, 0.42, 1.05, 1.15)
    b.anchor("Kaufen", (0, 0.1, 1.9), 0)
    return b


def eiswagen():
    b = B(3006)
    box(b, "cooler_white", -0.6, 0.6, 0.55, 1.35, -0.4, 0.4)
    box(b, "boat_blue", -0.62, 0.62, 1.35, 1.45, -0.42, 0.42)
    box(b, "boat_blue", -0.61, 0.61, 0.75, 0.95, 0.4, 0.42)
    b.text("PICOLÉ", ["cloth_white"] * 6, (0.0, 0.85, 0.42), 0.16, 0.01, simplify=0.005)
    for x in (-0.55, 0.55):
        ring(b, "rubber", 0.3, 0.05, (x, 0.35, 0.0), axis="x")
        b.beam("metal", (x, 0.35, 0.0), (x * 0.9, 0.55, 0.0), 0.03)
    b.beam("metal", (0.0, 0.55, -0.4), (0.0, 0.6, -1.5), 0.035)                      # rear bike part
    ring(b, "rubber", 0.33, 0.05, (0.0, 0.38, -1.6), axis="x")
    b.beam("metal", (0.0, 0.38, -1.6), (0.0, 0.95, -1.4), 0.03)
    box(b, "frame_black", -0.12, 0.12, 0.95, 1.0, -1.55, -1.3)
    b.beam("metal", (0.0, 1.45, 0.0), (0.0, 2.2, 0.0), 0.025)
    umbrella(b, 0.0, 0.0, "boat_blue", "cloth_white", h=2.3, r=0.9)
    b.anchor("Kaufen", (0, 0, 0.9), 0)
    return b


def kokos_stand():
    b = B(3015)
    box(b, "wood_a", -1.0, 1.0, 0, 0.9, -0.5, 0.5)
    box(b, "wood_dark", -1.05, 1.05, 0.9, 0.96, -0.55, 0.55)
    for k in range(22):
        x, z = b.rng.uniform(-0.85, 0.85), b.rng.uniform(-0.4, 0.4)
        sphere(b, "coconut_green", 0.16, (x, 1.08 + 0.12 * (k // 10), z), 0, (1, 0.9, 1))
    box(b, "cloth_white", -0.9, 0.9, 0.3, 0.75, 0.5, 0.52)
    b.text("COCO GELADO", ["kiosk_green"] * 11, (0.0, 0.52, 0.52), 0.18, 0.01, simplify=0.005)
    cooler(b, 1.5, 0.0, 0.7, 0.5, 0.45)
    umbrella(b, -0.2, 0.0, "kiosk_green", "lifeguard_yellow", h=2.4, r=1.5)
    b.cyl("plastic_white", 0.05, 0.25, (0.6, 1.08, 0.3), 6)
    b.anchor("Kaufen", (0, 0, 1.0), 0)
    return b


def barraca():
    """Vendor tent with chair stacks, coolers and hanging cangas (sarongs)."""
    b = B(3009)
    for x in (-1.5, 1.5):
        for z in (-1.5, 1.5):
            b.beam("metal", (x, 0, z), (x, 2.4, z), 0.04)
    b.hull("canvas", [(x, 2.4, z) for x in (-1.7, 1.7) for z in (-1.7, 1.7)] + [(x, 2.48, z) for x in (-1.7, 1.7) for z in (-1.7, 1.7)] + [(0, 2.9, 0)])
    for s in (-1, 1):
        box(b, "canvas", -1.7, 1.7, 2.1, 2.4, s * 1.7 - 0.01, s * 1.7 + 0.01)
    box(b, "cloth_white", -1.2, 1.2, 2.1, 2.38, 1.72, 1.74)
    b.text("BARRACA 12", ["boat_red"] * 10, (0.0, 2.24, 1.74), 0.2, 0.01, simplify=0.006)
    box(b, "wood_a", -1.2, 1.2, 0.78, 0.84, -1.3, -0.6)                              # table with drinks
    for x in (-1.1, 1.1):
        box(b, "metal", x - 0.02, x + 0.02, 0, 0.78, -0.95, -0.95 + 0.04)
    for k, x in enumerate(np.arange(-1.0, 1.1, 0.25)):
        b.cyl(["glass", "kiosk_green", "lifeguard_yellow", "boat_red"][k % 4], 0.04, 0.24, (x, 0.96, -1.0), 6)
    for i, x in enumerate((-1.1, -0.5)):                                               # chair stacks
        for k in range(5):
            b.box(["boat_blue", "lifeguard_yellow", "kiosk_green", "boat_red", "cloth_white"][(k + i) % 5], (0.5, 0.04, 0.5), (x, 0.25 + k * 0.08, 0.9), rot_x=-8)
        b.beam("metal", (x - 0.25, 0.0, 1.1), (x - 0.25, 0.65, 0.85), 0.015)
        b.beam("metal", (x + 0.25, 0.0, 1.1), (x + 0.25, 0.65, 0.85), 0.015)
    cooler(b, 0.6, 0.6, 0.7, 0.5, 0.45)
    cooler(b, 1.1, 0.0, 0.55, 0.4, 0.35)
    b.beam("net_rope", (-1.5, 2.05, -1.5), (1.5, 2.05, -1.5), 0.015)                   # cangas on a line
    for k, x in enumerate(np.arange(-1.3, 1.35, 0.45)):
        box(b, ["boat_blue", "ice_pink", "lifeguard_yellow", "kiosk_green", "buoy_orange", "boat_red"][k % 6], x - 0.2, x + 0.2, 1.0, 2.04, -1.52, -1.5)
    b.anchor("Kaufen", (0, 0, 2.3), 0)
    b.anchor("Stuehle_Mieten", (-0.8, 0, 1.6), 0)
    return b


# ===================================================================== FREIZEIT
def sandburg():
    b = B(3007)
    b.add("sand_wet", trimesh.creation.annulus(r_min=1.35, r_max=1.75, height=0.04, sections=20)
          .apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0])).apply_translation((0, 0.0, 0)))
    b.hull("beach_sand", [(1.3 * np.cos(a), 0, 1.3 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 13)[:-1]] + [(1.0 * np.cos(a), 0.25, 1.0 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 13)[:-1]])
    box(b, "beach_sand", -0.8, 0.8, 0.25, 0.65, -0.8, 0.8)                            # walls
    box(b, "sand_wet", -0.2, 0.2, 0.25, 0.55, 0.79, 0.82)                             # gate
    for x in np.arange(-0.75, 0.8, 0.3):
        for z in (-0.8, 0.8):
            box(b, "beach_sand", x - 0.07, x + 0.07, 0.65, 0.78, z - 0.06, z + 0.06)
    box(b, "beach_sand", -0.35, 0.35, 0.65, 1.25, -0.35, 0.35)                        # keep
    for x in np.arange(-0.3, 0.35, 0.2):
        for z in (-0.33, 0.33):
            box(b, "beach_sand", x - 0.05, x + 0.05, 1.25, 1.35, z - 0.04, z + 0.04)
    for (x, z) in [(-0.8, -0.8), (0.8, -0.8), (-0.8, 0.8), (0.8, 0.8)]:
        b.cyl("beach_sand", 0.22, 0.75, (x, 0.25 + 0.375, z), 8)
        b.hull("beach_sand", [(x + 0.25 * np.cos(a), 1.0, z + 0.25 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] + [(x, 1.4, z)])
    b.beam("wood_dark", (0, 1.25, 0), (0, 1.9, 0), 0.015)
    box(b, "lifeguard_red", 0.01, 0.3, 1.7, 1.88, -0.005, 0.005)
    b.cyl("boat_red", 0.14, 0.25, (1.9, 0.13, 0.8), 10)                                # bucket + shovel
    b.box("boat_blue", (0.08, 0.02, 0.45), (2.0, 0.02, 0.2), rot_y=30)
    b.box("boat_blue", (0.16, 0.02, 0.18), (2.12, 0.02, -0.04), rot_y=30)
    return b


def sonnenschirm_set():
    b = B(3008)
    umbrella(b, 0.0, 0.0, b.slot("accent", 1, "#EBC03F"), "cloth_white", h=2.3, r=1.5, tilt=0.15)
    beach_chair(b, -0.55, 0.6, 0, b.slot("accent", 3, "#2E5FA8"))
    beach_chair(b, 0.55, 0.6, 0, b.slot("accent", 3, "#2E5FA8"))
    cooler(b, 1.3, -0.3)
    b.anchor("Sitz_1", (-0.55, 0.33, 0.6), 0)
    b.anchor("Sitz_2", (0.55, 0.33, 0.6), 0)
    return b


def strandtuch_set():
    b = B(3016)
    acc = b.slot("accent", 1, "#C8372D")
    acc2 = b.slot("accent", 2, "#3E7D4F")
    for (x, mat, mat2) in ((-0.6, acc, "cloth_white"), (0.7, acc2, "lifeguard_yellow")):
        for k in range(6):
            box(b, mat if k % 2 == 0 else mat2, x - 0.45, x + 0.45, 0, 0.015, -0.9 + k * 0.3, -0.6 + k * 0.3)
    b.rock("boat_blue", 0.25, (1.5, 0.15, -0.6), 0.7)                                 # bag
    cooler(b, -1.5, -0.4, 0.45, 0.35, 0.3)
    for dx in (-0.06, 0.06):
        box(b, "lifeguard_yellow", -1.3 + dx - 0.05, -1.3 + dx + 0.05, 0, 0.025, 0.7, 0.95)
    b.cyl("sunscreen", 0.04, 0.18, (0.1, 0.09, -0.7), 8)
    sphere(b, "ball_white", 0.11, (1.3, 0.11, 0.8), 1)
    b.anchor("Liegen_1", (-0.6, 0.02, 0), 0)
    b.anchor("Liegen_2", (0.7, 0.02, 0), 0)
    return b


def volleyball():
    b = B(3010)
    for x0, x1, z0, z1 in [(-8, 8, -4.05, -3.95), (-8, 8, 3.95, 4.05), (-8.05, -7.95, -4, 4), (7.95, 8.05, -4, 4)]:
        box(b, "boat_blue", x0, x1, 0, 0.02, z0, z1)
    for z in (-4.9, 4.9):
        b.cyl("metal", 0.06, 2.6, (0, 1.3, z), 8)
    box(b, "fence_net", -0.01, 0.01, 1.55, 2.43, -4.5, 4.5)
    box(b, "cloth_white", -0.03, 0.03, 2.36, 2.45, -4.6, 4.6)
    box(b, "cloth_white", -0.03, 0.03, 1.52, 1.57, -4.6, 4.6)
    for z in (-4.0, 4.0):
        box(b, "boat_red", -0.03, 0.03, 2.43, 3.2, z - 0.01, z + 0.01)
    for z in (-4.9, 4.9):
        b.beam("net_rope", (0, 2.45, z), (0, 0.0, z + np.sign(z) * 1.2), 0.012)
    sphere(b, "ball_yellow", 0.11, (-3.0, 0.11, 1.5), 1)
    b.anchor("Feld_Mitte", (0, 0, 0), 0)
    return b


def fussballtor():
    b = B(3011)
    W, H, D = 5.5, 2.2, 1.6
    for x in (-W / 2, W / 2):
        b.cyl("cloth_white", 0.06, H, (x, H / 2, 0), 8)
        b.beam("cloth_white", (x, H, 0), (x, 0.0, -D), 0.04)
    b.beam("cloth_white", (-W / 2, H, 0), (W / 2, H, 0), 0.06)
    b.beam("cloth_white", (-W / 2, 0.02, -D), (W / 2, 0.02, -D), 0.04)
    b.hull("fence_net", [(x, y, z) for x in (-W / 2, W / 2) for (y, z) in ((H, 0), (0, -D), (H - 0.02, 0), (0.02, -D))])
    for x in (-W / 2, W / 2):
        b.hull("fence_net", [(x + e, y, z) for e in (0, 0.01) for (y, z) in ((H, 0), (0, 0), (0, -D))])
    sphere(b, "ball_white", 0.11, (0.8, 0.11, 3.0), 1)
    b.anchor("Tor", (0, 0, 0), 0)
    return b


def fitness():
    b = B(3012)
    box(b, "mat_green", -3.0, 3.0, 0, 0.05, -2.0, 2.0)
    for (x0, x1, h) in [(-2.6, -1.4, 2.2), (-1.4, -0.2, 2.5)]:                        # pull-up bars
        for x in (x0, x1):
            b.cyl("lifeguard_yellow", 0.05, h, (x, h / 2, -1.4), 8)
        b.beam("metal", (x0, h, -1.4), (x1, h, -1.4), 0.025)
    for z in (-0.25, 0.25):                                                           # parallel bars
        b.beam("metal", (0.6, 1.2, z), (2.4, 1.2, z), 0.03)
        for x in (0.7, 2.3):
            b.cyl("lifeguard_yellow", 0.04, 1.2, (x, 0.6, z), 8)
    b.box("wood_bleached", (0.45, 0.06, 1.6), (-1.5, 0.45, 1.0), rot_x=-15)           # sit-up bench
    b.beam("lifeguard_yellow", (-1.5, 0.0, 0.35), (-1.5, 0.66, 0.3), 0.04)
    b.beam("lifeguard_yellow", (-1.5, 0.0, 1.7), (-1.5, 0.24, 1.7), 0.04)
    for x in (1.0, 1.6, 2.2):                                                         # dip/step boxes
        box(b, "concrete_light", x - 0.25, x + 0.25, 0.05, 0.3 + 0.15 * (x > 1.5), 1.3, 1.7)
    box(b, "cloth_white", -2.8, -2.2, 1.2, 1.9, 1.85, 1.88)
    b.cyl("metal", 0.04, 1.9, (-2.5, 0.95, 1.9), 6)
    b.anchor("Training", (0, 0.05, 0), 0)
    return b


def surfboards():
    b = B(3014)
    for s in (-1, 1):
        b.beam("wood_bleached", (s * 1.0, 0, -0.6), (s * 1.0, 1.6, 0.0), 0.06)
        b.beam("wood_bleached", (s * 1.0, 0, 0.6), (s * 1.0, 1.6, 0.0), 0.06)
    for y in (0.5, 1.0, 1.5):
        b.beam("wood_bleached", (-1.0, y, -0.6 + 0.6 * y / 1.6), (1.0, y, -0.6 + 0.6 * y / 1.6), 0.04)
        b.beam("wood_bleached", (-1.0, y, 0.6 - 0.6 * y / 1.6), (1.0, y, 0.6 - 0.6 * y / 1.6), 0.04)
    cols = ["lifeguard_yellow", "boat_blue", "cloth_white", "ice_pink", "kiosk_green", "buoy_orange"]
    for k in range(6):
        side = 1 if k % 2 else -1
        y = 0.35 + (k // 2) * 0.5
        z = side * (0.6 - 0.6 * y / 1.6 + 0.08)
        sphere(b, cols[k], 1.0, (0.0, y + 0.06, z), 1, (1.05, 0.04, 0.28))
    for k, x in enumerate((1.9, 2.5)):                                                # two boards stuck in the sand
        m = trimesh.creation.icosphere(subdivisions=1, radius=1.0)
        m.apply_scale((0.28, 1.1, 0.04))
        m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(8 - 14 * k), [0, 0, 1]))
        b.add(cols[k + 2], m.apply_translation((x, 0.85, 0.2)))
    b.anchor("Surfbrett", (0, 0, 1.0), 0)
    return b


def fahrraeder():
    b = B(3018)
    box(b, "concrete_light", -3.2, 3.2, 0, 0.08, -0.8, 0.8)
    box(b, "bike_orange", 2.4, 3.0, 0.08, 1.5, -0.3, 0.2)                              # terminal
    box(b, "screen" if "screen" in PALETTE else "glass", 2.45, 2.95, 1.1, 1.4, 0.2, 0.22)
    b.beam("metal", (-3.0, 0.5, -0.5), (2.2, 0.5, -0.5), 0.04)
    for k, x in enumerate(np.arange(-2.7, 2.0, 0.85)):
        for z in (0.55, -0.45):
            ring(b, "rubber", 0.33, 0.035, (x, 0.41, z), axis="x", sections=12)
        b.beam("bike_orange", (x, 0.41, 0.55), (x, 0.75, 0.15), 0.035)
        b.beam("bike_orange", (x, 0.41, -0.45), (x, 0.42, 0.05), 0.035)
        b.beam("bike_orange", (x, 0.42, 0.05), (x, 0.8, -0.15), 0.035)
        b.beam("bike_orange", (x, 0.42, 0.05), (x, 0.75, 0.15), 0.035)
        b.beam("bike_orange", (x, 0.8, -0.15), (x, 0.75, 0.15), 0.03)
        box(b, "frame_black", x - 0.08, x + 0.08, 0.82, 0.88, -0.25, -0.05)
        b.beam("frame_black", (x - 0.28, 0.98, 0.33), (x + 0.28, 0.98, 0.33), 0.02)
        b.beam("bike_orange", (x, 0.75, 0.15), (x, 0.98, 0.33), 0.03)
        box(b, "bike_orange", x - 0.15, x + 0.15, 0.6, 0.78, 0.42, 0.62)              # basket
    b.anchor("Fahrrad_Leihen", (0, 0.08, 1.2), 0)
    return b


def fischerboot():
    """Small wooden fishing boat (Copacabana colony at Posto 6) on log rollers, oars, net pile."""
    b = B(3020)
    L, Wd, Hh = 5.6, 1.7, 0.75
    secs = []
    for i, f in enumerate(np.linspace(0, 1, 9)):
        z = -L / 2 + f * L
        w = Wd / 2 * (np.sin(np.pi * f) ** 0.6 if 0 < f < 1 else 0.05)
        keel = 0.28 + 0.25 * (abs(f - 0.5) * 2) ** 3
        secs.append((z, max(w, 0.05), keel))
    for (z0, w0, k0), (z1, w1, k1) in zip(secs[:-1], secs[1:]):
        for s in (-1, 1):
            b.hull("boat_blue", [(s * w0, k0 + Hh * 0.95, z0), (s * w1, k1 + Hh * 0.95, z1), (s * w0 * 0.3, k0, z0), (s * w1 * 0.3, k1, z1),
                                 (s * (w0 - 0.06), k0 + Hh * 0.95, z0), (s * (w1 - 0.06), k1 + Hh * 0.95, z1)])
            b.hull("boat_red", [(s * w0, k0 + Hh * 0.95, z0), (s * w1, k1 + Hh * 0.95, z1), (s * w0, k0 + Hh * 0.82, z0), (s * w1, k1 + Hh * 0.82, z1),
                                (s * (w0 + 0.02), k0 + Hh * 0.9, z0), (s * (w1 + 0.02), k1 + Hh * 0.9, z1)])
        b.hull("wood_bleached", [(x, k + 0.08, z) for (z, w, k) in ((z0, w0, k0), (z1, w1, k1)) for x in (-w * 0.35, w * 0.35)] +
               [(x, k + 0.04, z) for (z, w, k) in ((z0, w0, k0), (z1, w1, k1)) for x in (-w * 0.35, w * 0.35)])
    for z in (-1.0, 0.6):
        box(b, "wood_bleached", -0.75, 0.75, 0.62, 0.68, z - 0.15, z + 0.15)            # thwarts
    b.text("IEMANJÁ", ["cloth_white"] * 7, (0.86, 0.85, 0.4), 0.2, 0.01, rot_y=90, simplify=0.006)
    for z in (-1.5, 0.0, 1.5):
        m = trimesh.creation.cylinder(radius=0.11, height=2.2, sections=8)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
        b.add("wood_dark", m.apply_translation((0, 0.11, z)))
    for s in (-1, 1):
        b.box("wood_bleached", (0.08, 0.04, 2.4), (s * 0.4, 0.75, -0.1), rot_y=s * 6)
    for k in range(5):
        b.rock("net_rope", 0.35 - k * 0.04, (1.8 + 0.1 * k, 0.12 + k * 0.05, 1.2), 0.45)
    b.anchor("Boot", (0, 0, 0), 0)
    return b


BEACH = [
    ("01_kokospalme", "Kokospalme", "Natur", kokospalme),
    ("02_palmengruppe", "Palmengruppe", "Natur", palmengruppe),
    ("03_haengematte", "Hängematte zwischen Palmen", "Natur", haengematte),
    ("04_rettungsturm", "Rettungsturm (Salva-Vidas)", "Rettung", rettungsturm),
    ("05_duschen", "Strandduschen", "Rettung", duschen),
    ("06_muell_warnflagge", "Mülleimer + Warnflagge", "Rettung", muell_flagge),
    ("07_strandkiosk", "Strandkiosk (Quiosque)", "Essen", strandkiosk),
    ("08_eisladen", "Eisladen", "Essen", eisladen),
    ("09_eiswagen", "Eis-Fahrrad (Picolé)", "Essen", eiswagen),
    ("10_kokos_stand", "Kokosnuss-Stand", "Essen", kokos_stand),
    ("11_barraca", "Barraca (Strandverleih)", "Essen", barraca),
    ("12_sandburg", "Sandburg", "Freizeit", sandburg),
    ("13_sonnenschirm_set", "Sonnenschirm + 2 Stühle", "Freizeit", sonnenschirm_set),
    ("14_strandtuch_set", "Strandtücher-Set", "Freizeit", strandtuch_set),
    ("15_volleyball", "Beachvolleyball-Feld", "Sport", volleyball),
    ("16_fussballtor", "Beach-Soccer-Tor", "Sport", fussballtor),
    ("17_fitness", "Fitness-Station", "Sport", fitness),
    ("18_surfbretter", "Surfbrett-Ständer", "Sport", surfboards),
    ("19_leihraeder", "Leihrad-Station", "Freizeit", fahrraeder),
    ("20_fischerboot", "Fischerboot", "Freizeit", fischerboot),
]
