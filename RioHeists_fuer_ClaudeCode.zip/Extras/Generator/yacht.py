"""Megayacht SOBERANA – 150-m-Superyacht für einen Heist (fiktiv).
Konventionen wie Rio-Hafen: Wasserlinie y = 0, Pivot Mitte auf der Wasserlinie, Bug +X, Backbord (BB) -Z = Kaiseite, Steuerbord (SB) +Z.
Decks (Boden-Oberkante y): Tankdeck -2,6 · Unterdeck 1,2 · Hauptdeck 5,0 · Oberdeck 8,6 · Eignerdeck 12,2 · Brückendeck 15,8 · Sonnendeck 19,4 · Hardtop 23,0
Nodes: Aussen__ (Unterwasserschiff, Anhänge), Rumpf__ (Rumpf über y 1,2), <Deck>__ (Struktur), <Deck>_Innen__ (Einrichtung), Heist-Teile als eigene Nodes.
Heist nach Skizze: Schleich-Mission, kaputte Treppen (Zickzack-Route nach oben), Lüftungsschächte mit Klappen, Kapitän + Tresorschlüssel
ganz oben, Motor-Sabotage, Tauchschleuse (Flucht), Jetski-Seitengarage + Boots-Einstieg am Heck, Beute-Nodes (*_Beute_*), Pool-Gäste."""
import numpy as np
import trimesh
from shapely.geometry import Polygon, Point, box as sbox
from shapely.ops import unary_union
from lib import B, PALETTE, ALPHA, SLOT_PALETTES

SLOT_PALETTES.setdefault("hull", ["#14213D", "#1F3A5F", "#22252A", "#2F5D3A", "#8E2A26", "#5A6670", "#2B5FA8", "#F4F2EC"])

PALETTE.update({
    "yacht_white": "#F4F2EC", "teak": "#A07A55", "stainless": "#C9CED6", "gold_trim": "#C9A23A", "antifouling": "#2B2E33",
    "lining": "#E9E4DA", "oak": "#C9A57C", "cushion": "#F2EFE8", "cushion_navy": "#1F2A44", "marble_white": "#EEEAE2", "marble_black": "#1E1E22",
    "walnut": "#4E3424", "carpet_cream": "#D9CFBE", "carpet_navy": "#1E2A4A", "leather_white": "#EDE7DC", "leather_brown": "#6B4A2E",
    "velvet_blue": "#1E2A4A", "velvet_red": "#7A1631", "lacquer": "#17171A", "brass": "#C9A23A", "chrome": "#C9CED6",
    "gold": "#E0B23A", "gold_bar": "#D4AF37", "cash_green": "#4F7D4A", "diamond": "#E6F4FF", "gem_blue": "#1F4FD8",
    "gem_red": "#E0115F", "gem_green": "#2ECC71", "silver": "#C9CED6", "laser_red": "#FF2A2A", "vault_steel": "#8E959C",
    "engine_grey": "#7C8288", "engine_red": "#B03A2E", "pipe": "#6E7378", "safety_yellow": "#F2C230", "hazard": "#1E1E1E",
    "helipad": "#3A3F44", "heli_mark": "#F2C230", "heli_body": "#1F2A44", "heli_glass": "#2A3A48", "sub_yellow": "#F2B31F",
    "tender_navy": "#1F2A44", "rubber": "#1E1E1E", "crate": "#9C7A4E", "cream": "#E9E1D0", "server_black": "#141618",
    "art_red": "#C8372D", "art_blue": "#2E5FA8", "art_yellow": "#EBC03F", "art_green": "#3E7D4F", "art_orange": "#E8893A",
    "art_purple": "#6B2E8A", "art_black": "#1C1C1C", "art_white": "#F4F1EA", "uw_light": "#47C8F0",
    "dach_dome": "#F4F2EC", "dach_radar": "#2B2B2E", "dach_mast": "#EDEDE8", "dach_stahl": "#5B6168",
})
for _k, _v in {"glass": "#23313B", "glass_rail": "#B9D4DE", "glass_shop": "#9FC3D6", "frame_black": "#26282A", "lamp": "#F6E7B8",
               "screen": "#2FE0F0", "led_red": "#E53935", "led_green": "#36D46A", "pool": "#3FB6D3", "dach_licht": "#FFE9B0",
               "door_metal": "#5E6B66", "fence_net": "#C8CCD0", "hedge": "#3F7B3A", "cloth_white": "#F2F0EA", "wood_dark": "#5B4029",
               "flood_water": "#2C6E8F"}.items():
    PALETTE.setdefault(_k, _v)
ALPHA.update({"heli_glass": 0.75, "flood_water": 0.55})

# ------------------------------------------------------------------ main dimensions
DY = {"Tankdeck": -2.6, "Unterdeck": 1.2, "Hauptdeck": 5.0, "Oberdeck": 8.6, "Eignerdeck": 12.2, "Brueckendeck": 15.8, "Sonnendeck": 19.4}
ORDER = ["Tankdeck", "Unterdeck", "Hauptdeck", "Oberdeck", "Eignerdeck", "Brueckendeck", "Sonnendeck"]
LEVELS = ["Dach", "Sonnendeck", "Brueckendeck", "Eignerdeck", "Oberdeck", "Hauptdeck", "Unterdeck", "Tankdeck"]
TOP = 23.0
SLAB = 0.35
SPIRAL = (3.0, 0.0, 3.3)                        # guest spiral stair + glass lift (Unterdeck -> Sonnendeck)
CORE = (20.0, 24.0, 1.2, 4.4)                   # crew stair (Tankdeck -> Brueckendeck), x0 x1 z0 z1
PLIFT = (-12.5, -10.0, -8.5, -6.0)              # owner's private lift (Tankdeck <-> Eignerdeck), hidden shaft
GARAGE = (-62.0, -50.0)                         # tender garage hull doors (x range)
DIVE = (12.0, 15.0)                             # dive-lockout hull hatch (starboard = open water, Tankdeck, below the waterline)
JETSKI = (32.0, 38.0)                           # jet-ski side garage hull door (starboard, Unterdeck)
DUCT = (4.5, 5.5)                               # crawlable vent ducts under the ceiling (z range, starboard side)
DUCTS = {"Hauptdeck": (-56.0, 34.0, -50.0), "Oberdeck": (-44.0, 34.0, -40.0),            # x0, x1, x of the outside entry
         "Eignerdeck": (-32.0, 28.0, -26.0), "Brueckendeck": (-22.0, 29.0, -18.0)}
HATCHES = {"Hauptdeck": (-46.0, -22.0, -4.0, 12.0, 28.0), "Oberdeck": (-34.0, -12.0, 0.0, 11.0, 24.5),
           "Eignerdeck": (-20.0, -6.0, 4.0, 13.0, 24.0), "Brueckendeck": (-14.0, -5.0, 3.0, 14.0, 27.0)}
BROKEN_SPIRAL = {"Unterdeck", "Hauptdeck", "Oberdeck", "Eignerdeck"}   # guest spiral + lift out of order up to the bridge deck
BROKEN_CORE = {"Unterdeck", "Oberdeck"}                                # crew-stair flights starting on these decks collapsed
BROKEN_EXT = {"Hauptdeck", "Eignerdeck"}                               # aft outside flights starting on these decks collapsed
PICKUP = ("_Beute", "Schluessel", "Tauchausruestung")         # node names with these parts = stealable / pick-up (trigger box)
STX = [-75.0, -73.0, -70.0, -66.0, -62.0, -58.0, -54.0, -50.0, -45.0, -38.0, -28.0, -14.0, 0.0, 12.0, 15.0, 20.0, 26.0, 32.0, 38.0, 44.0,
       50.0, 55.0, 60.0, 64.0, 67.5, 70.0, 72.0, 73.5, 75.0]
YS = [5.0, 4.6, 4.3, 3.0, 1.2, 0.6, 0.0, -1.0, -2.5, -4.0, -5.0, -5.5]
SEC = [(5.0, 12.0), (4.6, 11.98), (4.3, 11.96), (3.0, 11.9), (1.2, 11.75), (0.6, 11.7), (0.0, 11.6), (-1.0, 11.4), (-2.5, 10.8),
       (-4.0, 9.2), (-5.0, 6.5), (-5.5, 0.3)]


def stem_x(y):
    """raked stem: deck edge x 75 (y 5), waterline x 72, forefoot x 60 (y -5.5)"""
    return 72.0 + 3.0 * y / 5.0 if y >= 0 else 72.0 + 12.0 * y / 5.5


def bottom_y(x):
    if x < -45.0:
        return -0.5 - 5.0 * ((x + 75.0) / 30.0) ** (1 / 0.7)
    if x > 60.0:
        return -5.5 + (x - 60.0) / 12.0 * 5.5 if x <= 72.0 else (x - 72.0) / 3.0 * 5.0
    return -5.5


def base_hb(y):
    return float(np.interp(y, [p[0] for p in SEC][::-1], [p[1] for p in SEC][::-1]))


def hb(x, y):
    """hull half-breadth at station x, height y"""
    y = min(y, 5.0)
    if y < bottom_y(x) - 1e-6:
        return 0.0
    w = base_hb(y)
    xs = stem_x(y)
    if x > 20.0:
        t = (x - 20.0) / max(xs - 20.0, 1e-3)
        if t >= 1.0:
            return 0.0
        w *= 1.0 - t * t
    if x < -60.0 and y >= -0.5:
        w *= 1.0 - 0.07 * (-60.0 - x) / 15.0
    if y < -0.5:
        xa = -75.0 + ((-0.5 - y) / 5.0) ** 0.7 * 30.0
        if x < xa - 1e-6:
            return 0.0
        t = (xa + 14.0 - x) / 14.0
        if t > 0:
            w *= np.sqrt(max(0.0, 1.0 - t * t))
    return float(w)


def outline(y, inset=0.0, n=150):
    """plan outline of the hull at height y as a shapely polygon in (x, z)"""
    xs = np.linspace(-75.0, 75.0, n)
    pts = [(x, hb(x, y) - inset) for x in xs if hb(x, y) - inset > 0.02]
    poly = Polygon(pts + [(x, -z) for (x, z) in pts[::-1]]).buffer(0)
    return poly


def sup_poly(xa, xf, hw, nose, r_aft=2.5):
    """superstructure / deck plan: straight sides, elliptic rounded front, rounded aft corners"""
    pts = [(xa, hw)]
    for x in np.linspace(xf - nose, xf, 14):
        t = (x - (xf - nose)) / nose
        pts.append((x, hw * np.sqrt(max(0.0, 1.0 - t * t))))
    poly = Polygon(pts + [(x, -z) for (x, z) in pts[::-1]]).buffer(0)
    return poly.buffer(-r_aft, join_style=1).buffer(r_aft, join_style=1)


def yacht():
    b = B(1501)
    b.pickup_tags = PICKUP
    rng = np.random.default_rng(1501)
    HULL = b.slot("hull", 1, "#14213D")

    # ================================================================ helpers
    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        if abs(x1 - x0) < 1e-4 or abs(y1 - y0) < 1e-4 or abs(z1 - z0) < 1e-4:
            return
        b.box(mat, (abs(x1 - x0), abs(y1 - y0), abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def flat(mat, poly, y0, y1):
        for p in getattr(poly, "geoms", [poly]):
            if p.is_empty or p.area < 1e-3 or p.geom_type != "Polygon":
                continue
            q = Polygon([(x, -z) for x, z in p.exterior.coords], [[(x, -z) for x, z in r.coords] for r in p.interiors])
            m = trimesh.creation.extrude_polygon(q, y1 - y0)
            m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
            b.add(mat, m.apply_translation((0, y0, 0)))

    def cyl_axis(mat, r, length, c, axis, sections=10):
        m = trimesh.creation.cylinder(radius=r, height=length, sections=sections)
        if axis == "x":
            m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
        elif axis == "y":
            m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        b.add(mat, m.apply_translation(c))

    def octa(r, s=1.3):
        return trimesh.convex.convex_hull(np.array([(r, 0, 0), (-r, 0, 0), (0, r * s, 0), (0, -r * s, 0), (0, 0, r), (0, 0, -r)]))

    def node(name, pivot):
        b.layer = name
        b.pivots[name] = tuple(float(v) for v in pivot)

    cam_count = {}

    def cam_id(prefix):
        cam_count[prefix] = cam_count.get(prefix, 0) + 1
        return f"{prefix}_{cam_count[prefix]}"

    def cam(name, x, y, z, yaw):
        box("yacht_white", x - 0.1, x + 0.1, y, y + 0.12, z - 0.1, z + 0.1)
        b.box("frame_black", (0.14, 0.14, 0.26), (x, y - 0.06, z), rot_y=yaw, rot_x=-25)
        b.anchor(name, (x, y - 0.06, z), yaw)

    def ring(poly, t):
        return poly.difference(poly.buffer(-t))

    def rails(poly, y, gaps=(), h=1.0, glass=True):
        r1 = ring(poly.buffer(-0.04), 0.06)
        r2 = ring(poly.buffer(-0.02), 0.12)
        for g in gaps:
            r1 = r1.difference(sbox(*g))
            r2 = r2.difference(sbox(*g))
        if glass:
            flat("glass_rail", r1, y, y + h)
        flat("stainless", r2, y + h, y + h + 0.06)

    def house(poly, y0, y1, doors=(), mull=3.2, band=(0.8, 0.45), solid=(), vents=()):
        r = ring(poly, 0.25)
        for d in doors:
            r = r.difference(sbox(*d))
        flat("yacht_white", r, y0, y0 + band[0])
        g, top = r, r
        cuts = [sbox(va, 0.0, vb, 30.0) for (va, vb) in vents]          # vent openings, starboard wall, top 0.9 m
        for (sa, sb) in solid:
            sol = r.intersection(sbox(sa, -30.0, sb, 30.0))
            g = g.difference(sbox(sa, -30.0, sb, 30.0))
            for c_ in cuts:
                sol = sol.difference(c_)
            flat("yacht_white", sol, y0 + band[0], y1 - band[1])
        for c_ in cuts:
            g = g.difference(c_)
            top = top.difference(c_)
            flat("yacht_white", r.intersection(c_), y0 + band[0], y1 - 0.9)
        flat("glass", g, y0 + band[0], y1 - band[1])
        flat("yacht_white", top, y1 - band[1], y1)
        line = poly.buffer(-0.125).exterior
        for k in range(int(line.length / mull)):
            p = line.interpolate(k * mull)
            if any(sbox(*d).buffer(0.3).contains(p) for d in doors) or any(c_.buffer(0.3).contains(p) for c_ in cuts):
                continue
            box("yacht_white", p.x - 0.09, p.x + 0.09, y0 + band[0], y1 - band[1], p.y - 0.09, p.y + 0.09)

    def flight_x(xa, xb, z0, z1, ya, yb, tread="teak", side="yacht_white", rail=True, broken=False, debris=True):
        """straight stair along X from (xa, ya) to (xb, yb); broken = middle part collapsed"""
        n = max(2, int(round(abs(yb - ya) / 0.18)))
        dx = (xb - xa) / n
        ka, kb = max(2, n // 4), n - max(2, n // 5)
        for k in range(n):
            if broken and ka <= k < kb:
                continue
            yy = ya + (yb - ya) * (k + 1) / n
            x = xa + dx * k
            box(tread, min(x, x + dx), max(x, x + dx), yy - 0.12, yy, z0, z1)
        if broken:
            xm0, xm1 = xa + dx * ka, xa + dx * kb
            ym0, ym1 = ya + (yb - ya) * ka / n, ya + (yb - ya) * kb / n
            for z in (z0, z1):
                for (p0, q0, p1, q1) in ((xa, ya, xm0, ym0), (xm1, ym1, xb, yb)):
                    b.hull(side, [(x, y_, z + e) for e in (-0.06, 0.06) for (x, y_) in ((p0, q0 - 0.4), (p1, q1 - 0.4), (p0, q0 + 0.05), (p1, q1 + 0.05))])
            if debris:
                broken_marks((xm0 + xm1) / 2, (z0 + z1) / 2, ya, 5, 0.7)
            sx = 1.0 if xb > xa else -1.0
            tape(xa - 0.5 * sx, z0, xa - 0.5 * sx, z1, ya)
            tape(xb + 0.5 * sx, z0, xb + 0.5 * sx, z1, yb)
            return
        for z in (z0, z1):
            b.hull(side, [(x, y_, z + e) for e in (-0.06, 0.06) for (x, y_) in ((xa, ya - 0.4), (xb, yb - 0.4), (xa, ya + 0.05), (xb, yb + 0.05))])
            if rail:
                b.beam("stainless", (xa, ya + 1.0, z), (xb, yb + 1.0, z), 0.04)

    def spiral(cx, cz, r0, r1, ya, yb, a0=0.0, broken=False):
        n = max(8, int(round((yb - ya) / 0.18)))
        da = 2 * np.pi * 0.92 / n
        for k in range(n):
            if broken and 3 <= k < n - 2:
                continue                                                    # collapsed middle part
            yy = ya + (yb - ya) * (k + 1) / n
            a, c = a0 + k * da, a0 + (k + 1) * da
            pts = [(cx + r * np.cos(t), y_, cz + r * np.sin(t)) for r in (r0, r1) for t in (a, c) for y_ in (yy - 0.1, yy)]
            b.hull("marble_white", pts)
        for k in range(n):
            if broken and 2 <= k < n - 2:
                continue
            a, c = a0 + k * da, a0 + (k + 1) * da
            y0_ = ya + (yb - ya) * (k + 1) / n + 0.95
            y1_ = ya + (yb - ya) * (k + 2) / n + 0.95
            b.beam("brass", (cx + r1 * np.cos(a), y0_, cz + r1 * np.sin(a)), (cx + r1 * np.cos(c), y1_, cz + r1 * np.sin(c)), 0.04)
        return a0 + n * da

    def stair_core(core, y0, y1, broken=False):
        x0, x1, z0, z1 = core
        ym = (y0 + y1) / 2
        zm = (z0 + z1) / 2
        box("lining", x0 + 0.15, x0 + 0.65, y0 - 0.1, y0, z0 + 0.15, z1 - 0.15)
        if not broken:
            box("lining", x1 - 0.65, x1 - 0.15, ym - 0.1, ym, z0 + 0.15, z1 - 0.15)
        flight_x(x0 + 0.65, x1 - 0.65, z0 + 0.15, zm - 0.05, y0, ym, "lining", "lining", False, broken, False)
        flight_x(x1 - 0.65, x0 + 0.65, zm + 0.05, z1 - 0.15, ym, y1, "lining", "lining", False, broken, False)

    def core_walls(core, y0, y1, door=True):
        x0, x1, z0, z1 = core
        r = ring(sbox(x0, z0, x1, z1), 0.15)
        if door:
            r = r.difference(sbox(x0 + 0.3, z0 - 0.3, x0 + 1.3, z0 + 0.3))
        flat("lining", r, y0, y1)

    def broken_marks(x, z, y, n=4, spread=1.2):
        """rubble of a collapsed stair"""
        for k in range(n):
            b.box("lining", (rng.uniform(0.4, 0.9), 0.12, rng.uniform(0.3, 0.6)), (x + rng.uniform(-spread, spread), y + 0.07, z + rng.uniform(-spread, spread)),
                  rot_y=rng.uniform(0, 180), rot_z=rng.uniform(-12, 12))
        for k in range(3):
            b.rock("lining", 0.18, (x + rng.uniform(-spread, spread), y + 0.1, z + rng.uniform(-spread, spread)), 0.6)

    def tape(x0, z0, x1, z1, y):
        """warning barrier: two posts + yellow tape"""
        for (x, z) in ((x0, z0), (x1, z1)):
            b.cyl("hazard", 0.04, 1.0, (x, y + 0.5, z), 6)
            b.cyl("frame_black", 0.18, 0.05, (x, y + 0.025, z), 8)
        for yy in (y + 0.55, y + 0.95):
            b.beam("safety_yellow", (x0, yy, z0), (x1, yy, z1), 0.03)

    def pflat(lv, mat, poly, y, yt):
        """partition from a plan polygon; under the vent duct it stops 0.9 m below the ceiling"""
        if lv in DUCTS:
            band = sbox(DUCTS[lv][0], DUCT[0], DUCTS[lv][1], DUCT[1])
            flat(mat, poly.difference(band), y, yt)
            flat(mat, poly.intersection(band), y, yt - 0.9)
        else:
            flat(mat, poly, y, yt)

    def pwall(lv, mat, x0, x1, z0, z1, y, yt):
        pflat(lv, mat, sbox(x0, z0, x1, z1), y, yt)

    def duct(lv, yt):
        """crawlable vent duct under the ceiling: hatches above guard spots, entry grille + ladder outside (starboard)"""
        x0, x1, xe = DUCTS[lv]
        d0, d1 = DUCT
        yb = yt - 0.9
        zw = HOUSES[lv].bounds[3]                                           # outer face of the starboard house wall
        run = sbox(x0, d0, x1, d1).union(sbox(xe - 0.5, d0, xe + 0.5, zw))
        holes = unary_union([sbox(hx - 0.45, d0 + 0.1, hx + 0.45, d1 - 0.1) for hx in HATCHES[lv]])
        b.layer = lv
        flat("pipe", run.difference(holes), yb, yb + 0.05)
        flat("pipe", ring(run, 0.05).difference(sbox(xe - 0.45, zw - 0.5, xe + 0.45, zw + 0.5)), yb, yt)
        for k, hx in enumerate(HATCHES[lv]):
            name = f"{lv}_Lueftungsklappe_{k + 1}"
            node(name, (hx - 0.45, yb, (d0 + d1) / 2))
            box("frame_black", hx - 0.45, hx + 0.45, yb - 0.01, yb + 0.04, d0 + 0.1, d1 - 0.1)
            flat("safety_yellow", ring(sbox(hx - 0.45, d0 + 0.1, hx + 0.45, d1 - 0.1), 0.06), yb + 0.04, yb + 0.05)   # marking seen from inside the duct
            for zz in np.arange(d0 + 0.2, d1 - 0.1, 0.15):
                box("stainless", hx - 0.43, hx + 0.43, yb - 0.03, yb - 0.01, zz - 0.02, zz + 0.02)
            b.layer = lv
            b.anchor(f"Lueftung_{lv}_Klappe_{k + 1}", (hx, DY[lv], (d0 + d1) / 2), 0)
        node(f"{lv}_Lueftung_Einstieg", (xe, yt, zw + 0.05))
        box("frame_black", xe - 0.5, xe + 0.5, yb, yt, zw + 0.02, zw + 0.06)
        for yy in np.arange(yb + 0.1, yt - 0.05, 0.12):
            box("stainless", xe - 0.45, xe + 0.45, yy, yy + 0.03, zw + 0.06, zw + 0.08)
        b.layer = lv
        for xx in (xe - 0.25, xe + 0.25):
            b.beam("stainless", (xx, DY[lv], zw + 0.25), (xx, yb, zw + 0.25), 0.03)
        for yy in np.arange(DY[lv] + 0.3, yb, 0.3):
            b.beam("stainless", (xe - 0.25, yy, zw + 0.25), (xe + 0.25, yy, zw + 0.25), 0.025)
        b.anchor(f"Lueftung_{lv}_Einstieg", (xe, DY[lv], zw + 0.9), 180)

    def loot(name, kind, x, y, z):
        """stealable item = own node (pick-up trigger is generated on export)"""
        prev = b.layer
        node(name, (x, y, z))
        if kind == "gold":
            for k, (dx, dz, dy) in enumerate(((-0.13, -0.07, 0.0), (0.13, -0.07, 0.0), (-0.13, 0.07, 0.0), (0.13, 0.07, 0.0), (0.0, 0.0, 0.07))):
                b.hull("gold_bar", [(x + dx + ex, y + dy, z + dz + ez) for ex in (-0.12, 0.12) for ez in (-0.065, 0.065)] +
                       [(x + dx + ex, y + dy + 0.07, z + dz + ez) for ex in (-0.1, 0.1) for ez in (-0.05, 0.05)])
        elif kind == "cash":
            for k in range(3):
                box("cash_green", x - 0.16, x + 0.16, y + k * 0.09, y + 0.08 + k * 0.09, z - 0.08, z + 0.08)
                box("cloth_white", x - 0.03, x + 0.03, y + k * 0.09, y + 0.085 + k * 0.09, z - 0.085, z + 0.085)
        elif kind == "watch":
            box("lacquer", x - 0.12, x + 0.12, y, y + 0.08, z - 0.1, z + 0.1)
            box("velvet_blue", x - 0.1, x + 0.1, y + 0.08, y + 0.09, z - 0.08, z + 0.08)
            b.cyl("gold", 0.04, 0.02, (x, y + 0.1, z), 8)
        elif kind == "jewels":
            box("velvet_red", x - 0.15, x + 0.15, y, y + 0.1, z - 0.11, z + 0.11)
            for k in range(4):
                b.add(["gem_blue", "gem_red", "gem_green", "diamond"][k], octa(0.025).apply_translation((x - 0.08 + k * 0.055, y + 0.13, z)))
        elif kind == "champagne":
            b.cyl("silver", 0.11, 0.24, (x, y + 0.12, z), 10)
            b.cyl("art_green", 0.045, 0.32, (x + 0.02, y + 0.3, z), 8)
            b.cyl("gold", 0.02, 0.05, (x + 0.02, y + 0.48, z), 6)
        elif kind == "laptop":
            box("silver", x - 0.17, x + 0.17, y, y + 0.02, z - 0.12, z + 0.12)
            b.box("frame_black", (0.34, 0.24, 0.015), (x, y + 0.12, z - 0.12), rot_x=-15)
        elif kind == "bag":
            b.hull("leather_brown", [(x + dx, y + yy, z + dz) for dx in (-0.18, 0.18) for dz in (-0.08, 0.08) for yy in (0.0,)] +
                   [(x + dx, y + 0.24, z + dz) for dx in (-0.14, 0.14) for dz in (-0.06, 0.06)])
            b.beam("gold", (x - 0.1, y + 0.24, z), (x + 0.1, y + 0.24, z), 0.015)
        elif kind == "statue":
            box("marble_black", x - 0.1, x + 0.1, y, y + 0.06, z - 0.1, z + 0.1)
            b.add("gold", octa(0.07, 2.2).apply_translation((x, y + 0.22, z)))
            b.add("gold", trimesh.creation.icosphere(subdivisions=0, radius=0.05).apply_translation((x, y + 0.42, z)))
        elif kind == "silver":
            b.cyl("silver", 0.09, 0.03, (x, y + 0.015, z), 10)
            b.cyl("silver", 0.025, 0.36, (x, y + 0.2, z), 6)
            box("silver", x - 0.2, x + 0.2, y + 0.34, y + 0.37, z - 0.015, z + 0.015)
            for dx in (-0.19, 0.0, 0.19):
                b.cyl("cloth_white", 0.018, 0.16, (x + dx, y + 0.45, z), 6)
        elif kind == "cigars":
            box("walnut", x - 0.15, x + 0.15, y, y + 0.08, z - 0.1, z + 0.1)
            box("gold", x - 0.15, x + 0.15, y + 0.08, y + 0.09, z - 0.1, z + 0.1)
        elif kind == "wine":
            box("crate", x - 0.22, x + 0.22, y, y + 0.16, z - 0.15, z + 0.15)
            for k in range(3):
                cyl_axis("art_red", 0.04, 0.3, (x, y + 0.2, z - 0.09 + k * 0.09), "x", 6)
        elif kind == "phone":
            box("frame_black", x - 0.04, x + 0.04, y, y + 0.012, z - 0.075, z + 0.075)
        elif kind == "key":
            box("gold", x - 0.03, x + 0.03, y, y + 0.012, z - 0.05, z + 0.05)
            box("gold", x - 0.01, x + 0.01, y, y + 0.012, z + 0.05, z + 0.12)
            t = trimesh.creation.torus(major_radius=0.05, minor_radius=0.008, major_sections=10, minor_sections=3)
            t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
            b.add("art_red", t.apply_translation((x, y + 0.006, z - 0.1)))
        b.layer = prev

    def scuba(name, x, y, z, face="+x"):
        """scuba set hanging on a rack: tank, jacket, mask, fins (pick-up)"""
        prev = b.layer
        node(name, (x, y, z))
        s_ = 1 if face[0] == "+" else -1
        if face[1] == "x":
            b.cyl("sub_yellow", 0.1, 0.65, (x, y + 1.0, z), 10)
            box("cushion_navy", x + s_ * 0.1, x + s_ * 0.22, y + 0.75, y + 1.35, z - 0.2, z + 0.2)
            box("frame_black", x + s_ * 0.22, x + s_ * 0.3, y + 1.45, y + 1.55, z - 0.09, z + 0.09)
            for dz in (-0.1, 0.1):
                box("frame_black", x + s_ * 0.05, x + s_ * 0.1, y + 0.1, y + 0.65, z + dz - 0.08, z + dz + 0.08)
        else:
            b.cyl("sub_yellow", 0.1, 0.65, (x, y + 1.0, z), 10)
            box("cushion_navy", x - 0.2, x + 0.2, y + 0.75, y + 1.35, z + s_ * 0.1, z + s_ * 0.22)
            box("frame_black", x - 0.09, x + 0.09, y + 1.45, y + 1.55, z + s_ * 0.22, z + s_ * 0.3)
            for dx in (-0.1, 0.1):
                box("frame_black", x + dx - 0.08, x + dx + 0.08, y + 0.1, y + 0.65, z + s_ * 0.05, z + s_ * 0.1)
        b.layer = prev

    def sofa(x, z, y, w=2.2, rot=0, mat="cushion"):
        s = {0: (0, -1), 180: (0, 1), 90: (-1, 0), 270: (1, 0)}[rot]
        if rot in (0, 180):
            box(mat, x - w / 2, x + w / 2, y, y + 0.42, z - 0.45, z + 0.45)
            box(mat, x - w / 2, x + w / 2, y + 0.42, y + 0.9, z + s[1] * 0.45 - 0.12, z + s[1] * 0.45 + 0.12)
            for e in (-1, 1):
                box(mat, x + e * w / 2 - 0.12, x + e * w / 2 + 0.12, y + 0.42, y + 0.65, z - 0.45, z + 0.45)
        else:
            box(mat, x - 0.45, x + 0.45, y, y + 0.42, z - w / 2, z + w / 2)
            box(mat, x + s[0] * 0.45 - 0.12, x + s[0] * 0.45 + 0.12, y + 0.42, y + 0.9, z - w / 2, z + w / 2)
            for e in (-1, 1):
                box(mat, x - 0.45, x + 0.45, y + 0.42, y + 0.65, z + e * w / 2 - 0.12, z + e * w / 2 + 0.12)

    def chair(x, z, y, rot=0.0, mat="leather_white"):
        r = np.radians(rot)
        b.box(mat, (0.5, 0.1, 0.5), (x, y + 0.45, z), rot_y=rot)
        b.box(mat, (0.5, 0.55, 0.08), (x - np.sin(r) * 0.22, y + 0.75, z - np.cos(r) * 0.22), rot_y=rot)
        b.cyl("chrome", 0.04, 0.42, (x, y + 0.21, z), 6)

    def table_round(x, z, y, r=0.6, h=0.75, top="marble_white"):
        b.cyl(top, r, 0.05, (x, y + h - 0.025, z), 14)
        b.cyl("chrome", 0.06, h - 0.05, (x, y + (h - 0.05) / 2, z), 6)
        b.cyl("chrome", r * 0.5, 0.04, (x, y + 0.02, z), 10)

    def sunbed(x, z, y, rot=0, mat="cushion"):
        if rot in (0, 180):
            s = 1 if rot == 0 else -1
            box("teak", x - 1.0, x + 1.0, y, y + 0.3, z - 0.4, z + 0.4)
            box(mat, x - 1.0, x + 0.4, y + 0.3, y + 0.42, z - 0.38, z + 0.38)
            b.box(mat, (0.75, 0.12, 0.76), (x + s * 0.7, y + 0.6, z), rot_z=s * 35)
        else:
            box("teak", x - 0.4, x + 0.4, y, y + 0.3, z - 1.0, z + 1.0)
            box(mat, x - 0.38, x + 0.38, y + 0.3, y + 0.42, z - 1.0, z + 0.4)
            b.box(mat, (0.76, 0.12, 0.75), (x, y + 0.6, z + 0.7), rot_x=-35)

    def bed(x, z, y, w=2.0, l=2.2, head="+x", mat="cushion"):
        if head in ("+x", "-x"):
            s = 1 if head == "+x" else -1
            box("walnut", x - l / 2, x + l / 2, y, y + 0.35, z - w / 2, z + w / 2)
            box(mat, x - l / 2 + 0.05, x + l / 2 - 0.05, y + 0.35, y + 0.6, z - w / 2 + 0.05, z + w / 2 - 0.05)
            box("walnut", x + s * l / 2 - 0.1, x + s * l / 2 + 0.1, y, y + 1.3, z - w / 2 - 0.1, z + w / 2 + 0.1)
            for e in (-0.45, 0.45):
                box("cushion_navy", x + s * (l / 2 - 0.45), x + s * (l / 2 - 0.15), y + 0.6, y + 0.78, z + e - 0.3, z + e + 0.3)
            box("cushion_navy", x - s * l / 2 - 0.0, x - s * (l / 2 - 0.55), y + 0.6, y + 0.64, z - w / 2 + 0.05, z + w / 2 - 0.05)
        else:
            s = 1 if head == "+z" else -1
            box("walnut", x - w / 2, x + w / 2, y, y + 0.35, z - l / 2, z + l / 2)
            box(mat, x - w / 2 + 0.05, x + w / 2 - 0.05, y + 0.35, y + 0.6, z - l / 2 + 0.05, z + l / 2 - 0.05)
            box("walnut", x - w / 2 - 0.1, x + w / 2 + 0.1, y, y + 1.3, z + s * l / 2 - 0.1, z + s * l / 2 + 0.1)
            for e in (-0.45, 0.45):
                box("cushion_navy", x + e - 0.3, x + e + 0.3, y + 0.6, y + 0.78, z + s * (l / 2 - 0.45), z + s * (l / 2 - 0.15))

    def bar_counter(x0, x1, z0, z1, y, stools_side=None):
        box("walnut", x0, x1, y, y + 1.05, z0, z1)
        box("marble_white", x0 - 0.05, x1 + 0.05, y + 1.05, y + 1.12, z0 - 0.05, z1 + 0.05)
        box("lamp", x0 + 0.1, x1 - 0.1, y + 0.05, y + 0.1, z0 - 0.02, z1 + 0.02)
        if stools_side:
            ax, s = stools_side
            if ax == "z":
                for x in np.arange(x0 + 0.5, x1 - 0.2, 0.8):
                    zz = (z1 + 0.55) if s > 0 else (z0 - 0.55)
                    b.cyl("chrome", 0.04, 0.75, (x, y + 0.375, zz), 6)
                    b.cyl("leather_white", 0.22, 0.08, (x, y + 0.79, zz), 8)
            else:
                for z in np.arange(z0 + 0.5, z1 - 0.2, 0.8):
                    xx = (x1 + 0.55) if s > 0 else (x0 - 0.55)
                    b.cyl("chrome", 0.04, 0.75, (xx, y + 0.375, z), 6)
                    b.cyl("leather_white", 0.22, 0.08, (xx, y + 0.79, z), 8)

    def bottles(x0, x1, z, y, n_rows=3, face=1):
        for k in range(n_rows):
            yy = y + 1.2 + k * 0.45
            box("glass", x0, x1, yy - 0.03, yy, z - 0.15, z + 0.15)
            for x in np.arange(x0 + 0.1, x1 - 0.05, 0.22):
                b.cyl("art_green" if rng.random() < 0.5 else "gold", 0.04, 0.28, (x, yy + 0.14, z), 5)

    def chandelier(cx, cz, ytop, drop=1.2, r0=0.9, tiers=2):
        b.beam("brass", (cx, ytop, cz), (cx, ytop - drop, cz), 0.03)
        for i in range(tiers):
            r = r0 * (1.0 - 0.35 * i)
            yy = ytop - drop - 0.35 * i
            t = trimesh.creation.torus(major_radius=r, minor_radius=0.03, major_sections=12, minor_sections=3)
            t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
            b.add("brass", t.apply_translation((cx, yy, cz)))
            for k in range(max(6, int(9 * r))):
                a = k * 2 * np.pi / max(6, int(9 * r))
                b.add("diamond", octa(0.05, 2.2).apply_translation((cx + r * np.cos(a), yy - 0.14, cz + r * np.sin(a))))
        b.cyl("lamp", 0.18 * r0, 0.35, (cx, ytop - drop - 0.25, cz), 8)

    ART = ["art_red", "art_blue", "art_yellow", "art_green", "art_orange", "art_purple", "art_black", "art_white"]

    def painting(name, x, y, z, w, h, face):
        """abstract painting on a wall; face = direction the picture looks at ('+x','-x','+z','-z')"""
        prev = b.layer
        node(name, (x, y, z))
        ax = face[1]
        s = 1 if face[0] == "+" else -1
        def P(u0, u1, v0, v1, d0, d1, mat):
            if ax == "x":
                box(mat, x + s * d0, x + s * d1, y + v0, y + v1, z + u0, z + u1)
            else:
                box(mat, x + u0, x + u1, y + v0, y + v1, z + s * d0, z + s * d1)
        P(-w / 2 - 0.08, w / 2 + 0.08, -h / 2 - 0.08, h / 2 + 0.08, 0.0, 0.05, "gold")
        P(-w / 2, w / 2, -h / 2, h / 2, 0.05, 0.07, ART[int(rng.integers(6, 8))])
        for k in range(3):
            u0 = rng.uniform(-w / 2, w / 4)
            v0 = rng.uniform(-h / 2, h / 4)
            P(u0, min(w / 2, u0 + rng.uniform(0.25, 0.6) * w), v0, min(h / 2, v0 + rng.uniform(0.25, 0.6) * h), 0.07, 0.08 + 0.005 * k,
              ART[int(rng.integers(0, 6))])
        b.layer = prev
        b.anchor(name, (x + (s * 0.8 if ax == "x" else 0.0), y - h / 2 - 1.0, z + (s * 0.8 if ax == "z" else 0.0)), 0)

    def sculpture(name, x, y, z, kind=0):
        box("marble_white", x - 0.35, x + 0.35, y, y + 1.0, z - 0.35, z + 0.35)
        prev = b.layer
        node(name, (x, y + 1.0, z))
        if kind == 0:
            for k in range(4):
                b.box("gold", (0.3 - 0.05 * k, 0.32, 0.3 - 0.05 * k), (x, y + 1.18 + 0.3 * k, z), rot_y=22 * k)
        elif kind == 1:
            t = trimesh.creation.torus(major_radius=0.35, minor_radius=0.08, major_sections=14, minor_sections=4)
            b.add("chrome", t.apply_translation((x, y + 1.45, z)))
            b.add("chrome", trimesh.creation.icosphere(subdivisions=1, radius=0.14).apply_translation((x, y + 1.45, z)))
        else:
            b.add("art_red", octa(0.28, 1.8).apply_translation((x, y + 1.5, z)))
        b.layer = prev
        b.anchor(name, (x, y, z), 0)

    def gem_tray(x0, x1, z0, z1, y, step=0.3):
        box("velvet_blue", x0, x1, y, y + 0.02, z0, z1)
        for x in np.arange(x0 + 0.12, x1 - 0.05, step):
            for z in np.arange(z0 + 0.12, z1 - 0.05, step):
                if rng.random() < 0.5:
                    m = trimesh.creation.cylinder(radius=0.035, height=0.012, sections=6)
                    m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
                    b.add("gold", m.apply_translation((x, y + 0.055, z)))
                b.add(["gem_blue", "gem_red", "gem_green", "diamond"][int(rng.integers(0, 4))], octa(0.03).apply_translation((x, y + 0.1, z)))

    def vitrine(name, x, z, y, w=1.4, d=0.7, loot=None):
        box("lacquer", x - w / 2, x + w / 2, y, y + 0.9, z - d / 2, z + d / 2)
        box("brass", x - w / 2 - 0.01, x + w / 2 + 0.01, y + 0.9, y + 0.94, z - d / 2 - 0.01, z + d / 2 + 0.01)
        prev = b.layer
        if loot:
            node(loot, (x, y + 0.94, z))
        gem_tray(x - w / 2 + 0.05, x + w / 2 - 0.05, z - d / 2 + 0.05, z + d / 2 - 0.05, y + 0.94)
        b.layer = prev
        node(name, (x, y + 1.2, z))
        box("glass_shop", x - w / 2, x + w / 2, y + 0.94, y + 1.45, z - d / 2, z + d / 2)
        b.layer = prev
        b.anchor(name, (x, y, z), 0)

    def gold_pallet(x, y, z, h=0.6, name=None):
        prev = b.layer
        if name:
            node(name, (x, y, z))
        box("crate", x - 0.6, x + 0.6, y, y + 0.14, z - 0.5, z + 0.5)
        box("gold_bar", x - 0.55, x + 0.55, y + 0.14, y + 0.14 + h, z - 0.45, z + 0.45)
        yy = y + 0.14 + h
        for i in range(3):
            for j in range(2):
                bx, bz = x - 0.36 + i * 0.36, z - 0.2 + j * 0.4
                b.hull("gold_bar", [(bx + dx, yy, bz + dz) for dx in (-0.12, 0.12) for dz in (-0.065, 0.065)] +
                       [(bx + dx, yy + 0.07, bz + dz) for dx in (-0.1, 0.1) for dz in (-0.05, 0.05)])
        b.layer = prev

    def laser_grid(name, x0, x1, z0, z1, y, n=7):
        prev = b.layer
        node(name, ((x0 + x1) / 2, y + 1.0, (z0 + z1) / 2))
        for k in range(n):
            yy = y + 0.3 + (k % 4) * 0.45
            x = x0 + (k + 0.5) * (x1 - x0) / n
            b.box("laser_red", (0.015, 0.015, z1 - z0), (x, yy, (z0 + z1) / 2), rot_x=(k % 3 - 1) * 16)
        b.layer = prev

    def plant(x, z, y, h=1.6):
        b.cyl("lacquer", 0.3, 0.55, (x, y + 0.275, z), 10)
        b.rock("hedge", 0.45, (x, y + 0.55 + h * 0.45, z), 1.6 * h / 1.6)

    def tender(name, x, z, y, L=10.0, W=3.0, rot=0.0):
        """limousine tender, bow +x"""
        prev = b.layer
        node(name, (x, y, z))
        pts = []
        for (dx, hw, yb) in ((-L / 2, W / 2 * 0.9, 0.5), (-L / 4, W / 2, 0.0), (L / 5, W / 2, 0.05), (L / 2 - 0.6, W / 4, 0.4), (L / 2, 0.05, 1.0)):
            for s in (-1, 1):
                pts += [(x + dx, y + yb, z + s * hw * 0.85), (x + dx, y + 1.2, z + s * hw)]
        b.hull(HULL, pts)
        b.hull("yacht_white", [(x + dx, y + 1.2, z + s * W / 2 * f) for (dx, f) in ((-L / 2, 0.9), (L / 2 - 0.7, 0.4), (L / 2 - 0.05, 0.03)) for s in (-1, 1)] +
               [(x + dx, y + 1.3, z + s * W / 2 * f) for (dx, f) in ((-L / 2, 0.9), (L / 2 - 0.7, 0.4)) for s in (-1, 1)])
        b.hull("yacht_white", [(x + dx, y + 1.3, z + s * W * 0.4) for dx in (-L * 0.3, L * 0.2) for s in (-1, 1)] +
               [(x + dx, y + 2.3, z + s * W * 0.33) for dx in (-L * 0.25, L * 0.05) for s in (-1, 1)])
        for s in (-1, 1):
            box("glass", x - L * 0.22, x + L * 0.1, y + 1.65, y + 2.15, z + s * W * 0.37 - 0.02, z + s * W * 0.37 + 0.02)
        box("teak", x - L / 2 + 0.2, x - L * 0.3, y + 1.21, y + 1.25, z - W * 0.4, z + W * 0.4)
        b.layer = prev

    def jetski(name, x, z, y, along="x"):
        """jet ski, bow +x (along='z': bow +z)"""
        prev = b.layer
        node(name, (x, y, z))
        P = (lambda u, v, w: (x + u, y + v, z + w)) if along == "x" else (lambda u, v, w: (x + w, y + v, z + u))
        b.hull("cushion_navy", [P(dx, yy, s * hw) for (dx, hw) in ((-1.4, 0.55), (0.6, 0.6), (1.5, 0.1)) for yy in (0.0, 0.6) for s in (-1, 1)])
        b.hull("leather_white", [P(dx, yy, s * 0.25) for dx in (-1.1, 0.1) for yy in (0.6, 0.95) for s in (-1, 1)])
        b.beam("chrome", P(0.5, 0.9, -0.4), P(0.5, 0.9, 0.4), 0.05)
        b.layer = prev

    def submarine(name, x, z, y):
        """3-seat tourist sub (yellow), bow +x"""
        prev = b.layer
        node(name, (x, y + 1.1, z))
        cyl_axis("sub_yellow", 1.0, 4.0, (x, y + 1.1, z), "x", 14)
        for s in (-1, 1):
            b.add("sub_yellow", trimesh.creation.icosphere(subdivisions=1, radius=1.0).apply_scale((1.0, 1.0, 1.0)).apply_translation((x + s * 2.0, y + 1.1, z)))
        dome = trimesh.creation.icosphere(subdivisions=2, radius=0.85)
        dome.apply_scale((1.2, 0.8, 1.0))
        b.add("heli_glass", dome.apply_translation((x + 1.2, y + 1.75, z)))
        for s in (-1, 1):
            cyl_axis("frame_black", 0.28, 0.9, (x - 1.6, y + 1.0, z + s * 1.25), "x", 10)
            box("sub_yellow", x - 2.6, x - 1.9, y + 0.6, y + 1.6, z + s * 0.05 - 0.05, z + s * 0.05 + 0.05)
        b.add("uw_light", octa(0.15).apply_translation((x + 3.0, y + 1.0, z)))
        box("frame_black", x - 1.6, x + 1.6, y, y + 0.15, z - 0.9, z + 0.9)
        b.layer = prev

    def helicopter(name, x, y, z):
        """twin-engine VIP helicopter, nose +x"""
        prev = b.layer
        node(name, (x, y, z))
        b.hull("heli_body", [(x + dx, y + yy, z + s * hw) for (dx, yy, hw) in ((-2.2, 1.0, 0.9), (-2.2, 2.9, 0.8), (1.6, 0.9, 0.95), (1.6, 2.8, 0.9),
                                                                              (3.1, 1.3, 0.5), (3.0, 2.3, 0.45)) for s in (-1, 1)])
        b.hull("heli_glass", [(x + dx, y + yy, z + s * hw) for (dx, yy, hw) in ((1.7, 1.6, 0.92), (1.7, 2.75, 0.85), (3.15, 1.45, 0.48), (3.05, 2.25, 0.42))
                              for s in (-1, 1)])
        for s in (-1, 1):
            box("heli_glass", x - 1.6, x + 1.2, y + 1.9, y + 2.5, z + s * 0.93 - 0.02, z + s * 0.93 + 0.02)
            b.beam("chrome", (x - 1.6, y + 0.15, z + s * 1.2), (x + 2.2, y + 0.15, z + s * 1.2), 0.08)
            for dx in (-1.0, 1.2):
                b.beam("chrome", (x + dx, y + 0.15, z + s * 1.2), (x + dx, y + 1.0, z + s * 0.8), 0.06)
        b.hull("heli_body", [(x - 2.2, y + yy, z + s * 0.35) for yy in (1.8, 2.7) for s in (-1, 1)] + [(x - 9.0, y + yy, z + s * 0.15) for yy in (2.3, 2.6) for s in (-1, 1)])
        b.hull("heli_body", [(x - 8.6, y + 2.3, z), (x - 9.6, y + 4.0, z), (x - 9.0, y + 2.3, z + 0.08), (x - 9.9, y + 3.9, z - 0.08), (x - 9.3, y + 2.4, z)])
        cyl_axis("frame_black", 0.85, 0.05, (x - 9.0, y + 2.9, z + 0.25), "z", 10)
        b.hull("heli_body", [(x + dx, y + 2.9, z + s * 0.5) for dx in (-1.6, 0.8) for s in (-1, 1)] + [(x + dx, y + 3.3, z + s * 0.35) for dx in (-1.2, 0.5) for s in (-1, 1)])
        b.cyl("frame_black", 0.12, 0.5, (x - 0.3, y + 3.55, z), 6)
        for k in range(5):
            a = k * 2 * np.pi / 5 + 0.3
            b.box("frame_black", (5.4, 0.05, 0.32), (x - 0.3 + 2.7 * np.cos(a), y + 3.8, z + 2.7 * np.sin(a)), rot_y=-np.degrees(a))
        box("gold_trim", x - 2.2, x + 1.6, y + 1.35, y + 1.45, z - 0.96, z + 0.96)
        b.layer = prev

    # ================================================================ HULL
    def hull_point(x, y):
        yy = max(y, bottom_y(x))
        w = hb(x, yy)
        if yy <= -5.45 and x < 58.0:
            w = max(w, 0.3)
        return yy, w

    grid = {}
    for i, x in enumerate(STX):
        for j, y in enumerate(YS):
            grid[i, j] = hull_point(x, y)
    nx, ny = len(STX), len(YS)
    parts = {}
    for s in (1, -1):
        for i in range(nx - 1):
            for j in range(ny - 1):
                if 2 <= j <= 4 and GARAGE[0] <= STX[i] and STX[i + 1] <= GARAGE[1]:
                    continue                                                  # tender garage door openings
                if s > 0 and 2 <= j <= 3 and JETSKI[0] <= STX[i] and STX[i + 1] <= JETSKI[1]:
                    continue                                                  # jet-ski side garage (starboard, y 1.2 .. 4.3)
                if s > 0 and j == 7 and DIVE[0] <= STX[i] and STX[i + 1] <= DIVE[1]:
                    continue                                                  # dive-lockout hatch (starboard, y -2.5 .. -1.0)
                q = []
                for (ii, jj) in ((i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)):
                    yy, w = grid[ii, jj]
                    q.append((STX[ii], yy, s * w))
                mat = "gold_trim" if j in (1, 5) else (HULL if j <= 4 else "antifouling")
                lay = "Rumpf" if j <= 3 else "Aussen"
                parts.setdefault((lay, mat), []).append(q)
    for i in range(nx - 1):                                                   # flat keel strip
        yy0, w0 = grid[i, ny - 1]
        yy1, w1 = grid[i + 1, ny - 1]
        parts.setdefault(("Aussen", "antifouling"), []).append([(STX[i], yy0, w0), (STX[i + 1], yy1, w1), (STX[i + 1], yy1, -w1), (STX[i], yy0, -w0)])
    for (lay, mat), quads in parts.items():
        V, F = [], []
        for q in quads:
            k = len(V)
            V += q
            F += [(k, k + 1, k + 2), (k, k + 2, k + 3)]
        m = trimesh.Trimesh(np.array(V, float), np.array(F), process=False)
        cen = m.triangles_center
        ref = np.c_[np.clip(cen[:, 0], -70.0, 68.0), np.full(len(cen), -1.0), np.zeros(len(cen))]
        flip = (m.face_normals * (cen - ref)).sum(1) < 0
        Fa = np.array(F)
        Fa[flip] = Fa[flip][:, ::-1]
        m = trimesh.Trimesh(np.array(V, float), Fa, process=True)
        b.add((lay, mat), m)
    # transom plate with the beach-club door opening
    tp = [(grid[0, j][1], grid[0, j][0]) for j in range(ny)]
    tpoly = Polygon(tp + [(-u, v) for (u, v) in tp[::-1]]).buffer(0).difference(sbox(-5.0, 1.0, 5.0, 3.8))
    for p in getattr(tpoly, "geoms", [tpoly]):
        for lay, (ya, yb_) in (("Rumpf", (1.2, 6.0)), ("Aussen", (-6.0, 1.2))):
            part = p.intersection(sbox(-20, ya, 20, yb_))
            for pp in getattr(part, "geoms", [part]):
                if pp.geom_type != "Polygon" or pp.area < 1e-3:
                    continue
                m = trimesh.creation.extrude_polygon(Polygon([(-u, v) for u, v in pp.exterior.coords]), 0.15)
                m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
                b.add((lay, HULL if ya > 0 else "antifouling"), m.apply_translation((-75.1, 0, 0)))
    b.layer = "Rumpf"
    for s in (-1, 1):                                                         # garage door jambs
        for x in GARAGE:
            box("stainless", x - 0.1, x + 0.1, 0.6, 4.3, s * 11.65 - 0.3, s * 11.65 + 0.3)
        box("stainless", GARAGE[0], GARAGE[1], 4.25, 4.35, s * 11.75 - 0.3, s * 11.75 + 0.3)
        box("stainless", GARAGE[0], GARAGE[1], 0.55, 0.65, s * 11.6 - 0.3, s * 11.6 + 0.3)
    for x in JETSKI:                                                          # jet-ski door jambs (starboard)
        w = hb(x, 2.4)
        box("stainless", x - 0.1, x + 0.1, 1.2, 4.3, w - 0.45, w + 0.15)
    for (yy, ya) in ((4.3, 4.25), (1.2, 1.1)):
        w0, w1 = hb(JETSKI[0], yy), hb(JETSKI[1], yy)
        b.hull("stainless", [(x_, ya + e, w + d) for (x_, w) in ((JETSKI[0], w0), (JETSKI[1], w1)) for e in (0.0, 0.1) for d in (-0.45, 0.12)])
    for x in DIVE:                                                            # dive hatch jambs (starboard)
        w = hb(x, -1.75)
        box("stainless", x - 0.08, x + 0.08, -2.5, -1.0, w - 0.25, w + 0.12)
    # hull windows (Unterdeck) + names
    for x in np.arange(-46.0, 52.0, 3.6):
        for s in (-1, 1):
            if s > 0 and JETSKI[0] - 1.0 < x < JETSKI[1] + 1.0:
                continue                                                      # these two sit on the jet-ski door
            w0, w1 = hb(x - 0.9, 2.6), hb(x + 0.9, 2.6)
            ang = np.degrees(np.arctan2(w1 - w0, 1.8))
            b.box("stainless", (1.96, 0.71, 0.04), (x, 2.6, s * ((w0 + w1) / 2 + 0.01)), rot_y=-s * ang)
            b.box("glass", (1.8, 0.55, 0.06), (x, 2.6, s * ((w0 + w1) / 2 + 0.03)), rot_y=-s * ang)
    for s in (-1, 1):
        x = 54.0
        w0, w1 = hb(x - 0.5, 3.0), hb(x + 0.5, 3.0)
        ang = np.degrees(np.arctan2(-(w1 - w0), 1.0))
        rot = np.degrees(np.arctan2(-(w1 - w0), s * 1.0))
        b.text("SOBERANA", "gold_trim", (x, 2.6, s * (hb(x, 2.6) + 0.06)), 1.1, 0.06, rot_y=rot, simplify=0.02)
    b.text("SOBERANA", "gold_trim", (-75.17, 4.3, 0.0), 0.55, 0.05, rot_y=-90, simplify=0.02)
    # bow: anchors in hawse pockets, stem plate
    for s in (-1, 1):
        x = 66.0
        w = hb(x, 3.2)
        box("stainless", x - 0.9, x + 0.9, 2.6, 3.8, s * (w + 0.02) - 0.15, s * (w + 0.02) + 0.15)
        b.hull("stainless", [(x + dx, y_, s * (w + 0.2)) for (dx, y_) in ((-0.5, 3.4), (0.5, 3.4), (0.0, 1.8))] +
               [(x + dx, y_, s * (w + 0.4)) for (dx, y_) in ((-0.6, 2.2), (0.6, 2.2), (0.0, 1.6))])
    # ================================================================ AUSSEN (below water: running gear)
    b.layer = "Aussen"
    for s in (-1, 1):
        z = s * 3.6
        b.beam("stainless", (-40.0, -4.6, z), (-62.0, -3.3, z), 0.35)
        for k in range(5):
            a = k * 2 * np.pi / 5
            b.box("gold_trim", (0.2, 1.4, 0.5), (-62.4, -3.3 + 0.75 * np.sin(a), z + 0.75 * np.cos(a)), rot_x=np.degrees(a))
        cyl_axis("stainless", 0.3, 0.6, (-62.4, -3.3, z), "x", 8)
        box("antifouling", -66.5, -64.5, -4.0, -1.0, z - 0.12, z + 0.12)                     # rudder
        b.box("antifouling", (3.0, 0.15, 1.6), (-20.0, -4.8, s * 9.3), rot_x=s * 20)        # stabiliser fins
        b.box("antifouling", (3.0, 0.15, 1.6), (10.0, -4.8, s * 9.3), rot_x=s * 20)
    for k in range(8):                                                         # underwater lights at the stern
        z = -7.0 + k * 2.0
        b.add("uw_light", trimesh.creation.icosphere(subdivisions=0, radius=0.22).apply_translation((-74.3, -0.45, z)))
    cyl_axis("frame_black", 0.9, 0.2, (63.0, -3.0, 0.0), "z", 12)              # bow thruster tunnel (both sides)

    # ================================================================ DECK GEOMETRY (shared)
    MAIN = outline(5.0)
    SLABS = {
        "Hauptdeck": MAIN,
        "Oberdeck": sup_poly(-61.0, 63.0, 11.4, 22.0, 1.0).intersection(MAIN.buffer(-0.35)),
        "Eignerdeck": sup_poly(-52.0, 46.0, 11.0, 16.0, 1.0).intersection(MAIN.buffer(-0.45)),
        "Brueckendeck": sup_poly(-42.0, 36.0, 10.6, 12.0, 1.0).intersection(MAIN.buffer(-0.9)),
        "Sonnendeck": sup_poly(-22.0, 26.0, 9.2, 10.0, 1.0),
    }
    HOUSES = {
        "Hauptdeck": sup_poly(-58.0, 40.0, 10.0, 14.0, 1.5),
        "Oberdeck": sup_poly(-46.0, 40.0, 10.2, 12.0, 1.5),
        "Eignerdeck": sup_poly(-34.0, 34.0, 9.6, 12.0, 1.5),
        "Brueckendeck": sup_poly(-24.0, 33.0, 9.0, 8.0, 1.5),
        "Sonnendeck": sup_poly(-1.0, 18.0, 6.0, 5.0, 1.5),
    }
    HARDTOP = sup_poly(-2.0, 24.0, 8.0, 6.0, 1.5)
    INTERIOR_FLOOR = {"Hauptdeck": "marble_white", "Oberdeck": "carpet_cream", "Eignerdeck": "oak", "Brueckendeck": "carpet_navy", "Sonnendeck": "teak"}
    spiral_hole = Point(SPIRAL[0], SPIRAL[1]).buffer(SPIRAL[2], 24)
    core_hole = sbox(CORE[0], CORE[2], CORE[1], CORE[3])
    plift_hole = sbox(PLIFT[0], PLIFT[2], PLIFT[1], PLIFT[3])
    BCSTAIRS = [sbox(-74.5, s * 7.0 if s > 0 else -8.8, -69.5, s * 8.8 if s > 0 else -7.0) for s in (1, -1)]
    POOL = sbox(-73.0, -4.5, -63.0, 4.5)
    HOLES = {
        "Unterdeck": [core_hole, plift_hole],
        "Hauptdeck": [spiral_hole, core_hole, plift_hole, POOL] + BCSTAIRS,
        "Oberdeck": [spiral_hole, core_hole, plift_hole],
        "Eignerdeck": [spiral_hole, core_hole, plift_hole],
        "Brueckendeck": [spiral_hole, core_hole],
        "Sonnendeck": [spiral_hole],
    }
    # stair flights between the aft decks: (deck_from, x_bottom, x_top, |z| range)
    EXT = [("Hauptdeck", -67.0, -61.0, (8.4, 9.8)), ("Oberdeck", -58.0, -52.0, (8.4, 9.8)), ("Eignerdeck", -48.0, -42.0, (8.2, 9.6)),
           ("Brueckendeck", -28.0, -22.0, (6.6, 8.0))]

    def ceil_of(lv):
        i = ORDER.index(lv)
        return DY[ORDER[i + 1]] - SLAB if i + 1 < len(ORDER) else TOP - SLAB

    # ================================================================ PER-DECK STRUCTURE
    # lower decks: floors inside the hull + lining walls
    for lv in ("Tankdeck", "Unterdeck"):
        b.layer = lv
        y = DY[lv]
        yt = ceil_of(lv)
        fl = outline(y, 0.25)
        for h in HOLES.get(lv, []):
            fl = fl.difference(h)
        flat("engine_grey" if lv == "Tankdeck" else "lining", fl, y - SLAB, y)
        lin = ring(outline(y, 0.15), 0.2)
        if lv == "Unterdeck":
            for s in (-1, 1):
                lin = lin.difference(sbox(GARAGE[0], -13.0, GARAGE[1], -10.0) if s < 0 else sbox(GARAGE[0], 10.0, GARAGE[1], 13.0))
            lin = lin.difference(sbox(-76.0, -5.0, -73.0, 5.0))
            cut = sbox(JETSKI[0], 8.0, JETSKI[1], 13.0)
            flat("lining", lin.intersection(cut), 4.3, yt)                     # lintel above the jet-ski door
            lin = lin.difference(cut)
        if lv == "Tankdeck":
            cut = sbox(DIVE[0], 8.0, DIVE[1], 13.0)
            flat("lining", lin.intersection(cut), -0.9, yt)                    # lintel above the dive hatch
            lin = lin.difference(cut)
        flat("lining", lin, y, yt)
    # upper decks: slabs (teak outside, interior floor inside), house walls, rails
    for lv in ("Hauptdeck", "Oberdeck", "Eignerdeck", "Brueckendeck", "Sonnendeck"):
        b.layer = lv
        y = DY[lv]
        yt = ceil_of(lv)
        sl = SLABS[lv]
        hs = HOUSES[lv]
        holes = unary_union(HOLES.get(lv, [])) if HOLES.get(lv) else Polygon()
        flat("yacht_white", sl.difference(holes), y - SLAB, y - 0.05)
        flat("teak", sl.difference(hs).difference(holes), y - 0.05, y)
        flat(INTERIOR_FLOOR[lv], hs.buffer(-0.2).difference(holes), y - 0.05, y)
        # roof of the part of the house below that is not covered by this deck's slab
        below = ORDER[ORDER.index(lv) - 1]
        if below in HOUSES:
            roof = HOUSES[below].difference(sl)
            if roof.area > 0.5:
                flat("yacht_white", roof, DY[lv] - SLAB, DY[lv] - 0.05)
    for lv in ("Oberdeck", "Eignerdeck", "Brueckendeck", "Sonnendeck"):           # LED strips under the deck edges
        b.layer = lv
        flat("lamp", ring(SLABS[lv].buffer(-0.12), 0.08), DY[lv] - SLAB - 0.03, DY[lv] - SLAB)
    # Hauptdeck: house, bulwark forward, rails, gates
    y = DY["Hauptdeck"]
    b.layer = "Hauptdeck"
    yt = ceil_of("Hauptdeck")
    hs = HOUSES["Hauptdeck"]
    house(hs, y, yt, doors=[(-58.6, -4.0, -57.4, 4.0), (-1.5, -10.6, 1.5, -9.2), (-1.5, 9.2, 1.5, 10.6), (39.0, -1.0, 41.0, 1.0)],
          vents=[(DUCTS["Hauptdeck"][2] - 0.5, DUCTS["Hauptdeck"][2] + 0.5)])
    for (z0, z1) in ((-4.0, -1.0), (1.0, 4.0)):
        box("glass_shop", -58.3, -58.2, y, yt - 0.3, z0, z1)
    bw = ring(MAIN.buffer(-0.05), 0.22).intersection(sbox(28.0, -20, 80.0, 20))
    flat(HULL, bw, y, y + 1.1)
    flat("teak", ring(MAIN.buffer(-0.02), 0.3).intersection(sbox(28.0, -20, 80.0, 20)), y + 1.1, y + 1.16)
    gate = [(-1.5, -13.0, 1.5, -10.5), (-1.5, 10.5, 1.5, 13.0)]
    rails(MAIN.difference(sbox(28.0, -20, 80.0, 20)).buffer(0), y, gaps=gate + [(27.0, -20.0, 29.0, 20.0)])
    for s, side in ((-1, "BB"), (1, "SB")):                                  # rail gates (side boarding) + house side doors
        node(f"Hauptdeck_Relingstor_{side}", (-1.5, y, s * 11.8))
        box("glass_rail", -1.5, 1.5, y, y + 1.0, s * 11.8 - 0.03, s * 11.8 + 0.03)
        box("stainless", -1.5, 1.5, y + 1.0, y + 1.06, s * 11.8 - 0.05, s * 11.8 + 0.05)
        node(f"Hauptdeck_Seitentuer_{side}", (-1.5, y, s * 9.9))
        box("glass_shop", -1.5, 1.5, y, yt - 0.3, s * 9.9 - 0.04, s * 9.9 + 0.04)
        box("stainless", -1.5, 1.5, yt - 0.3, yt - 0.2, s * 9.9 - 0.06, s * 9.9 + 0.06)
        b.layer = "Hauptdeck"
    node("Hauptdeck_Passerelle", (0.0, y, -11.9))                            # folding gangway to the quay (port side)
    b.hull("stainless", [(x, yy, z) for x in (-0.6, 0.6) for (yy, z) in ((y - 0.05, -11.9), (3.05, -16.6), (y - 0.25, -11.9), (2.85, -16.6))])
    for x in (-0.6, 0.6):
        b.beam("stainless", (x, y + 1.0, -11.9), (x, 4.05, -16.6), 0.03)
        b.beam("stainless", (x, y, -11.9), (x, y + 1.0, -11.9), 0.03)
        b.beam("stainless", (x, 3.05, -16.6), (x, 4.05, -16.6), 0.03)
    b.layer = "Hauptdeck"
    b.anchor("Passerelle_Oben", (0.0, y, -11.4), 0)
    b.anchor("Passerelle_Unten", (0.0, 3.0, -17.2), 0)
    # pool (glass bottom, visible from the beach club below)
    px0, pz0, px1, pz1 = POOL.bounds
    for (a, c, d, e) in ((px0, px1, pz0 - 0.2, pz0), (px0, px1, pz1, pz1 + 0.2), (px0 - 0.2, px0, pz0 - 0.2, pz1 + 0.2), (px1, px1 + 0.2, pz0 - 0.2, pz1 + 0.2)):
        box("yacht_white", a, c, 3.7, y, d, e)
    box("glass_shop", px0, px1, 3.7, 3.78, pz0, pz1)
    box("pool", px0, px1, 3.78, y - 0.15, pz0, pz1)
    for (a, c, d, e) in ((px0 - 0.35, px1 + 0.35, pz0 - 0.35, pz0), (px0 - 0.35, px1 + 0.35, pz1, pz1 + 0.35), (px1, px1 + 0.35, pz0, pz1)):
        box("marble_white", a, c, y - 0.05, y + 0.04, d, e)
    box("glass_rail", px0 - 0.1, px0, y - 0.05, y + 0.9, pz0, pz1)            # infinity edge glass
    for x in np.arange(px0 + 1.0, px1, 2.0):
        b.add("uw_light", octa(0.12).apply_translation((x, 4.1, 0.0)))
    # Oberdeck .. Sonnendeck: houses + rails
    DOORS = {
        "Oberdeck": [(-46.6, -4.0, -45.4, 4.0), (39.5, -1.0, 41.0, 1.0), (-1.5, -10.8, 1.5, -9.4), (-1.5, 9.4, 1.5, 10.8)],
        "Eignerdeck": [(-34.6, -3.0, -33.4, 3.0), (33.5, -1.0, 35.0, 1.0)],
        "Brueckendeck": [(-24.6, -2.0, -23.4, 2.0), (26.0, -9.6, 27.2, -8.0), (26.0, 8.0, 27.2, 9.6)],
        "Sonnendeck": [(-1.6, -1.5, -0.4, 1.5), (17.0, -1.0, 18.6, 1.0)],
    }
    for lv in ("Oberdeck", "Eignerdeck", "Brueckendeck", "Sonnendeck"):
        b.layer = lv
        y = DY[lv]
        yt = ceil_of(lv) if lv != "Sonnendeck" else TOP - SLAB
        band = (1.0, 0.3) if lv == "Brueckendeck" else (0.8, 0.45)
        house(HOUSES[lv], y, yt, DOORS[lv], 3.2, band, ((-33.6, -14.2),) if lv == "Eignerdeck" else (),
              [(DUCTS[lv][2] - 0.5, DUCTS[lv][2] + 0.5)] if lv in DUCTS else ())
        gaps = []
        for (dk, xa, xb, (za, zb)) in EXT:
            if ORDER.index(dk) + 1 == ORDER.index(lv):                        # stairs arrive at the aft edge of this slab
                gaps += [(xb - 1.0, za - 0.2, xb + 1.0, zb + 0.2), (xb - 1.0, -zb - 0.2, xb + 1.0, -za + 0.2)]
        if lv == "Oberdeck":
            gaps += [(42.0, -12.0, 70.0, 12.0)]                               # helideck edge: safety net instead of rails
        rails(SLABS[lv], y, gaps=gaps)
    # aft exterior stairs (port + starboard)
    for (dk, xa, xb, (za, zb)) in EXT:
        b.layer = dk
        ya, yb_ = DY[dk], DY[ORDER[ORDER.index(dk) + 1]]
        for s in (-1, 1):
            z0, z1 = sorted((s * za, s * zb))
            flight_x(xa, xb, z0, z1, ya, yb_, broken=dk in BROKEN_EXT)
    for lv in DUCTS:                                                          # crawlable vent ducts with hatches
        duct(lv, ceil_of(lv))
        b.layer = lv
        for k, hx in enumerate(HATCHES[lv]):
            b.anchor(f"Wache_{lv}_{k + 1}", (hx, DY[lv], (DUCT[0] + DUCT[1]) / 2), 90 if k % 2 else -90)
    # beach-club stairs (Unterdeck -> Hauptdeck, inside the stern)
    b.layer = "Unterdeck"
    for s in (-1, 1):
        z0, z1 = sorted((s * 7.1, s * 8.7))
        flight_x(-69.7, -74.3, z0, z1, DY["Unterdeck"], DY["Hauptdeck"], "teak", "lining")
    # guest spiral stair + glass lift (Unterdeck -> Sonnendeck)
    cx, cz, rr = SPIRAL
    a = 0.0
    for k, lv in enumerate(ORDER[1:-1]):
        b.layer = lv
        brk = lv in BROKEN_SPIRAL
        a = spiral(cx, cz, 1.25, rr - 0.1, DY[lv], DY[ORDER[ORDER.index(lv) + 1]], a, brk)
        if brk or lv == "Brueckendeck":                                       # lift out of order up to the bridge deck: sign on a stand
            sx_, sz_, y_ = cx + 3.95, cz + 0.0, DY[lv]
            b.cyl("frame_black", 0.03, 1.0, (sx_, y_ + 0.5, sz_), 6)
            b.cyl("frame_black", 0.2, 0.04, (sx_, y_ + 0.02, sz_), 8)
            box("safety_yellow", sx_ - 0.01, sx_ + 0.01, y_ + 1.0, y_ + 1.42, sz_ - 0.33, sz_ + 0.33)
            for li, txt in enumerate(("FORA DE", "SERVIÇO")):
                b.text(txt, "hazard", (sx_ + 0.01, y_ + 1.27 - li * 0.14, sz_), 0.075, 0.008, rot_y=90, simplify=0.05)
        if lv == "Unterdeck" or ORDER[ORDER.index(lv) - 1] in BROKEN_SPIRAL:   # tape around the open stairwell
            pts_ = [(cx + 3.6 * np.cos(t_), cz + 3.6 * np.sin(t_)) for t_ in np.linspace(0, 2 * np.pi, 9)]
            for (px_, pz_) in pts_[:-1]:
                b.cyl("hazard", 0.04, 1.0, (px_, DY[lv] + 0.5, pz_), 6)
                b.cyl("frame_black", 0.18, 0.05, (px_, DY[lv] + 0.025, pz_), 8)
            for (p0_, p1_) in zip(pts_[:-1], pts_[1:]):
                for yy in (DY[lv] + 0.55, DY[lv] + 0.95):
                    b.beam("safety_yellow", (p0_[0], yy, p0_[1]), (p1_[0], yy, p1_[1]), 0.03)
        if lv == "Unterdeck":
            broken_marks(cx + 1.6, cz + 1.6, DY[lv], 9, 1.3)
        b.cyl("glass_shop", 1.15, DY[ORDER[ORDER.index(lv) + 1]] - DY[lv], (cx, (DY[lv] + DY[ORDER[ORDER.index(lv) + 1]]) / 2, cz), 16)
        t = trimesh.creation.torus(major_radius=1.17, minor_radius=0.05, major_sections=16, minor_sections=3)
        t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        b.add("brass", t.apply_translation((cx, DY[lv] + 2.6, cz)))
        b.anchor(f"Aufzug_{lv}", (cx - 1.6, DY[lv], cz), 90)
        b.anchor(f"Wendeltreppe_{lv}", (cx + rr + 0.6, DY[lv], cz), -90)
    b.layer = "Sonnendeck"
    b.anchor("Aufzug_Sonnendeck", (cx - 1.6, DY["Sonnendeck"], cz), 90)
    # crew stair core (Tankdeck -> Brueckendeck) + owner's private lift shaft (Tankdeck -> Eignerdeck)
    for lv in ORDER[:-1]:
        b.layer = lv
        y, yt = DY[lv], ceil_of(lv)
        core_walls(CORE, y, yt, True)
        if lv != "Brueckendeck":
            stair_core(CORE, y, DY[ORDER[ORDER.index(lv) + 1]], lv in BROKEN_CORE)
        b.anchor(f"Crew_Treppe_{lv}", (CORE[0] + 0.8, y, CORE[2] - 0.8), 0)
        if ORDER.index(lv) <= ORDER.index("Eignerdeck"):
            pr = ring(plift_hole, 0.15)
            if lv in ("Tankdeck", "Eignerdeck"):
                pr = pr.difference(sbox(PLIFT[0] + 0.3, PLIFT[3] - 0.3, PLIFT[1] - 0.3, PLIFT[3] + 0.3))
            flat("walnut" if lv not in ("Tankdeck",) else "vault_steel", pr, y, yt)
    node("Tankdeck_Privataufzug", ((PLIFT[0] + PLIFT[1]) / 2, DY["Tankdeck"], (PLIFT[2] + PLIFT[3]) / 2))
    box("brass", PLIFT[0] + 0.2, PLIFT[1] - 0.2, DY["Tankdeck"] - 0.1, DY["Tankdeck"], PLIFT[2] + 0.2, PLIFT[3] - 0.2)
    box("walnut", PLIFT[0] + 0.2, PLIFT[0] + 0.3, DY["Tankdeck"], DY["Tankdeck"] + 2.5, PLIFT[2] + 0.2, PLIFT[3] - 0.2)
    box("brass", PLIFT[0] + 0.2, PLIFT[1] - 0.2, DY["Tankdeck"] + 2.5, DY["Tankdeck"] + 2.6, PLIFT[2] + 0.2, PLIFT[3] - 0.2)
    b.layer = "Tankdeck"
    b.anchor("Privataufzug_Tankdeck", ((PLIFT[0] + PLIFT[1]) / 2, DY["Tankdeck"], PLIFT[3] + 0.8), 0)
    b.anchor("Privataufzug_Eignerdeck", ((PLIFT[0] + PLIFT[1]) / 2, DY["Eignerdeck"], PLIFT[3] + 0.8), 0)

    # ================================================================ TANKDECK – engines, control room, VAULT, wine cellar, stores
    y, yt = DY["Tankdeck"], ceil_of("Tankdeck")
    b.layer = "Tankdeck"
    for x, doors in ((-28.0, [(-1.0, 1.0)]), (-14.0, [(-1.0, 1.0)]), (10.5, [(6.6, 7.8)]), (34.0, [(-1.0, 1.0)])):
        segs = [(-12.0, 12.0)]
        for d0, d1 in doors:
            segs = [(p, min(q, d0)) for (p, q) in segs if min(q, d0) > p] + [(max(p, d1), q) for (p, q) in segs if q > max(p, d1)]
        for p, q in segs:
            wall = sbox(x - 0.15, p, x + 0.15, q).intersection(outline(y, 0.2))
            flat("lining", wall, y, yt)
    b.layer = "Tankdeck_Innen"
    for s in (-1, 1):                                                         # main engines
        z = s * 3.8
        box("engine_red", -50.0, -38.0, y, y + 2.0, z - 1.2, z + 1.2)
        box("engine_grey", -49.5, -38.5, y + 2.0, y + 2.6, z - 0.9, z + 0.9)
        for x in np.arange(-49.0, -38.5, 1.5):
            b.cyl("engine_grey", 0.28, 0.3, (x, y + 2.75, z - 0.45), 8)
            b.cyl("engine_grey", 0.28, 0.3, (x, y + 2.75, z + 0.45), 8)
        box("engine_grey", -52.5, -50.0, y + 0.2, y + 1.6, z - 0.9, z + 0.9)
        b.beam("stainless", (-52.5, y + 0.9, z), (-56.0, y + 0.6, z), 0.3)
        b.beam("pipe", (-44.0, y + 2.9, z), (-44.0, yt - 0.2, z), 0.45)
        box("safety_yellow", -50.5, -37.5, y, y + 0.01, z - 1.7, z - 1.6)
    for k, x in enumerate((-35.0, -32.0)):                                     # generators
        box("engine_grey", x - 1.1, x + 1.1, y, y + 1.8, -9.0, -6.0)
        box("engine_grey", x - 1.1, x + 1.1, y, y + 1.8, 6.0, 9.0)
    for z in np.arange(-8.0, 8.5, 1.2):                                       # switchboard on the forward bulkhead
        box("frame_black", -28.75, -28.2, y, y + 2.1, z - 0.55, z + 0.55)
        box("led_green", -28.77, -28.75, y + 1.6, y + 1.7, z - 0.2, z - 0.1)
    box("hazard", -28.8, -28.7, y + 1.0, y + 1.5, -0.4, 0.4)
    box("led_red", -28.82, -28.8, y + 1.15, y + 1.35, -0.2, 0.2)
    b.anchor("Notabschaltung", (-29.6, y, 0.0), 90)
    b.anchor("Maschinenraum", (-44.0, y, 0.0), 0)
    for z in (-6.0, 6.0):
        b.beam("pipe", (-55.0, yt - 0.4, z), (-28.5, yt - 0.4, z), 0.25)
    box("glass_shop", -27.8, -20.0, y, yt, 3.8, 3.86)                         # engine control room (glass)
    for z in (5.5, 7.5):
        box("frame_black", -27.5, -21.0, y, y + 0.9, z - 0.4, z + 0.4)
        for x in np.arange(-27.0, -21.0, 0.9):
            b.box("screen", (0.7, 0.45, 0.05), (x, y + 1.15, z - 0.42), rot_x=-15)
    chair(-24.5, 6.4, y, 0.0, "leather_brown")
    b.anchor("Maschinenkontrollraum", (-24.0, y, 4.6), 180)
    for x in np.arange(-26.5, -15.0, 2.2):                                    # workshop + spare-part racks
        box("vault_steel", x - 0.8, x + 0.8, y, y + 2.2, -8.8, -8.2)
        for yy in (y + 0.6, y + 1.3, y + 2.0):
            box("crate", x - 0.7, x + 0.7, yy - 0.45, yy - 0.05, -8.75, -8.25)
    box("vault_steel", -20.0, -16.0, y, y + 0.9, -3.5, -2.3)
    # --- VAULT: antechamber (private lift arrives), steel gate, laser corridor, round door, strongroom
    box("lacquer", -9.0, -7.0, y, y + 0.8, -9.2, -8.4)
    box("screen", -8.8, -7.2, y + 0.82, y + 1.2, -8.45, -8.4)
    chair(-8.0, -7.9, y, 180.0, "leather_brown")
    b.anchor("Wache_Tresor", (-8.0, y, -7.4), 180)
    b.layer = "Tankdeck"
    for z in (-1.3, 1.3):                                                     # corridor walls
        box("vault_steel", -6.0, 0.0, y, yt, z - 0.15, z + 0.15)
    flat("vault_steel", ring(sbox(0.0, -6.0, 10.0, 6.0), 0.5).difference(sbox(-0.6, -1.15, 0.6, 1.15)), y, yt)
    node("Tankdeck_Gitter", (-6.0, y, -1.15))
    for z in np.arange(-1.1, 1.15, 0.14):
        box("vault_steel", -6.03, -5.97, y, y + 2.5, z - 0.025, z + 0.025)
    box("vault_steel", -6.05, -5.95, y + 2.45, y + 2.55, -1.15, 1.15)
    b.layer = "Tankdeck_Innen"
    box("frame_black", -6.3, -6.1, y + 1.1, y + 1.5, 1.35, 1.6)
    box("led_red", -6.32, -6.3, y + 1.3, y + 1.4, 1.42, 1.52)
    laser_grid("Tankdeck_Laser", -5.8, -0.3, -1.15, 1.15, y, 7)
    b.anchor("Laser_Start", (-6.8, y, 0.0), 90)
    b.anchor("Laser_Ende", (-0.6, y, 0.0), 90)
    frame = sbox(-1.3, y, 1.3, y + 2.6).difference(Point(0.0, y + 1.3).buffer(1.15, 24))
    for fp in getattr(frame, "geoms", [frame]):
        m = trimesh.creation.extrude_polygon(Polygon([(-u, v) for u, v in fp.exterior.coords]), 0.12)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
        b.add("chrome", m.apply_translation((-0.15, 0, 0)))
    box("vault_steel", -0.5, 0.5, y + 2.6, yt, -1.3, 1.3)
    node("Tankdeck_Tresortuer", (0.0, y + 1.6, -1.15))
    m = trimesh.creation.cylinder(radius=1.15, height=0.5, sections=24)
    m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    b.add("vault_steel", m.apply_translation((0.25, y + 1.3, 0.0)))
    cyl_axis("chrome", 0.22, 0.3, (-0.1, y + 1.3, 0.0), "x", 10)
    for k in range(3):
        b.box("chrome", (0.08, 1.5, 0.08), (-0.15, y + 1.3, 0.0), rot_x=k * 60)
    for k in range(10):
        a = k * np.pi / 5
        cyl_axis("chrome", 0.07, 0.2, (-0.05, y + 1.3 + 0.9 * np.sin(a), 0.9 * np.cos(a)), "x", 6)
    b.layer = "Tankdeck_Innen"
    box("frame_black", -0.25, -0.05, y + 2.6, y + 3.0, -0.9, -0.4)
    box("led_red", -0.27, -0.25, y + 2.75, y + 2.85, -0.75, -0.55)
    b.anchor("Zeitschloss", (-0.8, y, -0.65), 90)
    b.anchor("Tresor_Tuer", (-1.2, y, 0.0), 90)
    for k, (x, z) in enumerate(((1.6, -3.1), (3.2, -3.1), (1.6, 3.1), (3.2, 3.1), (5.6, -3.1), (5.6, 3.1))):  # gold (each pallet = loot)
        gold_pallet(x, y, z, 0.7, f"Tankdeck_Beute_Gold_{k + 1}")
    for k, (z0_, z1_) in enumerate(((-5.0, -1.6), (1.6, 5.0))):              # cash cages (cash stack = loot)
        box("fence_net", 6.4, 8.5, y, y + 2.2, z0_, z0_ + 0.03)
        box("fence_net", 6.4, 6.43, y, y + 2.2, z0_, z1_)
        node(f"Tankdeck_Beute_Bargeld_{k + 1}", (7.5, y, (z0_ + z1_) / 2))
        for j in range(3):
            box("cash_green", 6.6, 8.4, y + j * 0.4, y + 0.35 + j * 0.4, z0_ + 0.2, z1_ - 0.2)
            box("cloth_white", 7.4, 7.55, y + j * 0.4, y + 0.36 + j * 0.4, z0_ + 0.2, z1_ - 0.2)
        b.layer = "Tankdeck_Innen"
    for z in np.arange(-5.2, 5.3, 0.55):                                      # art storage rack (framed paintings)
        box("vault_steel", 8.8, 9.45, y + 2.7, y + 2.8, z - 0.02, z + 0.02)
        box("vault_steel", 8.8, 9.45, y, y + 0.35, z - 0.02, z + 0.02)
    for k, z in enumerate(np.arange(-4.95, 5.0, 0.55)):
        if k % 7 == 0:                                                        # 3 bundles of paintings = loot
            node(f"Tankdeck_Beute_Kunst_{k // 7 + 1}", (9.1, y + 0.4, z + 1.65))
        box(ART[k % 6], 8.85, 9.4, y + 0.4, y + 1.9, z - 0.04, z + 0.04)
        box("gold", 8.82, 9.42, y + 0.35, y + 0.42, z - 0.05, z + 0.05)
    b.layer = "Tankdeck_Innen"
    box("marble_black", 4.3, 5.1, y, y + 1.1, -0.4, 0.4)                     # the Safira Soberana
    node("Tankdeck_Beute_Safira", (4.7, y + 1.4, 0.0))
    sp = trimesh.convex.convex_hull(np.array([(0.18 * np.cos(a), 0.0, 0.18 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] +
                                             [(0.11 * np.cos(a + 0.4), 0.07, 0.11 * np.sin(a + 0.4)) for a in np.linspace(0, 2 * np.pi, 7)[:-1]] + [(0, -0.22, 0)]))
    b.add("gem_blue", sp.apply_translation((4.7, y + 1.45, 0.0)))
    b.cyl("velvet_blue", 0.25, 0.08, (4.7, y + 1.14, 0.0), 10)
    node("Tankdeck_Safira_Glas", (4.7, y + 1.5, 0.0))
    box("glass_shop", 4.25, 5.15, y + 1.1, y + 1.9, -0.45, 0.45)
    b.layer = "Tankdeck_Innen"
    b.anchor("Safira_Soberana", (4.7, y + 1.1, 0.0), 0)
    b.anchor("Tresor", (5.0, y, 0.0), 0)
    for (x0, z0) in ((0.6, -5.5), (0.6, 4.6)):                               # safe-deposit walls
        box("vault_steel", x0, x0 + 4.8, y, y + 2.6, z0, z0 + 0.9)
        for i in range(8):
            for j in range(4):
                zf = z0 + 0.9 if z0 < 0 else z0
                box("chrome", x0 + 0.05 + i * 0.6, x0 + 0.55 + i * 0.6, y + 0.15 + j * 0.62, y + 0.7 + j * 0.62, zf - 0.01, zf + 0.01)
    for (x, z, yaw) in ((-13.6, -9.0, 45), (-6.4, 1.6, 90), (0.8, -5.2, 135), (9.2, 5.2, -45), (-54.0, 0.0, 90), (-28.0, 8.5, -135)):
        cam(cam_id("Kamera_Tankdeck"), x, yt - 0.2, z, yaw)
    for x in np.arange(11.5, 19.5, 1.0):                                      # wine cellar (port; starboard = dive lockout)
        for s in (-1,):
            box("walnut", x - 0.4, x + 0.4, y, y + 2.4, s * 7.5 - 0.35, s * 7.5 + 0.35)
            for yy in np.arange(y + 0.3, y + 2.3, 0.4):
                box("art_red", x - 0.35, x + 0.35, yy, yy + 0.08, s * 7.5 - 0.36, s * 7.5 + 0.36)
    box("walnut", 13.0, 17.0, y, y + 0.9, -1.2, 1.2)
    for x in (13.8, 16.2):
        for s in (-1, 1):
            chair(x, s * 1.9, y, 0.0 if s < 0 else 180.0, "leather_brown")
    b.text("ADEGA", "gold", (10.66, y + 2.4, 2.5), 0.3, 0.02, rot_y=-90, simplify=0.02)
    b.anchor("Weinkeller", (15.0, y, 3.0), 90)
    for x in np.arange(25.0, 33.0, 2.0):                                      # provisions
        for s in (-1, 1):
            box("vault_steel", x - 0.7, x + 0.7, y, y + 2.2, s * 6.0 - 0.6, s * 6.0 + 0.6)
    for x in (40.0, 46.0):                                                    # forward stores + chain lockers
        box("crate", x - 1.0, x + 1.0, y, y + 1.2, -2.0, 2.0)
    for s in (-1, 1):
        b.cyl("pipe", 0.9, 3.0, (56.0, y + 1.5, s * 2.0), 12)

    # ================================================================ UNTERDECK – beach club, garage, crew, spa, security, crew cabins
    y, yt = DY["Unterdeck"], ceil_of("Unterdeck")
    b.layer = "Unterdeck"
    for (x, doors) in ((-63.0, [(-1.0, 1.0)]), (-48.0, [(-1.0, 1.0)]), (-10.0, [(-1.0, 1.0)]), (10.0, [(-1.0, 1.0)]), (25.0, [(-1.0, 1.0)])):
        segs = [(-12.0, 12.0)]
        for d0, d1 in doors:
            segs = [(p, min(q, d0)) for (p, q) in segs if min(q, d0) > p] + [(max(p, d1), q) for (p, q) in segs if q > max(p, d1)]
        for p, q in segs:
            flat("lining", sbox(x - 0.12, p, x + 0.12, q).intersection(outline(y, 0.2)), y, yt)
    box("glass_shop", -74.05, -73.95, y, yt, -6.0, -1.2)                     # beach-club glass front
    box("glass_shop", -74.05, -73.95, y, yt, 1.2, 6.0)
    for s in (-1, 1):
        for (xa, xb) in ((-40.0, -26.0), (-25.0, -11.0)):
            flat("lining", sbox(xa, s * 1.2 - 0.08, xb, s * 1.2 + 0.08), y, yt)
        for x in np.arange(-40.0, -10.5, 3.5):
            flat("lining", sbox(x - 0.06, min(s * 1.28, s * 10.5), x + 0.06, max(s * 1.28, s * 10.5)).intersection(outline(y, 0.2)), y, yt)
    node("Unterdeck_Heckklappe", (-75.05, 1.0, 0.0))                          # transom door = swim platform (fold down)
    box(HULL, -75.18, -75.03, 1.0, 3.8, -5.0, 5.0)
    b.text("RIO DE JANEIRO", "gold_trim", (-75.19, 2.4, 0.0), 0.45, 0.03, rot_y=-90, simplify=0.02)
    for s, side in ((-1, "BB"), (1, "SB")):                                  # garage hull doors (gull-wing, hinge at top)
        node(f"Unterdeck_Garagentor_{side}", ((GARAGE[0] + GARAGE[1]) / 2, 4.3, s * 11.95))
        box(HULL, GARAGE[0], GARAGE[1], 0.6, 4.3, s * 11.95 - 0.06, s * 11.95 + 0.06)
        box("gold_trim", GARAGE[0], GARAGE[1], 4.0, 4.08, s * 12.02 - 0.02, s * 12.02 + 0.02)
    xm_ = (JETSKI[0] + JETSKI[1]) / 2                                         # jet-ski side door (starboard), hinge at the bottom: folds down = platform
    node("Unterdeck_Jetski_Tor", (xm_, 1.2, hb(xm_, 1.2)))
    b.hull(HULL, [(x_, y_, hb(x_, y_) + e) for x_ in (JETSKI[0] + 0.1, JETSKI[1] - 0.1) for y_ in (1.22, 4.28) for e in (-0.07, 0.03)])
    for x_ in (33.2, 36.8):
        w0, w1 = hb(x_ - 0.9, 2.6), hb(x_ + 0.9, 2.6)
        ang = np.degrees(np.arctan2(w1 - w0, 1.8))
        b.box("stainless", (1.96, 0.71, 0.04), (x_, 2.6, (w0 + w1) / 2 + 0.04), rot_y=-ang)
        b.box("glass", (1.8, 0.55, 0.06), (x_, 2.6, (w0 + w1) / 2 + 0.06), rot_y=-ang)
    b.layer = "Unterdeck_Innen"
    for s in (-1, 1):                                                         # beach club
        sofa(-70.5, s * 4.2, y, 3.2, 0 if s < 0 else 180, "cushion")
    table_round(-70.5, 0.0, y, 0.8, 0.4, "teak")
    bar_counter(-66.5, -64.0, 4.0, 5.0, y, ("z", -1))
    bottles(-66.4, -64.1, 5.4, y)
    box("teak", -66.6, -63.4, y, yt, -9.5, -5.4)                              # sauna
    box("glass_shop", -66.6, -63.4, y, y + 2.2, -5.42, -5.38)
    b.anchor("Beach_Club", (-71.0, y, 0.0), 90)
    b.anchor("Badeplattform", (-77.0, 1.0, 0.0), 90)
    tender("Unterdeck_Tender_1", -56.0, 5.6, y + 0.3, 10.0, 3.0)              # garage
    tender("Unterdeck_Tender_2", -56.0, -5.6, y + 0.3, 10.0, 3.0)
    submarine("Unterdeck_UBoot", -56.5, 0.0, y)
    jetski("Unterdeck_Jetski_1", -50.5, 1.6, y)
    jetski("Unterdeck_Jetski_2", -50.5, -1.6, y)
    for z in (-5.6, 5.6):                                                     # overhead crane rails
        box("stainless", -62.5, -48.5, yt - 0.4, yt - 0.2, z - 0.15, z + 0.15)
    box("safety_yellow", -57.0, -55.0, yt - 0.7, yt - 0.4, -7.0, 7.0)
    for s in (-1, 1):
        for (x0, x1) in ((-61.0, -51.0),):
            box("safety_yellow", x0, x1, y, y + 0.01, s * 3.9 - 0.05, s * 3.9 + 0.05)
    b.anchor("Tendergarage", (-55.0, y, 0.0), 0)
    for x, z in ((-46.0, -6.0), (-46.0, -3.0), (-43.0, -6.0), (-43.0, -3.0)):    # crew mess
        box("cloth_white", x - 0.8, x + 0.8, y, y + 0.75, z - 0.5, z + 0.5)
        for dz in (-0.8, 0.8):
            box("leather_brown", x - 0.8, x + 0.8, y, y + 0.45, z + dz - 0.2, z + dz + 0.2)
    box("vault_steel", -47.5, -41.0, y, y + 0.95, 6.5, 7.3)                   # crew galley
    box("vault_steel", -47.5, -41.0, y, y + 2.2, 9.0, 9.6)
    b.anchor("Crew_Messe", (-44.5, y, -4.5), 0)
    for s in (-1, 1):                                                         # crew cabins (bunk beds)
        for x in np.arange(-38.25, -11.0, 3.5):
            zc = s * 6.0
            box("walnut", x - 1.0, x + 1.0, y, y + 0.45, zc - 0.45 + s * 2.0, zc + 0.45 + s * 2.0)
            box("cushion", x - 0.95, x + 0.95, y + 0.45, y + 0.6, zc - 0.4 + s * 2.0, zc + 0.4 + s * 2.0)
            box("walnut", x - 1.0, x + 1.0, y + 1.3, y + 1.45, zc - 0.45 + s * 2.0, zc + 0.45 + s * 2.0)
            box("cushion", x - 0.95, x + 0.95, y + 1.45, y + 1.6, zc - 0.4 + s * 2.0, zc + 0.4 + s * 2.0)
    b.anchor("Crew_Kabinen", (-25.0, y, 0.0), 0)
    for (x, z) in ((-6.0, -6.5), (-6.0, 6.5), (7.0, -6.5)):                  # spa: massage beds, hammam, loungers
        box("teak", x - 1.0, x + 1.0, y, y + 0.7, z - 0.4, z + 0.4)
        box("cushion", x - 0.95, x + 0.95, y + 0.7, y + 0.78, z - 0.35, z + 0.35)
    box("marble_white", 5.0, 9.5, y, yt, 4.5, 9.0)
    for z in (-3.0, 3.0):
        sunbed(-3.0, z, y, 90)
    plant(-8.5, 0.0, y, 1.4)
    b.anchor("Spa", (-5.0, y, 0.0), 0)
    for k, x in enumerate(np.arange(11.0, 19.0, 2.0)):                       # security quarters + armory
        box("vault_steel", x - 0.9, x + 0.9, y + 0.4, y + 0.5, -9.0, -8.0)
        box("cushion_navy", x - 0.88, x + 0.88, y + 0.5, y + 0.6, -8.95, -8.05)
        box("vault_steel", x - 0.9, x + 0.9, y + 1.5, y + 1.6, -9.0, -8.0)
        box("cushion_navy", x - 0.88, x + 0.88, y + 1.6, y + 1.7, -8.95, -8.05)
    for k in range(8):
        box("vault_steel", 11.0 + k * 0.6, 11.55 + k * 0.6, y, y + 1.9, -4.5, -4.0)
    box("vault_steel", 11.0, 18.0, y, y + 2.3, 7.8, 8.6)                     # weapons racks (abstract)
    for k in range(10):
        b.box("frame_black", (0.09, 1.0, 0.12), (11.5 + k * 0.65, y + 1.2, 7.75), rot_z=6)
    box("lacquer", 13.0, 16.0, y, y + 0.8, 2.0, 2.8)
    for x in (13.8, 15.2):
        box("screen", x - 0.5, x + 0.5, y + 0.85, y + 1.35, 2.75, 2.8)
    b.anchor("Wachraum", (14.5, y, 1.4), 180)
    b.anchor("Waffenkammer", (14.5, y, 7.0), 0)
    for s in (-1, 1):                                                         # forward crew cabins
        for x in np.arange(28.0, 47.0, 4.0):
            w = hb(x, y) - 0.6
            if w < 5.0 or (s > 0 and JETSKI[0] - 2.0 <= x <= JETSKI[1] + 1.0):
                continue
            box("walnut", x - 1.0, x + 1.0, y, y + 0.5, s * (w - 1.0) - 0.45, s * (w - 1.0) + 0.45)
            box("cushion", x - 0.95, x + 0.95, y + 0.5, y + 0.65, s * (w - 1.0) - 0.4, s * (w - 1.0) + 0.4)
    for (x, z, yaw) in ((-62.4, -9.5, 45), (-48.6, 9.5, -135), (-10.6, -9.0, 45), (10.6, 9.0, -45), (24.4, -8.0, 135), (-73.6, 7.0, 45)):
        cam(cam_id("Kamera_Unterdeck"), x, yt - 0.2, z, yaw)

    # ================================================================ HAUPTDECK – pool deck, saloon, dining, lobby, guest suites, foredeck
    y, yt = DY["Hauptdeck"], ceil_of("Hauptdeck")
    b.layer = "Hauptdeck"
    for x in (-30.0, -14.0, 8.0):                                             # partitions with wide openings
        for (p, q) in ((-9.6, -3.0), (3.0, 9.6)):
            pwall("Hauptdeck", "walnut", x - 0.1, x + 0.1, p, q, y, yt)
    for s in (-1, 1):                                                         # guest suites (x 8..35)
        cw = sbox(8.0, min(s * 1.2, s * 1.35), 36.0, max(s * 1.2, s * 1.35))
        if s > 0:
            cw = cw.difference(core_hole)                                    # the core wall (with its door) takes over here
        flat("walnut", cw, y, yt)
        for x in (17.0, 26.0):
            pflat("Hauptdeck", "walnut", sbox(x - 0.08, min(s * 1.35, s * 9.8), x + 0.08, max(s * 1.35, s * 9.8)).intersection(HOUSES["Hauptdeck"].buffer(-0.2)), y, yt)
    b.layer = "Hauptdeck_Innen"
    for s in (-1, 1):                                                         # pool deck
        for x in np.arange(-71.5, -64.0, 2.4):
            sunbed(x, s * 6.1, y, 90)
    for s in (-1, 1):
        sofa(-60.6, s * 5.2, y, 3.0, 90, "cushion")
    table_round(-60.0, 0.0, y, 0.9, 0.45, "teak")
    b.anchor("Pool", (-68.0, y, 0.0), 90)
    for s in (-1, 1):                                                         # main saloon
        sofa(-50.0, s * 4.0, y, 3.4, 0 if s < 0 else 180, "leather_white")
        sofa(-44.0, s * 4.0, y, 3.4, 0 if s < 0 else 180, "leather_white")
    box("carpet_navy", -53.0, -41.0, y, y + 0.012, -5.6, 5.6)
    box("cream", -52.6, -41.4, y, y + 0.014, -5.2, 5.2)
    for x in (-50.0, -44.0):
        box("marble_black", x - 1.0, x + 1.0, y, y + 0.4, -1.2, 1.2)
    for (x, z) in ((-53.5, -8.5), (-53.5, 8.5), (-39.0, 8.5)):
        b.cyl("brass", 0.03, 1.6, (x, y + 0.8, z), 6)
        b.cyl("lamp", 0.25, 0.35, (x, y + 1.75, z), 8)
    b.hull("lacquer", [(-36.0 + dx, yy, 6.0 + dz) for (dx, dz) in ((0, 0), (2.4, 0), (2.4, 1.0), (1.6, 2.6), (0.6, 2.6), (0, 1.5)) for yy in (y + 0.65, y + 0.95)])
    b.hull("lacquer", [(-36.0, y + 0.95, 6.0), (-33.6, y + 0.95, 6.0), (-36.0, y + 1.9, 6.3), (-33.6, y + 1.9, 6.3), (-36.0, y + 0.97, 6.3), (-33.6, y + 0.97, 6.3)])
    for (dx, dz) in ((0.3, 0.3), (2.1, 0.3), (1.1, 2.3)):
        box("lacquer", -36.0 + dx - 0.08, -36.0 + dx + 0.08, y, y + 0.65, 6.0 + dz - 0.08, 6.0 + dz + 0.08)
    box("screen", -30.25, -30.15, y + 1.0, y + 2.6, -8.0, -4.0)               # TV on the partition (port segment; the opening stays free)
    bar_counter(-40.0, -37.0, -9.0, -7.8, y, ("z", 1))
    bottles(-39.9, -37.1, -9.4, y)
    for x in (-50.0, -40.0):
        chandelier(x, 0.0, yt, 0.8, 1.0)
    painting("Hauptdeck_Beute_Bild_1", -47.0, y + 1.9, -9.65, 2.4, 1.5, "+z")
    painting("Hauptdeck_Beute_Bild_2", -47.0, y + 1.9, 9.65, 2.4, 1.5, "-z")
    b.anchor("Salon", (-47.0, y, 0.0), 90)
    box("carpet_navy", -28.6, -15.4, y, y + 0.012, -3.0, 3.0)
    box("walnut", -27.5, -16.5, y, y + 0.76, -1.0, 1.0)                     # dining for 20
    for x in np.arange(-27.0, -16.6, 1.1):
        chair(x, -1.6, y, 0.0, "velvet_blue")
        chair(x, 1.6, y, 180.0, "velvet_blue")
    chair(-28.3, 0.0, y, 90.0, "velvet_red")
    chair(-15.7, 0.0, y, -90.0, "velvet_red")
    for x in (-25.0, -19.0):
        chandelier(x, 0.0, yt, 0.7, 0.9)
    box("walnut", -27.0, -17.0, y, y + 0.9, -9.6, -9.0)
    painting("Hauptdeck_Beute_Bild_3", -22.0, y + 1.9, 9.65, 3.0, 1.6, "-z")
    b.anchor("Speisesaal", (-22.0, y, 3.0), 180)
    for (x, z) in ((-7.0, -6.0), (-7.0, 6.0)):                               # lobby
        sculpture(f"Hauptdeck_Beute_Skulptur_{1 if z < 0 else 2}", x, y, z, 0 if z < 0 else 1)
    plant(-12.5, 3.0, y, 1.8)
    plant(6.5, -6.5, y, 1.8)
    b.anchor("Lobby", (-3.0, y, 4.0), 180)
    for s in (-1, 1):                                                         # guest suites
        for (xa, xb) in ((8.3, 16.8), (17.2, 25.8), (26.2, 35.0)):
            if s > 0 and xa < 25.0:
                continue
            xm = (xa + xb) / 2
            bed(xm, s * 6.4, y, 2.0, 2.2, "+z" if s > 0 else "-z")
            if xb - xa > 7:
                sofa(xm, s * 2.4, y, 2.0, 180 if s > 0 else 0, "cushion_navy")
    box("vault_steel", 8.5, 16.7, y, y + 0.95, 7.0, 7.8)                     # galley (starboard)
    box("vault_steel", 8.5, 16.7, y, y + 2.2, 8.9, 9.4)
    box("vault_steel", 10.5, 15.5, y, y + 0.95, 3.0, 4.2)
    b.anchor("Kombuese", (14.0, y, 5.5), 0)
    for s in (-1, 1):                                                         # foredeck under the helideck: lounge, rescue tender, crane
        sofa(44.0, s * 2.6, y, 3.0, 0 if s < 0 else 180, "cushion")
    table_round(44.0, 0.0, y, 0.8, 0.45, "teak")
    for x in (52.5, 57.5):
        box("rubber", x - 0.3, x + 0.3, y, y + 0.5, -1.2, 1.2)
    tender("Hauptdeck_Rettungstender", 55.0, 0.0, y + 0.45, 7.0, 2.4)
    b.cyl("stainless", 0.25, 2.8, (60.0, y + 1.4, 2.6), 10)
    b.beam("stainless", (60.0, y + 2.6, 2.6), (55.5, y + 3.0, 0.6), 0.22)
    b.beam("frame_black", (55.5, y + 3.0, 0.6), (55.5, y + 2.0, 0.6), 0.03)
    b.anchor("Rettungstender", (55.0, y, -2.5), 0)
    for (x, z) in ((47.0, -5.5), (47.0, 5.5), (56.0, -4.0), (56.0, 4.0)):
        b.cyl("stainless", 0.18, DY["Oberdeck"] - SLAB - y, (x, (y + DY["Oberdeck"] - SLAB) / 2, z), 10)
    for s in (-1, 1):                                                         # windlasses + chains + bollards
        b.cyl("engine_grey", 0.7, 0.8, (66.0, y + 0.4, s * 1.8), 12)
        b.cyl("stainless", 0.5, 0.2, (66.0, y + 0.9, s * 1.8), 12)
        b.beam("frame_black", (66.0, y + 0.85, s * 1.8), (69.5, y + 0.05, s * 2.6), 0.18)
        for x in (60.0, 70.0):
            b.cyl("stainless", 0.2, 0.5, (x, y + 0.25, s * (hb(x, 5.0) - 0.7)), 8)
    b.anchor("Festmachen_Bug", (64.0, y, -4.0), 0)
    b.anchor("Festmachen_Heck", (-72.0, y, -9.5), 180)
    for (x, z, yaw) in ((-57.6, -9.5, 45), (-57.6, 9.5, 135), (-14.4, 9.5, -135), (7.6, -9.5, -45), (39.0, 0.0, 180), (-1.0, -9.5, 0)):
        cam(cam_id("Kamera_Hauptdeck"), x, yt - 0.2, z, yaw)

    # ================================================================ OBERDECK – aft dining, sky lounge, cinema, lobby, VIP suites, helideck
    y, yt = DY["Oberdeck"], ceil_of("Oberdeck")
    b.layer = "Oberdeck"
    for x in (-24.0, -8.0, 8.0):
        for (p, q) in ((-9.8, -2.0), (2.0, 9.8)):
            pwall("Oberdeck", "walnut", x - 0.1, x + 0.1, p, q, y, yt)
    for s in (-1, 1):
        cw = sbox(8.0, min(s * 1.2, s * 1.35), 36.0, max(s * 1.2, s * 1.35))
        if s > 0:
            cw = cw.difference(core_hole)                                    # the core wall (with its door) takes over here
        flat("walnut", cw, y, yt)
        pflat("Oberdeck", "walnut", sbox(21.9, min(s * 1.35, s * 9.9), 22.1, max(s * 1.35, s * 9.9)).intersection(HOUSES["Oberdeck"].buffer(-0.2))
              .difference(core_hole.buffer(0.02)), y, yt)
    b.layer = "Oberdeck_Innen"
    box("teak", -59.0, -50.0, y, y + 0.76, -1.1, 1.1)                         # aft dining for 12
    for x in np.arange(-58.4, -50.4, 1.3):
        chair(x, -1.7, y, 0.0, "cushion")
        chair(x, 1.7, y, 180.0, "cushion")
    bar_counter(-49.0, -47.0, -6.0, -2.0, y, ("x", -1))
    b.anchor("Achterdeck_Dinner", (-54.5, y, 3.0), 180)
    for s in (-1, 1):                                                         # sky lounge
        sofa(-38.0, s * 5.5, y, 4.0, 0 if s < 0 else 180, "cushion_navy")
        sofa(-31.0, s * 5.5, y, 3.0, 0 if s < 0 else 180, "cushion_navy")
    box("carpet_cream", -41.0, -27.0, y, y + 0.012, -7.0, 7.0)
    box("marble_black", -38.0, -30.0, y, y + 0.4, -1.0, 1.0)
    bar_counter(-45.0, -40.0, -9.4, -8.4, y, ("z", 1))
    chandelier(-34.0, 0.0, yt, 0.6, 1.1)
    b.anchor("Sky_Lounge", (-35.0, y, 0.0), 90)
    for r, x in enumerate((-21.5, -18.5, -15.5)):                              # cinema: 3 rows of recliners + screen
        for z in np.arange(-4.5, 4.6, 1.5):
            box("leather_brown", x - 0.5, x + 0.5, y + 0.2 * r, y + 0.2 * r + 0.45, z - 0.45, z + 0.45)
            b.box("leather_brown", (0.15, 0.6, 0.85), (x - 0.45, y + 0.2 * r + 0.75, z), rot_z=15)
        if r:
            box("carpet_navy", x - 0.8, x + 0.8, y, y + 0.2 * r, -5.2, 5.2)
    box("frame_black", -8.35, -8.15, y + 0.4, yt - 0.3, -4.5, 4.5)
    box("screen", -8.4, -8.35, y + 0.5, yt - 0.4, -4.3, 4.3)
    b.anchor("Kino", (-16.0, y, 0.0), 90)
    nb = 1
    for s in (-1, 1):                                                         # VIP suites
        for (xa, xb) in ((8.3, 21.8), (22.2, 35.5)):
            if s > 0 and xa < 21.0:
                bed(14.0, s * 6.5, y, 2.2, 2.3, "+z")
                continue
            xm = (xa + xb) / 2
            bed(xm, s * 6.6, y, 2.2, 2.3, "+z" if s > 0 else "-z")
            sofa(xm - 3.0, s * 2.8, y, 2.4, 180 if s > 0 else 0, "cushion")
            painting(f"Oberdeck_Beute_Bild_{nb}", xm, y + 1.8, s * 1.45, 1.6, 1.0, "+z" if s > 0 else "-z")
            nb += 1
    # helideck (forward, on this deck)
    HX, HZ, HR = 50.0, 0.0, 7.0
    b.cyl("helipad", HR, 0.04, (HX, y + 0.02, HZ), 32)
    t = trimesh.creation.annulus(r_min=HR - 0.5, r_max=HR - 0.2, height=0.02, sections=32)
    t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    b.add("heli_mark", t.apply_translation((HX, y + 0.05, HZ)))
    for (x0_, x1_, z0_, z1_) in ((HX - 1.6, HX + 1.6, -1.6, -1.0), (HX - 1.6, HX + 1.6, 1.0, 1.6), (HX - 0.3, HX + 0.3, -1.0, 1.0)):
        box("cloth_white", x0_, x1_, y + 0.04, y + 0.06, z0_, z1_)
    for k in range(16):
        a = k * np.pi / 8
        b.cyl("led_green", 0.07, 0.08, (HX + HR * np.cos(a), y + 0.06, HZ + HR * np.sin(a)), 6)
    net = ring(SLABS["Oberdeck"], 1.0).intersection(sbox(43.0, -12.0, 70.0, 12.0))
    flat("fence_net", net, y - 0.25, y - 0.2)
    b.anchor("Hubschrauber_Bug", (HX, y, HZ), 0)
    for (x, z, yaw) in ((-45.6, -9.5, 45), (-24.4, 9.5, -135), (-7.6, -9.5, -45), (39.6, 0.0, 180)):
        cam(cam_id("Kamera_Oberdeck"), x, yt - 0.2, z, yaw)

    # ================================================================ EIGNERDECK – terrace, art gallery, office (secret shelf), owner's suite
    y, yt = DY["Eignerdeck"], ceil_of("Eignerdeck")
    b.layer = "Eignerdeck"
    for (x, p, q) in ((-14.0, -9.3, -1.5), (-14.0, 1.5, 9.3), (0.0, -9.3, -1.6), (0.0, 1.6, 9.3), (8.0, -9.3, -1.6), (8.0, 1.6, 9.3), (18.0, -9.3, -3.0), (18.0, 3.0, 9.3)):
        pwall("Eignerdeck", "walnut", x - 0.1, x + 0.1, p, q, y, yt)
    for s in (-1, 1):                                                         # gallery partition panels
        box("art_white", -28.0, -26.0, y, yt - 0.3, s * 3.0 - 0.1, s * 3.0 + 0.1)
        box("art_white", -21.0, -19.0, y, yt - 0.3, s * 3.0 - 0.1, s * 3.0 + 0.1)
    b.layer = "Eignerdeck_Innen"
    for s in (-1, 1):                                                         # aft terrace: sofas around the fire pit
        sofa(-44.0, s * 3.0, y, 4.0, 0 if s < 0 else 180, "cushion")
    sofa(-47.5, 0.0, y, 4.0, 90, "cushion")
    b.cyl("marble_black", 1.0, 0.45, (-44.0, y + 0.225, 0.0), 14)
    b.cyl("art_orange", 0.7, 0.05, (-44.0, y + 0.47, 0.0), 12)
    bar_counter(-37.5, -35.5, 5.0, 8.5, y, ("x", -1))
    b.anchor("Feuerstelle", (-44.0, y, 0.0), 0)
    n = 1                                                                     # art gallery
    for x in (-31.0, -24.0, -17.0):
        for s in (-1, 1):
            painting(f"Eignerdeck_Beute_Bild_{n}", x, y + 1.9, s * 9.2, 2.6, 1.7, "-z" if s > 0 else "+z")
            n += 1
    for x in (-27.0, -20.0):
        for s in (-1, 1):
            painting(f"Eignerdeck_Beute_Bild_{n}", x, y + 1.7, s * 2.88, 1.4, 1.1, "-z" if s > 0 else "+z")
            n += 1
    for k, x in enumerate((-30.0, -23.5, -16.5)):
        sculpture(f"Eignerdeck_Beute_Skulptur_{k + 1}", x, y, 0.0, k)
    box("leather_white", -26.0, -22.0, y, y + 0.45, 5.0, 5.8)
    b.text("GALERIA", "gold", (-33.7, y + 2.6, 0.0), 0.35, 0.02, rot_y=90, simplify=0.02)
    b.anchor("Kunstgalerie", (-24.0, y, 0.0), 90)
    box("walnut", -7.5, -4.5, y, y + 0.78, -1.2, 1.2)                         # owner's office
    box("screen", -7.3, -7.2, y + 0.8, y + 1.25, -0.6, 0.6)
    chair(-8.4, 0.0, y, 90.0, "leather_brown")
    for z in (-0.8, 0.8):
        chair(-3.6, z, y, -90.0, "leather_white")
    for x in (-13.2, -8.9, -7.55, -6.2):                                      # library wall (port), the shelf in front of the lift is a node
        box("walnut", x - 0.65, x + 0.65, y, yt - 0.2, -9.2, -8.7)
        for yy in np.arange(y + 0.4, yt - 0.3, 0.45):
            box(ART[int(rng.integers(0, 8))], x - 0.6, x + 0.6, yy, yy + 0.3, -8.95, -8.75)
    node("Eignerdeck_Regal", (PLIFT[0], y, PLIFT[3]))
    box("walnut", PLIFT[0] - 0.1, PLIFT[1] + 0.1, y, yt - 0.2, PLIFT[3] + 0.02, PLIFT[3] + 0.4)
    for yy in np.arange(y + 0.4, yt - 0.3, 0.45):
        box("leather_brown", PLIFT[0], PLIFT[1], yy, yy + 0.3, PLIFT[3] + 0.3, PLIFT[3] + 0.42)
    b.layer = "Eignerdeck_Innen"
    b.anchor("Geheimregal", ((PLIFT[0] + PLIFT[1]) / 2, y, PLIFT[3] + 1.0), 180)
    b.anchor("Eignerbuero", (-6.0, y, 3.0), 180)
    painting("Eignerdeck_Beute_Bild_Buero", -13.8, y + 1.9, 3.0, 2.0, 1.4, "+x")
    for k, z in enumerate((-8.4, -6.6, -4.8)):                                # owner's dressing room: jewellery vitrines (port)
        vitrine(f"Eignerdeck_Vitrine_{k + 1}", 13.0, z, y, 1.4, 0.7, f"Eignerdeck_Beute_Schmuck_Vitrine{k + 1}")
    for k, z in enumerate((-8.4, -6.6)):
        vitrine(f"Eignerdeck_Vitrine_{k + 4}", 16.0, z, y, 1.4, 0.7, f"Eignerdeck_Beute_Schmuck_Vitrine{k + 4}")
    box("walnut", 8.3, 17.7, y, yt - 0.3, -9.3, -9.0)
    b.anchor("Ankleide", (14.5, y, -3.0), 180)
    box("marble_white", 9.0, 17.0, y, y + 0.006, 3.0, 9.2)                    # bathroom (starboard)
    b.hull("marble_white", [(12.5 + 1.4 * np.cos(a), yy, 6.5 + 0.8 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 13)[:-1] for yy in (y, y + 0.6)])
    b.cyl("pool", 1.1, 0.05, (12.5, y + 0.5, 6.5), 12)
    sofa(11.0, 0.0, y, 3.0, 90, "cushion")                                    # suite lounge
    box("marble_black", 12.6, 13.6, y, y + 0.4, -1.0, 1.0)
    b.cyl("carpet_cream", 3.2, 0.012, (26.0, y + 0.006, 0.0), 24)
    b.cyl("walnut", 1.6, 0.4, (26.0, y + 0.2, 0.0), 24)                       # round bed
    b.cyl("cushion", 1.5, 0.2, (26.0, y + 0.5, 0.0), 24)
    b.hull("velvet_blue", [(27.7 + 0.25 * np.cos(a), yy, 1.7 * np.sin(a)) for a in np.linspace(-1.2, 1.2, 7) for yy in (y, y + 1.4)])
    for e in (-0.5, 0.5):
        box("cushion_navy", 26.8, 27.2, y + 0.7, y + 0.85, e - 0.3, e + 0.3)
    box("walnut", 19.5, 20.5, y, y + 0.9, -6.5, -3.5)
    box("screen", 19.95, 20.05, y + 1.0, y + 2.2, -6.0, -4.0)
    chandelier(26.0, 0.0, yt, 0.4, 1.2, 3)
    b.anchor("Eignersuite", (24.0, y, 0.0), 90)
    b.cyl("teak", 2.2, 0.6, (39.5, y + 0.3, 0.0), 16)                         # private foredeck jacuzzi
    b.cyl("pool", 1.9, 0.05, (39.5, y + 0.58, 0.0), 16)
    for s in (-1, 1):
        sunbed(42.5, s * 3.2, y, 0)
    b.anchor("Privatdeck_Jacuzzi", (39.5, y, 0.0), 0)
    for (x, z, yaw) in ((-33.6, -9.0, 45), (-14.4, 9.0, -135), (-0.4, -9.0, -45), (17.6, -9.0, -45), (33.0, 0.0, 180)):
        cam(cam_id("Kamera_Eignerdeck"), x, yt - 0.2, z, yaw)

    # ================================================================ BRUECKENDECK – helipad, observation lounge, security, captain, bridge
    y, yt = DY["Brueckendeck"], ceil_of("Brueckendeck")
    b.layer = "Brueckendeck"
    for (x, p, q) in ((-10.0, -8.8, 8.8), (-1.0, -8.8, -1.0), (-1.0, 1.0, 8.8), (8.0, -8.8, -1.2), (8.0, 1.2, 8.8), (24.0, -8.6, -1.0), (24.0, 4.4, 8.6)):
        pwall("Brueckendeck", "lining", x - 0.1, x + 0.1, p, q, y, yt)
    node("Brueckendeck_Sicherheitstuer", (-1.0, y, -1.0))
    box("vault_steel", -1.08, -0.92, y, y + 2.3, -1.0, 1.0)
    b.layer = "Brueckendeck"
    box("frame_black", -0.92, -0.86, y + 1.1, y + 1.5, -1.6, -1.25)
    b.anchor("Kartenleser_Sicherheit", (-0.2, y, -1.4), -90)
    PX_, PZ_, PR_ = -33.0, 0.0, 8.0                                            # aft helipad
    b.cyl("helipad", PR_, 0.04, (PX_, y + 0.02, PZ_), 32)
    t = trimesh.creation.annulus(r_min=PR_ - 0.5, r_max=PR_ - 0.2, height=0.02, sections=32)
    t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    b.add("heli_mark", t.apply_translation((PX_, y + 0.05, PZ_)))
    for (x0_, x1_, z0_, z1_) in ((PX_ - 1.6, PX_ + 1.6, -1.6, -1.0), (PX_ - 1.6, PX_ + 1.6, 1.0, 1.6), (PX_ - 0.3, PX_ + 0.3, -1.0, 1.0)):
        box("cloth_white", x0_, x1_, y + 0.04, y + 0.06, z0_, z1_)
    for k in range(16):
        a = k * np.pi / 8
        b.cyl("led_green", 0.07, 0.08, (PX_ + PR_ * np.cos(a), y + 0.06, PZ_ + PR_ * np.sin(a)), 6)
    b.layer = "Brueckendeck_Innen"
    helicopter("Brueckendeck_Heli", PX_, y + 0.06, PZ_)
    box("safety_yellow", -26.5, -25.0, y, y + 1.4, -9.6, -8.6)               # refuel station
    b.cyl("frame_black", 0.25, 0.3, (-25.8, y + 1.55, -9.1), 8)
    b.anchor("Hubschrauber_Achtern", (PX_, y, PZ_), 0)
    for s in (-1, 1):                                                         # observation lounge
        sofa(-18.0, s * 5.5, y, 4.0, 0 if s < 0 else 180, "cushion")
    table_round(-18.0, 0.0, y, 0.9, 0.45, "marble_black")
    b.beam("brass", (-22.0, y, -6.0), (-22.0, y + 1.2, -6.0), 0.05)
    cyl_axis("brass", 0.12, 0.9, (-21.7, y + 1.35, -6.0), "x", 8)
    b.anchor("Panorama_Lounge", (-17.0, y, 0.0), 90)
    for i in range(6):                                                         # security centre: monitor wall + desks
        for j in range(3):
            box("frame_black", -9.85, -9.75, y + 0.9 + j * 0.65, y + 1.5 + j * 0.65, -7.6 + i * 1.25, -6.5 + i * 1.25)
            box("screen", -9.75, -9.72, y + 0.95 + j * 0.65, y + 1.45 + j * 0.65, -7.55 + i * 1.25, -6.55 + i * 1.25)
    for z in (-4.0, 3.0):
        box("lacquer", -8.0, -6.0, y, y + 0.78, z - 1.5, z + 1.5)
        for dz in (-0.8, 0.8):
            box("screen", -7.95, -7.9, y + 0.8, y + 1.2, z + dz - 0.35, z + dz + 0.35)
            chair(-5.4, z + dz, y, -90.0, "leather_brown")
    box("frame_black", -2.2, -1.2, y, y + 1.9, 6.0, 8.0)
    box("led_red", -1.22, -1.2, y + 1.4, y + 1.6, 6.8, 7.2)
    for k in range(6):
        b.box("frame_black", (0.09, 1.0, 0.12), (-2.0, y + 1.0, -8.2 + k * 0.4), rot_z=6)
    b.anchor("Sicherheitszentrale", (-6.0, y, 0.0), -90)
    b.anchor("Alarm_Hauptschalter", (-2.0, y, 7.0), 90)
    b.anchor("Waffenschrank", (-2.6, y, -7.2), 90)
    bed(14.0, -6.0, y, 1.8, 2.2, "-z")                                        # captain's cabin
    box("walnut", 10.0, 12.0, y, y + 0.78, -9.0, -8.3)
    chair(11.0, -7.7, y, 180.0, "leather_brown")
    b.anchor("Kapitaenskabine", (12.0, y, -3.0), 0)
    for k in range(4):                                                         # radio room (starboard)
        box("frame_black", 9.0 + k * 1.4, 10.2 + k * 1.4, y, y + 1.8, 8.0, 8.6)
        box("led_green", 9.2 + k * 1.4, 9.4 + k * 1.4, y + 1.4, y + 1.5, 7.98, 8.0)
    b.anchor("Funkraum", (11.0, y, 6.0), 0)
    for z in np.arange(-6.0, 6.1, 1.0):                                        # bridge: curved console
        x = 30.0 + 1.6 * (1 - (z / 6.5) ** 2) - 1.6
        b.box("frame_black", (0.9, 0.95, 1.05), (x, y + 0.475, z), rot_y=np.degrees(np.arctan2(z, 6.5)) * 0.5)
        b.box("screen", (0.05, 0.45, 0.8), (x + 0.3, y + 1.15, z), rot_z=-20, rot_y=np.degrees(np.arctan2(z, 6.5)) * 0.5)
    for z in (-2.0, 0.0, 2.0):
        b.cyl("leather_white", 0.35, 0.5, (27.6, y + 0.65, z), 10)
        b.box("leather_white", (0.15, 0.8, 0.7), (27.2, y + 1.2, z), rot_z=10)
        b.cyl("chrome", 0.08, 0.4, (27.6, y + 0.2, z), 6)
    cyl_axis("walnut", 0.35, 0.05, (28.9, y + 1.25, 0.0), "x", 14)
    box("walnut", 25.0, 26.5, y, y + 0.95, -6.5, -4.5)                       # chart table
    b.anchor("Bruecke_Steuer", (27.6, y, 0.0), 90)
    for s in (-1, 1):                                                          # bridge wing consoles
        box("frame_black", 27.0, 28.0, y, y + 1.1, s * 9.5 - 0.35, s * 9.5 + 0.35)
    for (x, z, yaw) in ((-23.6, -8.5, 45), (-9.6, 8.5, -135), (-1.6, -2.5, -90), (23.6, -8.0, 135), (-41.0, 0.0, 90)):
        cam(cam_id("Kamera_Brueckendeck"), x, yt - 0.2 if x > -24 else y + 3.0, z, yaw)

    # ================================================================ SONNENDECK – spa pool, sunbeds, gym, bar, forward lounge
    y = DY["Sonnendeck"]
    b.layer = "Sonnendeck_Innen"
    box("teak", -18.0, -10.0, y, y + 0.5, -3.0, 3.0)                          # spa pool (raised)
    box("pool", -17.7, -10.3, y + 0.35, y + 0.47, -2.7, 2.7)
    for x in np.arange(-17.0, -10.5, 2.0):
        b.add("uw_light", octa(0.09).apply_translation((x, y + 0.4, 0.0)))
    for s in (-1, 1):
        for x in (-20.0, -16.5, -13.0, -9.5):
            sunbed(x, s * 5.6, y, 90)
    b.anchor("Spa_Pool", (-14.0, y, 0.0), 0)
    for k, x in enumerate(np.arange(7.0, 15.5, 1.8)):                          # gym
        box("frame_black", x - 0.4, x + 0.4, y, y + 0.3, -4.3, -2.5)
        box("frame_black", x - 0.35, x + 0.35, y + 0.3, y + 1.4, -2.6, -2.5)
    for k in range(3):
        box("frame_black", 7.0 + k * 1.6, 8.0 + k * 1.6, y, y + 2.0, 3.5, 4.5)
    bar_counter(13.5, 15.0, 1.5, 4.5, y, ("x", -1))
    b.anchor("Fitness", (10.0, y, -1.0), 90)
    for s in (-1, 1):                                                          # forward lounge under the hardtop
        sofa(20.0, s * 3.5, y, 3.6, 0 if s < 0 else 180, "cushion_navy")
    table_round(20.0, 0.0, y, 0.8, 0.45, "teak")
    for (x, z) in ((22.5, -3.6), (22.5, 3.6), (19.5, -6.4), (19.5, 6.4)):
        b.cyl("stainless", 0.12, TOP - SLAB - y, (x, (y + TOP - SLAB) / 2, z), 8)
    for (x, z, yaw) in ((-1.4, -5.0, 45), (17.6, 0.0, 180), (-21.0, 0.0, 90)):
        cam(cam_id("Kamera_Sonnendeck"), x, y + 2.9, z, yaw)

    # ================================================================ DACH – hardtop, radar arch, mast, domes
    b.layer = "Dach"
    flat("dach_dome", HARDTOP, TOP - SLAB, TOP)
    flat("dach_stahl", ring(HARDTOP, 0.15), TOP - SLAB - 0.05, TOP - SLAB)
    flat("dach_licht", ring(HARDTOP.buffer(-0.25), 0.08), TOP - SLAB - 0.08, TOP - SLAB - 0.05)
    for s in (-1, 1):                                                          # radar arch legs
        b.hull("dach_mast", [(x, TOP, s * z) for x in (8.0, 12.0) for z in (4.6, 5.6)] + [(x, TOP + 4.0, s * z) for x in (9.6, 11.4) for z in (2.6, 3.4)])
    b.hull("dach_mast", [(x, TOP + 3.8, z) for x in (9.4, 11.6) for z in (-3.6, 3.6)] + [(x, TOP + 4.6, z) for x in (9.6, 11.4) for z in (-3.3, 3.3)])
    for s in (-1, 1):
        dome = trimesh.creation.icosphere(subdivisions=2, radius=1.05)
        b.add("dach_dome", dome.apply_translation((10.5, TOP + 5.55, s * 2.4)))
        b.cyl("dach_mast", 0.55, 0.5, (10.5, TOP + 4.8, s * 2.4), 10)
    b.hull("dach_mast", [(x, TOP + 4.6, z) for x in (10.0, 11.0) for z in (-0.4, 0.4)] + [(x, TOP + 9.0, z) for x in (10.2, 10.8) for z in (-0.2, 0.2)])
    for yy, w in ((TOP + 7.2, 2.6), (TOP + 8.4, 1.8)):
        box("dach_mast", 10.2, 10.8, yy, yy + 0.18, -w, w)
        b.box("dach_radar", (0.25, 0.25, w * 1.6), (10.9, yy + 0.45, 0.0), rot_y=18)
    dome = trimesh.creation.icosphere(subdivisions=1, radius=0.6)
    b.add("dach_dome", dome.apply_translation((10.5, TOP + 9.5, 0.0)))
    b.cyl("dach_licht", 0.12, 0.3, (10.5, TOP + 10.25, 0.0), 6)
    for s in (-1, 1):
        b.beam("dach_stahl", (10.5, TOP + 7.3, s * 2.4), (10.5, TOP + 10.5, s * 2.4), 0.05)
        b.cyl("dach_licht", 0.15, 0.25, (12.0, TOP + 4.2, s * 3.0), 8)
    b.cyl("dach_stahl", 0.3, 0.6, (16.0, TOP + 0.3, -3.0), 8)                  # searchlight + horn
    b.box("dach_licht", (0.5, 0.4, 0.5), (16.0, TOP + 0.8, -3.0), rot_z=10)
    b.anchor("Radarmast", (10.5, TOP, 0.0), 0)
    # ================================================================ HEIST (Skizze): Einstiege, Tauchschleuse, Sabotage, Kapitän + Schlüssel, Beute, Wachen
    ART_DE = {"watch": "Uhr", "jewels": "Schmuck", "phone": "Handy", "bag": "Tasche", "champagne": "Champagner", "cash": "Bargeld",
              "laptop": "Laptop", "cigars": "Zigarren", "wine": "Wein", "silver": "Kerzenleuchter", "statue": "Statue"}
    cnt = {}

    def L(lv, kind, x, yy, z, tag=""):
        art = ART_DE[kind]
        cnt[(lv, art, tag)] = cnt.get((lv, art, tag), 0) + 1
        b.layer = lv + "_Innen"
        loot(f"{lv}_Beute_{art}_{tag}{cnt[(lv, art, tag)]}", kind, x, yy, z)

    # --- jet-ski side garage (Unterdeck, starboard): entry from the water
    y, yt = DY["Unterdeck"], ceil_of("Unterdeck")
    xm_ = (JETSKI[0] + JETSKI[1]) / 2
    ZI = 6.2                                                                  # inner wall of the bay
    b.layer = "Unterdeck"
    for xw in (31.0, 38.9):
        flat("lining", sbox(xw - 0.06, ZI, xw + 0.06, 13.0).intersection(outline(y, 0.2)), y, yt)
    flat("lining", sbox(31.0, ZI - 0.06, 38.9, ZI + 0.06).difference(sbox(34.4, ZI - 0.3, 35.6, ZI + 0.3)), y, yt)
    box("lining", 34.4, 35.6, y + 2.2, yt, ZI - 0.06, ZI + 0.06)
    b.hull("stainless", [(x_, y_, hb(x_, 1.2) + d) for x_ in JETSKI for y_ in (1.12, 1.2) for d in (-0.5, 0.0)])   # sill: floor -> hull
    b.layer = "Unterdeck_Innen"
    for k, x_ in enumerate((33.4, 36.4)):
        for dx in (-0.35, 0.35):
            box("stainless", x_ + dx - 0.04, x_ + dx + 0.04, y, y + 0.06, ZI + 0.3, hb(x_, y) - 0.35)
        jetski(f"Unterdeck_Jetski_{k + 3}", x_, 8.2, y + 0.06, "z")
    box("frame_black", 31.06, 31.2, y + 1.1, y + 1.5, 6.75, 7.15)               # door switch
    box("led_green", 31.2, 31.22, y + 1.35, y + 1.42, 6.9, 7.0)
    b.text("JET SKI", "safety_yellow", (35.0, y + 2.45, ZI - 0.06), 0.18, 0.01, rot_y=180, simplify=0.02)
    b.anchor("Jetski_Einstieg_Wasser", (xm_, 0.0, hb(xm_, 0.0) + 2.5), 180)
    b.anchor("Jetski_Einstieg_Plattform", (xm_, 1.2, hb(xm_, 1.2) + 1.5), 180)
    b.anchor("Jetski_Garage", (xm_, y, 7.0), 0)
    b.anchor("Jetski_Tor_Schalter", (31.7, y, 6.95), -90)

    # --- small-boat entry at the stern: black RHIB next to the swim platform
    b.layer = None
    X0, Z0 = -80.0, -2.8
    node("Heist_Schlauchboot", (X0, 0.0, Z0))
    for s_ in (-1, 1):
        cyl_axis("rubber", 0.26, 3.4, (X0 - 0.3, 0.3, Z0 + s_ * 0.75), "x", 10)
        b.hull("rubber", [(X0 + 1.4, 0.3 + dy, Z0 + s_ * 0.75 + dz) for dy in (-0.26, 0.26) for dz in (-0.26, 0.26)] + [(X0 + 2.3, 0.45, Z0 + s_ * 0.12)])
    b.hull("rubber", [(X0 + 2.3, 0.45, Z0 - 0.12), (X0 + 2.3, 0.45, Z0 + 0.12), (X0 + 2.0, 0.2, Z0), (X0 + 1.9, 0.5, Z0)])
    box("frame_black", X0 - 2.0, X0 + 1.6, 0.05, 0.14, Z0 - 0.62, Z0 + 0.62)
    box("frame_black", X0 - 0.3, X0 + 0.3, 0.14, 0.95, Z0 - 0.3, Z0 + 0.3)
    box("glass", X0 + 0.25, X0 + 0.32, 0.95, 1.2, Z0 - 0.28, Z0 + 0.28)
    box("frame_black", X0 - 2.35, X0 - 2.0, 0.15, 0.85, Z0 - 0.18, Z0 + 0.18)
    box("frame_black", X0 - 2.3, X0 - 2.2, -0.45, 0.15, Z0 - 0.06, Z0 + 0.06)
    b.layer = None
    b.anchor("Boot_Einstieg_Heck", (-78.0, 0.0, -2.8), 90)
    b.anchor("Boot_Ausstieg_Badeplattform", (-76.6, 1.0, -1.5), 90)

    # --- dive lockout (Tankdeck, starboard): scuba gear, flooding, hull hatch below the waterline = escape
    y, yt = DY["Tankdeck"], ceil_of("Tankdeck")
    ZC = 8.0
    b.layer = "Tankdeck"
    for xw in (11.0, 17.0):
        flat("vault_steel", sbox(xw - 0.08, ZC, xw + 0.08, 13.0).intersection(outline(y, 0.2)), y, yt)
    flat("vault_steel", sbox(11.0, ZC - 0.08, 17.0, ZC + 0.08).difference(sbox(15.0, ZC - 0.3, 16.2, ZC + 0.3)), y, yt)
    box("vault_steel", 15.0, 16.2, y + 2.2, yt, ZC - 0.08, ZC + 0.08)
    for xw in DIVE:                                                           # hatch tunnel: lining -> hull (follows the hull)
        b.hull("vault_steel", [(xw + e, y_, z_) for e in (-0.05, 0.05) for y_ in (y, -0.9) for z_ in (10.3, hb(xw, max(y_, -2.5)) - 0.02)])
    box("vault_steel", DIVE[0], DIVE[1], -1.0, -0.9, 10.3, hb(13.5, -1.0) + 0.05)
    box("vault_steel", DIVE[0], DIVE[1], y, -2.5, 10.3, hb(13.5, -2.5))
    b.text("MERGULHO", "safety_yellow", (15.6, y + 2.45, ZC - 0.08), 0.16, 0.01, rot_y=180, simplify=0.02)
    node("Tankdeck_Tauchluke", (13.5, -1.0, hb(13.5, -1.0)))                 # outer hatch, hinge at the top
    b.hull("antifouling", [(x_, y_, hb(x_, y_) + e) for x_ in (DIVE[0] + 0.03, DIVE[1] - 0.03) for y_ in (-2.47, -1.03) for e in (-0.07, 0.02)])
    for y_ in (-2.2, -1.3):
        b.beam("stainless", (DIVE[0] + 0.4, y_, hb(13.5, y_) - 0.12), (DIVE[1] - 0.4, y_, hb(13.5, y_) - 0.12), 0.05)
    node("Tankdeck_Tauchschleuse_Tuer", (15.0, y, ZC))                        # watertight inner door, hinge x 15.0
    box("vault_steel", 15.0, 16.2, y, y + 2.2, ZC - 0.06, ZC + 0.06)
    box("glass_shop", 15.45, 15.75, y + 1.55, y + 1.85, ZC - 0.07, ZC + 0.07)
    for e in (-0.1, 0.1):
        cyl_axis("chrome", 0.22, 0.05, (15.6, y + 1.1, ZC + e), "z", 10)
    b.layer = "Tankdeck_Innen"
    box("stainless", 11.3, 14.1, y + 1.62, y + 1.67, ZC + 0.08, ZC + 0.14)
    for k, x_ in enumerate((11.6, 12.3, 13.0, 13.7)):
        scuba(f"Tankdeck_Tauchausruestung_{k + 1}", x_, y, ZC + 0.18, "+z")
    box("teak", 16.35, 16.9, y, y + 0.45, 8.6, 10.1)
    box("frame_black", 11.08, 11.25, y + 1.0, y + 1.6, 9.6, 10.1)
    box("led_red", 11.25, 11.27, y + 1.4, y + 1.5, 9.7, 9.8)
    box("led_green", 11.25, 11.27, y + 1.4, y + 1.5, 9.9, 10.0)
    node("Tankdeck_Tauchschleuse_Wasser", (14.0, y, 9.2))                     # flood water: move up in +Y to flood the chamber
    box("flood_water", 11.1, 16.9, y + 0.01, y + 0.07, ZC + 0.1, 10.3)
    b.layer = "Tankdeck_Innen"
    b.anchor("Tauchschleuse_Tuer", (15.6, y, ZC - 0.9), 0)
    b.anchor("Tauchschleuse_Innen", (14.0, y, 9.3), 0)
    b.anchor("Tauchschleuse_Ausruestung", (12.6, y, 8.9), 180)
    b.anchor("Tauchschleuse_Fluten", (11.75, y, 9.85), -90)
    b.anchor("Tauchschleuse_Ausstieg", (13.5, -1.8, hb(13.5, -1.75) + 1.5), 0)
    b.anchor("Flucht_Taucher_Richtung", (13.5, -2.0, 45.0), 0)

    # --- engine sabotage: fuel injection pump on each main engine (both destroyed -> power + time lock off, yacht can't leave)
    for s_, side in ((-1, "BB"), (1, "SB")):
        zf = s_ * 2.6
        node(f"Tankdeck_Motor_{side}_Einspritzpumpe", (-44.0, y + 0.5, zf - s_ * 0.25))
        box("engine_grey", -45.0, -43.0, y + 0.5, y + 1.5, zf - s_ * 0.5, zf)
        box("safety_yellow", -44.7, -43.5, y + 1.1, y + 1.4, zf - s_ * 0.52, zf - s_ * 0.5)
        box("led_red", -43.35, -43.15, y + 1.2, y + 1.3, zf - s_ * 0.53, zf - s_ * 0.5)
        for xx in (-44.7, -44.2, -43.8, -43.3):
            b.beam("pipe", (xx, y + 1.5, zf - s_ * 0.25), (xx, y + 1.85, zf + s_ * 0.2), 0.05)
        b.layer = "Tankdeck_Innen"
        b.anchor(f"Sabotage_Motor_{side}", (-44.0, y, s_ * 1.3), 0 if s_ > 0 else 180)
        b.anchor(f"Motor_Rauch_{side}", (-44.0, y + 2.8, s_ * 3.8), 0)

    # --- captain + safe key (bridge): the key lies on the side table next to the captain's chair
    y = DY["Brueckendeck"]
    b.layer = "Brueckendeck_Innen"
    b.cyl("chrome", 0.04, 0.68, (27.3, y + 0.34, -1.0), 6)
    b.cyl("walnut", 0.22, 0.04, (27.3, y + 0.7, -1.0), 10)
    loot("Brueckendeck_Tresor_Schluessel", "key", 27.3, y + 0.72, -1.0)
    b.anchor("Kapitaen", (27.6, y, 0.0), 90)

    # --- pool deck (Hauptdeck aft): rich guests = extra mission (threaten them, take their valuables)
    y = DY["Hauptdeck"]
    b.layer = "Hauptdeck_Innen"
    POOLLOOT = {(-1, 0): "watch", (-1, 1): "jewels", (-1, 2): "phone", (1, 0): "bag", (1, 1): "champagne", (1, 2): "cash"}
    ng = 1
    for s_ in (-1, 1):
        for k, x in enumerate((-70.3, -67.9, -65.5)):
            b.layer = "Hauptdeck_Innen"
            box("teak", x - 0.22, x + 0.22, y, y + 0.45, s_ * 6.6 - 0.22, s_ * 6.6 + 0.22)
            L("Hauptdeck", POOLLOOT[(s_, k)], x, y + 0.45, s_ * 6.6, "Pool")
        b.layer = "Hauptdeck_Innen"
        for x in (-71.5, -69.1, -66.7):
            b.anchor(f"Pool_Gast_{ng}", (x, y + 0.42, s_ * 6.1), 0)
            ng += 1
    b.anchor("Pool_Gast_7", (-68.0, 3.78, 1.5), -90)
    b.anchor("Pool_Gast_8", (-65.5, 3.78, -2.0), -90)
    b.anchor("Pool_Bedrohen", (-62.0, y, 0.0), -90)

    # --- stealable items everywhere (each = own node "<Deck>_Beute_<Art>_<n>" with a pick-up trigger)
    y = DY["Tankdeck"]
    L("Tankdeck", "wine", 14.0, y + 0.9, 0.0)
    L("Tankdeck", "wine", 16.0, y + 0.9, -0.4)
    L("Tankdeck", "phone", -8.5, y + 0.8, -9.0)
    y = DY["Unterdeck"]
    L("Unterdeck", "champagne", -65.8, y + 1.12, 4.5)
    L("Unterdeck", "watch", -70.5, y + 0.4, 0.25)
    L("Unterdeck", "phone", -70.2, y + 0.4, -0.35)
    L("Unterdeck", "watch", -6.6, y + 0.78, -6.5)
    L("Unterdeck", "jewels", 7.5, y + 0.78, -6.5)
    L("Unterdeck", "laptop", 14.5, y + 0.8, 2.25)
    L("Unterdeck", "cash", 13.4, y + 0.8, 2.2)
    L("Unterdeck", "phone", -46.0, y + 0.75, -3.0)
    y = DY["Hauptdeck"]
    L("Hauptdeck", "cigars", -50.0, y + 0.4, 0.5)
    L("Hauptdeck", "champagne", -38.5, y + 1.12, -8.4)
    L("Hauptdeck", "silver", -24.5, y + 0.76, 0.0)
    L("Hauptdeck", "silver", -19.5, y + 0.76, 0.0)
    L("Hauptdeck", "bag", 12.55, y + 0.6, -5.7)
    L("Hauptdeck", "jewels", 21.5, y + 0.6, -5.7)
    L("Hauptdeck", "watch", 30.6, y + 0.6, 5.7)
    y = DY["Oberdeck"]
    L("Oberdeck", "silver", -54.5, y + 0.76, 0.0)
    L("Oberdeck", "champagne", -48.0, y + 1.12, -4.0)
    L("Oberdeck", "cigars", -36.0, y + 0.4, 0.3)
    L("Oberdeck", "watch", -32.0, y + 0.4, -0.3)
    L("Oberdeck", "champagne", -42.5, y + 1.12, -8.9)
    L("Oberdeck", "phone", -18.5, y + 0.65, 1.5)
    L("Oberdeck", "bag", 15.05, y + 0.6, -5.85)
    L("Oberdeck", "jewels", 28.85, y + 0.6, -5.85)
    L("Oberdeck", "laptop", 14.0, y + 0.6, 5.75)
    L("Oberdeck", "watch", 28.85, y + 0.6, 5.85)
    y = DY["Eignerdeck"]
    L("Eignerdeck", "laptop", -6.6, y + 0.78, 0.5)
    L("Eignerdeck", "cash", -5.4, y + 0.78, -0.5)
    L("Eignerdeck", "watch", 20.0, y + 0.9, -3.85)
    L("Eignerdeck", "bag", 25.2, y + 0.6, -0.8)
    L("Eignerdeck", "champagne", -36.5, y + 1.12, 6.0)
    y = DY["Brueckendeck"]
    L("Brueckendeck", "laptop", -6.9, y + 0.78, 3.0)
    L("Brueckendeck", "cash", 11.0, y + 0.78, -8.65)
    L("Brueckendeck", "watch", 14.0, y + 0.6, -5.3)
    L("Brueckendeck", "cigars", -18.0, y + 0.45, 0.25)
    y = DY["Sonnendeck"]
    L("Sonnendeck", "champagne", 14.2, y + 1.12, 3.0)
    L("Sonnendeck", "phone", -16.5, y + 0.42, 5.2)
    L("Sonnendeck", "bag", -13.0, y + 0.42, -5.6)
    L("Sonnendeck", "watch", 20.0, y + 0.45, 0.25)

    # --- guards, patrol routes, hiding spots, police (anchors only)
    b.layer = None

    def route(name, lv, pts):
        for k, (x, z) in enumerate(pts):
            nx_, nz_ = pts[(k + 1) % len(pts)]
            b.anchor(f"Patrouille_{lv}_{name}_{k + 1}", (x, DY[lv], z), round(float(np.degrees(np.arctan2(nx_ - x, nz_ - z))), 1))

    route("A", "Unterdeck", [(-70.5, 2.5), (-64.0, 0.0), (-59.8, 2.8), (-52.0, 2.8), (-47.0, 0.0), (-41.0, -1.5)])
    route("B", "Unterdeck", [(-38.0, 0.0), (-11.5, 0.0), (-2.0, 0.0), (9.0, 0.0), (17.0, 0.6), (24.0, 0.0), (33.0, 4.5), (44.0, 1.0)])
    route("A", "Hauptdeck", [(-62.0, 10.5), (-40.0, 11.0), (-10.0, 11.0), (20.0, 11.0), (36.0, 9.0)])
    route("B", "Hauptdeck", [(-55.0, 0.0), (-47.0, 0.0), (-32.0, 0.0), (-22.0, 2.8), (-12.0, 0.0), (2.0, 4.6), (12.0, 0.0), (30.0, 0.0)])
    route("A", "Oberdeck", [(-57.0, -6.0), (-48.0, -10.75), (-20.0, -10.75), (10.0, -10.75), (38.0, -8.0), (46.0, -5.0)])
    route("B", "Oberdeck", [(-44.0, 0.0), (-34.0, 3.0), (-26.0, -7.0), (-19.0, -7.0), (-12.0, -4.0)])
    route("A", "Eignerdeck", [(-48.0, -6.0), (-40.0, -7.5), (-24.0, 6.5), (-10.0, 4.0), (4.0, 5.5), (12.0, 2.0), (24.0, 5.5)])
    route("A", "Brueckendeck", [(-41.0, -6.5), (-29.5, -5.0), (-29.5, 5.0), (-41.0, 6.5)])
    route("B", "Brueckendeck", [(4.0, -5.0), (12.0, 0.0), (18.0, 6.0), (24.8, 0.1)])
    route("A", "Sonnendeck", [(-20.5, 0.0), (-14.0, 4.0), (-4.0, 0.0), (5.0, -5.0), (20.0, -6.0)])
    route("A", "Tankdeck", [(-9.0, -4.0), (-17.0, 0.0), (-24.0, 2.0), (-31.0, 0.0), (-44.0, 0.0), (-53.5, 0.0)])
    for (nm, lv, x, z, yaw) in (("Wache_Beachclub", "Unterdeck", -68.5, -2.0, -90), ("Wache_Garage", "Unterdeck", -52.5, 2.8, 90),
                                ("Wache_Wachraum", "Unterdeck", 12.5, 0.6, 0), ("Wache_Jetski", "Unterdeck", 34.0, 4.5, 180),
                                ("Wache_Maschinenraum", "Tankdeck", -35.0, 0.0, -90), ("Wache_Brueckendeck_Achtern", "Brueckendeck", -25.5, 0.0, -90),
                                ("Wache_Sicherheitszentrale", "Brueckendeck", -4.0, -4.0, -90), ("Wache_Sonnendeck", "Sonnendeck", -4.0, 0.0, 90)):
        b.anchor(nm, (x, DY[lv], z), yaw)
    for (nm, lv, x, z) in (("Versteck_Beachclub_Bar", "Unterdeck", -65.2, 5.8), ("Versteck_Garage", "Unterdeck", -56.0, 8.6),
                           ("Versteck_Spa", "Unterdeck", 4.3, 6.5), ("Versteck_Jetski", "Unterdeck", 38.2, 6.8),
                           ("Versteck_Salon_Fluegel", "Hauptdeck", -35.0, 9.2), ("Versteck_Speisesaal", "Hauptdeck", -16.4, -9.2),
                           ("Versteck_Kombuese", "Hauptdeck", 13.0, 2.5), ("Versteck_Kino", "Oberdeck", -22.9, 3.0),
                           ("Versteck_Skylounge", "Oberdeck", -38.0, 6.6), ("Versteck_Suite", "Oberdeck", 20.5, 8.5),
                           ("Versteck_Galerie", "Eignerdeck", -27.0, 3.7), ("Versteck_Buero", "Eignerdeck", -9.0, 2.0),
                           ("Versteck_Ankleide", "Eignerdeck", 14.5, -7.5), ("Versteck_Heli", "Brueckendeck", -36.5, 1.8),
                           ("Versteck_Kapitaenskabine", "Brueckendeck", 15.3, -7.3), ("Versteck_Fitness", "Sonnendeck", 8.5, 5.1),
                           ("Versteck_Maschinenraum", "Tankdeck", -33.5, 7.5), ("Versteck_Weinkeller", "Tankdeck", 15.0, -8.6)):
        b.anchor(nm, (x, DY[lv], z), 0)
    for (nm, x, yy, z, yaw) in (("Polizei_Boot_1", -95.0, 0.0, 20.0, 60), ("Polizei_Boot_2", 0.0, 0.0, 45.0, 180),
                                ("Polizei_Boot_3", 95.0, 0.0, 20.0, -120), ("Polizei_Boot_4", -95.0, 0.0, -4.0, 90),
                                ("Polizei_Heli", 0.0, 45.0, 30.0, 180), ("Polizei_Kai_1", -40.0, 3.0, -22.0, 0),
                                ("Polizei_Kai_2", 0.0, 3.0, -24.0, 0), ("Polizei_Kai_3", 40.0, 3.0, -22.0, 0),
                                ("Polizei_Zugang_Gangway", 0.0, 3.0, -18.5, 0), ("Polizei_Zugang_Heck", -78.0, 1.0, 3.0, 90)):
        b.anchor(nm, (x, yy, z), yaw)
    b.layer = None
    b.anchor("Liegeplatz_Kaiseite", (0.0, 0.0, -12.0), 0)
    b.anchor("Wache_Gangway", (0.0, DY["Hauptdeck"], -9.0), 180)
    b.anchor("Wache_Achterdeck", (-60.0, DY["Hauptdeck"], 8.0), 90)
    b.anchor("Wache_Eignerdeck", (-1.0, DY["Eignerdeck"], -4.0), 0)
    b.anchor("Wache_Bruecke", (25.0, DY["Brueckendeck"], -3.0), 90)
    b.anchor("Notluke_Tankdeck", (44.0, DY["Tankdeck"], 4.0), 0)
    return b
