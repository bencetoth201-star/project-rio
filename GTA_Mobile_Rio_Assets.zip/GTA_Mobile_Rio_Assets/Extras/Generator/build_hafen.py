"""Build the harbour kit → out_hafen/*.glb/.obj/.mtl + meta.json"""
import json, os
import numpy as np
from lib import export, SLOT_PALETTES
import hafen

os.makedirs("out_hafen", exist_ok=True)
meta = []
for slug, name, cls, fn in hafen.HAFEN:
    b = fn()                                    # no normalize: pivots are meaningful (water line, quay centre, crane centre)
    tris, mats, bnd, slots = export(b, f"out_hafen/{slug}", name)
    size = bnd[1] - bnd[0]
    lot = (float(2 * np.ceil(size[0] / 2)), float(2 * np.ceil(size[2] / 2)))
    combos = int(np.prod([len(SLOT_PALETTES[s.split("_")[1]]) for s in slots])) if slots else 1
    meta.append(dict(slug=slug, name=name, cls=cls, tris=tris, mats=mats, slots=slots, combos=combos,
                     size=[round(float(v), 1) for v in size], lot=[lot[0], lot[1]],
                     anchors={k: [round(float(c), 3) for c in p] + [yaw] for k, (p, yaw) in b.anchors.items()},
                     offset=[round(float(-(bnd[0][0] + bnd[1][0]) / 2), 2), round(float(-(bnd[0][2] + bnd[1][2]) / 2), 2)]))
    print(f"{slug:28s} tris={tris:5d} size={np.round(size, 1).tolist()} lot={lot}")
json.dump(dict(houses=meta, palettes=SLOT_PALETTES, rows={"Schiffe": 0, "Kai": 1, "Kräne": 2, "Container": 3, "Gebäude": 4}, gap=6,
               title="Rio-Hafen", subtitle="17 Hafenteile: 300-m-Containerschiff, Schlepper, Kaikanten, Kräne, Container, Hafengebäude · Wasser y = 0, Kai +3 m",
               lotLabel="Fläche", allLabel="Hafenteile", allHint="Hafen-Set nebeneinander"),
          open("out_hafen/meta.json", "w"), indent=1, ensure_ascii=False)
