# Rio-Heists

Heist-Schauplätze für GTA Mobile: **Casa Império** (Mega-Heist-Palast, „Megabank“) + **abgeriegelte Version** (Rollläden, Panzertüren,
Strom aus, Notlicht), **Megayacht SOBERANA** (Schleich-Heist, 86 Beute-Teile) und die **Maya-Kanalisation** als Baukasten
(15 Teile + Beispielnetz: Gang zur Maya-Wand im Palast, Boot-Parkplatz, Pyramiden-Halle, Geheimtor, Bootslift, Versteck-Garage).
Ordner `Assets` ins Unity-Projekt ziehen, glTFast installieren, **Tools ▸ Rio Heists ▸ …**. Details: `ANLEITUNG_CLAUDE_CODE_HEISTS.md`.
