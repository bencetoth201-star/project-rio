"""Casa Império – Palácio Imperial da Joalheria (v2, monumental). Fiktiv.
Stil: monumentale Staatsbank / Münzanstalt (Säulenportikus, Kuppel mit Buntglas, Gold tief unter der Erde).

Gebäude 64 x 56 m, Vorplatz mit Brunnen + Eisenzaun (vorne), Lkw-Hof mit Rampe (hinten) → Grundstück 72 x 108 m.
Ebenen (Fußboden-Oberkante y):
  Dach  27.0  Dachterrasse, Kuppel (bis ~53 m), Eck-Wachtürme, Helikopterlandeplatz, Lüftungsschacht
  OG3   21.0  Sicherheitszentrale, Direktorsuite mit Geheimsafe, Kaserne + Waffenkammer, Büros
  OG2   15.5  Sitzungssaal, Edelsteinschleiferei, Goldschmiede, Kantine, Arbeitstresor
  OG1    9.5  Sala Imperial (Krone) hinter Laser-Korridor, Uhrenmuseum, Auktionssaal, Archiv
  EG     1.65 Grand Salon unter der Kuppel mit 'Estrela do Rio', Sicherheitsschleusen, Salons, Tesouraria, Lkw-Aufzug
  UG1   -4.5  Panzergarage, Serverraum, Stromzentrale, Lüftungszentrale, Kontrollposten
  UG2  -10.5  Goldschmelze + Prägerei, Raffinerie-Labor, Tresor-Vorraum mit Aufzug, Pumpenraum (Flutsystem)
  UG3  -20.5  Câmara de Ouro: Goldtresor 44 x 34 m, 6-m-Rundtür, Flutkanäle + Schieber, Diamantkammer, Sprengstellen Tresor/Maya-Wand
Nodes: <Ebene>__ (Struktur: Böden, Wände, Säulen, Fassade), <Ebene>_Innen__ (Einrichtung), Heist-Teile als eigene Nodes."""
import numpy as np
import trimesh
from shapely.geometry import Polygon, Point, box as sbox
from lib import B, PALETTE, ALPHA

PALETTE.update({
    "stone_imperial": "#E3D9C6", "stone_dark": "#B9AD96", "stone_rustic": "#CFC3AA", "bronze": "#8C6A3B", "bronze_dark": "#6B4F2A",
    "marble_white": "#EEEAE2", "marble_black": "#1E1E22", "marble_green": "#1F4D3A", "marble_red": "#7E2E2E",
    "velvet_purple": "#4A1E5A", "velvet_red": "#7A1631", "velvet_blue": "#1E2A4A", "lacquer": "#17171A", "brass": "#C9A23A",
    "carpet_red": "#6E1424", "walnut": "#4E3424", "laser_red": "#FF2A2A", "helipad": "#3A3F44", "vault_steel": "#8E959C",
    "gold_bar": "#D4AF37", "silver": "#C9CED6", "gem_green": "#2ECC71", "gem_red": "#E0115F", "gem_blue": "#2F6FE0",
    "diamond": "#E6F4FF", "cream": "#E9E1D0", "server_black": "#141618", "safety_yellow": "#F2C230", "pipe": "#6E7378",
    "brick_old": "#8A4A36", "statue_bronze": "#5F7F6A", "dome_green": "#5E9C8A", "dome_rib": "#4A7A6B", "molten": "#FFB22E",
    "flood_water": "#2C6E8F", "water_jet": "#BFE6F5", "iron": "#1E1F22", "iron_fence": "#1E1F22", "flag_green": "#1F6B3A",
    "flag_gold": "#E3B23C", "flag_white": "#F2F0EA", "crate": "#9C7A4E", "cash_green": "#4F7D4A", "hazard": "#1E1E1E",
    "dach_rand": "#D6CBB4", "dach_stahl": "#5B6168", "dach_gelb": "#F2C230", "dach_vitral_r": "#C8323C", "dach_vitral_b": "#2F5FC8",
    "dach_vitral_g": "#2E9E5A", "dach_vitral_y": "#E8B830", "dach_bronze": "#8C6A3B",
    "maya_kalk": "#C8B48A", "maya_kalk_dunkel": "#9C8862", "maya_rot": "#8E3B2A", "maya_jade": "#3E8C6E",
    "rack_stahl": "#3D5A80", "rack_orange": "#E07A2E", "cardboard": "#B08A5A", "lamp_aus": "#6E6A5E", "rolladen": "#7C838A",
    "rolladen_dunkel": "#4E545A", "panzer": "#5A6068", "sandsack": "#A8946A",
})
for _k, _v in {"gold": "#C9A23A", "screen": "#2FE0F0", "glass_shop": "#9FC3D6", "glass_rail": "#BFD9E6", "chrome": "#C9CED6",
               "dach_licht": "#FFE9B0", "led_green": "#36D46A", "led_red": "#FF3B30", "mirror": "#DCE0E6"}.items():
    PALETTE.setdefault(_k, _v)
ALPHA.update({"flood_water": 0.55, "water_jet": 0.45, "iron_fence": 0.7})

X0, X1, Z0, Z1 = -32.0, 32.0, -28.0, 28.0
T = 0.6
IX0, IX1, IZ0, IZ1 = X0 + T, X1 - T, Z0 + T, Z1 - T
SLAB = 0.45
LV = {"UG3": -20.5, "UG2": -10.5, "UG1": -4.5, "EG": 1.65, "OG1": 9.5, "OG2": 15.5, "OG3": 21.0}
TOP = 26.5
ORDER = ["UG3", "UG2", "UG1", "EG", "OG1", "OG2", "OG3"]
LEVELS = ["Dach", "OG3", "OG2", "OG1", "EG", "UG1", "UG2", "UG3"]
AT = (-14.0, 14.0, -10.0, 14.0)                  # atrium (open EG → dome)
DCX, DCZ, DR = 0.0, 2.0, 12.0                    # dome centre + radius
CORE_L = (IX0, -25.0, IZ0, -17.4)                # stair cores UG2 → OG3 (R also → roof)
CORE_R = (25.0, IX1, IZ0, -17.4)
VEH = (-4.0, 4.0, -26.6, -16.0)                  # truck elevator EG ↔ UG1
ELV_L = (-9.3, -6.7, -13.6, -10.6)               # glass elevators UG2 -> OG3 (between the atrium columns)
ELV_R = (6.7, 9.3, -13.6, -10.6)
VLIFT = (-3.0, 3.0, -24.5, -19.5)                # vault lift UG2 ↔ UG3
MST = (19.0, 22.0, -26.0, -15.0)                 # maintenance stair UG2 → UG3
VENT = (-24.6, -22.6, -27.4, -25.4)               # ventilation shaft UG1 -> roof (back wall, next to core W)
GEMS = ["gem_green", "gem_red", "gem_blue", "diamond"]
FACES = (("front", 32.0), ("back", 32.0), ("left", 28.0), ("right", 28.0))
PORTALS = ((-9.0, -5.0), (-2.5, 2.5), (5.0, 9.0))
KW = (2.5, 5.5)                                  # UG3 east outer wall: old Maya stones = blast point into the sewer (z range)
BR = (2.5, 5.5)                                  # UG3 vault east wall: weak spot = blast point into the vault (z range)


def top_of(lv):
    i = ORDER.index(lv)
    return LV[ORDER[i + 1]] - SLAB if i + 1 < len(ORDER) else TOP


def bot_of(lv):
    return LV[lv] - SLAB


def palacio(abgeriegelt=False):
    """abgeriegelt=True: Variante im Abriegelungs-Zustand (Stahlrollläden, Panzertore, Barrikaden, Notlicht)."""
    b = B(1822)
    b.pickup_tags = ("_Beute",)
    rng = np.random.default_rng(1822)

    # ================================================================ generic helpers
    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        if abs(x1 - x0) < 1e-4 or abs(y1 - y0) < 1e-4 or abs(z1 - z0) < 1e-4:
            return
        b.box(mat, (abs(x1 - x0), abs(y1 - y0), abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def wall_x(mat, z, x0, x1, y0, y1, holes=(), t=T):
        z0, z1 = z - t / 2, z + t / 2
        xs = [x0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [x1]
        for a, c in zip(xs[0::2], xs[1::2]):
            if c - a > 1e-3:
                box(mat, a, c, y0, y1, z0, z1)
        for (xa, xb, ya, yb) in holes:
            if ya > y0:
                box(mat, xa, xb, y0, ya, z0, z1)
            if yb < y1:
                box(mat, xa, xb, yb, y1, z0, z1)

    def wall_z(mat, x, z0, z1, y0, y1, holes=(), t=T):
        x0, x1 = x - t / 2, x + t / 2
        zs = [z0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [z1]
        for a, c in zip(zs[0::2], zs[1::2]):
            if c - a > 1e-3:
                box(mat, x0, x1, y0, y1, a, c)
        for (za, zb, ya, yb) in holes:
            if ya > y0:
                box(mat, x0, x1, y0, ya, za, zb)
            if yb < y1:
                box(mat, x0, x1, yb, y1, za, zb)

    def flat(mat, poly, y0, y1):
        for p in getattr(poly, "geoms", [poly]):
            if p.area < 1e-3:
                continue
            q = Polygon([(x, -z) for x, z in p.exterior.coords], [[(x, -z) for x, z in r.coords] for r in p.interiors])
            m = trimesh.creation.extrude_polygon(q, y1 - y0)
            m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
            b.add(mat, m.apply_translation((0, y0, 0)))

    def ring_y(mat, cx, cz, rmin, rmax, y0, y1, sections=32):
        m = trimesh.creation.annulus(r_min=rmin, r_max=rmax, height=y1 - y0, sections=sections)
        m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
        b.add(mat, m.apply_translation((cx, (y0 + y1) / 2, cz)))

    def cyl_axis(mat, r, length, c, axis, sections=10):
        m = trimesh.creation.cylinder(radius=r, height=length, sections=sections)
        if axis == "x":
            m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
        elif axis == "z":
            pass
        else:
            m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        b.add(mat, m.apply_translation(c))

    def floor_slab(lv, mat, holes):
        y = LV[lv]
        fp = sbox(IX0, IZ0, IX1, IZ1)
        for h in holes:
            fp = fp.difference(sbox(h[0], h[2], h[1], h[3]))
        flat("concrete", fp, y - SLAB, y - 0.03)
        flat(mat, fp, y - 0.03, y)

    def fpt(face, u, y, d):
        if face == "front":
            return (u, y, Z1 + d)
        if face == "back":
            return (u, y, Z0 - d)
        if face == "left":
            return (X0 - d, y, u)
        return (X1 + d, y, u)

    def fbox(face, mat, u0, u1, y0, y1, d0, d1):
        p0, p1 = fpt(face, u0, y0, d0), fpt(face, u1, y1, d1)
        box(mat, min(p0[0], p1[0]), max(p0[0], p1[0]), y0, y1, min(p0[2], p1[2]), max(p0[2], p1[2]))

    def fhull(face, mat, pts):
        b.hull(mat, [fpt(face, u, y, d) for (u, y, d) in pts])

    def win(face, u, y0, h, w, style):
        """Applied window: stone surround, glass, bronze mullions, sill + hood (no hole in the wall)."""
        fbox(face, "stone_dark", u - w / 2 - 0.25, u + w / 2 + 0.25, y0 - 0.1, y0 + h + 0.25, 0.0, 0.08)
        fbox(face, "glass", u - w / 2, u + w / 2, y0, y0 + h, 0.08, 0.11)
        fbox(face, "bronze", u - 0.04, u + 0.04, y0, y0 + h, 0.11, 0.14)
        fbox(face, "bronze", u - w / 2, u + w / 2, y0 + h * 0.62, y0 + h * 0.62 + 0.07, 0.11, 0.14)
        fbox(face, "stone_imperial", u - w / 2 - 0.4, u + w / 2 + 0.4, y0 - 0.3, y0 - 0.1, 0.0, 0.3)
        if style == "pediment":
            fhull(face, "stone_imperial", [(u - w / 2 - 0.5, y0 + h + 0.25, 0.0), (u + w / 2 + 0.5, y0 + h + 0.25, 0.0), (u, y0 + h + 1.0, 0.0),
                                           (u - w / 2 - 0.5, y0 + h + 0.25, 0.35), (u + w / 2 + 0.5, y0 + h + 0.25, 0.35), (u, y0 + h + 1.0, 0.35)])
            for k in np.linspace(u - w / 2, u + w / 2, 4):
                fbox(face, "stone_imperial", k - 0.09, k + 0.09, y0 - 1.1, y0 - 0.3, 0.05, 0.2)                 # balconette balusters
            fbox(face, "stone_imperial", u - w / 2 - 0.4, u + w / 2 + 0.4, y0 - 1.25, y0 - 1.1, 0.0, 0.3)
        elif style == "cornice":
            fbox(face, "stone_imperial", u - w / 2 - 0.45, u + w / 2 + 0.45, y0 + h + 0.25, y0 + h + 0.55, 0.0, 0.32)
        elif style == "grille":
            for k in np.arange(u - w / 2 + 0.25, u + w / 2 - 0.1, 0.42):
                fbox(face, "iron", k - 0.03, k + 0.03, y0, y0 + h, 0.14, 0.19)
            fbox(face, "iron", u - w / 2, u + w / 2, y0 + h * 0.5, y0 + h * 0.5 + 0.05, 0.14, 0.19)
            fbox(face, "stone_imperial", u - 0.35, u + 0.35, y0 + h + 0.25, y0 + h + 0.8, 0.0, 0.25)

    def balustrade(x0, z0, x1, z1, y, h=1.05, mat="stone_imperial", step=0.55):
        if abs(x1 - x0) >= abs(z1 - z0):
            a, c = sorted((x0, x1))
            if c - a < 0.2:
                return
            box(mat, a, c, y, y + 0.18, z0 - 0.22, z0 + 0.22)
            box(mat, a, c, y + h - 0.14, y + h, z0 - 0.26, z0 + 0.26)
            for x in np.arange(a + step / 2, c, step):
                box(mat, x - 0.07, x + 0.07, y + 0.18, y + h - 0.14, z0 - 0.08, z0 + 0.08)
        else:
            a, c = sorted((z0, z1))
            if c - a < 0.2:
                return
            box(mat, x0 - 0.22, x0 + 0.22, y, y + 0.18, a, c)
            box(mat, x0 - 0.26, x0 + 0.26, y + h - 0.14, y + h, a, c)
            for z in np.arange(a + step / 2, c, step):
                box(mat, x0 - 0.08, x0 + 0.08, y + 0.18, y + h - 0.14, z - 0.07, z + 0.07)

    def column(x, z, y0, y1, r, mat, base="brass", sections=12):
        box(base, x - r - 0.12, x + r + 0.12, y0, y0 + 0.3, z - r - 0.12, z + r + 0.12)
        b.cyl(mat, r, (y1 - 0.35) - (y0 + 0.3), (x, (y0 + 0.3 + y1 - 0.35) / 2, z), sections)
        box(base, x - r - 0.18, x + r + 0.18, y1 - 0.35, y1, z - r - 0.18, z + r + 0.18)

    def flight(x0, x1, za, zb, ya, yb, mat="marble_white", side_mat=None):
        n = max(2, int(round(abs(yb - ya) / 0.17)))
        dz = (zb - za) / n
        for k in range(n):
            yy = ya + (yb - ya) * (k + 1) / n
            z = za + dz * k
            box(mat, x0, x1, yy - 0.17, yy, min(z, z + dz), max(z, z + dz))
        if side_mat:
            for x in (x0, x1):
                b.hull(side_mat, [(x + e, yy_, z_) for e in (-0.07, 0.07) for (yy_, z_) in ((ya - 0.35, za), (yb - 0.35, zb), (ya + 0.02, za), (yb + 0.02, zb))])

    def stairwell(core, y0, y1, mat="concrete_light"):
        cx0, cx1, cz0, cz1 = core
        xm, ym = (cx0 + cx1) / 2, (y0 + y1) / 2
        box(mat, cx0 + 0.2, cx1 - 0.2, y0 - 0.3, y0, cz1 - 1.8, cz1)
        box(mat, cx0 + 0.2, cx1 - 0.2, ym - 0.3, ym, cz0 + 0.2, cz0 + 2.0)
        flight(cx0 + 0.3, xm - 0.1, cz1 - 1.8, cz0 + 2.0, y0, ym, mat)
        flight(xm + 0.1, cx1 - 0.3, cz0 + 2.0, cz1 - 1.8, ym, y1, mat)
        b.beam("safety_yellow", (xm, y0 + 1.0, cz1 - 1.8), (xm, ym + 1.0, cz0 + 2.0), 0.035)
        b.beam("safety_yellow", (xm, ym + 1.0, cz0 + 2.0), (xm, y1 + 1.0, cz1 - 1.8), 0.035)

    def core_walls(core, lv, inner_x, tag):
        cx0, cx1, cz0, cz1 = core
        y0, yt = LV[lv], top_of(lv)
        wall_z("concrete_light", inner_x, cz0, cz1, y0, yt, t=0.3)
        xd = (cx0 + cx1) / 2
        wall_x("concrete_light", cz1, cx0, cx1, y0, yt, [(xd - 0.7, xd + 0.7, y0, y0 + 2.3)], t=0.3)
        box("door_metal", xd - 0.7, xd + 0.7, y0, y0 + 2.3, cz1 - 0.05, cz1 + 0.05)
        box("led_green", xd - 0.35, xd + 0.35, y0 + 2.45, y0 + 2.7, cz1 + 0.15, cz1 + 0.18)
        b.anchor(f"Treppenhaus_{tag}_{lv}", (xd, y0, cz1 + 0.8), 0)

    cam_count = {}

    def cam_id(prefix):
        cam_count[prefix] = cam_count.get(prefix, 0) + 1
        return f"{prefix}_{cam_count[prefix]}"

    def cam(name, x, y, z, yaw):
        box("cloth_white", x - 0.1, x + 0.1, y, y + 0.15, z - 0.1, z + 0.1)
        b.box("frame_black", (0.14, 0.14, 0.26), (x, y - 0.06, z), rot_y=yaw, rot_x=-25)
        b.anchor(name, (x, y - 0.06, z), yaw)

    def chair(x, z, y, rot=0.0, mat="velvet_red"):
        r = np.radians(rot)
        b.box(mat, (0.5, 0.1, 0.5), (x, y + 0.45, z), rot_y=rot)
        b.box(mat, (0.5, 0.5, 0.08), (x - np.sin(r) * 0.22, y + 0.75, z - np.cos(r) * 0.22), rot_y=rot)
        b.box("frame_black", (0.4, 0.4, 0.4), (x, y + 0.2, z), rot_y=rot)

    def desk(x, z, y, w=1.6, d=0.8, mat="walnut", screens=1, along="x"):
        if along == "x":
            box(mat, x - w / 2, x + w / 2, y, y + 0.75, z - d / 2, z + d / 2)
            for k in range(screens):
                sx = x + (k - (screens - 1) / 2) * 0.6
                box("frame_black", sx - 0.27, sx + 0.27, y + 0.8, y + 1.15, z - d / 2 + 0.1, z - d / 2 + 0.15)
                box("screen", sx - 0.24, sx + 0.24, y + 0.83, y + 1.12, z - d / 2 + 0.15, z - d / 2 + 0.16)
        else:
            box(mat, x - d / 2, x + d / 2, y, y + 0.75, z - w / 2, z + w / 2)
            for k in range(screens):
                sz = z + (k - (screens - 1) / 2) * 0.6
                box("frame_black", x - d / 2 + 0.1, x - d / 2 + 0.15, y + 0.8, y + 1.15, sz - 0.27, sz + 0.27)
                box("screen", x - d / 2 + 0.15, x - d / 2 + 0.16, y + 0.83, y + 1.12, sz - 0.24, sz + 0.24)

    def sofa(x, z, y, w=2.0, rot=0, mat="velvet_red"):
        if rot in (0, 180):
            s = 1 if rot == 0 else -1
            box(mat, x - w / 2, x + w / 2, y, y + 0.45, z - 0.4, z + 0.4)
            box(mat, x - w / 2, x + w / 2, y + 0.45, y + 0.95, z - s * 0.4 - 0.1, z - s * 0.4 + 0.1)
        else:
            s = 1 if rot == 90 else -1
            box(mat, x - 0.4, x + 0.4, y, y + 0.45, z - w / 2, z + w / 2)
            box(mat, x - s * 0.4 - 0.1, x - s * 0.4 + 0.1, y + 0.45, y + 0.95, z - w / 2, z + w / 2)

    def server_rack(x, z, y, w=0.6, d=1.0):
        box("server_black", x - w / 2, x + w / 2, y, y + 2.1, z - d / 2, z + d / 2)
        for yy in np.arange(y + 0.3, y + 2.0, 0.3):
            box("led_green" if rng.random() < 0.8 else "led_red", x + w / 2, x + w / 2 + 0.01, yy, yy + 0.03, z - 0.3, z - 0.2)

    def octa(r, s=1.3):
        return trimesh.convex.convex_hull(np.array([(r, 0, 0), (-r, 0, 0), (0, r * s, 0), (0, -r * s, 0), (0, 0, r), (0, 0, -r)]))

    def ring(x, y, z, rot=0.0):
        m = trimesh.creation.cylinder(radius=0.034, height=0.012, sections=6)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(rot), [0, 1, 0]))
        b.add("gold" if rng.random() < 0.7 else "silver", m.apply_translation((x, y + 0.036, z)))
        b.add(GEMS[int(rng.integers(0, 4))], octa(0.015).apply_translation((x, y + 0.078, z)))

    def watch(x, y, z, rot=0.0):
        b.box("lacquer" if rng.random() < 0.5 else "silver", (0.04, 0.012, 0.2), (x, y + 0.006, z), rot_y=rot)
        b.cyl("gold" if rng.random() < 0.5 else "silver", 0.03, 0.016, (x, y + 0.018, z), 6)

    def necklace_bust(x, y, z, rot=0.0, mat="velvet_blue"):
        r = np.radians(rot)
        def P(dx, yy, dz):
            return (x + dx * np.cos(r) + dz * np.sin(r), y + yy, z - dx * np.sin(r) + dz * np.cos(r))
        b.hull(mat, [P(sx * 0.16, 0.0, sz * 0.08) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.12, 0.22, sz * 0.06) for sx in (-1, 1) for sz in (-1, 1)])
        b.hull(mat, [P(sx * 0.045, 0.22, sz * 0.045) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.04, 0.4, sz * 0.04) for sx in (-1, 1) for sz in (-1, 1)])
        m = trimesh.creation.torus(major_radius=0.07, minor_radius=0.008, major_sections=8, minor_sections=3)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2 - 0.5, [1, 0, 0]))
        m.apply_transform(trimesh.transformations.rotation_matrix(r, [0, 1, 0]))
        b.add("gold", m.apply_translation(P(0, 0.25, 0.015)))
        b.add(GEMS[int(rng.integers(0, 4))], octa(0.03).apply_translation(P(0, 0.17, 0.075)))

    def tray(x0, x1, z0, z1, y, kind="mix", step=0.32):
        box("velvet_blue", x0, x1, y, y + 0.02, z0, z1)
        for x in np.arange(x0 + 0.13, x1 - 0.05, step):
            for z in np.arange(z0 + 0.13, z1 - 0.05, step):
                if kind == "watch" or (kind == "mix" and rng.random() < 0.25):
                    watch(x, y + 0.02, z, rng.uniform(-10, 10))
                else:
                    ring(x, y + 0.02, z, rng.uniform(0, 180))

    def vitrine(node, x, z, y0, w=1.8, d=0.8, kind="mix", back=None):
        prev = b.layer
        box("lacquer", x - w / 2, x + w / 2, y0, y0 + 0.85, z - d / 2, z + d / 2)
        box("brass", x - w / 2 - 0.01, x + w / 2 + 0.01, y0 + 0.85, y0 + 0.9, z - d / 2 - 0.01, z + d / 2 + 0.01)
        box("brass", x - w / 2 + 0.05, x + w / 2 - 0.05, y0, y0 + 0.06, z - d / 2 + 0.05, z + d / 2 - 0.05)
        loot = node.replace("_Vitrine_", "_Beute_Uhr_Vitrine" if kind == "watch" else "_Beute_Schmuck_Vitrine")
        b.layer = loot                                                                     # contents = stealable
        b.pivots[loot] = (x, y0 + 0.9, z)
        tray(x - w / 2 + 0.06, x + w / 2 - 0.06, z - d / 2 + 0.06, z + d / 2 - 0.06, y0 + 0.9, kind)
        b.layer = node
        b.pivots[node] = (x, y0 + 1.15, z)
        box("glass_shop", x - w / 2, x + w / 2, y0 + 0.9, y0 + 1.4, z - d / 2, z + d / 2)
        for (a, c) in ((-1, -1), (-1, 1), (1, -1), (1, 1)):
            box("brass", x + a * w / 2 - 0.015, x + a * w / 2 + 0.015, y0 + 0.9, y0 + 1.42, z + c * d / 2 - 0.015, z + c * d / 2 + 0.015)
        b.layer = prev
        b.anchor(node, (x, y0, z), 0)

    def wall_case(x_wall, za, zb, y0, side, h=2.4):
        xi = x_wall + side * 0.55
        a, c = sorted((x_wall, xi))
        box("lacquer", a, c, y0, y0 + 0.95, za, zb)
        box("velvet_blue", x_wall + side * 0.02 - 0.01, x_wall + side * 0.02 + 0.01, y0 + 0.95, y0 + h, za, zb)
        box("glass_shop", xi - 0.02, xi + 0.02, y0 + 0.95, y0 + h, za, zb)
        box("lacquer", a, c, y0 + h, y0 + h + 0.25, za, zb)
        box("brass", a, c, y0 + h + 0.25, y0 + h + 0.29, za, zb)
        for z in np.arange(za, zb + 0.01, 2.0):
            box("brass", xi - 0.025, xi + 0.025, y0 + 0.95, y0 + h, z - 0.02, z + 0.02)
        for yy in (y0 + 1.3, y0 + 1.75):
            box("glass", a, c, yy - 0.01, yy, za, zb)
            box("lamp", x_wall + side * 0.06 - 0.02, x_wall + side * 0.06 + 0.02, yy + 0.38, yy + 0.4, za + 0.1, zb - 0.1)
            for z in np.arange(za + 0.3, zb - 0.2, 0.85):
                (ring if rng.random() < 0.6 else watch)((a + c) / 2, yy, z, 90)

    def chandelier(cx, cz, ytop, drop=2.0, r0=1.0, tiers=3):
        b.beam("brass", (cx, ytop, cz), (cx, ytop - drop, cz), 0.04)
        for i in range(tiers):
            r = r0 * (1.0 - 0.3 * i)
            yy = ytop - drop - 0.4 * i
            t = trimesh.creation.torus(major_radius=r, minor_radius=0.035, major_sections=12, minor_sections=3)
            t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
            b.add("brass", t.apply_translation((cx, yy, cz)))
            n = max(6, int(10 * r))
            for k in range(n):
                a = k * 2 * np.pi / n
                b.add("diamond", octa(0.06 * (1 + r0 / 3), 2.0).apply_translation((cx + r * np.cos(a), yy - 0.15, cz + r * np.sin(a))))
        b.cyl("lamp", 0.22 * r0, 0.45, (cx, ytop - drop - 0.35, cz), 8)

    def statue(x, y, z, rot=0.0, s=1.0, mat="statue_bronze", arm=True):
        r = np.radians(rot)
        def P(dx, yy, dz):
            return (x + (dx * np.cos(r) + dz * np.sin(r)) * s, y + yy * s, z + (-dx * np.sin(r) + dz * np.cos(r)) * s)
        b.hull(mat, [P(sx * 0.55, 0.0, sz * 0.45) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.32, 1.5, sz * 0.25) for sx in (-1, 1) for sz in (-1, 1)])
        b.hull(mat, [P(sx * 0.32, 1.5, sz * 0.25) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.42, 2.3, sz * 0.22) for sx in (-1, 1) for sz in (-1, 1)])
        b.add(mat, trimesh.creation.icosphere(subdivisions=1, radius=0.22 * s).apply_translation(P(0, 2.6, 0)))
        b.beam(mat, P(-0.4, 2.2, 0.0), P(-0.5, 1.45, 0.2), 0.12 * s)
        if arm:
            b.beam(mat, P(0.4, 2.2, 0.0), P(0.62, 3.1, 0.15), 0.12 * s)
            t = trimesh.creation.torus(major_radius=0.22 * s, minor_radius=0.045 * s, major_sections=10, minor_sections=4)
            t.apply_transform(trimesh.transformations.rotation_matrix(r, [0, 1, 0]))
            b.add("gold", t.apply_translation(P(0.66, 3.35, 0.15)))

    def lion(x, y, z, rot=0.0, mat="statue_bronze"):
        r = np.radians(rot)
        def P(dx, yy, dz):
            return (x + dx * np.cos(r) + dz * np.sin(r), y + yy, z - dx * np.sin(r) + dz * np.cos(r))
        b.hull(mat, [P(sx * 0.55, 0.0, dz) for sx in (-1, 1) for dz in (-1.3, 1.0)] + [P(sx * 0.45, 0.9, dz) for sx in (-1, 1) for dz in (-1.1, 0.6)])
        b.hull(mat, [P(sx * 0.62, 0.4, dz) for sx in (-1, 1) for dz in (0.4, 1.3)] + [P(sx * 0.55, 1.7, dz) for sx in (-1, 1) for dz in (0.5, 1.2)])
        b.hull(mat, [P(sx * 0.3, 1.05, dz) for sx in (-1, 1) for dz in (1.2, 1.8)] + [P(sx * 0.24, 1.55, dz) for sx in (-1, 1) for dz in (1.2, 1.7)])
        for sx in (-0.35, 0.35):
            b.hull(mat, [P(sx + e, 0.0, dz) for e in (-0.14, 0.14) for dz in (1.0, 1.95)] + [P(sx + e, 0.25, dz) for e in (-0.14, 0.14) for dz in (1.0, 1.85)])
        b.beam(mat, P(0.0, 0.3, -1.3), P(0.35, 0.12, -2.0), 0.08)

    def gold_pallet(x, y, z, h=0.6, name=None):
        prev = b.layer
        if name:
            b.layer = name
            b.pivots[name] = (x, y, z)
        box("crate", x - 0.6, x + 0.6, y, y + 0.14, z - 0.5, z + 0.5)
        box("gold_bar", x - 0.55, x + 0.55, y + 0.14, y + 0.14 + h, z - 0.45, z + 0.45)
        yy = y + 0.14 + h
        for i in range(3):
            for j in range(2):
                bx, bz = x - 0.36 + i * 0.36, z - 0.2 + j * 0.4
                b.hull("gold_bar", [(bx + dx, yy, bz + dz) for dx in (-0.12, 0.12) for dz in (-0.065, 0.065)] +
                       [(bx + dx, yy + 0.07, bz + dz) for dx in (-0.1, 0.1) for dz in (-0.05, 0.05)])
        b.layer = prev

    def lamp_post(x, z, y=0.0, h=6.0):
        b.cyl("iron", 0.32, 1.0, (x, y + 0.5, z), 8)
        b.cyl("iron", 0.12, h, (x, y + 1.0 + h / 2, z), 8)
        for a in (0.3, 2.4, 4.5):
            dx, dz = 0.8 * np.cos(a), 0.8 * np.sin(a)
            b.beam("iron", (x, y + h + 0.6, z), (x + dx, y + h + 0.9, z + dz), 0.05)
            box("lamp", x + dx - 0.18, x + dx + 0.18, y + h + 0.45, y + h + 0.95, z + dz - 0.18, z + dz + 0.18)
            b.hull("iron", [(x + dx + sx * 0.25, y + h + 0.95, z + dz + sz * 0.25) for sx in (-1, 1) for sz in (-1, 1)] + [(x + dx, y + h + 1.2, z + dz)])

    def flagpole(x, y, z, h, mat):
        b.cyl("iron", 0.08, h, (x, y + h / 2, z), 8)
        b.add("gold", trimesh.creation.icosphere(subdivisions=0, radius=0.16).apply_translation((x, y + h + 0.1, z)))
        b.hull(mat, [(x + 0.1, y + h - 0.3, z), (x + 3.3, y + h - 0.55, z), (x + 0.1, y + h - 2.4, z), (x + 3.3, y + h - 2.15, z),
                     (x + 0.1, y + h - 0.3, z + 0.03), (x + 3.3, y + h - 2.15, z + 0.03)])

    def palm_planter(x, z, y=0.0, h=7.0):
        b.cyl("stone_imperial", 1.0, 0.8, (x, y + 0.4, z), 10)
        b.cyl("hedge", 0.9, 0.05, (x, y + 0.82, z), 10)
        b.palm(x, z, h, (0.5 * np.cos(x + z), 0.4 * np.sin(x - z)), y=y + 0.8)

    def laser_grid(node, x0, x1, z0, z1, y, n=6, along="z"):
        """Red laser beams across a corridor (beams run along X if along == 'z' i.e. corridor along Z)."""
        prev = b.layer
        b.layer = node
        b.pivots[node] = ((x0 + x1) / 2, y + 1.0, (z0 + z1) / 2)
        for k in range(n):
            yy = y + 0.3 + (k % 4) * 0.45
            rot = (k % 3 - 1) * 18
            if along == "z":
                z = z0 + (k + 0.5) * (z1 - z0) / n
                b.box("laser_red", (x1 - x0, 0.015, 0.015), ((x0 + x1) / 2, yy, z), rot_z=rot)
            else:
                x = x0 + (k + 0.5) * (x1 - x0) / n
                b.box("laser_red", (0.015, 0.015, z1 - z0), (x, yy, (z0 + z1) / 2), rot_x=rot)
        b.layer = prev
        if along == "z":
            for x in (x0, x1):
                box("frame_black", x - 0.08, x + 0.08, y, y + 2.2, z0, z1)
        else:
            for z in (z0, z1):
                box("frame_black", x0, x1, y, y + 2.2, z - 0.08, z + 0.08)

    # ================================================================ AUSSEN
    b.layer = "Aussen"
    yE = LV["EG"]
    box("stone_dark", -36.0, 36.0, 0.0, 0.08, Z1, 62.0)                                     # plaza
    box("asphalt", -36.0, 36.0, 0.0, 0.06, -46.0, Z0)                                       # truck yard
    for s in (-1, 1):
        box("asphalt", min(s * 32.0, s * 36.0), max(s * 32.0, s * 36.0), 0.0, 0.06, Z0, Z1)
    for z in np.arange(41.0, 62.0, 3.0):
        box("stone_imperial", -36.0, 36.0, 0.08, 0.086, z, z + 0.15)
    for rr in (9.0, 11.5):
        ring_y("stone_imperial", 0.0, 51.0, rr, rr + 0.35, 0.08, 0.09, 40)
    for k in range(16):
        a = k * np.pi / 8
        b.beam("stone_imperial", (9.35 * np.cos(a), 0.08, 51.0 + 9.35 * np.sin(a)), (16.5 * np.cos(a), 0.08, 51.0 + 16.5 * np.sin(a)), 0.15)
    for face, L in FACES:                                                                  # rusticated plinth
        fbox(face, "stone_rustic", -L - 0.15, L + 0.15, 0.0, yE, 0.0, 0.15)
        for yy in (0.55, 1.1):
            fbox(face, "stone_dark", -L - 0.15, L + 0.15, yy, yy + 0.05, 0.15, 0.17)
    # portico floor + grand stair + cheek walls with lions
    box("stone_imperial", -26.0, 26.0, 0.0, yE, Z1, 34.0)
    for k in range(1, 11):
        box("stone_imperial", -25.5, 25.5, 0.0, yE - 0.15 * k, 34.0 + 0.5 * (k - 1), 34.0 + 0.5 * k)
    for s in (-1, 1):
        box("stone_imperial", min(s * 25.5, s * 27.7), max(s * 25.5, s * 27.7), 0.0, 1.9, 33.8, 39.2)
        box("stone_dark", min(s * 25.4, s * 27.8), max(s * 25.4, s * 27.8), 1.9, 2.05, 33.7, 39.3)
        lion(s * 26.6, 2.05, 36.3, 0.0)
    # colossal colonnade (layer "Portikus": hidden together with the roof in the gallery)
    b.layer = "Portikus"
    CZ = 31.6
    COLX = np.arange(-22.0, 22.1, 4.0)
    for x in COLX:
        box("stone_imperial", x - 1.15, x + 1.15, yE, yE + 0.5, CZ - 1.15, CZ + 1.15)
        b.cyl("stone_imperial", 1.0, 0.35, (x, yE + 0.68, CZ), 16)
        b.cyl("marble_white", 0.85, 17.0 - 2.5, (x, (2.5 + 17.0) / 2, CZ), 16)
        for k in range(8):
            a = k * np.pi / 4 + np.pi / 8
            box("stone_dark", x + 0.86 * np.cos(a) - 0.05, x + 0.86 * np.cos(a) + 0.05, 2.8, 16.7, CZ + 0.86 * np.sin(a) - 0.05, CZ + 0.86 * np.sin(a) + 0.05)
        b.hull("stone_imperial", [(x + 0.85 * np.cos(a), 17.0, CZ + 0.85 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] +
               [(x + sx * 1.25, 17.75, CZ + sz * 1.25) for sx in (-1, 1) for sz in (-1, 1)])
        box("stone_imperial", x - 1.3, x + 1.3, 17.75, 18.1, CZ - 1.3, CZ + 1.3)
        for sx in (-1, 1):
            for sz in (-1, 1):
                b.add("stone_imperial", trimesh.creation.icosphere(subdivisions=0, radius=0.26).apply_translation((x + sx * 1.05, 17.5, CZ + sz * 1.05)))
    for x in (-20.0, -12.0, 12.0, 20.0):                                                   # hanging banners
        box("flag_green", x - 1.0, x + 1.0, 9.0, 16.6, CZ - 0.03, CZ + 0.03)
        for (ya, yb_) in ((9.0, 9.25), (16.35, 16.6)):
            box("flag_gold", x - 1.0, x + 1.0, ya, yb_, CZ - 0.04, CZ + 0.04)
        b.beam("brass", (x - 1.2, 16.75, CZ), (x + 1.2, 16.75, CZ), 0.07)
        b.add("gold", octa(0.45, 1.2).apply_translation((x, 13.0, CZ + 0.06)))
        t = trimesh.creation.torus(major_radius=0.62, minor_radius=0.05, major_sections=12, minor_sections=3)
        b.add("gold", t.apply_translation((x, 13.0, CZ + 0.06)))
    # entablature, portico ceiling + roof, lettering
    box("stone_imperial", -24.5, 24.5, 17.8, 18.1, Z1, 30.2)                                # coffered ceiling
    for x in np.arange(-22.0, 22.1, 4.0):
        box("stone_dark", x - 1.5, x + 1.5, 17.75, 17.8, Z1 + 0.4, 29.9)
    box("stone_imperial", -24.5, 24.5, 18.1, 19.4, 30.2, 33.0)                              # architrave
    box("stone_imperial", -24.5, 24.5, 19.4, 20.6, 30.2, 33.0)                              # frieze
    box("stone_imperial", -25.2, 25.2, 20.6, 21.2, 29.9, 33.45)                             # cornice
    for x in np.arange(-24.9, 25.0, 0.5):
        box("stone_imperial", x - 0.1, x + 0.1, 20.35, 20.6, 33.0, 33.25)                   # dentils
    box("stone_imperial", -24.5, 24.5, 21.2, 21.5, Z1, 30.2)                                # portico roof behind the pediment
    b.text("CASA IMPÉRIO", "gold", (0.0, 20.0, 33.0), 1.05, 0.08, simplify=0.015)
    b.text("ALTA JOALHERIA · MDCCCXXII", "bronze", (0.0, 18.75, 33.0), 0.5, 0.05, simplify=0.01)
    # pediment with raking cornices, tympanum clock + laurels, acroteria statues
    PZ0, PZ1 = 30.0, 33.3
    b.hull("stone_imperial", [(x, 21.2, z) for x in (-24.8, 24.8) for z in (PZ0, PZ1)] + [(0.0, 27.6, z) for z in (PZ0, PZ1)])
    for s in (-1, 1):
        b.hull("stone_imperial", [(xx, yy, z) for (xx, yy) in ((s * 25.4, 21.1), (0.0, 27.75), (s * 25.4, 21.6), (0.0, 28.25)) for z in (PZ0 - 0.1, PZ1 + 0.4)])
    b.hull("stone_dark", [(x, y_, PZ1 + 0.02) for (x, y_) in ((-22.8, 21.6), (22.8, 21.6), (0.0, 26.7))] + [(x, y_, PZ1 + 0.04) for (x, y_) in ((-22.8, 21.6), (22.8, 21.6), (0.0, 26.7))])
    cyl_axis("marble_white", 1.6, 0.12, (0.0, 23.9, PZ1 + 0.1), "z", 24)
    t = trimesh.creation.torus(major_radius=1.68, minor_radius=0.1, major_sections=24, minor_sections=4)
    b.add("gold", t.apply_translation((0.0, 23.9, PZ1 + 0.18)))
    for k in range(12):
        a = k * np.pi / 6
        box("bronze", 1.35 * np.cos(a) - 0.06, 1.35 * np.cos(a) + 0.06, 23.9 + 1.35 * np.sin(a) - 0.06, 23.9 + 1.35 * np.sin(a) + 0.06, PZ1 + 0.16, PZ1 + 0.2)
    b.box("bronze_dark", (0.12, 1.1, 0.05), (0.25, 24.35, PZ1 + 0.22), rot_z=-25)
    b.box("bronze_dark", (0.1, 1.45, 0.05), (-0.35, 23.6, PZ1 + 0.25), rot_z=-118)
    for s in (-1, 1):
        for k in range(10):
            a = np.radians(200 - k * 14) if s < 0 else np.radians(-20 + k * 14)
            px, py = s * 1.2 + s * 2.6 * abs(np.cos(a)) * 0.9, 23.2 + 1.1 * np.sin(a) * 0.6
            lf = octa(0.18, 2.2)
            lf.apply_transform(trimesh.transformations.rotation_matrix(np.radians(60 * s), [0, 0, 1]))
            b.add("gold", lf.apply_translation((s * (2.0 + k * 0.42), 23.0 + 0.5 * np.sin(k * 0.6), PZ1 + 0.1)))
    statue(0.0, 27.9, PZ0 + 1.2, 0.0, 1.5, "statue_bronze")
    for s in (-1, 1):
        statue(s * 24.3, 21.4, PZ0 + 1.3, -s * 10, 1.15, "statue_bronze")
    b.layer = "Aussen"
    # fountain
    FX, FZ = 0.0, 51.0
    ring_y("stone_imperial", FX, FZ, 6.6, 7.4, 0.08, 0.85, 40)
    ring_y("stone_dark", FX, FZ, 7.3, 7.55, 0.85, 0.95, 40)
    b.cyl("stone_dark", 6.6, 0.1, (FX, 0.13, FZ), 40)
    b.cyl("flood_water", 6.6, 0.45, (FX, 0.42, FZ), 40)
    b.cyl("stone_imperial", 1.0, 2.4, (FX, 1.28, FZ), 12)
    b.hull("stone_imperial", [(FX + 0.9 * np.cos(a), 2.4, FZ + 0.9 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] +
           [(FX + 2.6 * np.cos(a), 3.0, FZ + 2.6 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 13)[:-1]])
    b.cyl("flood_water", 2.45, 0.06, (FX, 3.0, FZ), 12)
    b.cyl("stone_imperial", 0.35, 1.6, (FX, 3.8, FZ), 8)
    b.hull("stone_imperial", [(FX + 0.3 * np.cos(a), 4.5, FZ + 0.3 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 7)[:-1]] +
           [(FX + 1.1 * np.cos(a), 4.85, FZ + 1.1 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]])
    statue(FX, 4.85, FZ, 0.0, 0.75, "gold")
    for k in range(8):
        a = k * np.pi / 4
        c, s_ = np.cos(a), np.sin(a)
        b.beam("water_jet", (FX + 2.6 * c, 3.0, FZ + 2.6 * s_), (FX + 3.7 * c, 1.9, FZ + 3.7 * s_), 0.08)
        b.beam("water_jet", (FX + 3.7 * c, 1.9, FZ + 3.7 * s_), (FX + 4.3 * c, 0.5, FZ + 4.3 * s_), 0.07)
        a2 = a + np.pi / 8
        c2, s2 = np.cos(a2), np.sin(a2)
        b.beam("water_jet", (FX + 6.9 * c2, 0.85, FZ + 6.9 * s2), (FX + 5.2 * c2, 2.1, FZ + 5.2 * s2), 0.06)
        b.beam("water_jet", (FX + 5.2 * c2, 2.1, FZ + 5.2 * s2), (FX + 3.6 * c2, 0.5, FZ + 3.6 * s2), 0.06)
    for k in range(4):                                                                     # benches around the fountain
        a = np.pi / 4 + k * np.pi / 2
        b.box("stone_imperial", (2.6, 0.45, 0.7), (FX + 10.2 * np.cos(a), 0.3, FZ + 10.2 * np.sin(a)), rot_y=-np.degrees(a) + 90)
    for s in (-1, 1):                                                                     # flags, lamps, palms
        for x, m in ((12.0, "flag_green"), (16.0, "flag_gold"), (20.0, "flag_white")):
            box("stone_imperial", s * x - 0.5, s * x + 0.5, 0.0, 0.6, 43.0, 44.0)
            flagpole(s * x, 0.6, 43.5, 15.0, m)
        for (x, z) in ((6.0, 41.5), (26.0, 41.5), (6.0, 60.0), (26.0, 60.0)):
            lamp_post(s * x, z)
        for z in (42.5, 47.0, 51.5, 56.0):
            palm_planter(s * 33.5, z, 0.0, 7.5)
    # police barriers (crowd control) inside the fence
    for s in (-1, 1):
        for k in range(6):
            x0 = s * (6.5 + k * 2.6)
            x1 = s * (6.5 + k * 2.6 + 2.4)
            for xx in (x0, x1):
                b.beam("vault_steel", (xx, 0.0, 58.5), (xx, 1.1, 58.5), 0.04)
                b.beam("vault_steel", (xx, 0.0, 58.2), (xx, 0.0, 58.8), 0.04)
            for yy in (0.25, 1.1):
                b.beam("vault_steel", (x0, yy, 58.5), (x1, yy, 58.5), 0.035)
            for t_ in np.linspace(0.2, 0.8, 5):
                xx = x0 + (x1 - x0) * t_
                b.beam("vault_steel", (xx, 0.25, 58.5), (xx, 1.1, 58.5), 0.02)
    b.anchor("Polizei_Linie", (0.0, 0.0, 57.0), 180)

    def fence_run(a0, a1, fixed, axis, gaps=()):
        segs = [(a0, a1)]
        for g0, g1 in gaps:
            out = []
            for s0, s1 in segs:
                if g1 <= s0 or g0 >= s1:
                    out.append((s0, s1))
                else:
                    if g0 > s0:
                        out.append((s0, g0))
                    if g1 < s1:
                        out.append((g1, s1))
            segs = out
        def B_(m, p0, p1, y0, y1, w0, w1):
            if axis == "x":
                box(m, p0, p1, y0, y1, fixed + w0, fixed + w1)
            else:
                box(m, fixed + w0, fixed + w1, y0, y1, p0, p1)
        def P_(p, y, w):
            return (p, y, fixed + w) if axis == "x" else (fixed + w, y, p)
        for s0, s1 in segs:
            B_("stone_imperial", s0, s1, 0.0, 0.7, -0.3, 0.3)
            B_("iron_fence", s0, s1, 0.7, 3.2, -0.03, 0.03)
            B_("iron", s0, s1, 3.1, 3.2, -0.05, 0.05)
            for p in np.arange(s0 + 0.5, s1, 1.0):
                B_("iron", p - 0.025, p + 0.025, 0.7, 3.1, -0.025, 0.025)
            for p in np.arange(s0, s1 + 0.01, 3.0):
                B_("iron", p - 0.06, p + 0.06, 0.7, 3.5, -0.06, 0.06)
                b.hull("gold", [P_(p + dx, 3.5, dw) for dx in (-0.08, 0.08) for dw in (-0.08, 0.08)] + [P_(p, 3.85, 0.0)])
            for p in (s0, s1):
                B_("stone_imperial", p - 0.45, p + 0.45, 0.0, 3.6, -0.45, 0.45)
                B_("stone_imperial", p - 0.55, p + 0.55, 3.6, 3.85, -0.55, 0.55)
                b.add("gold", trimesh.creation.icosphere(subdivisions=0, radius=0.3).apply_translation(P_(p, 4.15, 0.0)))

    fence_run(-36.0, 36.0, 62.0, "x", [(-6.6, 6.6)])
    fence_run(-36.0, 36.0, -46.0, "x", [(-6.5, 6.5)])
    for s in (-1, 1):
        fence_run(-46.0, 62.0, s * 36.0, "z")
    for s in (-1, 1):                                                                     # main gate pillars with lanterns + crowns
        x0g, x1g = sorted((s * 5.0, s * 6.6))
        box("stone_imperial", x0g, x1g, 0.0, 5.2, 61.3, 62.7)
        box("stone_dark", x0g - 0.15, x1g + 0.15, 5.2, 5.5, 61.15, 62.85)
        b.cyl("gold", 0.35, 0.3, ((x0g + x1g) / 2, 5.65, 62.0), 8)
        for k in range(5):
            a = k * 2 * np.pi / 5
            b.hull("gold", [((x0g + x1g) / 2 + 0.3 * np.cos(a) + dx, 5.8, 62.0 + 0.3 * np.sin(a) + dz) for dx in (-0.05, 0.05) for dz in (-0.05, 0.05)] +
                   [((x0g + x1g) / 2 + 0.3 * np.cos(a), 6.2, 62.0 + 0.3 * np.sin(a))])
        box("lamp", (x0g + x1g) / 2 - 0.2, (x0g + x1g) / 2 + 0.2, 3.6, 4.3, 62.7, 62.95)
        bx = s * 9.8                                                                       # guard booth
        box("stone_imperial", bx - 1.4, bx + 1.4, 0.0, 3.0, 58.6, 61.4)
        box("glass", bx - 1.2, bx + 1.2, 1.1, 2.4, 61.4, 61.45)
        box("glass", bx - 1.2, bx + 1.2, 1.1, 2.4, 58.55, 58.6)
        box("stone_dark", bx - 1.7, bx + 1.7, 3.0, 3.3, 58.3, 61.7)
        b.anchor(f"Wachhaus_Tor_{'W' if s < 0 else 'O'}", (bx, 0.0, 57.8), 180)
    for name, x0g, x1g, hinge in (("Tor_Haupt_L", -5.0, 0.0, -5.0), ("Tor_Haupt_R", 0.0, 5.0, 5.0)):
        b.layer = name
        b.pivots[name] = (hinge, 0.0, 62.0)
        box("iron", x0g, x1g, 0.15, 0.3, 61.95, 62.05)
        box("iron", x0g, x1g, 3.3, 3.45, 61.95, 62.05)
        box("iron", x0g, x1g, 1.6, 1.7, 61.95, 62.05)
        for x in np.arange(x0g + 0.12, x1g, 0.2):
            box("iron", x - 0.025, x + 0.025, 0.15, 3.45, 61.97, 62.03)
            b.hull("gold", [(x + dx, 3.45, 62.0 + dz) for dx in (-0.04, 0.04) for dz in (-0.04, 0.04)] + [(x, 3.7, 62.0)])
        cx_ = (x0g + x1g) / 2
        t = trimesh.creation.torus(major_radius=0.6, minor_radius=0.05, major_sections=12, minor_sections=3)
        b.add("gold", t.apply_translation((cx_, 2.45, 62.05)))
    b.layer = "Aussen"
    b.anchor("Haupttor", (0.0, 0.0, 63.0), 180)
    # back yard: truck ramp up to the EG, back gate (sliding), booth, transformer, bollards
    b.hull("concrete", [(x, y_, z) for x in (-6.0, 6.0) for (y_, z) in ((0.06, -44.0), (0.0, Z0), (yE, Z0), (0.07, -44.0))])
    for s in (-1, 1):
        b.hull("concrete_light", [(s * 6.0 + e, y_, z) for e in (0.0, s * 0.3) for (y_, z) in ((0.0, -44.0), (0.0, Z0), (yE + 1.0, Z0), (1.0, -44.0))])
        for z in np.arange(-43.0, Z0, 3.0):
            b.cyl("safety_yellow", 0.15, 1.0, (s * 7.0, 0.5, z), 8)
        box("hazard", s * 4.4 - 0.25, s * 4.4 + 0.25, yE, yE + 0.9, Z0 - 0.3, Z0)
    b.layer = "Tor_Logistik"                                                               # roll door, lift it in +Y
    b.pivots["Tor_Logistik"] = (0.0, yE + 5.0, Z0 + 0.3)
    box("vault_steel", -4.0, 4.0, yE, yE + 5.0, Z0 + 0.25, Z0 + 0.35)
    for yy in np.arange(yE + 0.2, yE + 5.0, 0.4):
        box("pipe", -4.0, 4.0, yy, yy + 0.06, Z0 + 0.2, Z0 + 0.25)
    box("safety_yellow", -4.0, 4.0, yE, yE + 0.15, Z0 + 0.18, Z0 + 0.25)
    b.layer = "Tor_Hintertuer"
    b.pivots["Tor_Hintertuer"] = (12.0, yE, Z0 + 0.3)
    box("door_metal", 12.0, 13.2, yE, yE + 2.3, Z0 + 0.25, Z0 + 0.35)
    box("chrome", 12.95, 13.1, yE + 1.0, yE + 1.08, Z0 + 0.15, Z0 + 0.25)
    b.layer = "Tor_Hof"
    b.pivots["Tor_Hof"] = (-6.5, 0.0, -46.0)
    box("vault_steel", -6.5, 6.5, 0.1, 0.25, -46.05, -45.95)
    box("vault_steel", -6.5, 6.5, 2.9, 3.05, -46.05, -45.95)
    box("fence_net", -6.5, 6.5, 0.25, 2.9, -46.02, -45.98)
    for x in np.arange(-6.5, 6.6, 1.6):
        box("vault_steel", x - 0.04, x + 0.04, 0.1, 3.05, -46.05, -45.95)
    b.layer = "Aussen"
    box("stone_imperial", 8.5, 11.0, 0.0, 2.9, -44.5, -42.0)
    box("glass", 8.4, 8.45, 1.1, 2.3, -44.2, -42.3)
    box("stone_dark", 8.3, 11.2, 2.9, 3.15, -44.7, -41.8)
    b.anchor("Wachhaus_Hof", (7.6, 0.0, -43.2), -90)
    box("meter", 22.0, 25.0, 0.0, 2.4, -36.0, -34.0)
    b.anchor("Strom_Trafo", (23.5, 0.0, -36.8), 180)
    for k in range(3):
        box("vault_steel" if k % 2 else "flag_green", -26.0 + k * 2.2, -24.2 + k * 2.2, 0.0, 1.4, -40.0, -38.6)
    b.anchor("Geldtransporter_Hof", (0.0, 0.0, -38.0), 0)
    b.anchor("Eingang", (0.0, yE, 36.0), 180)

    # ================================================================ STRUCTURE (per floor)
    HOLES = {"UG2": [VLIFT, MST], "UG1": [CORE_L, CORE_R, ELV_L, ELV_R], "EG": [CORE_L, CORE_R, ELV_L, ELV_R, VEH],
             "OG1": [CORE_L, CORE_R, ELV_L, ELV_R, AT], "OG2": [CORE_L, CORE_R, ELV_L, ELV_R, AT], "OG3": [CORE_L, CORE_R, ELV_L, ELV_R, AT]}
    FIN = {"UG2": "concrete_light", "UG1": "concrete_light", "EG": "marble_white", "OG1": "marble_white", "OG2": "walnut", "OG3": "carpet_red"}
    FRONT_EG = [(a, c, yE, 8.25) for a, c in PORTALS] + [(-15.5, -12.5, 2.9, 7.6), (12.5, 15.5, 2.9, 7.6),
                                                         (-29.5, -26.0, 2.9, 7.6), (-23.5, -20.0, 2.9, 7.6), (20.0, 23.5, 2.9, 7.6), (26.0, 29.5, 2.9, 7.6)]
    BACK_EG = [(-4.0, 4.0, yE, yE + 5.0), (12.0, 13.2, yE, yE + 2.3)]
    WIN = {"EG": (2.9, 4.5, 2.2, "grille"), "OG1": (10.6, 3.5, 2.0, "pediment"), "OG2": (16.5, 3.0, 1.9, "cornice"), "OG3": (22.0, 2.6, 1.8, "plain")}
    COL_AT = sorted(set([(s * 14.0, z) for s in (-1, 1) for z in (-10.0, -6.0, -2.0, 2.0, 6.0, 10.0, 14.0)] +
                        [(x, z) for x in (-10.0, -6.0, -2.0, 2.0, 6.0, 10.0) for z in (-10.0, 14.0)]))
    for lv in ORDER:
        b.layer = lv
        y0, yb, yt = LV[lv], bot_of(lv), top_of(lv)
        under = lv.startswith("UG")
        wm = "concrete" if under else "stone_imperial"
        if lv in HOLES:
            floor_slab(lv, FIN[lv], HOLES[lv])
        if lv == "EG":
            wall_x(wm, Z1 - T / 2, X0, X1, yb, yt, FRONT_EG)
            wall_x(wm, Z0 + T / 2, X0, X1, yb, yt, BACK_EG)
        else:
            box(wm, X0, X1, yb, yt, Z1 - T, Z1)
            box(wm, X0, X1, yb, yt, Z0, Z0 + T)
        for x in (X0 + T / 2, X1 - T / 2):
            if lv == "UG3" and x > 0:                                                     # opening for the old Maya stones (sewer blast point)
                wall_z(wm, x, Z0 + T, Z1 - T, yb, yt, [(KW[0], KW[1], y0, y0 + 3.0)])
            else:
                box(wm, x - T / 2, x + T / 2, yb, yt, Z0 + T, Z1 - T)
        if not under:
            for face, L in FACES:                                                         # cornice band
                fbox(face, "stone_imperial", -L - 0.3, L + 0.3, yt - 0.45, yt - 0.05, 0.0, 0.35)
            for sx in (-1, 1):                                                            # quoins
                for sz in (-1, 1):
                    for k, yy in enumerate(np.arange(yb, yt - 0.5, 0.75)):
                        cx_, cz_ = sx * 32.0, sz * 28.0
                        if k % 2 == 0:
                            box("stone_imperial", min(cx_ - sx * 1.5, cx_ + sx * 0.12), max(cx_ - sx * 1.5, cx_ + sx * 0.12), yy, yy + 0.7,
                                min(cz_ - sz * 0.6, cz_ + sz * 0.12), max(cz_ - sz * 0.6, cz_ + sz * 0.12))
                        else:
                            box("stone_imperial", min(cx_ - sx * 0.6, cx_ + sx * 0.12), max(cx_ - sx * 0.6, cx_ + sx * 0.12), yy, yy + 0.7,
                                min(cz_ - sz * 1.5, cz_ + sz * 0.12), max(cz_ - sz * 1.5, cz_ + sz * 0.12))
            wy, wh, ww, style = WIN[lv]
            if lv == "EG":                                                                 # rustication grooves (around the openings)
                for yy in np.arange(yb + 0.6, yt - 0.6, 0.7):
                    for face, L in FACES:
                        cuts = [(a, c) for (a, c, ya, yb_) in (FRONT_EG if face == "front" else BACK_EG if face == "back" else []) if ya <= yy <= yb_]
                        segs = [(-L, L)]
                        for g0, g1 in cuts:
                            segs = [s for (p, q) in segs for s in ((p, min(q, g0 - 0.3)), (max(p, g1 + 0.3), q)) if s[1] - s[0] > 0.1]
                        for p, q in segs:
                            fbox(face, "stone_dark", p, q, yy, yy + 0.06, 0.0, 0.04)
                for (a, c, ya, yb_) in FRONT_EG:                                           # bronze frames + keystones
                    fbox("front", "bronze", a - 0.18, a, ya, yb_, -0.05, 0.12)
                    fbox("front", "bronze", c, c + 0.18, ya, yb_, -0.05, 0.12)
                    fbox("front", "bronze", a - 0.18, c + 0.18, yb_, yb_ + 0.18, -0.05, 0.12)
                    fbox("front", "stone_imperial", (a + c) / 2 - 0.4, (a + c) / 2 + 0.4, yb_ + 0.18, yb_ + 0.75, 0.0, 0.25)
                    if yb_ < 8.0:
                        fbox("front", "glass_shop", a, c, ya, yb_, -0.25, -0.2)
                        fbox("front", "stone_imperial", a - 0.3, c + 0.3, ya - 0.25, ya, 0.0, 0.3)
                for u in (-28.0, -24.0, -20.0, -16.0, -8.0, 8.0, 16.0, 20.0, 24.0, 28.0, -12.0):
                    win("back", u, wy, wh, ww, style)
            else:
                us = np.arange(-28.0, 28.1, 4.0)
                for u in us:
                    win("back", u, wy, wh, ww, style)
                    if lv in ("OG1", "OG3") or abs(u) > 25.5:
                        win("front", u, wy, wh, ww, style)
            for face in ("left", "right"):
                for u in np.arange(-24.0, 24.1, 4.0):
                    win(face, u, wy, wh, ww, style)
                if lv != "EG":
                    for u in np.arange(-26.0, 26.1, 4.0):
                        fbox(face, "stone_imperial", u - 0.45, u + 0.45, yb, yt - 0.45, 0.0, 0.25)
            for u in np.arange(-26.0, 26.1, 4.0):
                if lv != "EG":
                    fbox("back", "stone_imperial", u - 0.45, u + 0.45, yb, yt - 0.45, 0.0, 0.25)
                if lv != "EG" or not any(a - 0.8 < u < c + 0.8 for (a, c, _, _) in FRONT_EG):
                    fbox("front", "stone_imperial", u - 0.6, u + 0.6, yb if lv != "EG" else yE, min(yt - 0.45, 17.8), 0.0, 0.25)
        # cores, elevators, vent shaft
        if lv != "UG3":
            core_walls(CORE_L, lv, CORE_L[1], "W")
            core_walls(CORE_R, lv, CORE_R[0], "O")
            if lv != "OG3":
                nxt = ORDER[ORDER.index(lv) + 1]
                stairwell(CORE_L, y0, LV[nxt])
                stairwell(CORE_R, y0, LV[nxt])
            else:
                stairwell(CORE_R, y0, TOP + 0.5)
                box("concrete_light", CORE_L[0] + 0.2, CORE_L[1] - 0.2, y0 - 0.3, y0, CORE_L[3] - 1.8, CORE_L[3])
            for tag, e in (("L", ELV_L), ("R", ELV_R)):
                ex0, ex1, ez0, ez1 = e
                ytop = (LV[ORDER[ORDER.index(lv) + 1]] if lv != "OG3" else TOP)
                for xa in (ex0, ex1):
                    for za in (ez0, ez1):
                        box("bronze", xa - 0.1, xa + 0.1, y0, ytop, za - 0.1, za + 0.1)
                box("glass_shop", ex0 - 0.02, ex0 + 0.02, y0, ytop, ez0, ez1)
                box("glass_shop", ex1 - 0.02, ex1 + 0.02, y0, ytop, ez0, ez1)
                box("glass_shop", ex0, ex1, y0, ytop, ez0 - 0.02, ez0 + 0.02)
                box("glass_shop", ex0, ex1, y0 + 2.6, ytop, ez1 - 0.02, ez1 + 0.02)
                box("bronze", ex0, ex1, y0 + 2.5, y0 + 2.6, ez1 - 0.06, ez1 + 0.06)
                b.anchor(f"Aufzug_{tag}_{lv}", ((ex0 + ex1) / 2, y0, ez1 + 0.8), 0)
        if lv in ("UG1", "EG", "OG1", "OG2", "OG3"):
            box("marble_white" if lv == "EG" else "concrete_light", VENT[0], VENT[1], y0, yt, VENT[2], VENT[3])
        if lv in ("EG", "OG1", "OG2", "OG3"):                                              # atrium colonnade + gallery balustrades
            cmat = "marble_white" if lv == "EG" else "stone_imperial"
            cols = COL_AT + ([(x, 18.0) for x in np.arange(-14.0, 14.1, 4.0)] if lv == "EG" else [])
            for (x, z) in cols:
                column(x, z, y0, yt, 0.55, cmat, "brass")
            if lv != "EG":
                xs_e = [-14.0, -10.0, -6.0, -2.0, 2.0, 6.0, 10.0, 14.0]
                zs_e = [-10.0, -6.0, -2.0, 2.0, 6.0, 10.0, 14.0]
                for a, c in zip(xs_e[:-1], xs_e[1:]):
                    if not (lv == "OG1" and (a == -14.0 or c == 14.0)):
                        balustrade(a + 0.7, -10.0, c - 0.7, -10.0, y0)
                    balustrade(a + 0.7, 14.0, c - 0.7, 14.0, y0)
                for a, c in zip(zs_e[:-1], zs_e[1:]):
                    for s in (-1, 1):
                        balustrade(s * 14.0, a + 0.7, s * 14.0, c - 0.7, y0)
                box("stone_imperial", AT[0] - 0.3, AT[1] + 0.3, y0 - SLAB - 0.4, y0 - SLAB, AT[2] - 0.3, AT[2] + 0.3)      # gallery edge beams
                box("stone_imperial", AT[0] - 0.3, AT[1] + 0.3, y0 - SLAB - 0.4, y0 - SLAB, AT[3] - 0.3, AT[3] + 0.3)
                for s in (-1, 1):
                    box("stone_imperial", s * 14.0 - 0.3, s * 14.0 + 0.3, y0 - SLAB - 0.4, y0 - SLAB, AT[2], AT[3])

    # ================================================================ EG – Grand Salon
    y, yt = LV["EG"], top_of("EG")
    b.layer = "EG"
    wall_x("stone_imperial", -14.0, -18.0, 18.0, y, yt, [(-1.4, 1.4, y, y + 3.0), (-16.6, -15.4, y, y + 2.4), (15.4, 16.6, y, y + 2.4)], t=0.4)
    for s in (-1, 1):
        x = s * 18.0
        holes = [(-16.6, -15.4, y, y + 2.4), (-9.0, -5.0, y, y + 5.5), (6.0, 10.0, y, y + 5.5), (19.5, 22.5, y, y + 4.0)]
        if s < 0:
            holes.append((-21.85, -20.65, y, y + 2.4))                                    # sketch: door Tesouraria -> technical room
        wall_z("stone_imperial", x, IZ0, IZ1, y, yt, holes, t=0.5)
        for (za, zb) in ((-9.0, -5.0), (6.0, 10.0)):
            box("bronze", x - 0.3, x + 0.3, y + 5.5, y + 5.75, za - 0.15, zb + 0.15)
            box("stone_imperial", x - 0.3, x + 0.3, y + 5.75, y + 6.6, (za + zb) / 2 - 0.4, (za + zb) / 2 + 0.4)
        a, c = sorted((x, s * IX1))
        wall_x("stone_imperial", -14.0, a, c, y, yt, [(min(s * 20.0, s * 21.2), max(s * 20.0, s * 21.2), y, y + 2.4)], t=0.4)
        wall_x("stone_imperial", 18.0, a, c, y, yt, [(min(s * 23.5, s * 26.5), max(s * 23.5, s * 26.5), y, y + 4.0)], t=0.4)
    for s in (-1, 1):                                                                     # imperial double staircase EG → OG1
        xa, xb = sorted((s * 10.7, s * 13.3))
        flight(xa, xb, 10.0, -9.9, y, LV["OG1"], "marble_white", "marble_black")
        for xx in (xa, xb):
            b.beam("bronze", (xx, y + 1.0, 10.0), (xx, LV["OG1"] + 1.0, -9.9), 0.05)
        for xx in (xa, xb):
            b.cyl("bronze", 0.12, 1.3, (xx, y + 0.65, 10.1), 8)
            b.cyl("lamp", 0.16, 0.3, (xx, y + 1.45, 10.1), 8)
    b.layer = "EG_Innen"
    # hall inlay, carpet, pedestal with the Estrela do Rio
    ring_y("marble_black", DCX, DCZ, 5.2, 5.5, y, y + 0.006, 40)
    ring_y("marble_green", DCX, DCZ, 7.0, 7.2, y, y + 0.006, 40)
    for k in range(16):
        a = k * np.pi / 8
        r1 = 10.0 if k % 2 == 0 else 7.9
        m = "marble_green" if k % 2 == 0 else "marble_black"
        b.hull(m, [(DCX + 5.5 * np.cos(a + e), yy, DCZ + 5.5 * np.sin(a + e)) for e in (-0.1, 0.1) for yy in (y, y + 0.007)] +
               [(DCX + r1 * np.cos(a), yy, DCZ + r1 * np.sin(a)) for yy in (y, y + 0.007)])
    box("carpet_red", -1.6, 1.6, y, y + 0.01, 14.6, 27.3)
    for (x0_, x1_, z0_, z1_) in ((-12.6, 12.6, -8.6, -8.2), (-12.6, 12.6, 12.2, 12.6), (-12.6, -12.2, -8.6, 12.6), (12.2, 12.6, -8.6, 12.6),
                                 (-17.2, 17.2, -13.4, -13.1), (-17.2, 17.2, 16.9, 17.2), (-17.2, -16.9, -13.4, 17.2), (16.9, 17.2, -13.4, 17.2)):
        box("marble_black", x0_, x1_, y, y + 0.005, z0_, z1_)
    for (x, z) in COL_AT:                                                                  # green marble squares under the columns
        box("marble_green", x - 0.95, x + 0.95, y, y + 0.004, z - 0.95, z + 0.95)
    box("carpet_red", -1.6, 1.6, y, y + 0.01, 7.6, 11.0)
    for k, r in enumerate((3.4, 2.8, 2.2)):
        b.cyl("marble_black" if k % 2 == 0 else "marble_white", r, 0.25, (DCX, y + 0.125 + k * 0.25, DCZ), 24)
    yp = y + 0.75
    b.cyl("brass", 0.95, 0.15, (DCX, yp + 0.075, DCZ), 12)
    b.cyl("marble_green", 0.75, 1.25, (DCX, yp + 0.775, DCZ), 12)
    b.cyl("brass", 0.92, 0.12, (DCX, yp + 1.46, DCZ), 12)
    b.cyl("velvet_purple", 0.72, 0.08, (DCX, yp + 1.56, DCZ), 12)
    for k in range(20):
        a = k * np.pi / 10
        box("lacquer", DCX + 4.0 * np.cos(a) - 0.3, DCX + 4.0 * np.cos(a) + 0.3, y, y + 0.012, DCZ + 4.0 * np.sin(a) - 0.3, DCZ + 4.0 * np.sin(a) + 0.3)
    for k in range(12):
        a0, a1 = k * np.pi / 6, (k + 1) * np.pi / 6
        p0 = (DCX + 5.0 * np.cos(a0), DCZ + 5.0 * np.sin(a0))
        p1 = (DCX + 5.0 * np.cos(a1), DCZ + 5.0 * np.sin(a1))
        b.cyl("brass", 0.04, 1.0, (p0[0], y + 0.5, p0[1]), 6)
        b.beam("velvet_red", (p0[0], y + 0.88, p0[1]), (p1[0], y + 0.88, p1[1]), 0.035)
    for k in range(4):
        a = np.pi / 4 + k * np.pi / 2
        px, pz = DCX + 6.2 * np.cos(a), DCZ + 6.2 * np.sin(a)
        b.cyl("frame_black", 0.06, 1.8, (px, y + 0.9, pz), 6)
        b.box("lamp", (0.35, 0.25, 0.35), (px, y + 1.9, pz), rot_y=-np.degrees(a) + 90, rot_x=30)
    box("marble_black", DCX - 0.9, DCX + 0.9, y + 0.75, y + 1.35, DCZ + 3.0, DCZ + 3.15)
    b.text("ESTRELA DO RIO", "gold", (DCX, y + 1.05, DCZ + 3.15), 0.12, 0.01, simplify=0.01)
    b.anchor("Druckplatten", (DCX, y, DCZ), 0)
    b.layer = "EG_Beute_Edelstein_Estrela"
    b.pivots["EG_Beute_Edelstein_Estrela"] = (DCX, yp + 1.95, DCZ)
    dm = trimesh.convex.convex_hull(np.array([(0.26 * np.cos(a), 0.0, 0.26 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 13)[:-1]] +
                                             [(0.17 * np.cos(a + 0.26), 0.1, 0.17 * np.sin(a + 0.26)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] + [(0, -0.34, 0)]))
    b.add("diamond", dm.apply_translation((DCX, yp + 2.25, DCZ)))
    for k in range(3):
        b.beam("brass", (DCX + 0.15 * np.cos(k * 2.1), yp + 1.6, DCZ + 0.15 * np.sin(k * 2.1)), (DCX + 0.2 * np.cos(k * 2.1), yp + 2.0, DCZ + 0.2 * np.sin(k * 2.1)), 0.02)

    b.layer = "EG_Diamant_Glas"
    b.pivots["EG_Diamant_Glas"] = (DCX, yp + 2.3, DCZ)
    b.cyl("glass_shop", 0.68, 1.5, (DCX, yp + 1.6 + 0.75, DCZ), 16)
    b.cyl("brass", 0.7, 0.08, (DCX, yp + 3.14, DCZ), 16)
    b.layer = "EG_Innen"
    b.anchor("Estrela_do_Rio", (DCX, yp + 1.6, DCZ), 0)
    # reception, benches, indoor palms
    RX = 7.0
    b.hull("marble_black", [(x, yy, z) for x in (RX - 3.0, RX + 3.0) for yy in (y, y + 1.1) for z in (11.4, 12.2)] + [(RX, yy, 12.7) for yy in (y, y + 1.1)])
    box("gold", RX - 3.1, RX + 3.1, y + 1.1, y + 1.16, 11.3, 12.3)
    b.text("CASA IMPÉRIO", "gold", (RX, y + 0.65, 12.72), 0.26, 0.02, simplify=0.012)
    for x in (RX - 1.5, RX + 1.5):
        chair(x, 10.7, y, 0.0, "velvet_purple")
        box("frame_black", x - 0.27, x + 0.27, y + 1.16, y + 1.5, 11.5, 11.55)
    b.anchor("Rezeption", (RX, y, 13.4), 180)
    for (x, z) in ((-7.5, -4.0), (7.5, -4.0), (-7.5, 7.0), (7.5, 7.0)):
        box("marble_white", x - 1.3, x + 1.3, y + 0.35, y + 0.5, z - 0.35, z + 0.35)
        for dx in (-1.0, 1.0):
            box("marble_white", x + dx - 0.15, x + dx + 0.15, y, y + 0.35, z - 0.3, z + 0.3)
    for (x, z) in ((-16.0, 12.5), (16.0, 12.5), (-16.0, 0.5), (16.0, 0.5)):
        palm_planter(x, z, y, 4.8)
    # vestibule: 5 airlock lanes, metal detectors, x-ray, guards, queue
    for k, lx in enumerate((-8.0, -4.0, 0.0, 4.0, 8.0)):
        for x in (lx - 1.45, lx + 1.45):
            box("glass_shop", x - 0.03, x + 0.03, y, y + 3.0, 20.4, 23.6)
        for side, z in (("A", 23.6), ("B", 20.4)):                                        # airlock doors: own nodes (slide in X)
            name = f"EG_Schleuse_{k + 1}{side}"
            b.layer = name
            b.pivots[name] = (lx, y, z)
            box("glass_shop", lx - 1.35, lx + 1.35, y, y + 2.9, z - 0.03, z + 0.03)
            box("brass", lx - 1.35, lx + 1.35, y + 2.85, y + 2.9, z - 0.05, z + 0.05)
            b.layer = "EG_Innen"
        for x in (lx - 0.6, lx + 0.5):
            box("vault_steel", x, x + 0.1, y, y + 2.4, 21.9, 22.1)
        box("vault_steel", lx - 0.6, lx + 0.6, y + 2.3, y + 2.5, 21.9, 22.1)
        box("led_green", lx - 0.15, lx + 0.15, y + 2.35, y + 2.45, 22.1, 22.11)
        b.anchor(f"Schleuse_{k + 1}", (lx, y, 24.6), 180)
    box("glass_shop", -9.6, 9.6, y + 3.05, y + 3.1, 20.3, 23.7)
    for z in (20.3, 23.7):
        box("bronze", -9.6, 9.6, y + 3.0, y + 3.2, z - 0.08, z + 0.08)
    for x in np.arange(-9.6, 9.7, 4.8):
        box("bronze", x - 0.06, x + 0.06, y + 3.0, y + 3.2, 20.3, 23.7)
    for s in (-1, 1):
        x = s * 10.9
        box("frame_black", x - 0.55, x + 0.55, y, y + 1.4, 21.0, 24.0)
        box("lacquer", x - 0.5, x + 0.5, y + 0.85, y + 0.9, 19.8, 25.2)
        box("screen", x - 0.3, x + 0.3, y + 1.5, y + 1.9, 24.2, 24.25)
        desk(s * 15.0, 21.5, y, 2.4, 1.0, "lacquer", 2)
        chair(s * 15.0, 20.5, y, 180.0, "lacquer")
        b.anchor(f"Wachmann_Eingang_{'W' if s < 0 else 'O'}", (s * 15.0, y, 20.4), 180)
    for x in (-10.0, -6.0, -2.0, 2.0, 6.0, 10.0):                                          # queue lanes in front of the airlocks
        for z in (24.0, 25.25, 26.5):
            b.cyl("brass", 0.035, 0.95, (x, y + 0.48, z), 6)
            b.cyl("brass", 0.12, 0.04, (x, y + 0.02, z), 8)
        b.beam("velvet_red", (x, y + 0.85, 24.0), (x, y + 0.85, 26.5), 0.03)
    for s in (-1, 1):                                                                     # glass partitions: nobody bypasses security
        for (u0, u1) in ((9.55, 10.35), (11.45, 17.75)):
            a, c = sorted((s * u0, s * u1))
            box("glass_shop", a, c, y, y + 2.6, 23.57, 23.63)
            box("brass", a, c, y + 2.6, y + 2.66, 23.55, 23.65)
    for k, (xa, xb) in enumerate(PORTALS):                                                # bronze portal leaves (own nodes)
        xm = (xa + xb) / 2
        for side, p0, p1, hinge in (("L", xa, xm, xa), ("R", xm, xb, xb)):
            name = f"EG_Portal_{k + 1}{side}"
            b.layer = name
            b.pivots[name] = (hinge, y, 27.7)
            box("bronze", p0 + 0.02, p1 - 0.02, y, 8.2, 27.6, 27.8)
            for (ya, yb_) in ((y + 0.6, y + 3.0), (y + 3.6, 7.7)):
                box("bronze_dark", p0 + 0.3, p1 - 0.3, ya, yb_, 27.8, 27.86)
            hx = p1 - 0.25 if side == "L" else p0 + 0.25
            box("gold", hx - 0.04, hx + 0.04, y + 1.0, y + 1.6, 27.86, 27.92)
    b.layer = "EG_Innen"
    # left salon: diamonds
    wall_case(IX0, -12.0, 15.0, y, 1)
    n = 1
    for x in (-24.0, -20.6):
        for z in (-10.0, -4.0, 5.0, 11.0):
            vitrine(f"EG_Vitrine_{n}", x, z, y, 1.8, 0.8, "mix")
            n += 1
    for z in (-6.0, 8.0):
        chandelier(-25.0, z, yt, 1.6, 1.0)
    sofa(-29.6, 8.0, y, 2.2, 90, "velvet_purple")
    sofa(-29.6, -5.0, y, 2.2, 90, "velvet_purple")
    b.text("DIAMANTES", "gold", (-17.7, y + 6.4, 8.0), 0.45, 0.03, rot_y=90, simplify=0.008)
    # right salon: high jewellery + champagne bar + piano
    wall_case(IX1, -12.0, 0.0, y, -1)
    for x in (21.5, 24.8):
        for z in (-10.0, -4.0):
            vitrine(f"EG_Vitrine_{n}", x, z, y, 1.8, 0.8, "mix")
            n += 1
    for z in (4.0, 10.0):
        vitrine(f"EG_Vitrine_{n}", 21.5, z, y, 1.8, 0.8, "mix")
        n += 1
    box("walnut", 28.0, 28.8, y, y + 1.1, 4.0, 13.0)
    box("marble_black", 27.9, 28.9, y + 1.1, y + 1.16, 3.9, 13.1)
    for yy in (y + 1.3, y + 1.9, y + 2.5):
        box("glass", 30.8, IX1, yy - 0.03, yy, 4.0, 13.0)
        box("lamp", IX1 - 0.04, IX1 - 0.01, yy + 0.05, yy + 0.5, 4.0, 13.0)
        for z in np.arange(4.3, 12.8, 0.35):
            b.cyl("gold" if rng.random() < 0.3 else "flag_green", 0.05, 0.32, (31.05, yy + 0.16, z), 6)
    for z in np.arange(5.0, 12.5, 1.5):
        b.cyl("brass", 0.04, 0.75, (27.4, y + 0.375, z), 6)
        b.cyl("velvet_red", 0.22, 0.1, (27.4, y + 0.8, z), 8)
    b.text("BAR IMPERIAL", "gold", (31.3, y + 3.3, 8.5), 0.35, 0.02, rot_y=-90, simplify=0.008)
    b.hull("lacquer", [(24.0 + dx, yy, 6.0 + dz) for (dx, dz) in ((0, 0), (2.4, 0), (2.4, 1.0), (1.6, 2.6), (0.6, 2.6), (0, 1.5)) for yy in (y + 0.65, y + 0.95)])
    b.hull("lacquer", [(24.0 + dx, y + 0.95, 6.0 + dz) for (dx, dz) in ((0, 0), (2.4, 0))] + [(24.0 + dx, y + 1.9, 6.0 + dz) for (dx, dz) in ((0, 0.3), (2.4, 0.3))] +
           [(24.0 + dx, y + 0.97, 6.0 + dz) for (dx, dz) in ((0, 0.3), (2.4, 0.3))])
    for (dx, dz) in ((0.3, 0.3), (2.1, 0.3), (1.1, 2.3)):
        box("lacquer", 24.0 + dx - 0.08, 24.0 + dx + 0.08, y, y + 0.65, 6.0 + dz - 0.08, 6.0 + dz + 0.08)
    box("cloth_white", 24.2, 26.2, y + 0.95, y + 0.98, 6.05, 6.3)
    box("lacquer", 24.6, 25.8, y, y + 0.5, 5.0, 5.4)
    for (x, z) in ((23.0, 14.5), (27.0, 14.5)):
        sofa(x, z, y, 2.4, 180, "velvet_purple")
    b.cyl("marble_black", 0.5, 0.05, (25.0, y + 0.5, 15.8), 12)
    b.text("ALTA JOALHERIA", "gold", (17.7, y + 6.4, 8.0), 0.4, 0.03, rot_y=-90, simplify=0.008)
    chandelier(25.0, -6.0, yt, 1.6, 1.0)
    chandelier(25.0, 9.0, yt, 1.6, 1.0)
    # front boutiques: watches (left), bridal (right)
    for s in (-1, 1):
        for (u0, u1) in ((26.0, 29.5), (20.0, 23.5)):
            a, c = sorted((s * u0, s * u1))
            box("velvet_red", a, c, y, 2.85, 26.7, IZ1)
            for k, x in enumerate(np.linspace(a + 0.5, c - 0.5, 4)):
                if s < 0:
                    b.cyl("velvet_blue", 0.1, 0.3, (x, 3.0, 27.0), 8)
                    watch(x, 3.15, 27.0, 90)
                else:
                    necklace_bust(x, 2.85, 27.0, 0.0)
        for x in (s * 27.5, s * 21.5):
            vitrine(f"EG_Vitrine_{n}", x, 22.0, y, 1.8, 0.8, "watch" if s < 0 else "mix")
            n += 1
        chandelier(s * 24.7, 22.5, yt, 1.4, 0.8)
        b.text("RELÓGIOS" if s < 0 else "NOIVAS", ["gold"] * (8 if s < 0 else 6), (s * 25.0, y + 5.0, 17.75), 0.4, 0.03, rot_y=180, simplify=0.008)
    # back zone: truck elevator, cash office (Tesouraria), gold reception, lockers, security post
    b.layer = "EG_Fahrzeugaufzug"
    b.pivots["EG_Fahrzeugaufzug"] = ((VEH[0] + VEH[1]) / 2, y, (VEH[2] + VEH[3]) / 2)
    box("vault_steel", VEH[0] + 0.1, VEH[1] - 0.1, y - 0.3, y, VEH[2] + 0.1, VEH[3] - 0.1)
    for k in range(8):
        box("safety_yellow" if k % 2 == 0 else "hazard", VEH[0] + 0.1 + k, VEH[0] + 1.1 + k, y, y + 0.01, VEH[3] - 0.5, VEH[3] - 0.1)
    for x in (-2.0, 2.0):
        box("frame_black", x - 0.4, x + 0.4, y, y + 0.02, VEH[2] + 0.5, VEH[3] - 0.6)
    b.layer = "EG_Innen"
    for s in (-1, 1):
        for z in np.arange(VEH[2] + 0.5, VEH[3], 2.0):
            b.cyl("safety_yellow", 0.06, 1.1, (s * 4.3, y + 0.55, z), 6)
        b.beam("hazard", (s * 4.3, y + 1.0, VEH[2] + 0.5), (s * 4.3, y + 1.0, VEH[3] - 0.5), 0.03)
    b.anchor("Fahrzeugaufzug_EG", (0.0, y, -21.3), 0)
    b.anchor("Geldtransporter_EG", (0.0, y, -21.3), 0)
    box("lacquer", -17.0, -5.5, y, y + 1.1, -16.9, -16.2)
    box("glass_shop", -17.0, -5.5, y + 1.1, y + 3.0, -16.6, -16.5)
    for x in np.arange(-16.0, -6.0, 2.2):
        box("brass", x - 0.25, x + 0.25, y + 1.1, y + 1.15, -16.9, -16.2)
        box("frame_black", x - 0.1, x + 0.1, y + 1.6, y + 1.75, -16.62, -16.48)
    b.text("TESOURARIA", "gold", (-11.25, y + 3.4, -16.5), 0.35, 0.02, simplify=0.008)
    for z in (-19.5, -23.0):
        box("cloth_white", -16.5, -7.0, y, y + 0.9, z - 0.5, z + 0.5)
        for x in np.arange(-15.5, -7.5, 2.0):
            box("frame_black", x - 0.3, x + 0.3, y + 0.9, y + 1.25, z - 0.25, z + 0.25)
            box("cash_green", x + 0.4, x + 0.75, y + 0.9, y + 1.05, z - 0.2, z + 0.2)
    for k in range(4):
        x = -16.0 + k * 1.6
        box("fence_net", x - 0.5, x + 0.5, y, y + 1.5, -26.6, -25.6)
        for j in range(3):
            box("cash_green", x - 0.4, x + 0.4, y + 0.1 + j * 0.4, y + 0.4 + j * 0.4, -26.5, -25.7)
    b.anchor("Tesouraria", (-11.25, y, -15.6), 0)
    box("lacquer", 5.5, 17.0, y, y + 1.1, -16.9, -16.2)
    box("glass_shop", 5.5, 17.0, y + 1.1, y + 3.0, -16.6, -16.5)
    for z in (-19.5, -23.0):
        box("cloth_white", 7.0, 16.5, y, y + 0.9, z - 0.5, z + 0.5)
        for x in np.arange(7.8, 16.0, 2.0):
            box("frame_black", x - 0.25, x + 0.25, y + 0.9, y + 1.0, z - 0.25, z + 0.25)
            b.hull("gold_bar", [(x + 0.6 + dx, y + 0.9, z + dz) for dx in (-0.12, 0.12) for dz in (-0.06, 0.06)] + [(x + 0.6 + dx, y + 0.97, z + dz) for dx in (-0.1, 0.1) for dz in (-0.045, 0.045)])
    b.text("RECEPÇÃO DE OURO", "gold", (11.25, y + 3.4, -16.5), 0.35, 0.02, simplify=0.008)
    b.anchor("Goldannahme", (11.25, y, -15.6), 0)
    for k in range(9):
        box("vault_steel", -24.2 + k * 0.6, -23.65 + k * 0.6, y, y + 1.9, -14.7, -14.25)
    desk(21.5, -20.0, y, 2.4, 1.0, "lacquer", 3)
    chair(21.5, -19.0, y, 180.0, "lacquer")
    for k in range(4):
        b.box("frame_black", (0.1, 1.0, 0.12), (24.2, y + 1.2, -23.0 + k * 0.35), rot_x=8)
    b.anchor("Wachposten_Hof", (21.5, y, -18.8), 180)
    # --- sketch: technical room (power box + lockdown box) behind the Tesouraria, weapons check at the truck lift, guards
    b.layer = "EG_Technik_Tuer"
    b.pivots["EG_Technik_Tuer"] = (-18.0, y, -21.85)
    box("door_metal", -18.06, -17.94, y, y + 2.4, -21.83, -20.67)
    box("chrome", -17.94, -17.9, y + 1.0, y + 1.08, -20.95, -20.75)
    box("chrome", -18.1, -18.06, y + 1.0, y + 1.08, -20.95, -20.75)
    b.layer = "EG_Innen"
    b.text("TÉCNICA", "gold", (-17.74, y + 2.75, -21.25), 0.2, 0.02, rot_y=90, simplify=0.01)
    box("door_metal", -22.4, -19.0, y, y + 2.2, IZ0, IZ0 + 0.65)                          # power cabinet ("Strombox")
    box("frame_black", -22.3, -19.1, y + 0.3, y + 2.0, IZ0 + 0.65, IZ0 + 0.67)
    for i in range(6):
        for j in range(4):
            box("door_metal" if (i + j) % 3 else "safety_yellow", -22.15 + i * 0.4, -21.9 + i * 0.4, y + 1.2 + j * 0.2, y + 1.32 + j * 0.2, IZ0 + 0.67, IZ0 + 0.72)
    box("safety_yellow", -22.2, -21.0, y + 0.5, y + 0.9, IZ0 + 0.67, IZ0 + 0.69)
    b.text("ENERGIA", "hazard", (-21.6, y + 0.62, IZ0 + 0.69), 0.14, 0.01, simplify=0.01)
    for i in range(5):
        box("led_green", -22.1 + i * 0.25, -21.98 + i * 0.25, y + 2.05, y + 2.12, IZ0 + 0.67, IZ0 + 0.7)
    for k in range(3):
        b.beam("pipe", (-22.0 + k * 1.2, y + 2.2, IZ0 + 0.3), (-22.0 + k * 1.2, top_of("EG"), IZ0 + 0.3), 0.08)
    b.layer = "EG_Strom_Hebel"                                                            # main switch: pull down = power off
    b.pivots["EG_Strom_Hebel"] = (-19.55, y + 1.3, IZ0 + 0.72)
    box("frame_black", -19.75, -19.35, y + 1.1, y + 1.5, IZ0 + 0.67, IZ0 + 0.78)
    b.beam("chrome", (-19.55, y + 1.3, IZ0 + 0.8), (-19.55, y + 1.75, IZ0 + 0.95), 0.05)
    box("marble_red", -19.67, -19.43, y + 1.72, y + 1.84, IZ0 + 0.9, IZ0 + 1.0)
    b.layer = "EG_Innen"
    xs_ = -18.25                                                                           # lockdown box ("Sicherheitsbox") on the wall next to the door
    box("vault_steel", xs_ - 0.35, xs_, y + 0.9, y + 2.1, -26.6, -25.2)
    box("frame_black", xs_ - 0.37, xs_ - 0.35, y + 1.0, y + 2.0, -26.5, -25.3)
    b.cyl("led_red", 0.12, 0.1, (xs_ - 0.42, y + 1.4, -25.9), 10)
    box("chrome", xs_ - 0.42, xs_ - 0.37, y + 1.7, y + 1.8, -26.25, -26.15)
    for i in range(4):
        box("led_green" if i < 3 else "led_red", xs_ - 0.39, xs_ - 0.37, y + 1.9, y + 1.95, -26.3 + i * 0.2, -26.2 + i * 0.2)
    box("hazard", xs_ - 0.38, xs_ - 0.36, y + 0.95, y + 1.1, -26.5, -25.3)
    b.text("BLOQUEIO", "safety_yellow", (xs_ - 0.37, y + 2.2, -25.9), 0.12, 0.01, rot_y=-90, simplify=0.01)
    b.layer = "EG_Abriegelung_Klappe"                                                     # flip cover over the red lockdown button
    b.pivots["EG_Abriegelung_Klappe"] = (xs_ - 0.4, y + 1.6, -25.9)
    box("glass_shop", xs_ - 0.5, xs_ - 0.47, y + 1.22, y + 1.6, -26.12, -25.68)
    b.layer = "EG_Innen"
    b.anchor("Strombox", (-20.7, y, IZ0 + 1.6), 180)
    b.anchor("Sicherheitsbox", (xs_ - 1.1, y, -25.9), 90)
    b.anchor("Technikraum", (-21.5, y, -20.0), 0)
    for x in (-0.75, 0.75):                                                                # weapons check for the delivery driver (walk-through detector)
        box("vault_steel", x - 0.08, x + 0.08, y, y + 2.2, -15.45, -14.95)
    box("vault_steel", -0.83, 0.83, y + 2.2, y + 2.4, -15.45, -14.95)
    box("led_green", -0.2, 0.2, y + 2.4, y + 2.46, -15.3, -15.1)
    box("frame_black", 1.6, 3.6, y, y + 0.85, -15.7, -14.7)                                # x-ray belt
    box("door_metal", 2.1, 3.1, y + 0.85, y + 1.55, -15.6, -14.8)
    box("screen", 3.0, 3.5, y + 1.0, y + 1.35, -14.66, -14.62)
    b.anchor("Waffenkontrolle", (0.0, y, -15.8), 0)
    b.anchor("Lagereingang", (0.0, yE, Z0 - 0.8), 0)
    b.anchor("Lkw_Lieferung", (0.0, 0.95, -35.0), 0)
    for (nm, x, z, yaw) in (("Wache_Lieferung_1", -1.8, -15.0, 180), ("Wache_Lieferung_2", 4.9, -15.2, -90),
                            ("Wache_Tesouraria", -11.0, -21.25, 0), ("Wache_Goldannahme", 11.0, -21.25, 0)):
        b.anchor(nm, (x, y, z), yaw)
    for k, (x, z, yaw) in enumerate([(-31.0, 17.5, 135), (31.0, 17.5, -135), (-31.0, -13.6, 45), (31.0, -13.6, -45), (-17.6, 26.9, 135), (17.6, 26.9, -135),
                                     (-13.6, -9.6, 45), (13.6, -9.6, -45), (0.0, -14.4, 180), (-17.6, -27.0, 45), (17.6, -27.0, -45), (0.0, 17.6, 180)]):
        cam(f"Kamera_EG_{k + 1}", x, yt - 0.3, z, yaw)

    # ================================================================ OG1 – Sala Imperial, watch museum, auction hall, archive
    y, yt = LV["OG1"], top_of("OG1")
    b.layer = "OG1"
    wall_x("stone_imperial", -14.0, -18.0, 18.0, y, yt, [(-1.4, 1.4, y, y + 2.6), (-16.6, -15.4, y, y + 2.4), (15.4, 16.6, y, y + 2.4)], t=0.4)
    for s in (-1, 1):
        wall_z("stone_imperial", s * 18.0, IZ0, IZ1, y, yt, [(-16.6, -15.4, y, y + 2.4), (-1.2, 1.2, y, y + 2.8), (21.6, 23.0, y, y + 2.4)], t=0.4)
        a, c = sorted((s * 18.0, s * IX1))
        wall_x("stone_imperial", -14.0, a, c, y, yt, [(min(s * 20.0, s * 21.2), max(s * 20.0, s * 21.2), y, y + 2.4)], t=0.4)
    wall_x("velvet_red", 18.0, -18.0, 18.0, y, yt, [(-1.0, 1.0, y, y + 2.8)], t=0.4)
    box("frame_black", -1.2, 1.2, y + 2.8, y + 3.1, 17.75, 18.25)
    b.text("SALA IMPERIAL", "gold", (0.0, y + 3.6, 17.79), 0.4, 0.02, rot_y=180, simplify=0.012)
    b.layer = "OG1_Sala_Tuer"                                                              # vault-style door into the laser tunnel
    b.pivots["OG1_Sala_Tuer"] = (-1.0, y, 18.0)
    box("vault_steel", -1.0, 1.0, y, y + 2.8, 17.9, 18.1)
    box("chrome", 0.55, 0.75, y + 1.2, y + 1.35, 17.8, 17.9)
    b.layer = "OG1"
    for s in (-1, 1):
        name = f"OG1_Sala_Seitentuer_{'W' if s < 0 else 'O'}"                               # locked side doors (keycard)
        b.layer = name
        b.pivots[name] = (s * 18.0, y, 21.6)
        box("vault_steel", s * 18.0 - 0.1, s * 18.0 + 0.1, y, y + 2.4, 21.6, 23.0)
        b.layer = "OG1"
        ra, rb = sorted((s * 18.2, s * 18.27))
        box("frame_black", ra, rb, y + 1.2, y + 1.6, 23.2, 23.5)                          # keycard reader (wing side)
        b.anchor(f"Kartenleser_Sala_{'W' if s < 0 else 'O'}", (s * 19.0, y, 23.35), -90 * s)
    b.layer = "OG1_Innen"
    for s in (-1, 1):                                                                     # glass laser tunnel inside the Sala
        box("glass_shop", s * 1.6 - 0.03, s * 1.6 + 0.03, y, y + 2.8, 18.2, 21.2)
        box("brass", s * 1.6 - 0.05, s * 1.6 + 0.05, y + 2.8, y + 2.86, 18.2, 21.2)
    box("glass_shop", -1.6, 1.6, y + 2.8, y + 2.83, 18.2, 21.2)
    laser_grid("OG1_Laser", -1.55, 1.55, 18.35, 21.1, y, 8, "z")
    b.anchor("Laser_Start", (0.0, y, 17.2), 0)
    b.anchor("Laser_Ende", (0.0, y, 21.7), 0)
    box("frame_black", 1.6, 2.1, y + 1.0, y + 1.6, 17.65, 17.8)
    box("led_red", 1.75, 1.95, y + 1.35, y + 1.45, 17.63, 17.65)
    b.anchor("Laser_Steuerung", (1.85, y, 17.0), 180)
    for s in (-1, 1):
        for (za, zb) in ((18.2, 21.6), (23.0, IZ1)):
            box("velvet_red", s * 17.75 - 0.05, s * 17.75 + 0.05, y, yt, za, zb)
        for z in (19.9, 25.2):
            box("gold", s * 17.68 - 0.04, s * 17.68 + 0.04, y + 1.6, y + 3.6, z - 1.2, z + 1.2)
            box("marble_green", s * 17.63 - 0.02, s * 17.63 + 0.02, y + 1.75, y + 3.45, z - 1.05, z + 1.05)
    PX, PZ = 0.0, 23.6
    box("marble_black", PX - 1.0, PX + 1.0, y, y + 1.15, PZ - 1.0, PZ + 1.0)
    box("brass", PX - 1.05, PX + 1.05, y + 1.15, y + 1.21, PZ - 1.05, PZ + 1.05)
    for k in range(16):
        a = k * np.pi / 8
        box("lacquer", PX + 2.0 * np.cos(a) - 0.28, PX + 2.0 * np.cos(a) + 0.28, y, y + 0.012, PZ + 2.0 * np.sin(a) - 0.28, PZ + 2.0 * np.sin(a) + 0.28)
    b.layer = "OG1_Beute_Krone"
    b.pivots["OG1_Beute_Krone"] = (PX, y + 1.6, PZ)
    b.cyl("velvet_purple", 0.38, 0.12, (PX, y + 1.27, PZ), 12)
    t = trimesh.creation.torus(major_radius=0.3, minor_radius=0.045, major_sections=12, minor_sections=4)
    t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    b.add("gold", t.apply_translation((PX, y + 1.38, PZ)))
    for k in range(8):
        a = k * np.pi / 4
        p0 = np.array([PX + 0.3 * np.cos(a), y + 1.38, PZ + 0.3 * np.sin(a)])
        b.beam("gold", tuple(p0), (PX + 0.13 * np.cos(a), y + 1.85, PZ + 0.13 * np.sin(a)), 0.035)
        b.add(GEMS[k % 4], octa(0.04).apply_translation(tuple(p0 + [0, 0.13, 0])))
    b.add("gold", trimesh.creation.icosphere(subdivisions=1, radius=0.08).apply_translation((PX, y + 1.93, PZ)))
    b.beam("gold", (PX, y + 1.98, PZ), (PX, y + 2.2, PZ), 0.025)
    b.beam("gold", (PX - 0.08, y + 2.12, PZ), (PX + 0.08, y + 2.12, PZ), 0.025)
    b.add("gem_red", octa(0.07).apply_translation((PX, y + 1.48, PZ + 0.32)))
    b.layer = "OG1_Krone_Glas"
    b.pivots["OG1_Krone_Glas"] = (PX, y + 1.85, PZ)
    box("glass_shop", PX - 0.75, PX + 0.75, y + 1.21, y + 2.5, PZ - 0.75, PZ + 0.75)
    box("brass", PX - 0.77, PX + 0.77, y + 2.5, y + 2.56, PZ - 0.77, PZ + 0.77)
    b.layer = "OG1_Innen"
    b.anchor("Coroa_Imperial", (PX, y + 1.25, PZ), 0)
    nv = 1
    for (x, z) in ((-6.0, 20.6), (6.0, 20.6), (-12.0, 20.6), (12.0, 20.6), (-9.0, 25.4), (9.0, 25.4), (-15.0, 20.6), (15.0, 20.6), (-15.0, 25.4), (15.0, 25.4)):
        box("marble_black", x - 0.55, x + 0.55, y, y + 1.05, z - 0.55, z + 0.55)
        if nv % 3 == 0:
            b.beam("gold", (x - 0.25, y + 1.15, z), (x + 0.25, y + 1.15, z), 0.04)                     # scepter on cushion
            b.add("gem_blue", octa(0.06).apply_translation((x + 0.3, y + 1.15, z)))
            b.cyl("velvet_purple", 0.3, 0.06, (x, y + 1.08, z), 8)
        else:
            necklace_bust(x, y + 1.05, z, 0.0, "velvet_purple")
        node = f"OG1_Vitrine_{nv}"
        b.layer = node
        b.pivots[node] = (x, y + 1.55, z)
        box("glass_shop", x - 0.5, x + 0.5, y + 1.05, y + 2.05, z - 0.5, z + 0.5)
        b.layer = "OG1_Innen"
        b.anchor(node, (x, y, z), 0)
        nv += 1
    chandelier(0.0, 23.6, yt, 1.2, 1.2)
    box("marble_red", -2.6, 2.6, y, y + 0.2, 25.9, IZ1)                                    # throne dais
    box("marble_red", -2.0, 2.0, y + 0.2, y + 0.4, 26.4, IZ1)
    box("gold", -2.6, 2.6, y + 0.18, y + 0.22, 25.86, 25.94)
    box("gold", -2.0, 2.0, y + 0.38, y + 0.42, 26.36, 26.44)
    TZ = 26.85
    box("velvet_red", -0.6, 0.6, y + 0.4, y + 0.95, TZ - 0.45, TZ + 0.35)
    b.hull("gold", [(x, y + 0.95, z) for x in (-0.7, 0.7) for z in (TZ + 0.35, TZ + 0.5)] + [(x, y + 2.9, z) for x in (-0.45, 0.45) for z in (TZ + 0.35, TZ + 0.5)] + [(0.0, y + 3.25, TZ + 0.42)])
    box("velvet_red", -0.5, 0.5, y + 1.05, y + 2.7, TZ + 0.29, TZ + 0.35)
    for sx in (-1, 1):
        box("gold", sx * 0.62 - 0.08, sx * 0.62 + 0.08, y + 0.95, y + 1.25, TZ - 0.45, TZ + 0.35)
        b.cyl("gold", 0.25, 0.08, (sx * 2.2, y + 0.44, 26.9), 8)                              # candelabras
        b.cyl("gold", 0.05, 2.0, (sx * 2.2, y + 1.44, 26.9), 6)
        b.beam("gold", (sx * 2.2 - 0.3, y + 2.4, 26.9), (sx * 2.2 + 0.3, y + 2.4, 26.9), 0.04)
        for k in range(3):
            b.cyl("cloth_white", 0.04, 0.3, (sx * 2.2 + (k - 1) * 0.3, y + 2.57, 26.9), 6)
    b.add("gem_red", octa(0.1).apply_translation((0.0, y + 3.0, TZ + 0.3)))
    b.anchor("Thron", (0.0, y + 0.4, TZ), 180)
    for (x, z, yaw) in ((-17.4, 18.6, 135), (17.4, 18.6, -135), (-17.4, IZ1 - 0.3, 45), (17.4, IZ1 - 0.3, -45)):
        cam(cam_id("Kamera_Sala"), x, yt - 0.3, z, yaw)
    # watch museum (left wing) + tall clock
    wall_case(IX0, -12.0, 16.0, y, 1)
    for (x, z) in ((-24.0, -10.0), (-24.0, -4.0), (-24.0, 4.0), (-24.0, 10.0), (-20.6, -4.0), (-20.6, 4.0)):
        vitrine(f"OG1_Vitrine_{nv}", x, z, y, 1.8, 0.8, "watch")
        nv += 1
    box("walnut", -18.9, -18.3, y, y + 3.2, 13.4, 14.4)
    cyl_axis("cream", 0.35, 0.05, (-18.27, y + 2.6, 13.9), "x", 12)
    b.beam("brass", (-18.27, y + 2.1, 13.9), (-18.27, y + 1.0, 13.9), 0.03)
    cyl_axis("brass", 0.15, 0.04, (-18.27, y + 0.95, 13.9), "x", 10)
    b.text("MUSEU DO RELÓGIO", "gold", (-17.8, y + 3.3, 0.0), 0.35, 0.02, rot_y=90, simplify=0.008)
    for (x, z) in ((-24.0, 16.0), (-24.0, 22.0), (-20.6, 16.0), (-20.6, 22.0), (-27.6, 25.6)):
        vitrine(f"OG1_Vitrine_{nv}", x, z, y, 1.8, 0.8, "watch")
        nv += 1
    for z in (19.0, 20.4, 24.6, 26.2):                                                     # tall-case clocks along the Sala wall
        x = -18.6
        box("walnut", x - 0.3, x + 0.3, y, y + 2.4, z - 0.4, z + 0.4)
        b.hull("walnut", [(x + dx, y + 2.4, z + dz) for dx in (-0.3, 0.3) for dz in (-0.4, 0.4)] + [(x, y + 2.75, z + dz) for dz in (-0.4, 0.4)])
        cyl_axis("cream", 0.28, 0.05, (x - 0.32, y + 2.0, z), "x", 12)
        b.beam("brass", (x - 0.33, y + 1.6, z), (x - 0.33, y + 0.75, z), 0.03)
        cyl_axis("brass", 0.12, 0.04, (x - 0.34, y + 0.7, z), "x", 10)
    cyl_axis("gold", 1.4, 0.08, (IX0 + 0.04, y + 3.2, 21.5), "x", 24)                        # big astronomical clock
    cyl_axis("cream", 1.25, 0.1, (IX0 + 0.09, y + 3.2, 21.5), "x", 24)
    cyl_axis("velvet_blue", 0.8, 0.12, (IX0 + 0.1, y + 3.2, 21.5), "x", 24)
    b.beam("gold", (IX0 + 0.18, y + 3.2, 21.5), (IX0 + 0.18, y + 4.2, 21.8), 0.05)
    b.beam("gold", (IX0 + 0.18, y + 3.2, 21.5), (IX0 + 0.18, y + 2.6, 20.8), 0.05)
    b.anchor("Astronomische_Uhr", (IX0 + 1.5, y, 21.5), 90)
    # auction hall (right wing): podium, screen, phone desk, 10 x 8 chairs
    box("walnut", 19.0, 30.5, y, y + 0.4, -13.6, -9.6)
    box("walnut", 24.0, 25.4, y + 0.4, y + 1.5, -11.2, -10.5)
    b.cyl("brass", 0.06, 0.12, (24.7, y + 1.56, -10.85), 8)
    box("frame_black", 20.0, 29.8, y + 2.0, y + 5.0, -13.75, -13.65)
    box("screen", 20.2, 29.6, y + 2.15, y + 4.85, -13.65, -13.6)
    b.text("LEILÃO", "gold", (24.7, y + 5.4, -13.6), 0.4, 0.02, simplify=0.008)
    for z in np.arange(-7.0, 15.0, 2.0):
        for x in np.arange(20.0, 29.6, 1.2):
            if abs(x - 24.8) < 0.7:
                continue
            chair(x, z, y, 180.0, "velvet_red")
    box("walnut", 30.3, 31.0, y, y + 0.75, -6.0, 6.0)
    for z in np.arange(-5.0, 5.5, 1.5):
        box("frame_black", 30.4, 30.8, y + 0.75, y + 0.85, z - 0.15, z + 0.15)
    b.anchor("Auktionssaal", (24.7, y, -8.0), 0)
    for (x, z) in ((21.5, 18.5), (21.5, 23.5), (27.5, 18.5), (27.5, 23.5)):                 # lots on preview
        vitrine(f"OG1_Vitrine_{nv}", x, z, y, 1.8, 0.8, "mix")
        nv += 1
    sofa(30.6, 21.0, y, 3.0, 270, "velvet_purple")
    b.anchor("Auktionator", (24.7, y + 0.4, -11.8), 0)
    # archive (back zone)
    for x in np.arange(-15.0, 15.5, 2.5):
        if abs(x) < 2.0:
            continue
        box("vault_steel", x - 0.35, x + 0.35, y, y + 2.6, -26.5, -16.0)
        for yy in (y + 0.5, y + 1.15, y + 1.8, y + 2.45):
            box("cardboard", x - 0.33, x + 0.33, yy - 0.4, yy - 0.05, -26.3, -16.2)
    b.anchor("Archiv", (0.0, y, -20.0), 0)
    for (x, z, yaw) in ((-31.0, -13.6, 45), (31.0, -13.6, -45), (0.0, -14.4, 180), (-31.0, 17.5, 135)):
        cam(cam_id("Kamera_OG1"), x, yt - 0.3, z, yaw)

    # ================================================================ OG2 – boardroom, lapidary, goldsmiths, canteen, work vault
    y, yt = LV["OG2"], top_of("OG2")
    b.layer = "OG2"
    wall_x("stone_imperial", -14.0, -18.0, 18.0, y, yt, [(-1.0, 1.0, y, y + 2.4), (-16.6, -15.4, y, y + 2.4), (15.4, 16.6, y, y + 2.4)], t=0.3)
    for s in (-1, 1):
        wall_z("stone_imperial", s * 18.0, IZ0, IZ1, y, yt, [(-16.6, -15.4, y, y + 2.4), (-1.0, 1.0, y, y + 2.4), (21.6, 23.0, y, y + 2.4)], t=0.3)
        a, c = sorted((s * 18.0, s * IX1))
        wall_x("stone_imperial", -14.0, a, c, y, yt, [(min(s * 20.0, s * 21.2), max(s * 20.0, s * 21.2), y, y + 2.4)], t=0.3)
    wall_x("stone_imperial", 18.0, IX0, IX1, y, yt, [(-1.0, 1.0, y, y + 2.4), (-25.4, -24.0, y, y + 2.4), (24.0, 25.4, y, y + 2.4)], t=0.3)
    wall_x("vault_steel", -21.0, 18.0, 24.7, y, yt, [(20.4, 21.6, y, y + 2.2)], t=0.4)
    b.layer = "OG2_Arbeitstresor_Tuer"
    b.pivots["OG2_Arbeitstresor_Tuer"] = (20.4, y, -21.0)
    box("vault_steel", 20.4, 21.6, y, y + 2.2, -20.85, -20.7)
    cyl_axis("chrome", 0.22, 0.08, (21.0, y + 1.2, -20.66), "z", 10)
    b.layer = "OG2_Innen"
    box("frame_black", 21.8, 22.1, y + 1.1, y + 1.5, -20.82, -20.8)
    box("led_green", 21.88, 22.02, y + 1.35, y + 1.42, -20.84, -20.82)
    box("walnut", -9.0, 9.0, y, y + 0.78, 21.8, 23.6)                                     # boardroom
    for x in np.arange(-8.0, 8.1, 2.0):
        chair(x, 21.1, y, 0.0, "lacquer")
        chair(x, 24.3, y, 180.0, "lacquer")
    chair(-9.8, 22.7, y, 90.0, "velvet_red")
    for s in (-1, 1):
        box("frame_black", s * 17.8 - 0.05, s * 17.8 + 0.05, y + 1.2, y + 3.0, 20.5, 25.0)
        box("screen", s * 17.72 - 0.02, s * 17.72 + 0.02, y + 1.3, y + 2.9, 20.6, 24.9)
    for x in (-10.0, -5.0, 5.0, 10.0):
        box("gold", x - 0.9, x + 0.9, y + 1.4, y + 3.4, 18.2, 18.26)
        box("marble_red", x - 0.75, x + 0.75, y + 1.55, y + 3.25, 18.26, 18.28)
    b.anchor("Sitzungssaal", (0.0, y, 20.0), 0)
    for k, z in enumerate(np.arange(-11.0, 15.0, 3.2)):                                     # lapidary benches
        box("walnut", -30.0, -25.0, y, y + 0.9, z - 0.6, z + 0.6)
        for x in (-29.0, -27.5, -26.0):
            b.cyl("vault_steel", 0.28, 0.05, (x, y + 0.95, z), 12)
            box("lamp", x, x + 0.3, y + 1.38, y + 1.44, z - 0.3, z - 0.1)
            b.beam("frame_black", (x + 0.35, y + 0.9, z - 0.4), (x + 0.2, y + 1.4, z - 0.2), 0.02)
            b.add(GEMS[k % 4], octa(0.05).apply_translation((x - 0.15, y + 1.0, z + 0.3)))
        for x in (-29.0, -26.0):
            b.cyl("frame_black", 0.22, 0.5, (x, y + 0.25, z + 1.0), 8)
    for z in (-8.0, -2.0, 4.0, 10.0):                                                      # gemology microscopes
        box("cloth_white", -22.5, -19.0, y, y + 0.9, z - 0.7, z + 0.7)
        for x in (-21.8, -19.8):
            box("frame_black", x - 0.15, x + 0.15, y + 0.9, y + 1.0, z - 0.2, z + 0.2)
            b.beam("frame_black", (x, y + 1.0, z - 0.1), (x, y + 1.5, z + 0.05), 0.05)
    b.text("LAPIDAÇÃO", "bronze", (-17.8, y + 3.0, 0.0), 0.3, 0.02, rot_y=90, simplify=0.008)
    b.anchor("Schleiferei", (-26.0, y, 0.0), 90)
    for k, z in enumerate(np.arange(-11.0, 15.0, 3.2)):                                     # goldsmith benches + design desks
        box("walnut", 25.0, 30.5, y, y + 0.95, z - 0.55, z + 0.55)
        for x in (26.0, 28.0, 30.0):
            box("wood_dark" if "wood_dark" in PALETTE else "walnut", x - 0.2, x + 0.2, y + 0.85, y + 0.95, z - 0.7, z - 0.5)
            box("lamp", x - 0.15, x + 0.15, y + 1.5, y + 1.56, z - 0.2, z + 0.1)
            b.beam("frame_black", (x + 0.3, y + 0.95, z + 0.4), (x + 0.1, y + 1.55, z), 0.02)
            ring(x - 0.2, y + 0.95, z + 0.2, 30.0)
            b.cyl("frame_black", 0.22, 0.5, (x, y + 0.25, z - 1.0), 8)
    for z in (-8.0, -2.0, 4.0, 10.0):
        desk(20.5, z, y, 1.6, 0.8, "cloth_white", 2, "z")
    b.text("OURIVESARIA", "bronze", (17.8, y + 3.0, 0.0), 0.3, 0.02, rot_y=-90, simplify=0.008)
    b.anchor("Goldschmiede", (27.0, y, 0.0), -90)
    for (x, z) in ((-12.0, -18.0), (-6.0, -18.0), (6.0, -24.0), (12.0, -24.0), (-12.0, -24.0), (-6.0, -24.0)):   # canteen
        box("cloth_white", x - 1.0, x + 1.0, y, y + 0.75, z - 0.6, z + 0.6)
        for dz in (-0.9, 0.9):
            for dx in (-0.5, 0.5):
                chair(x + dx, z + dz, y, 0.0 if dz < 0 else 180.0, "flag_green")
    box("vault_steel", 4.0, 16.0, y, y + 0.95, -16.0, -15.3)
    box("fridge" if "fridge" in PALETTE else "vault_steel", 15.0, 16.5, y, y + 2.0, -18.5, -17.5)
    b.anchor("Kantine", (-8.0, y, -21.0), 0)
    for k in range(6):                                                                     # work vault behind steel wall
        box("vault_steel", 19.0 + (k % 3) * 1.6, 20.3 + (k % 3) * 1.6, y + (k // 3) * 1.0, y + 0.9 + (k // 3) * 1.0, IZ0 + 0.2, IZ0 + 1.0)
    box("walnut", 19.5, 23.5, y, y + 0.9, -24.0, -22.5)
    tray(19.6, 23.4, -23.9, -22.6, y + 0.9, "mix", 0.35)
    b.anchor("Arbeitstresor", (21.0, y, -20.2), 180)
    for (x, z, yaw) in ((-31.0, -13.6, 45), (31.0, -13.6, -45), (0.0, 17.6, 180), (-17.6, 26.9, 135)):
        cam(cam_id("Kamera_OG2"), x, yt - 0.3, z, yaw)

    # ================================================================ OG3 – security HQ, director, barracks, armory, offices
    y, yt = LV["OG3"], top_of("OG3")
    b.layer = "OG3"
    wall_x("stone_imperial", -14.0, -18.0, 18.0, y, yt, [(-1.0, 1.0, y, y + 2.4), (-16.6, -15.4, y, y + 2.4), (15.4, 16.6, y, y + 2.4)], t=0.3)
    for s in (-1, 1):
        wall_z("stone_imperial", s * 18.0, IZ0, IZ1, y, yt, [(-16.6, -15.4, y, y + 2.4), (-1.0, 1.0, y, y + 2.4), (21.6, 23.0, y, y + 2.4)], t=0.3)
        a, c = sorted((s * 18.0, s * IX1))
        wall_x("stone_imperial", -14.0, a, c, y, yt, [(min(s * 20.0, s * 21.2), max(s * 20.0, s * 21.2), y, y + 2.4)], t=0.3)
    wall_x("glass_shop", 18.0, -18.0, 18.0, y, yt, [(-1.0, 1.0, y, y + 2.4)], t=0.08)
    for s in (-1, 1):
        a, c = sorted((s * 18.0, s * IX1))
        wall_x("stone_imperial", 18.0, a, c, y, yt, [(min(s * 24.0, s * 25.4), max(s * 24.0, s * 25.4), y, y + 2.4)], t=0.3)
    wall_x("stone_imperial", 4.0, 18.0, IX1, y, yt, [(21.0, 22.4, y, y + 2.4)], t=0.3)
    b.layer = "OG3_Innen"
    for i in range(12):                                                                    # monitor wall (faces the operators)
        for j in range(4):
            x = -13.2 + i * 2.4
            yy = y + 0.9 + j * 0.8
            box("frame_black", x - 1.15, x + 1.15, yy, yy + 0.75, IZ1 - 0.25, IZ1 - 0.12)
            box("screen", x - 1.1, x + 1.1, yy + 0.04, yy + 0.71, IZ1 - 0.27, IZ1 - 0.25)
    for z in (22.0, 24.5):
        for x in (-9.0, -3.0, 3.0, 9.0):
            box("lacquer", x - 2.0, x + 2.0, y, y + 0.78, z - 0.45, z + 0.45)
            for dx in (-1.1, 0.0, 1.1):
                box("screen", x + dx - 0.35, x + dx + 0.35, y + 0.8, y + 1.25, z + 0.35, z + 0.4)
            for dx in (-1.0, 1.0):
                chair(x + dx, z - 0.9, y, 0.0, "lacquer")
    box("lacquer", -2.5, 2.5, y, y + 0.9, 19.3, 20.7)
    box("screen", -2.4, 2.4, y + 0.9, y + 0.93, 19.4, 20.6)
    box("frame_black", 15.5, 17.0, y + 0.9, y + 2.0, IZ1 - 0.3, IZ1 - 0.1)
    box("led_red", 15.9, 16.6, y + 1.4, y + 1.6, IZ1 - 0.32, IZ1 - 0.3)
    b.anchor("Sicherheitszentrale", (0.0, y, 21.0), 0)
    b.anchor("Alarm_Hauptschalter", (16.2, y, IZ1 - 1.0), 0)
    b.anchor("Ueberwachung_Kameras", (0.0, y, 23.0), 0)
    # director suite (left wing)
    box("walnut", -27.0, -23.0, y, y + 0.8, 6.0, 8.0)
    box("frame_black", -25.6, -24.4, y + 0.8, y + 1.15, 7.2, 7.3)
    chair(-25.0, 9.0, y, 180.0, "velvet_red")
    box("velvet_red", -25.3, -24.7, y + 0.95, y + 1.6, 9.2, 9.35)
    for x in (-26.0, -24.0):
        chair(x, 5.0, y, 0.0, "velvet_purple")
    sofa(-21.0, 13.0, y, 3.0, 270, "velvet_purple")
    b.cyl("marble_black", 0.6, 0.45, (-23.0, y + 0.225, 13.0), 12)
    box("walnut", IX0, IX0 + 0.5, y, y + 2.6, -10.0, 2.0)
    for yy in (y + 0.6, y + 1.2, y + 1.8, y + 2.4):
        box("cardboard", IX0 + 0.05, IX0 + 0.45, yy - 0.45, yy - 0.05, -9.7, 1.7)
    b.cyl("walnut", 0.1, 0.9, (-21.0, y + 0.45, -6.0), 8)
    b.add("flag_gold", trimesh.creation.icosphere(subdivisions=1, radius=0.4).apply_translation((-21.0, y + 1.3, -6.0)))
    box("carpet_red", -29.0, -20.0, y, y + 0.01, 2.0, 15.0)
    box("vault_steel", IX0, IX0 + 0.06, y + 1.5, y + 2.4, 12.5, 13.5)                      # the hidden safe
    box("chrome", IX0 + 0.06, IX0 + 0.09, y + 1.9, y + 2.0, 12.9, 13.1)
    b.layer = "OG3_Gemaelde"
    b.pivots["OG3_Gemaelde"] = (IX0 + 0.1, y + 2.0, 11.8)
    box("gold", IX0 + 0.06, IX0 + 0.14, y + 1.2, y + 2.8, 11.8, 14.2)
    box("marble_green", IX0 + 0.14, IX0 + 0.15, y + 1.35, y + 2.65, 11.95, 14.05)
    b.layer = "OG3_Innen"
    b.anchor("Direktor_Safe", (IX0 + 0.8, y, 13.0), 90)
    b.anchor("Direktor", (-25.0, y, 9.6), 180)
    # LAGER / depot (right wing, sketch): pallet racks, crates – directly below the helipad stair (east core)
    def rack(x, z0, z1, y0, levels=(0.15, 1.6, 3.05), d=1.1):
        for zz in np.arange(z0, z1 + 0.01, 2.7):
            for dx in (-d / 2, d / 2):
                box("rack_stahl", x + dx - 0.05, x + dx + 0.05, y0, y0 + 4.3, zz - 0.05, zz + 0.05)
        for ly in levels:
            for dx in (-d / 2, d / 2):
                box("rack_orange", x + dx - 0.05, x + dx + 0.05, y0 + ly, y0 + ly + 0.12, z0, z1)
            box("crate", x - d / 2, x + d / 2, y0 + ly + 0.12, y0 + ly + 0.16, z0, z1)
            zz = z0 + 0.2
            while zz < z1 - 0.6:
                w_ = float(rng.choice([0.5, 0.7, 0.9]))
                h_ = float(rng.choice([0.35, 0.5, 0.7, 0.9]))
                if rng.random() < 0.85:
                    box("cardboard" if rng.random() < 0.6 else "crate", x - d / 2 + 0.08, x + d / 2 - 0.08, y0 + ly + 0.16, y0 + ly + 0.16 + h_, zz, zz + w_)
                zz += w_ + 0.12
    for x in (21.0, 25.0):
        rack(x, -12.6, 2.6, y)
        rack(x, 6.0, 16.4, y)
    rack(30.7, -12.6, 2.6, y, d=1.0)
    for (x, z, n) in ((28.6, 8.0, 3), (30.0, 8.0, 2), (28.6, 10.0, 2), (30.0, 12.5, 3), (28.6, 14.6, 1)):
        for k in range(n):
            box("crate", x - 0.6, x + 0.6, y + k * 0.75, y + 0.7 + k * 0.75, z - 0.6, z + 0.6)
    box("crate", 27.0, 28.4, y, y + 0.14, 16.0, 17.2)                                     # pallet + pallet jack
    b.beam("rack_orange", (27.7, y + 0.12, 15.2), (27.7, y + 1.1, 14.9), 0.05)
    box("rack_orange", 27.3, 28.1, y + 0.05, y + 0.2, 14.4, 16.0)
    b.text("DEPÓSITO", "gold", (17.84, y + 2.9, 0.0), 0.25, 0.02, rot_y=-90, simplify=0.01)
    b.anchor("Lager", (23.0, y, -4.0), 90)
    b.anchor("Lager_Depot", (29.3, y, 16.4), 90)
    b.layer = "OG3_Lager_Tuer"
    b.pivots["OG3_Lager_Tuer"] = (21.0, y, 4.0)
    box("vault_steel", 21.0, 22.4, y, y + 2.4, 3.95, 4.05)
    b.layer = "OG3_Innen"
    for x in np.arange(-15.0, 15.1, 4.0):                                                  # open-plan offices (back)
        if abs(x) < 2.5:
            continue
        for z in (-17.0, -21.0, -25.0):
            desk(x, z, y, 1.6, 0.8, "cloth_white", 1)
            chair(x, z + 0.8, y, 180.0, "lacquer")
    for (x, z, yaw) in ((-17.6, 18.4, 135), (17.6, 18.4, -135), (-31.0, -13.6, 45), (31.0, 3.6, -45), (0.0, -14.4, 180)):
        cam(cam_id("Kamera_OG3"), x, yt - 0.3, z, yaw)

    # ================================================================ UG1 – armoured garage, servers, power, ventilation, checkpoint
    y, yt = LV["UG1"], top_of("UG1")
    b.layer = "UG1"
    for s in (-1, 1):
        wall_z("concrete_light", s * 18.0, -17.4, IZ1, y, yt, [(-6.0, -4.6, y, y + 2.3), (13.0, 14.4, y, y + 2.3)], t=0.3)
        a, c = sorted((s * 18.0, s * IX1))
        wall_x("concrete_light", 10.0, a, c, y, yt, [(min(s * 21.0, s * 22.4), max(s * 21.0, s * 22.4), y, y + 2.3)], t=0.3)
    wall_x("concrete_light", -8.0, -18.0, 18.0, y, yt, [(-7.0, 7.0, y, y + 4.2)], t=0.3)
    for s in (-1, 1):
        wall_z("vault_steel", s * 4.15, VEH[2], VEH[3], y, yt, t=0.3)
    b.layer = "UG1_Innen"
    for k in range(8):
        box("safety_yellow" if k % 2 == 0 else "hazard", VEH[0] + k, VEH[0] + 1 + k, y, y + 0.01, VEH[3] - 0.4, VEH[3])
    for x in (-15.0, -11.0, 11.0, 15.0):                                                  # armoured van bays
        for xx in (x - 1.8, x + 1.8):
            box("paint_white", xx - 0.06, xx + 0.06, y, y + 0.01, -26.5, -17.0)
        b.anchor(f"Geldtransporter_{'W' if x < 0 else 'O'}{abs(int(x))}", (x, y, -21.5), 0)
    box("concrete_light", -17.0, 17.0, y, y + 1.0, -11.5, -8.4)                           # loading dock
    for x in np.arange(-15.0, 15.5, 5.0):
        box("hazard", x - 1.2, x + 1.2, y + 0.9, y + 1.0, -11.6, -11.5)
    for k in range(6):
        box("fence_net", -16.5 + k * 2.2, -14.7 + k * 2.2, y + 1.0, y + 2.6, -9.5, -8.6)
        box("cash_green", -16.3 + k * 2.2, -14.9 + k * 2.2, y + 1.0, y + 1.6, -9.4, -8.7)
    b.anchor("Panzergarage", (0.0, y, -12.5), 0)
    for k, z in enumerate((-2.0, 6.5, 15.0)):                                              # banknote printing hall: 3 press lines
        box("vault_steel", -12.0, 11.0, y, y + 1.1, z - 1.0, z + 1.0)
        for e in (-1.6, 1.5):
            box("safety_yellow", -15.6, 16.0, y, y + 0.01, z + e, z + e + 0.1)
        box("cloth_white", -13.2, 11.0, y + 1.1, y + 1.13, z - 0.8, z + 0.8)                   # paper web
        for x in np.arange(-10.0, 10.0, 3.2):
            box(("flag_green", "velvet_blue", "marble_red")[k], x - 1.1, x + 1.1, y + 1.1, y + 2.7, z - 1.15, z + 1.15)
            box("vault_steel", x - 1.15, x + 1.15, y + 2.7, y + 2.85, z - 1.2, z + 1.2)
            cyl_axis("chrome", 0.32, 2.1, (x + 1.45, y + 1.45, z), "z", 10)
            box("screen", x - 0.45, x + 0.45, y + 1.9, y + 2.35, z + 1.15, z + 1.17)
            box("led_green", x + 0.6, x + 0.8, y + 2.4, y + 2.5, z + 1.15, z + 1.17)
        cyl_axis("cloth_white", 1.05, 1.8, (-14.2, y + 1.15, z), "z", 14)                       # paper reel
        box("vault_steel", -15.4, -13.0, y, y + 0.35, z - 1.0, z + 1.0)
        box("vault_steel", 11.0, 13.2, y, y + 1.4, z - 0.9, z + 0.9)                           # cutter + stacker
        box("hazard", 11.0, 13.2, y + 1.4, y + 1.6, z - 0.9, z + 0.9)
        box("crate", 13.6, 15.6, y, y + 0.15, z - 0.6, z + 0.6)
        for j in range(4):
            box("cash_green", 13.7, 15.5, y + 0.15 + j * 0.22, y + 0.35 + j * 0.22, z - 0.5, z + 0.5)
            box("cloth_white", 14.5, 14.7, y + 0.15 + j * 0.22, y + 0.36 + j * 0.22, z - 0.51, z + 0.51)
    nbp = 0
    for x in np.arange(-14.0, 15.0, 2.4):                                                 # cash pallets waiting for the vans (loot)
        for z in (20.0, 23.0):
            nbp += 1
            b.layer = f"UG1_Beute_Bargeld_{nbp}"
            b.pivots[b.layer] = (float(x), y, z)
            box("crate", x - 0.8, x + 0.8, y, y + 0.15, z - 0.6, z + 0.6)
            h = 0.6 + 0.4 * ((int(x * 10) // 24 + int(z)) % 3)
            box("cash_green", x - 0.75, x + 0.75, y + 0.15, y + 0.15 + h, z - 0.55, z + 0.55)
            box("cloth_white", x - 0.1, x + 0.1, y + 0.15, y + 0.16 + h, z - 0.56, z + 0.56)
            box("cloth_white", x - 0.76, x + 0.76, y + 0.15, y + 0.16 + h, z - 0.1, z + 0.1)
            b.layer = "UG1_Innen"
    for x in (-15.5, -12.5):
        box("cloth_white", x - 1.0, x + 1.0, y, y + 0.9, 25.6, 26.8)                            # counting tables
        for dx in (-0.5, 0.4):
            box("frame_black", x + dx - 0.2, x + dx + 0.2, y + 0.9, y + 1.2, 25.9, 26.4)
            box("cash_green", x + dx + 0.25, x + dx + 0.45, y + 0.9, y + 1.0, 25.9, 26.2)
    b.text("IMPRESSÃO DE CÉDULAS", "gold", (0.0, y + 4.3, -7.83), 0.45, 0.02, simplify=0.012)
    b.anchor("Notendruckerei", (0.0, y, -6.0), 0)
    b.anchor("Bargeld_Paletten", (0.0, y, 21.5), 0)
    for x in np.arange(-30.0, -19.5, 1.5):                                                # server room
        for z in (13.5, 18.0, 22.5):
            server_rack(x, z, y)
    for x in (-30.5, -19.5):
        box("cloth_white", x - 0.5, x + 0.5, y, y + 2.0, 25.0, 26.8)
    b.anchor("Server", (-25.0, y, 15.7), 90)
    for (x, z) in ((22.0, 14.0), (22.0, 20.0)):                                           # power: transformers, switchgear, generators, tank
        box("vault_steel", x - 1.4, x + 1.4, y, y + 2.4, z - 1.2, z + 1.2)
        for k in range(6):
            box("vault_steel", x - 1.5, x + 1.5, y + 0.3, y + 2.1, z - 1.2 + k * 0.48, z - 1.15 + k * 0.48)
    for k in range(10):
        box("vault_steel", 26.0 + (k % 5) * 1.0, 26.9 + (k % 5) * 1.0, y, y + 2.2, 11.0 + (k // 5) * 2.2, 11.6 + (k // 5) * 2.2)
        box("safety_yellow", 26.2 + (k % 5) * 1.0, 26.7 + (k % 5) * 1.0, y + 1.6, y + 1.7, 11.6 + (k // 5) * 2.2, 11.62 + (k // 5) * 2.2)
    for z in (17.0, 22.5):
        box("safety_yellow", 26.0, 30.5, y, y + 1.8, z - 1.0, z + 1.0)
        box("frame_black", 26.3, 30.2, y + 1.8, y + 2.1, z - 0.7, z + 0.7)
    cyl_axis("vault_steel", 1.0, 5.0, (28.0, y + 1.0, 26.0), "x", 12)
    b.anchor("Hauptstrom", (24.5, y, 11.0), 0)
    for k, z in enumerate((-12.0, -4.0, 4.0)):                                              # ventilation plant + shaft bottom
        box("vault_steel", -30.5, -24.0, y, y + 2.8, z - 1.5, z + 1.5)
        cyl_axis("frame_black", 1.0, 0.4, (-23.8, y + 1.4, z), "x", 12)
    vcx = (VENT[0] + VENT[1]) / 2
    b.beam("pipe", (vcx, yt - 0.6, VENT[3]), (vcx, yt - 0.6, -13.6), 0.8)
    b.beam("pipe", (vcx, yt - 0.6, -13.6), (-24.0, yt - 0.6, -12.0), 0.8)
    for yy in np.arange(y + 0.3, y + 1.8, 0.2):                                             # grille on the shaft (crawl-in point)
        box("frame_black", VENT[0] + 0.2, VENT[1] - 0.2, yy, yy + 0.06, VENT[3], VENT[3] + 0.05)
    box("vault_steel", VENT[0] + 0.1, VENT[1] - 0.1, y + 0.2, y + 1.9, VENT[3] - 0.01, VENT[3] + 0.01)
    b.anchor("Lueftungsschacht_UG1", ((VENT[0] + VENT[1]) / 2, y, VENT[3] + 0.8), 0)
    desk(23.0, -6.0, y, 2.4, 1.0, "lacquer", 3)                                           # security checkpoint
    chair(23.0, -5.0, y, 180.0, "lacquer")
    b.layer = "UG1_Gitter"
    b.pivots["UG1_Gitter"] = (18.0, y, -6.0)
    for z in np.arange(-6.0, -4.55, 0.15):
        box("vault_steel", 17.95, 18.05, y, y + 2.3, z - 0.025, z + 0.025)
    b.layer = "UG1_Innen"
    b.anchor("Checkpoint", (23.0, y, -4.6), 180)
    for z in np.arange(-15.0, 8.5, 2.6):                                                   # money-bag shelves (Wertsack-Lager)
        box("vault_steel", 29.4, 31.2, y, y + 0.06, z - 0.9, z + 0.9)
        box("vault_steel", 29.4, 31.2, y + 1.2, y + 1.26, z - 0.9, z + 0.9)
        for zz in (z - 0.9, z + 0.9):
            box("vault_steel", 29.4, 31.2, y, y + 2.4, zz - 0.04, zz + 0.04)
        for k, yy in enumerate((y + 0.06, y + 1.26)):
            for j in range(3):
                b.rock("crate", 0.36, (29.9 + (j % 2) * 0.7, yy + 0.3, z - 0.5 + j * 0.5), 0.8)
    for k in range(5):                                                                     # cash carts (loot)
        x, z = 24.0 + (k % 3) * 1.6, 0.5 + (k // 3) * 2.2
        b.layer = f"UG1_Beute_Bargeld_Wagen{k + 1}"
        b.pivots[b.layer] = (x, y, z)
        box("fence_net", x - 0.5, x + 0.5, y + 0.15, y + 1.5, z - 0.7, z + 0.7)
        box("cash_green", x - 0.4, x + 0.4, y + 0.15, y + 0.9, z - 0.6, z + 0.6)
        box("vault_steel", x - 0.5, x + 0.5, y + 0.1, y + 0.15, z - 0.7, z + 0.7)
        b.layer = "UG1_Innen"
    b.anchor("Wertsack_Lager", (28.0, y, -3.0), 90)
    for (x, z, yaw) in ((-17.6, -27.0, 45), (17.6, -27.0, -45), (0.0, -8.4, 180), (-18.4, 26.9, 135), (18.4, 26.9, -135), (17.6, -9.0, -45)):
        cam(cam_id("Kamera_UG1"), x, yt - 0.3, z, yaw)

    # ================================================================ UG2 – foundry + mint, refinery, vault antechamber, pump room
    y, yt = LV["UG2"], top_of("UG2")
    b.layer = "UG2"
    wall_x("concrete_light", -10.0, IX0, IX1, y, yt, [(-20.0, -18.0, y, y + 3.0), (-1.5, 1.5, y, y + 2.6), (18.0, 20.0, y, y + 3.0)], t=0.4)
    for s in (-1, 1):
        wall_z("concrete_light", s * 6.0, -10.0, IZ1, y, yt, [(0.0, 3.0, y, y + 3.0), (18.0, 21.0, y, y + 3.0)], t=0.3)
        wall_z("concrete_light", s * 12.0, IZ0, -10.0, y, yt, [(-14.0, -12.6, y, y + 2.3)], t=0.4)
    wall_x("concrete_light", -17.0, -12.0, 12.0, y, yt, [(-1.5, 1.5, y, y + 2.6)], t=0.3)
    b.layer = "UG2_Innen"
    # foundry: furnaces with molten gold, hood + ducts, ladle crane, casting line, cooling tank
    for x in (-27.0, -20.5, -14.0):
        box("vault_steel", x - 1.5, x + 1.5, y, y + 1.6, 21.0, 24.0)
        b.cyl("hazard", 0.95, 0.5, (x, y + 1.85, 22.5), 12)
        b.cyl("molten", 0.78, 0.04, (x, y + 2.12, 22.5), 12)
        b.hull("vault_steel", [(x + dx, y + 3.4, z) for dx in (-1.6, 1.6) for z in (20.9, 24.1)] + [(x + dx, y + 4.3, z) for dx in (-0.4, 0.4) for z in (22.1, 22.9)])
        b.beam("pipe", (x, y + 4.3, 22.5), (x, yt, 22.5), 0.5)
        box("frame_black", x + 1.6, x + 2.2, y, y + 1.6, 23.3, 24.0)
        box("screen", x + 1.6, x + 2.2, y + 1.2, y + 1.5, 23.28, 23.3)
        box("safety_yellow", x - 2.2, x + 2.2, y, y + 0.01, 19.8, 20.0)
    b.anchor("Schmelzoefen", (-20.5, y, 19.0), 0)
    for z in (18.0, 26.5):
        box("safety_yellow", -30.5, -8.5, yt - 0.7, yt - 0.4, z - 0.2, z + 0.2)
    box("safety_yellow", -21.2, -19.8, yt - 1.0, yt - 0.7, 17.8, 26.7)
    box("vault_steel", -21.0, -20.0, yt - 1.6, yt - 1.0, 21.8, 22.8)
    b.beam("frame_black", (-20.5, yt - 1.6, 22.3), (-20.5, y + 3.2, 20.0), 0.03)
    b.cyl("hazard", 0.55, 0.9, (-20.5, y + 2.7, 19.6), 10)
    b.cyl("molten", 0.45, 0.03, (-20.5, y + 3.16, 19.6), 10)
    box("vault_steel", -29.0, -9.0, y, y + 0.9, 12.4, 13.6)                               # casting line
    for x in np.arange(-28.6, -9.2, 0.5):
        box("pipe", x - 0.08, x + 0.08, y + 0.9, y + 1.0, 12.5, 13.5)
    for x in np.arange(-28.0, -9.5, 1.0):
        box("frame_black", x - 0.35, x + 0.35, y + 1.0, y + 1.12, 12.7, 13.3)
        b.hull("gold_bar", [(x + dx, y + 1.12, 13.0 + dz) for dx in (-0.25, 0.25) for dz in (-0.12, 0.12)] + [(x + dx, y + 1.2, 13.0 + dz) for dx in (-0.21, 0.21) for dz in (-0.09, 0.09)])
    box("vault_steel", -12.5, -8.5, y, y + 1.0, 4.5, 8.0)
    box("flood_water", -12.3, -8.7, y + 0.6, y + 0.95, 4.7, 7.8)
    b.anchor("Gusslinie", (-19.0, y, 11.5), 0)
    for k, x in enumerate((-27.0, -22.0, -17.0)):                                          # mint presses (Prägerei)
        box("vault_steel", x - 1.0, x + 1.0, y, y + 0.9, 1.0, 3.0)
        for dx in (-0.8, 0.8):
            box("vault_steel", x + dx - 0.15, x + dx + 0.15, y + 0.9, y + 3.4, 1.85, 2.15)
        box("vault_steel", x - 1.0, x + 1.0, y + 3.4, y + 3.9, 1.6, 2.4)
        b.cyl("chrome", 0.25, 1.4, (x, y + 2.7, 2.0), 10)
        b.cyl("frame_black", 0.35, 0.2, (x, y + 1.0, 2.0), 10)
        for j in range(6):
            b.cyl("gold", 0.05, 0.4, (x + 1.4 + 0.12 * (j % 3), y + 0.2, 2.0 + 0.12 * (j // 3)), 8)
        box("cash_green" if k == 1 else "vault_steel", x - 0.5, x + 0.5, y, y + 0.5, 3.6, 4.4)
    b.text("CUNHAGEM DE MOEDAS", "gold", (-22.0, y + 4.5, 0.6), 0.3, 0.02, simplify=0.01)
    b.anchor("Praegerei", (-22.0, y, 5.0), 180)
    for k, x in enumerate((-28.0, -25.5, -23.0, -20.5)):                                    # gold granule bins
        box("safety_yellow", x - 1.0, x + 1.0, y, y + 0.9, -7.5, -5.5)
        b.rock("gold", 0.8, (x, y + 0.85, -6.5), 0.35)
    for x in (-15.0, -11.0):
        box("cloth_white", x - 1.5, x + 1.5, y, y + 0.9, -7.0, -5.8)
        box("frame_black", x - 0.3, x + 0.3, y + 0.9, y + 1.05, -6.7, -6.1)
    for z in np.arange(-6.0, 26.0, 8.0):
        b.beam("pipe", (-30.8, yt - 0.5, z), (-7.0, yt - 0.5, z), 0.35)
    b.text("FUNDIÇÃO", "gold", (-6.25, y + 3.4, 10.0), 0.4, 0.02, rot_y=-90, simplify=0.008)
    # refinery lab (right)
    for z in np.arange(-7.5, 25.0, 4.0):
        box("vault_steel", 29.6, IX1, y, y + 2.4, z - 1.4, z + 1.4)
        box("glass_shop", 29.55, 29.6, y + 1.0, y + 2.0, z - 1.3, z + 1.3)
        b.beam("pipe", (30.5, y + 2.4, z), (30.5, yt, z), 0.3)
    for x in (12.0, 18.0, 24.0):
        box("cloth_white", x - 0.8, x + 0.8, y, y + 0.92, -6.0, 22.0)
        for z in np.arange(-5.0, 21.5, 2.5):
            b.cyl("glass", 0.08, 0.3, (x - 0.3, y + 1.07, z), 6)
            box("frame_black", x + 0.1, x + 0.5, y + 0.92, y + 1.1, z - 0.2, z + 0.2)
    for (x, z) in ((8.5, 20.0), (8.5, 23.5)):
        b.cyl("cloth_white", 1.2, 3.2, (x, y + 1.6, z), 12)
    for k in range(8):
        b.cyl("gem_blue" if k % 2 else "safety_yellow", 0.3, 0.9, (8.0 + (k % 4) * 0.7, y + 0.45, 12.0 + (k // 4) * 0.7), 8)
    b.text("REFINARIA", "gold", (6.25, y + 3.4, 10.0), 0.4, 0.02, rot_y=90, simplify=0.008)
    b.anchor("Raffinerie", (18.0, y, 8.0), 90)
    for x in np.arange(-4.5, 5.0, 1.5):                                                    # gold crate storage (middle)
        for z in np.arange(-8.0, 26.0, 2.5):
            box("crate", x - 0.6, x + 0.6, y, y + 0.7, z - 0.5, z + 0.5)
            if (int(x * 2) + int(z)) % 3 == 0:
                box("crate", x - 0.55, x + 0.55, y + 0.7, y + 1.35, z - 0.45, z + 0.45)
    # vault antechamber: mantrap gates, laser, guard desk, vault lift cage
    for name, z in (("UG2_Gitter_1", -10.0), ("UG2_Gitter_2", -17.0)):
        b.layer = name
        b.pivots[name] = (-1.5, y, z)
        for x in np.arange(-1.4, 1.45, 0.14):
            box("vault_steel", x - 0.025, x + 0.025, y, y + 2.6, z - 0.03, z + 0.03)
        box("vault_steel", -1.5, 1.5, y + 2.5, y + 2.6, z - 0.06, z + 0.06)
    b.layer = "UG2"
    for s in (-1, 1):                                                                     # mantrap corridor: glass walls, guards watch from the side rooms
        wall_z("glass_shop", s * 1.55, -16.85, -10.15, y, yt, t=0.08)
        box("vault_steel", s * 1.55 - 0.08, s * 1.55 + 0.08, y + 2.6, yt, -16.85, -10.15)
    b.layer = "UG2_Innen"
    laser_grid("UG2_Laser", -1.45, 1.45, -16.4, -10.6, y, 6, "z")
    desk(7.5, -13.0, y, 2.4, 1.0, "lacquer", 3)
    chair(7.5, -12.0, y, 180.0, "lacquer")
    box("frame_black", 1.7, 2.0, y + 1.2, y + 1.6, -17.3, -17.15)
    box("led_green", 1.75, 1.95, y + 1.4, y + 1.5, -17.36, -17.3)
    b.anchor("Wache_Tresor", (7.5, y, -11.8), 180)
    b.anchor("Biometrie", (1.85, y, -16.4), 0)
    vx0, vx1, vz0, vz1 = VLIFT
    for xa in (vx0, vx1):
        for za in (vz0, vz1):
            box("vault_steel", xa - 0.12, xa + 0.12, y, yt, za - 0.12, za + 0.12)
    box("fence_net", vx0, vx0 + 0.03, y, yt, vz0, vz1)
    box("fence_net", vx1 - 0.03, vx1, y, yt, vz0, vz1)
    box("fence_net", vx0, vx1, y, yt, vz0, vz0 + 0.03)
    box("fence_net", vx0, vx1, y + 2.8, yt, vz1 - 0.03, vz1)
    b.text("CÂMARA DE OURO", "gold", (0.0, y + 3.5, vz1 + 0.02), 0.35, 0.02, simplify=0.008)
    b.layer = "UG2_Tresoraufzug"
    b.pivots["UG2_Tresoraufzug"] = (0.0, y, (vz0 + vz1) / 2)
    box("vault_steel", vx0 + 0.15, vx1 - 0.15, y - 0.25, y, vz0 + 0.15, vz1 - 0.15)
    for k in range(6):
        box("safety_yellow" if k % 2 == 0 else "hazard", vx0 + 0.15 + k, vx0 + 1.15 + k, y, y + 0.01, vz1 - 0.6, vz1 - 0.15)
    for x in (vx0 + 0.2, vx1 - 0.2):
        box("vault_steel", x - 0.05, x + 0.05, y, y + 2.4, vz0 + 0.2, vz1 - 0.2)
    box("vault_steel", vx0 + 0.15, vx1 - 0.15, y + 2.4, y + 2.5, vz0 + 0.15, vz1 - 0.15)
    b.layer = "UG2_Innen"
    b.anchor("Tresoraufzug_UG2", (0.0, y, vz1 + 0.8), 0)
    # pump room for the flood system
    for k, (x, z) in enumerate(((14.0, -24.0), (14.0, -20.0), (24.0, -12.0), (28.0, -12.0))):
        box("flag_green", x - 0.9, x + 0.9, y, y + 0.9, z - 0.7, z + 0.7)
        cyl_axis("vault_steel", 0.55, 1.4, (x + 1.3, y + 0.6, z), "x", 10)
        b.beam("pipe", (x + 2.0, y + 0.6, z), (x + 2.0, y - 0.5, z), 0.4)
    b.beam("pipe", (13.0, y + 2.4, -14.5), (30.5, y + 2.4, -14.5), 0.45)
    for x in np.arange(14.0, 30.0, 3.0):
        t = trimesh.creation.torus(major_radius=0.35, minor_radius=0.05, major_sections=10, minor_sections=3)
        b.add("gem_red", t.apply_translation((x, y + 2.4, -14.0)))
        b.beam("pipe", (x, y + 2.4, -14.5), (x, y + 2.4, -13.95), 0.08)
    box("frame_black", 23.0, 25.0, y, y + 1.8, -16.2, -15.6)
    box("screen", 23.2, 24.8, y + 1.0, y + 1.6, -15.62, -15.58)
    box("led_red", 23.3, 23.5, y + 1.7, y + 1.75, -15.6, -15.55)
    b.text("CONTROLE DE INUNDAÇÃO", "safety_yellow", (24.0, y + 2.1, -15.58), 0.14, 0.01, simplify=0.004)
    b.anchor("Flutsteuerung", (24.0, y, -14.9), 0)
    mx0, mx1, mz0, mz1 = MST
    b.layer = "UG3_Innen"                                                                  # the steep stair itself lives in the UG3 height range
    flight(mx0 + 0.1, mx1 - 0.1, mz1, mz0, y, LV["UG3"], "vault_steel", "vault_steel")
    b.layer = "UG2_Innen"
    for x in (mx0, mx1):
        box("safety_yellow", x - 0.05, x + 0.05, y, y + 1.1, mz0, mz1)
    box("safety_yellow", mx0, mx1, y, y + 1.1, mz0 - 0.05, mz0 + 0.05)
    b.layer = "UG2_Schott"
    b.pivots["UG2_Schott"] = (mx0, y, mz1)
    box("vault_steel", mx0, mx1, y, y + 2.2, mz1 - 0.05, mz1 + 0.05)
    box("hazard", mx0 + 0.2, mx1 - 0.2, y + 1.9, y + 2.1, mz1 + 0.05, mz1 + 0.07)
    b.layer = "UG2_Innen"
    b.anchor("Wartungstreppe_UG2", ((mx0 + mx1) / 2, y, mz1 + 0.8), 0)
    for k in range(10):                                                                    # guard lockers (back left)
        box("vault_steel", -24.0 + k * 0.6, -23.45 + k * 0.6, y, y + 1.9, -17.0, -16.5)
    for (x, z, yaw) in ((-30.8, 26.9, 135), (-6.6, -9.4, -45), (30.8, 26.9, -135), (0.0, -10.6, 0), (-11.6, -17.6, 45), (11.6, -27.0, -45)):
        cam(cam_id("Kamera_UG2"), x, yt - 0.3, z, yaw)

    # ================================================================ UG3 – Câmara de Ouro
    y, yt = LV["UG3"], top_of("UG3")
    b.layer = "UG3"
    VX0, VX1, VZ0, VZ1 = -22.0, 22.0, -12.0, 22.0                                         # vault interior
    W2 = 2.0
    CH = 1.6                                                                               # flood channel width
    outer = sbox(IX0, IZ0, IX1, IZ1)
    vault_in = sbox(VX0, VZ0, VX1, VZ1)
    channel = vault_in.difference(sbox(VX0 + CH, VZ0 + CH, VX1 - CH, VZ1 - CH))
    flat("concrete", outer.difference(channel), y - SLAB, y - 0.03)
    flat("concrete_light", outer.difference(channel), y - 0.03, y)
    flat("concrete", channel, y - SLAB - 1.0, y - 1.03)
    flat("flood_water", channel, y - 1.03, y - 0.35)
    for (x0_, x1_, z0_, z1_) in ((VX0 + CH - 0.15, VX0 + CH, VZ0 + CH, VZ1 - CH), (VX1 - CH, VX1 - CH + 0.15, VZ0 + CH, VZ1 - CH),
                                 (VX0 + CH, VX1 - CH, VZ0 + CH - 0.15, VZ0 + CH), (VX0 + CH, VX1 - CH, VZ1 - CH, VZ1 - CH + 0.15)):
        box("safety_yellow", x0_, x1_, y, y + 0.15, z0_, z1_)
    box("vault_steel", -2.6, 2.6, y - 0.05, y, VZ0, VZ0 + CH)                             # bridge plate at the door
    wall_x("vault_steel", VZ0 - W2 / 2, VX0 - W2, VX1 + W2, y - 1.0, yt, [(-3.2, 3.2, y, y + 6.4)], t=W2)
    wall_x("vault_steel", VZ1 + W2 / 2, VX0 - W2, VX1 + W2, y - 1.0, yt, t=W2)
    for s in (-1, 1):
        wall_z("vault_steel", s * (VX1 + W2 / 2), VZ0, VZ1, y - 1.0, yt, [(BR[0], BR[1], y, y + 3.2)] if s > 0 else (), t=W2)
    for face_z, sgn in ((VZ0 - W2 - 0.02, -1), (VZ0 + 0.02, 1)):                            # round door frames on both faces
        frame = sbox(-3.8, y, 3.8, y + 7.0).difference(Point(0.0, y + 3.2).buffer(3.05, 24))
        for p in getattr(frame, "geoms", [frame]):
            m = trimesh.creation.extrude_polygon(p, 0.3)
            if sgn < 0:
                m.apply_translation((0, 0, -0.3))
            b.add("chrome", m.apply_translation((0, 0, face_z)))
    TD = (-18.7, -17.5)                                                                    # sketch: door from the tunnel to the maintenance-stair side
    for s in (-1, 1):
        wall_z("concrete", s * 2.6, -19.5, VZ0 - W2, y, yt, [(TD[0], TD[1], y, y + 2.3)] if s > 0 else (), t=0.4)
    b.layer = "UG3_Tunnel_Tuer"
    b.pivots["UG3_Tunnel_Tuer"] = (2.6, y, TD[0])
    box("vault_steel", 2.54, 2.66, y, y + 2.3, TD[0] + 0.02, TD[1] - 0.02)
    box("chrome", 2.66, 2.71, y + 1.0, y + 1.1, TD[1] - 0.3, TD[1] - 0.12)
    box("hazard", 2.66, 2.68, y + 1.95, y + 2.15, TD[0] + 0.1, TD[1] - 0.1)
    b.layer = "UG3_Innen"
    box("frame_black", 2.8, 2.9, y + 1.1, y + 1.5, TD[1] + 0.15, TD[1] + 0.45)          # card reader (outside)
    box("led_red", 2.9, 2.91, y + 1.35, y + 1.42, TD[1] + 0.25, TD[1] + 0.35)
    b.anchor("Tunnel_Tuer", (3.7, y, (TD[0] + TD[1]) / 2), -90)
    b.layer = "UG3_Tresorwand_Sprengstelle"                                                # weak spot in the vault wall: bomb 1
    b.pivots["UG3_Tresorwand_Sprengstelle"] = (VX1 + W2 / 2, y, (BR[0] + BR[1]) / 2)
    box("vault_steel", VX1, VX1 + W2, y, y + 3.2, BR[0], BR[1])
    box("brick_old", VX1 + W2 + 0.01, VX1 + W2 + 0.12, y, y + 3.2, BR[0] + 0.1, BR[1] - 0.1)
    for yy in np.arange(y + 0.25, y + 3.2, 0.25):
        box("concrete_dk", VX1 + W2 + 0.12, VX1 + W2 + 0.14, yy, yy + 0.02, BR[0] + 0.1, BR[1] - 0.1)
    b.layer = "UG3_Innen"
    box("vault_steel", VX1 - CH, VX1, y - 0.05, y, BR[0], BR[1])                          # bridge plate over the flood channel
    # vault door (own node, hinge on the left), time lock, tunnel laser
    b.layer = "UG3_Tresortuer"
    b.pivots["UG3_Tresortuer"] = (-3.1, y + 3.2, VZ0 - W2 / 2)
    m = trimesh.creation.cylinder(radius=3.05, height=1.6, sections=28)
    b.add("vault_steel", m.apply_translation((0.0, y + 3.2, VZ0 - W2 / 2 - 0.1)))
    dz_ = VZ0 - W2                                                                       # outer wall face (-14)
    for k in range(4):                                                                     # wheel handle: 4 spokes + rim
        b.box("chrome", (2.4, 0.12, 0.12), (0.0, y + 3.2, dz_ - 0.3), rot_z=k * 45)
    t = trimesh.creation.torus(major_radius=1.2, minor_radius=0.07, major_sections=16, minor_sections=4)
    b.add("chrome", t.apply_translation((0.0, y + 3.2, dz_ - 0.3)))
    cyl_axis("chrome", 0.35, 0.5, (0.0, y + 3.2, dz_ - 0.15), "z", 12)
    for k in range(16):
        a = k * np.pi / 8
        cyl_axis("chrome", 0.14, 0.3, (2.55 * np.cos(a), y + 3.2 + 2.55 * np.sin(a), dz_ + 0.05), "z", 8)
    ring_ = trimesh.creation.annulus(r_min=2.75, r_max=3.0, height=0.12, sections=28)
    b.add("brass", ring_.apply_translation((0.0, y + 3.2, dz_ + 0.04)))
    b.layer = "UG3_Innen"
    box("frame_black", 3.8, 4.4, y + 1.3, y + 2.1, VZ0 - W2 - 0.3, VZ0 - W2 - 0.05)
    box("led_red", 3.95, 4.25, y + 1.75, y + 1.9, VZ0 - W2 - 0.32, VZ0 - W2 - 0.3)
    b.anchor("Zeitschloss", (4.1, y, VZ0 - W2 - 1.0), 180)
    b.anchor("Tresor_Tuer", (0.0, y, VZ0 - W2 - 2.0), 0)
    laser_grid("UG3_Tunnel_Laser", -2.4, 2.4, TD[1] + 0.35, VZ0 - W2 - 0.4, y, 6, "z")   # starts behind the side door
    vx0, vx1, vz0, vz1 = VLIFT
    for xa in (vx0, vx1):
        box("concrete", xa - 0.2, xa + 0.2, y, yt, vz0, vz1)
    box("concrete", vx0, vx1, y, yt, vz0 - 0.2, vz0)
    b.anchor("Tresoraufzug_UG3", (0.0, y, vz1 + 0.8), 0)
    for z in np.arange(-19.0, VZ0 - W2, 1.5):
        box("lamp", -0.5, 0.5, yt - 0.1, yt - 0.05, z - 0.3, z + 0.3)
    # gold: pallets in a grid, side racks, cash cages, central table
    ng = 0
    for sx in (-1, 1):
        for i, ax in enumerate(np.arange(3.8, 17.0, 2.6)):
            for j, z in enumerate(np.arange(-8.6, 11.0, 2.4)):
                ng += 1
                gold_pallet(sx * ax, y, z, (0.9, 1.25, 1.55)[(i + j) % 3], f"UG3_Beute_Gold_{ng}")
    for s in (-1, 1):
        xr = s * (VX1 - CH - 0.9)
        for (za_, zb_) in (((-8.0, 1.6), (6.4, 14.0)) if s > 0 else ((-8.0, 14.0),)):        # the east rack leaves the breach free
            for yy in (y, y + 1.0, y + 2.0, y + 3.0):
                box("vault_steel", xr - 0.5, xr + 0.5, yy, yy + 0.06, za_, zb_)
                box("gold_bar", xr - 0.4, xr + 0.4, yy + 0.06, yy + 0.3, za_ + 0.2, zb_ - 0.2)
            for z in list(np.arange(za_, zb_ + 0.01, 2.2)) + [zb_]:
                box("vault_steel", xr - 0.5, xr + 0.5, y, y + 3.4, z - 0.04, z + 0.04)
    nb = 0
    for s in (-1, 1):
        for k in range(3):
            x = s * (6.0 + k * 3.4)
            box("fence_net", x - 1.5, x + 1.5, y, y + 2.6, 15.0, 15.04)
            box("fence_net", x - 1.5, x - 1.46, y, y + 2.6, 15.0, 19.6)
            nb += 1
            b.layer = f"UG3_Beute_Bargeld_{nb}"
            b.pivots[b.layer] = (x, y, 17.6)
            for j in range(3):
                for i in range(4):
                    box("cash_green", x - 1.2 + i * 0.6, x - 0.8 + i * 0.6, y + j * 0.32, y + 0.3 + j * 0.32, 16.0, 19.2)
            b.layer = "UG3_Innen"
    box("walnut", -2.0, 2.0, y, y + 0.9, 3.5, 6.5)
    for k in range(12):
        b.add(GEMS[k % 4], octa(0.07).apply_translation((-1.5 + (k % 4) * 1.0, y + 0.98, 4.0 + (k // 4) * 1.0)))
    b.anchor("Tresor", (0.0, y, 0.0), 0)
    b.anchor("Goldpaletten", (-8.0, y, 2.0), 0)
    b.anchor("Bargeld", (9.0, y, 17.0), 0)
    # diamond chamber at the far end (glass box with its own laser grid + the 'Coração do Brasil')
    for x in (-5.0, 5.0):
        box("glass_shop", x - 0.03, x + 0.03, y, y + 3.0, 13.5, VZ1 - CH - 0.2)
    for (xa, xb) in ((-5.0, -1.0), (1.0, 5.0)):
        box("glass_shop", xa, xb, y, y + 3.0, 13.47, 13.53)
    box("glass_shop", -5.0, 5.0, y + 3.0, y + 3.04, 13.5, VZ1 - CH - 0.2)
    for (x0_, x1_, z0_, z1_) in ((-5.1, 5.1, 13.4, 13.6), (-5.1, 5.1, VZ1 - CH - 0.3, VZ1 - CH - 0.1), (-5.1, -4.9, 13.4, VZ1 - CH - 0.1), (4.9, 5.1, 13.4, VZ1 - CH - 0.1)):
        box("vault_steel", x0_, x1_, y + 3.0, y + 3.15, z0_, z1_)
    b.layer = "UG3_Glastuer"                                                               # sliding glass door of the diamond chamber
    b.pivots["UG3_Glastuer"] = (0.0, y, 13.5)
    box("glass_shop", -1.0, 1.0, y, y + 2.6, 13.46, 13.54)
    box("chrome", -1.0, 1.0, y + 2.55, y + 2.65, 13.44, 13.56)
    b.layer = "UG3_Innen"
    laser_grid("UG3_Laser", -4.9, 4.9, 14.0, 19.8, y, 6, "z")
    box("marble_black", -0.6, 0.6, y, y + 1.2, 17.4, 18.6)
    b.layer = "UG3_Beute_Edelstein_Coracao"
    b.pivots["UG3_Beute_Edelstein_Coracao"] = (0.0, y + 1.5, 18.0)
    hm = trimesh.convex.convex_hull(np.array([(0.32 * np.cos(a), 0.12 * np.sin(2 * a), 0.18 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 13)[:-1]] + [(0, -0.4, 0), (0, 0.25, 0)]))
    b.add("gem_red", hm.apply_translation((0.0, y + 1.65, 18.0)))
    b.layer = "UG3_Innen"
    b.anchor("Coracao_do_Brasil", (0.0, y + 1.2, 18.0), 0)
    for k, x in enumerate((-3.8, 3.8)):
        box("lacquer", x - 0.8, x + 0.8, y, y + 1.0, 16.0, 19.0)
        b.layer = f"UG3_Beute_Schmuck_{k + 1}"
        b.pivots[b.layer] = (x, y + 1.0, 17.5)
        tray(x - 0.7, x + 0.7, 16.1, 18.9, y + 1.0, "mix", 0.35)
        b.layer = "UG3_Innen"
    # flood system: inlet pipes + sluice gates (own nodes), level marks, overhead crane rails
    inlets = ((-14.0, VZ0 + 0.05, "z+"), (14.0, VZ0 + 0.05, "z+"), (-14.0, VZ1 - 0.05, "z-"), (14.0, VZ1 - 0.05, "z-"))
    for k, (x, z, d) in enumerate(inlets):
        sz_ = 1 if d == "z+" else -1
        cyl_axis("pipe", 0.85, 1.6, (x, yt - 1.6, z + sz_ * 0.8), "z", 14)
        name = f"UG3_Flutschieber_{k + 1}"
        b.layer = name
        b.pivots[name] = (x, yt - 1.6, z + sz_ * 1.65)
        box("vault_steel", x - 1.0, x + 1.0, yt - 2.6, yt - 0.6, z + sz_ * 1.6 - 0.08, z + sz_ * 1.6 + 0.08)
        box("hazard", x - 0.9, x + 0.9, yt - 2.5, yt - 2.3, z + sz_ * 1.69 - 0.01, z + sz_ * 1.69 + 0.01)
        b.layer = "UG3_Innen"
        b.anchor(name, (x, y, z + sz_ * 3.0), 0 if sz_ > 0 else 180)
    for s in (-1, 1):
        for k, hh in enumerate((1.0, 2.0, 3.0, 4.0)):
            box("safety_yellow", s * (VX1 - 0.02) - 0.02, s * (VX1 - 0.02) + 0.02, y + hh - 0.04, y + hh, -2.0, 6.0)
            b.text(f"{hh:.0f} m", "safety_yellow", (s * (VX1 - 0.05), y + hh + 0.25, 2.0), 0.3, 0.01, rot_y=-90 * s, simplify=0.006)
        box("safety_yellow", s * 17.0 - 0.18, s * 17.0 + 0.18, yt - 0.6, yt - 0.3, VZ0, VZ1)
    box("safety_yellow", -17.0, 17.0, yt - 0.9, yt - 0.6, 3.9, 4.3)
    box("vault_steel", -0.8, 0.8, yt - 1.6, yt - 0.9, 3.4, 4.8)
    b.beam("frame_black", (0.0, yt - 1.6, 4.1), (0.0, y + 2.6, 4.1), 0.03)
    b.layer = "UG3_Flutwasser"
    b.pivots["UG3_Flutwasser"] = (0.0, y, 5.0)
    box("flood_water", VX0, VX1, y - 0.3, y - 0.28, VZ0, VZ1)                             # hidden in the slab: move up in +Y to flood
    b.layer = "UG3_Innen"
    b.anchor("Flutwasser", (0.0, y, 5.0), 0)
    # east service corridor: maintenance stair landing, sewer access, weak brick wall, escape tunnel
    for z in np.arange(-26.0, 26.0, 4.0):
        b.beam("pipe", (30.6, yt - 0.5, z), (30.6, yt - 0.5, z + 4.0), 0.25)
    b.anchor("Sprengladung_Tresor", (VX1 + W2 + 0.8, y, (BR[0] + BR[1]) / 2), -90)
    # sewer blast point: old Maya stones fill the opening in the east outer wall (bomb 2) -> Maya sewer kit (Kanal_Anschluss)
    b.layer = "UG3_Kanalwand"
    b.pivots["UG3_Kanalwand"] = (X1 - T / 2, y, (KW[0] + KW[1]) / 2)
    for i, yy in enumerate(np.arange(y, y + 3.0 - 1e-6, 0.5)):
        cuts = [KW[0]] + [v for v in np.arange(KW[0] + (0.75 if i % 2 else 1.25), KW[1] - 0.3, 1.0)] + [KW[1]]
        for k_, (za, zb) in enumerate(zip(cuts[:-1], cuts[1:])):
            box("maya_kalk" if (i + k_) % 3 else "maya_kalk_dunkel", X1 - T + 0.01, X1 - 0.01, yy + 0.02, yy + 0.48, za + 0.02, zb - 0.02)
    zc_ = (KW[0] + KW[1]) / 2
    box("maya_rot", X1 - T - 0.02, X1 - T + 0.01, y + 1.1, y + 2.3, zc_ - 0.6, zc_ + 0.6)                  # glyph: 2 bars + 3 dots
    for k_ in range(2):
        box("maya_jade", X1 - T - 0.05, X1 - T - 0.02, y + 1.3 + k_ * 0.22, y + 1.42 + k_ * 0.22, zc_ - 0.45, zc_ + 0.45)
    for k_ in range(3):
        box("maya_jade", X1 - T - 0.05, X1 - T - 0.02, y + 1.85, y + 2.0, zc_ - 0.38 + k_ * 0.3, zc_ - 0.22 + k_ * 0.3)
    b.layer = "UG3_Innen"
    for k in range(4):
        box("crate", 29.2 + (k % 2) * 0.9, 29.9 + (k % 2) * 0.9, y + (k // 2) * 0.6, y + 0.55 + (k // 2) * 0.6, 7.0, 7.7)
    b.anchor("Sprengladung_Kanal", (X1 - T - 0.8, y, zc_), 90)
    b.anchor("Kanal_Anschluss", (X1, y, zc_), 90)
    for (nm, x, z, yaw) in (("Wache_UG3_Tunnel", 4.5, -20.5, 0), ("Wache_UG3_Gang_1", 27.5, -12.0, 0), ("Wache_UG3_Gang_2", 27.5, 14.0, 180),
                            ("Wache_UG3_Tresor_1", -10.0, 13.0, 180), ("Wache_UG3_Tresor_2", 10.3, -9.8, 0)):
        b.anchor(nm, (x, y, z), yaw)
    for z in np.arange(-20.0, 26.0, 6.0):
        box("lamp", 27.8, 29.2, yt - 0.1, yt - 0.05, z - 0.4, z + 0.4)
    for (x, z, yaw) in ((VX0 + 0.6, VZ0 + 0.6, 135), (VX1 - 0.6, VZ0 + 0.6, -135), (VX0 + 0.6, VZ1 - 0.6, 45), (VX1 - 0.6, VZ1 - 0.6, -45),
                        (0.0, 13.6, 180), (-2.2, -19.0, 0), (28.5, -24.0, 0)):
        cam(cam_id("Kamera_UG3"), x, yt - 0.6, z, yaw)

    # ================================================================ DACH – roof, dome + stained glass, turrets, helipad
    b.layer = "Dach"
    rp = sbox(X0, Z0, X1, Z1).difference(Point(DCX, DCZ).buffer(DR, 48)).difference(sbox(CORE_R[0], CORE_R[2], CORE_R[1], CORE_R[3]))
    flat("dach", rp, TOP, TOP + 0.5)
    from shapely.ops import unary_union
    strips = [sbox(x - 0.06, Z0, x + 0.06, Z1) for x in np.arange(-28.0, 28.1, 4.0)] + [sbox(X0, z - 0.06, X1, z + 0.06) for z in np.arange(-24.0, 24.1, 4.0)]
    grid = unary_union(strips).difference(Point(DCX, DCZ).buffer(DR + 0.7, 48)).difference(sbox(CORE_R[0], CORE_R[2], X1, CORE_R[3] + 0.4))
    flat("dach_rand", grid, TOP + 0.5, TOP + 0.52)
    for sx in (-1, 1):                                                                     # barrel-vault skylights over the wings
        cx = sx * 24.5
        box("dach_rand", cx - 2.8, cx + 2.8, TOP + 0.5, TOP + 1.0, -12.4, 14.4)
        b.hull("glass", [(cx + 2.4 * np.cos(a), TOP + 1.0 + 2.4 * np.sin(a), z) for a in np.linspace(0, np.pi, 9) for z in (-12.0, 14.0)])
        for z in np.arange(-12.0, 14.1, 2.0):
            arc = [(cx + 2.45 * np.cos(a), TOP + 1.0 + 2.45 * np.sin(a), z) for a in np.linspace(0, np.pi, 7)]
            for p0, p1 in zip(arc[:-1], arc[1:]):
                b.beam("dach_bronze", p0, p1, 0.1)
        b.beam("dach_bronze", (cx, TOP + 3.45, -12.0), (cx, TOP + 3.45, 14.0), 0.14)
    ring_y("dach_rand", DCX, DCZ, DR - 0.6, DR + 0.0, TOP - 0.6, TOP + 0.5, 48)
    # stained glass ceiling (seen from the hall below)
    for i, (r0, r1) in enumerate(((1.6, 5.0), (5.0, 8.5), (8.5, DR - 0.6))):
        n = 12 * (i + 1)
        for k in range(n):
            a0, a1 = k * 2 * np.pi / n, (k + 1) * 2 * np.pi / n
            mat = ("dach_vitral_r", "dach_vitral_b", "dach_vitral_y", "dach_vitral_g")[(k + i) % 4] if i != 1 else ("dach_vitral_b", "dach_vitral_y")[k % 2]
            pts = [(DCX + r * np.cos(a), yy, DCZ + r * np.sin(a)) for r in (r0, r1) for a in (a0, a1) for yy in (TOP - 0.35, TOP - 0.3)]
            b.hull(mat, pts)
        ring_y("dach_bronze", DCX, DCZ, r1 - 0.08, r1 + 0.08, TOP - 0.38, TOP - 0.27, 48)
    b.cyl("dach_vitral_y", 1.6, 0.06, (DCX, TOP - 0.32, DCZ), 16)
    for k in range(24):
        a = k * np.pi / 12
        b.beam("dach_bronze", (DCX + 1.6 * np.cos(a), TOP - 0.3, DCZ + 1.6 * np.sin(a)), (DCX + (DR - 0.6) * np.cos(a), TOP - 0.3, DCZ + (DR - 0.6) * np.sin(a)), 0.06)
    # giant chandelier hanging from the stained glass over the diamond
    b.beam("dach_bronze", (DCX, TOP - 0.3, DCZ), (DCX, 17.5, DCZ), 0.06)
    for i, (r, yy, n) in enumerate(((3.2, 17.4, 24), (2.4, 16.6, 18), (1.6, 15.8, 14), (0.9, 15.0, 10))):
        t = trimesh.creation.torus(major_radius=r, minor_radius=0.06, major_sections=24, minor_sections=3)
        t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        b.add("dach_bronze", t.apply_translation((DCX, yy, DCZ)))
        for k in range(n):
            a = k * 2 * np.pi / n
            b.add("diamond", octa(0.1, 2.2).apply_translation((DCX + r * np.cos(a), yy - 0.3, DCZ + r * np.sin(a))))
            if k % 3 == 0:
                b.cyl("dach_licht", 0.05, 0.25, (DCX + r * np.cos(a), yy + 0.15, DCZ + r * np.sin(a)), 6)
        for k in range(6):
            a = k * np.pi / 3
            b.beam("dach_bronze", (DCX, yy + 0.8, DCZ), (DCX + r * np.cos(a), yy, DCZ + r * np.sin(a)), 0.03)
    # drum + dome + lantern
    ring_y("stone_imperial", DCX, DCZ, DR, DR + 0.6, TOP + 0.5, TOP + 5.5, 48)
    for k in range(16):
        a = k * np.pi / 8
        c, s_ = np.cos(a), np.sin(a)
        yaw = np.degrees(np.arctan2(c, s_))
        b.box("glass", (1.4, 2.6, 0.08), (DCX + (DR + 0.62) * c, TOP + 2.8, DCZ + (DR + 0.62) * s_), rot_y=yaw)
        b.box("stone_dark", (1.8, 3.1, 0.06), (DCX + (DR + 0.6) * c, TOP + 2.8, DCZ + (DR + 0.6) * s_), rot_y=yaw)
        a2 = a + np.pi / 16
        b.box("stone_imperial", (0.6, 5.0, 0.35), (DCX + (DR + 0.75) * np.cos(a2), TOP + 3.0, DCZ + (DR + 0.75) * np.sin(a2)), rot_y=np.degrees(np.arctan2(np.cos(a2), np.sin(a2))))
    ring_y("stone_imperial", DCX, DCZ, DR - 0.2, DR + 1.3, TOP + 5.5, TOP + 6.0, 48)
    nlon, nlat = 32, 7
    r_top = 2.4
    phi_max = np.arccos(r_top / (DR + 0.6))
    V, F = [], []
    for i in range(nlat + 1):
        phi = phi_max * i / nlat
        rr = (DR + 0.6) * np.cos(phi)
        yy = TOP + 6.0 + 11.0 * np.sin(phi) / np.sin(phi_max)
        for j in range(nlon):
            th = 2 * np.pi * j / nlon
            V.append((DCX + rr * np.cos(th), yy, DCZ + rr * np.sin(th)))
    for i in range(nlat):
        for j in range(nlon):
            a_, b_ = i * nlon + j, i * nlon + (j + 1) % nlon
            c_, d_ = (i + 1) * nlon + (j + 1) % nlon, (i + 1) * nlon + j
            F += [(a_, b_, c_), (a_, c_, d_)]
    dome = trimesh.Trimesh(np.array(V), np.array(F), process=False)
    cen = np.array([DCX, TOP + 6.0, DCZ])
    flip = (dome.face_normals * (dome.triangles_center - cen)).sum(1) < 0
    Fa = np.array(F)
    Fa[flip] = Fa[flip][:, ::-1]
    b.add("dome_green", trimesh.Trimesh(np.array(V), Fa, process=False))
    for j in range(0, nlon, 2):
        pts = [V[i * nlon + j] for i in range(nlat + 1)]
        for p, q in zip(pts[:-1], pts[1:]):
            pp = np.array(p) + (np.array(p) - cen) * 0.01
            qq = np.array(q) + (np.array(q) - cen) * 0.01
            b.beam("dome_rib", tuple(pp), tuple(qq), 0.22)
    ytop_d = TOP + 17.0
    ring_y("dome_rib", DCX, DCZ, r_top - 0.2, r_top + 0.2, ytop_d - 0.2, ytop_d + 0.2, 24)
    for k in range(8):
        a = k * np.pi / 4
        b.cyl("stone_imperial", 0.15, 3.0, (DCX + 2.1 * np.cos(a), ytop_d + 1.7, DCZ + 2.1 * np.sin(a)), 6)
    b.cyl("glass", 1.9, 2.9, (DCX, ytop_d + 1.65, DCZ), 12)
    b.cyl("dach_licht", 0.8, 1.2, (DCX, ytop_d + 1.6, DCZ), 8)
    b.cyl("stone_imperial", 2.5, 0.3, (DCX, ytop_d + 3.3, DCZ), 16)
    b.hull("dome_green", [(DCX + 2.4 * np.cos(a), ytop_d + 3.45, DCZ + 2.4 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 13)[:-1]] + [(DCX, ytop_d + 5.5, DCZ)])
    b.cyl("gold", 0.25, 0.5, (DCX, ytop_d + 5.6, DCZ), 8)
    b.add("gold", trimesh.creation.icosphere(subdivisions=1, radius=0.45).apply_translation((DCX, ytop_d + 6.2, DCZ)))
    flagpole(DCX, ytop_d + 6.6, DCZ, 6.0, "flag_green")
    b.cyl("led_red", 0.15, 0.25, (DCX, ytop_d + 12.8, DCZ), 8)
    b.anchor("Kuppel_Laterne", (DCX, ytop_d + 0.2, DCZ + 2.6), 0)
    # roof balustrade, corner turrets with searchlights, flags, roof hatches, AC, vent cap, antennas
    for (x0_, z0_, x1_, z1_) in ((X0 + 0.3, Z1 - 0.3, X1 - 0.3, Z1 - 0.3), (X0 + 0.3, Z0 + 0.3, CORE_R[0] - 0.3, Z0 + 0.3),
                                 (X0 + 0.3, Z0 + 0.3, X0 + 0.3, Z1 - 0.3), (X1 - 0.3, CORE_R[3] + 0.3, X1 - 0.3, Z1 - 0.3)):
        balustrade(x0_, z0_, x1_, z1_, TOP + 0.5, 1.1, "dach_rand", 0.8)
    for sx in (-1, 1):
        for sz in (-1, 1):
            if sx > 0 and sz < 0:
                continue
            tx, tz = sx * 29.0, sz * 25.0
            b.hull("dach_rand", [(tx + 2.0 * np.cos(a), yy, tz + 2.0 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1] for yy in (TOP + 0.5, TOP + 4.5)])
            for k in range(8):
                a = k * np.pi / 4 + np.pi / 8
                b.box("glass", (0.6, 1.0, 0.06), (tx + 2.0 * np.cos(a), TOP + 3.2, tz + 2.0 * np.sin(a)), rot_y=np.degrees(np.arctan2(np.cos(a), np.sin(a))))
            b.hull("dome_green", [(tx + 2.3 * np.cos(a), TOP + 4.5, tz + 2.3 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] + [(tx, TOP + 7.0, tz)])
            b.add("gold", trimesh.creation.icosphere(subdivisions=0, radius=0.25).apply_translation((tx, TOP + 7.2, tz)))
            sl = (tx - sx * 2.8, TOP + 1.6, tz - sz * 1.2)
            b.cyl("dach_stahl", 0.15, 1.1, (sl[0], TOP + 1.05, sl[2]), 6)
            b.box("dach_licht", (0.7, 0.5, 0.7), sl, rot_x=-20 * sz)
            b.anchor(f"Wachturm_{'W' if sx < 0 else 'O'}{'N' if sz < 0 else 'S'}", (tx, TOP + 0.5, tz), 0)
    for x in (-8.0, 0.0, 8.0):
        flagpole(x, TOP + 0.5, 26.2, 9.0, ("flag_green", "flag_gold", "flag_white")[int(x / 8) + 1])
    HX, HZ = -14.0, -19.0                                                                  # helipad
    box("dach_rand", HX - 6.5, HX + 6.5, TOP + 0.5, TOP + 1.7, HZ - 6.5, HZ + 6.5)
    b.cyl("helipad", 6.0, 0.06, (HX, TOP + 1.73, HZ), 24)
    t = trimesh.creation.annulus(r_min=5.3, r_max=5.6, height=0.02, sections=24)
    t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    b.add("dach_gelb", t.apply_translation((HX, TOP + 1.77, HZ)))
    for (x0_, x1_, z0_, z1_) in ((HX - 1.5, HX - 1.0, HZ - 2.2, HZ + 2.2), (HX + 1.0, HX + 1.5, HZ - 2.2, HZ + 2.2), (HX - 1.0, HX + 1.0, HZ - 0.25, HZ + 0.25)):
        box("cloth_white", x0_, x1_, TOP + 1.76, TOP + 1.78, z0_, z1_)
    for k in range(12):
        a = k * np.pi / 6
        b.cyl("led_green", 0.08, 0.1, (HX + 6.2 * np.cos(a), TOP + 1.8, HZ + 6.2 * np.sin(a)), 6)
    for k in range(6):
        box("dach_rand", HX + 6.5 + k * 0.3, HX + 6.8 + k * 0.3, TOP + 0.5, TOP + 1.7 - k * 0.2, HZ - 1.0, HZ + 1.0)
    b.anchor("Hubschrauber", (HX, TOP + 1.77, HZ), 0)
    cx0, cx1, cz0, cz1 = CORE_R                                                            # roof stair house
    wall_z("dach_rand", cx0 + 0.15, Z0, cz1 + 0.3, TOP + 0.5, TOP + 3.6, [(cz1 - 1.6, cz1 - 0.4, TOP + 0.5, TOP + 2.8)], t=0.3)
    wall_z("dach_rand", X1 - 0.15, Z0, cz1 + 0.3, TOP + 0.5, TOP + 3.6, t=0.3)
    wall_x("dach_rand", Z0 + 0.15, cx0, X1, TOP + 0.5, TOP + 3.6, t=0.3)
    wall_x("dach_rand", cz1 + 0.15, cx0, X1, TOP + 0.5, TOP + 3.6, t=0.3)
    box("dach_rand", cx0 - 0.2, X1 + 0.1, TOP + 3.6, TOP + 4.0, Z0 - 0.1, cz1 + 0.5)
    box("dach_stahl", cx0 + 0.3, cx1 - 0.3, TOP + 0.2, TOP + 0.5, cz1 - 1.8, cz1 - 0.05)       # top landing of the stair
    box("dach_licht", cx0 - 0.25, cx0, TOP + 2.95, TOP + 3.1, cz1 - 1.3, cz1 - 0.7)
    b.layer = "Dach_Tuer"
    b.pivots["Dach_Tuer"] = (cx0, TOP + 0.5, cz1 - 1.6)
    box("door_metal", cx0 - 0.05, cx0 + 0.05, TOP + 0.5, TOP + 2.8, cz1 - 1.6, cz1 - 0.4)
    b.layer = "Dach"
    b.anchor("Dachtuer", (cx0 - 0.8, TOP + 0.5, cz1 - 1.0), -90)
    box("vault_steel", 10.0, 11.4, TOP + 0.5, TOP + 0.85, -22.0, -20.6)
    b.anchor("Dachluke", (10.7, TOP + 0.85, -21.3), 0)
    for (x, z) in ((10.0, -15.0), (13.0, -15.0), (16.0, -15.0), (10.0, -11.5), (13.0, -11.5), (16.0, -11.5)):
        box("ac", x - 1.1, x + 1.1, TOP + 0.5, TOP + 1.8, z - 1.1, z + 1.1)
        b.cyl("frame_black", 0.75, 0.05, (x, TOP + 1.83, z), 10)
    box("vault_steel", VENT[0], VENT[1], TOP + 0.5, TOP + 2.2, VENT[2], VENT[3])
    for yy in np.arange(TOP + 0.7, TOP + 2.1, 0.2):
        box("frame_black", VENT[0] - 0.02, VENT[1] + 0.02, yy, yy + 0.05, VENT[2] - 0.02, VENT[3] + 0.02)
    b.anchor("Lueftungsschacht_Dach", ((VENT[0] + VENT[1]) / 2, TOP + 2.2, (VENT[2] + VENT[3]) / 2), 0)
    for (x, z, h) in ((18.5, 20.0, 10.0), (20.5, 23.0, 7.0)):
        b.beam("dach_stahl", (x, TOP + 0.5, z), (x, TOP + 0.5 + h, z), 0.07)
        b.cyl("led_red", 0.12, 0.2, (x, TOP + 0.6 + h, z), 6)
    b.cyl("cloth_white", 0.6, 0.06, (20.0, TOP + 1.6, 6.0), 12)
    b.beam("dach_stahl", (20.0, TOP + 0.5, 6.0), (20.0, TOP + 1.6, 6.0), 0.05)
    for (x, z, yaw) in ((-31.6, 27.6, 180), (31.6, -27.6, 0), (0.0, -27.6, 0), (-31.6, -27.6, 0)):
        cam(cam_id("Kamera_Dach"), x, TOP + 1.8, z, yaw)
    b.layer = None
    for (nm, lv, x, z, yaw) in (("Wache_EG_Salon_W", "EG", -22.3, 0.5, 90), ("Wache_EG_Salon_O", "EG", 23.2, 1.0, -90), ("Wache_EG_Halle", "EG", 0.0, -12.3, 0),
                                ("Wache_OG1_1", "OG1", -16.0, 16.0, 135), ("Wache_OG1_2", "OG1", 16.0, 16.0, -135), ("Wache_OG1_3", "OG1", 0.0, -12.0, 0),
                                ("Wache_OG2_1", "OG2", -16.0, -12.0, 45), ("Wache_OG2_2", "OG2", 16.0, 16.0, -135),
                                ("Wache_OG3_1", "OG3", 0.0, 16.6, 180), ("Wache_OG3_2", "OG3", -16.0, -12.0, 45), ("Wache_OG3_3", "OG3", 16.0, -12.0, -45),
                                ("Wache_UG1_1", "UG1", -10.0, 0.0, 90), ("Wache_UG1_2", "UG1", 10.0, 10.0, -90), ("Wache_UG1_3", "UG1", 0.0, -20.0, 0),
                                ("Wache_UG2_1", "UG2", -6.0, -16.0, 0), ("Wache_UG2_2", "UG2", 6.5, 10.0, 180)):
        b.anchor(nm, (x, LV[lv], z), yaw)
    for (nm, x, z, yaw) in (("Wache_Dach_1", 0.0, -20.0, -90), ("Wache_Dach_2", 18.0, 20.0, 180)):
        b.anchor(nm, (x, TOP + 0.5, z), yaw)

    def abriegelung():
        """Lockdown state (like in the heist series): steel roller shutters on every window, blast doors in front of the portals,
        welded beams on the truck gate, steel grilles in the security lanes, roof sealed, barricades, power off (red emergency light)."""
        remap = {"lamp": "lamp_aus", "dach_licht": "lamp_aus", "sign_light": "lamp_aus", "glass": "glass_aus",
                 "glass_shop": "glass_shop_aus", "screen": "screen_aus", "led_green": "led_aus"}
        for src, dst in remap.items():
            if dst not in ("lamp_aus",):
                PALETTE.setdefault(dst, {"screen_aus": "#1C2A30", "led_aus": "#2A3A2E"}.get(dst, PALETTE.get(src, "#6F98AE")))
            if src in ALPHA:
                ALPHA.setdefault(dst, ALPHA[src])
        for key in list(b.parts):
            layer, mat = key if isinstance(key, tuple) else (None, key)
            if mat == "laser_red":                                                         # lasers off (power cut)
                del b.parts[key]
            elif mat in remap:
                nk = (layer, remap[mat]) if layer else remap[mat]
                b.parts[nk].extend(b.parts.pop(key))
        FN = {"front": "Vorne", "back": "Hinten", "left": "Links", "right": "Rechts"}

        def shutters(node, face, items):                                                   # items: (u, y0, h, w); pivot = top edge (roll down = scale Y)
            if not items:
                return
            ytop_ = max(y0 + h for (u, y0, h, w) in items) + 0.05
            b.layer = node
            b.pivots[node] = fpt(face, 0.0, ytop_, 0.23)
            for (u, y0, h, w) in items:
                fbox(face, "rolladen", u - w / 2 - 0.15, u + w / 2 + 0.15, y0 - 0.12, y0 + h + 0.05, 0.21, 0.25)
                for k in range(1, 4):
                    yy = y0 + h * k / 4
                    fbox(face, "rolladen_dunkel", u - w / 2 - 0.15, u + w / 2 + 0.15, yy - 0.025, yy + 0.025, 0.25, 0.256)
            b.layer = "Abriegelung_" + node.split("_")[1] + "_Kaesten"                     # housings per level (static)
            for (u, y0, h, w) in items:
                fbox(face, "rolladen_dunkel", u - w / 2 - 0.2, u + w / 2 + 0.2, y0 + h + 0.05, y0 + h + 0.3, 0.15, 0.36)

        wy, wh, ww, _ = WIN["EG"]
        shutters("Abriegelung_EG_Hinten", "back", [(u, wy, wh, ww) for u in (-28.0, -24.0, -20.0, -16.0, -12.0, -8.0, 8.0, 16.0, 20.0, 24.0, 28.0)])
        shutters("Abriegelung_EG_Vorne", "front", [((a + c) / 2, ya, yb_ - ya, c - a) for (a, c, ya, yb_) in FRONT_EG if (a, c) not in PORTALS])
        for face in ("left", "right"):
            shutters(f"Abriegelung_EG_{FN[face]}", face, [(u, wy, wh, ww) for u in np.arange(-24.0, 24.1, 4.0)])
        for lv in ("OG1", "OG2", "OG3"):
            wy, wh, ww, _ = WIN[lv]
            us = np.arange(-28.0, 28.1, 4.0)
            shutters(f"Abriegelung_{lv}_Hinten", "back", [(u, wy, wh, ww) for u in us])
            shutters(f"Abriegelung_{lv}_Vorne", "front", [(u, wy, wh, ww) for u in us if lv in ("OG1", "OG3") or abs(u) > 25.5])
            for face in ("left", "right"):
                shutters(f"Abriegelung_{lv}_{FN[face]}", face, [(u, wy, wh, ww) for u in np.arange(-24.0, 24.1, 4.0)])
        b.layer = "Abriegelung_EG_Portale"                                                # blast doors in front of the bronze portals
        b.pivots[b.layer] = (0.0, 8.45, Z1 + 0.25)
        for (a, c) in PORTALS:
            box("panzer", a - 0.35, c + 0.35, yE, 8.45, Z1 + 0.05, Z1 + 0.4)
            for xx in np.linspace(a - 0.15, c + 0.15, 4):
                box("rolladen_dunkel", xx - 0.08, xx + 0.08, yE, 8.4, Z1 + 0.4, Z1 + 0.5)
            for yy in (yE + 1.6, yE + 3.6, yE + 5.6):
                box("rolladen_dunkel", a - 0.3, c + 0.3, yy - 0.1, yy + 0.1, Z1 + 0.4, Z1 + 0.5)
            for k in range(int(np.ceil((c - a + 0.7) / 0.5))):
                xx = a - 0.35 + k * 0.5
                box("safety_yellow" if k % 2 == 0 else "hazard", xx, min(xx + 0.5, c + 0.35), yE + 0.05, yE + 0.5, Z1 + 0.5, Z1 + 0.52)
        b.layer = "Abriegelung_EG_Lkw_Tor"                                                # welded beams across the truck gate
        b.pivots[b.layer] = (0.0, yE, Z0 - 0.2)
        for yy in (yE + 0.8, yE + 2.5, yE + 4.2):
            box("panzer", -4.7, 4.7, yy - 0.18, yy + 0.18, Z0 - 0.4, Z0 - 0.05)
        for xx in (-4.4, 0.0, 4.4):
            box("panzer", xx - 0.15, xx + 0.15, yE, yE + 5.2, Z0 - 0.45, Z0 - 0.1)
        b.layer = "Abriegelung_EG_Hintertuer"
        b.pivots[b.layer] = (12.6, yE, Z0 - 0.1)
        box("panzer", 11.75, 13.45, yE, yE + 2.55, Z0 - 0.15, Z0 - 0.03)
        for yy in (yE + 0.6, yE + 1.9):
            box("rolladen_dunkel", 11.7, 13.5, yy - 0.08, yy + 0.08, Z0 - 0.25, Z0 - 0.15)
        b.layer = "Abriegelung_EG_Schleusen"                                              # steel grilles in front of the 5 airlocks
        b.pivots[b.layer] = (0.0, yE + 3.0, 24.0)
        for lx in (-8.0, -4.0, 0.0, 4.0, 8.0):
            for xx in np.arange(lx - 1.35, lx + 1.36, 0.3):
                box("panzer", xx - 0.03, xx + 0.03, yE, yE + 3.0, 23.95, 24.05)
            for yy in (yE + 0.3, yE + 1.5, yE + 2.7):
                box("panzer", lx - 1.4, lx + 1.4, yy - 0.04, yy + 0.04, 23.94, 24.06)
        b.layer = "Abriegelung_EG_Barrikaden"                                             # sandbags behind the portals
        for (a, c) in PORTALS:
            for row in range(3):
                for xx in np.arange(a - 0.1, c + 0.11, 0.62):
                    b.box("sandsack", (0.6, 0.3, 0.42), (xx + (0.31 if row % 2 else 0.0), yE + 0.15 + row * 0.29, 27.1), rot_y=float(rng.uniform(-6, 6)))
        cx0, cx1, cz0, cz1 = CORE_R
        b.layer = "Abriegelung_Dach"                                                      # roof door, roof hatch, vent shaft sealed
        b.pivots[b.layer] = (cx0, TOP + 0.5, cz1 - 1.0)
        box("panzer", cx0 - 0.12, cx0 - 0.02, TOP + 0.5, TOP + 3.0, cz1 - 1.85, cz1 - 0.15)
        for yy in (TOP + 1.0, TOP + 2.2):
            b.beam("panzer", (cx0 - 0.2, yy, cz1 - 2.0), (cx0 - 0.2, yy + 0.6, cz1), 0.12)
        box("panzer", 9.8, 11.6, TOP + 0.85, TOP + 1.0, -22.2, -20.4)
        box("panzer", VENT[0] - 0.1, VENT[1] + 0.1, TOP + 2.2, TOP + 2.35, VENT[2] - 0.1, VENT[3] + 0.1)
        b.layer = "Abriegelung_Aussen"                                                    # anti-vehicle hedgehogs + concrete blocks at both gates
        axes = [np.array((0.816 * np.cos(t_), 0.577, 0.816 * np.sin(t_))) for t_ in (0.3, 0.3 + 2.094, 0.3 + 4.189)]
        for x in np.arange(-20.0, 20.1, 4.0):
            c_ = np.array((x, 0.6, 41.0))
            for a_ in axes:
                b.beam("panzer", tuple(c_ - 0.9 * a_), tuple(c_ + 0.9 * a_), 0.16)
        for zg in (60.0, -44.3):
            for xx in (-4.2, -2.1, 0.0, 2.1, 4.2):
                b.hull("concrete_light", [(xx + dx, yy, zg + dz) for dx in (-1.0, 1.0) for (yy, dz) in ((0.08, -0.3), (0.08, 0.3), (0.88, -0.08), (0.88, 0.08))])
        for lv in ORDER:                                                                   # power off: only red emergency lights
            b.layer = f"Abriegelung_{lv}_Notlicht"
            yl = top_of(lv) - 0.05
            for x in (-26.0, -8.0, 8.0, 26.0):
                for z in (-22.0, 0.0, 22.0):
                    if lv != "UG3" and AT[0] - 1.0 < x < AT[1] + 1.0 and AT[2] - 1.0 < z < AT[3] + 1.0:
                        continue
                    box("led_red", x - 0.25, x + 0.25, yl - 0.08, yl, z - 0.12, z + 0.12)
        beacons = [(sx * 29.0, TOP + 7.45, sz * 25.0) for sx in (-1, 1) for sz in (-1, 1) if not (sx > 0 and sz < 0)]
        beacons += [((a + c) / 2, 8.8, Z1 + 0.3) for (a, c) in PORTALS] + [(0.0, yE + 5.6, Z0 - 0.3)]
        for (x, yy, z) in beacons:
            b.layer = "Abriegelung_Dach_Leuchten" if yy > TOP else "Abriegelung_EG_Leuchten"
            b.cyl("frame_black", 0.22, 0.12, (x, yy + 0.06, z), 8)
            b.cyl("led_red", 0.17, 0.3, (x, yy + 0.27, z), 8)
        b.layer = None
        for k, (x, yy, z) in enumerate(beacons):
            b.anchor(f"Alarm_Leuchte_{k + 1}", (x, yy, z), 0)

    if abgeriegelt:
        b.norm_bounds = (np.min([m.bounds[0] for ms in b.parts.values() for m in ms], axis=0),
                         np.max([m.bounds[1] for ms in b.parts.values() for m in ms], axis=0))
        abriegelung()
    b.layer = None
    return b
