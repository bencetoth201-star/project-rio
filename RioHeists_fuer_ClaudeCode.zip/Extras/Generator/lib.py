"""Shared low-poly building helpers. Y-up, meters, front faces +Z."""
import numpy as np
import trimesh
from collections import defaultdict

PALETTE = {
    # masonry
    "brick": "#B5582F", "brick_b": "#C4683A", "brick_dark": "#8E4325", "brick_raw": "#A2512E",
    "concrete": "#9C9B93", "concrete_dk": "#7C7B74", "concrete_white": "#ECEAE4",
    "plaster_up": "#3FA39A", "plaster_low": "#E2BE5A", "plaster_pink": "#E07A8C",
    "plaster_yellow": "#EBC03F", "plaster_blue": "#6FB3D9", "plaster_cream": "#EFE1C0",
    "plaster_cream_dk": "#D8C7A2", "trim": "#E9E5D8", "stone_white": "#F4F2EC",
    # wood / sheets
    "wood_a": "#8A6440", "wood_b": "#A57B4F", "wood_dark": "#5B4029", "plywood": "#C9A878",
    "wood_warm": "#A86B3C", "deck": "#9C6B42",
    "tin": "#A9AFB1", "tin_rust": "#8F5A3A", "tarp_blue": "#2F6FC0",
    # openings
    "glass": "#23313B", "glass_open": "#1A1A1A", "glass_big": "#6F98AE", "glass_rail": "#B9D4DE",
    "frame_black": "#26282A", "shop_dark": "#2A2622",
    "door_blue": "#2E5FA8", "door_wood": "#7A4E2D", "door_green": "#5F8A63", "door_metal": "#5E6B66",
    "shutter": "#8D9296", "shutter_green": "#3E7D4F", "shutter_blue": "#2F6EA5",
    # metal / misc
    "metal": "#363636", "metal_red": "#A33A2C", "gate_metal": "#3B3F38", "meter": "#BFC2BE",
    "tank": "#2D6FB7", "tank_lid": "#24599A", "tank_white": "#DCDCD6",
    "rebar": "#7A4B2E", "ac": "#DADAD3", "solar": "#1E2E55",
    "roof_tile": "#B2552F", "tile_blue": "#2C5E9E", "tile_floor": "#CDBFA6",
    "counter": "#E9E9E4", "sign_red": "#C8372D", "sign_white": "#F2F0EA",
    "plastic_red": "#C8372D", "plastic_white": "#F2F0EA", "parasol": "#D9472F", "parasol_white": "#F1EEE6",
    "cloth_red": "#C8372D", "cloth_yellow": "#F0C419", "cloth_white": "#F2F0EA", "cloth_green": "#2E8B57",
    "gas": "#E0702A", "rubber": "#1E1E1E", "stone": "#8A877F",
    "pot": "#A4532E", "plant": "#3D7A33", "hedge": "#3F7B3A", "palm_trunk": "#8A6A48", "palm_leaf": "#4E8F3A",
    "pool": "#3FB6D3", "lamp": "#F6E7B8", "cement_bag": "#CFC6B0", "grass": "#6A9A45",
    # Tankstelle 257
    "brand_green": "#1E9A48", "brand_brown": "#7A3B2A", "promo_red": "#D0302B", "sign_light": "#FAFAF6",
    "asphalt": "#5E5F62", "concrete_light": "#9C9C99", "dach": "#7C7C7A", "dach_technik": "#B9BBBC",
    "glass_shop": "#6A8A9C", "fridge": "#E6EAEC", "shelf": "#C5C9CC", "safe": "#3A4046", "keypad": "#151515",
    "led_green": "#36D46A", "dach_licht": "#F6F2E2",
    "court_green": "#3E7A4A",
    "bank_sand": "#E2C7A0", "bank_brown": "#8A5A3B", "bank_floor": "#CFC6B8", "bunker": "#4B4643", "bunker_floor": "#8C8780",
    "gold": "#E0B23A", "money": "#5E9A55", "vault": "#6E7378", "led_red": "#E53935", "atm_blue": "#1E63C6", "atm_grey": "#5A5F66",
    "sign_dark": "#3B3634", "glass_bank": "#33507A", "court_blue": "#2F5E9A", "fence_net": "#1F3A2A", "led_orange": "#FF9A2E", "cardboard": "#B08D5A", "paint_white": "#F2F2EE",
}


# ---------------- colour slots ----------------
SLOT_PALETTES = {
    "wall": ["#3FA39A", "#EBC03F", "#E07A8C", "#6FB3D9", "#8FD0B0", "#E8893A", "#A98BC9", "#B7C94A",
             "#E5664E", "#EFE1C0", "#EDEBE4", "#4F9FD6", "#F0A07A", "#5BA35B", "#D9A441", "#C8473A"],
    "nwall": ["#F2F0EA", "#E9E4D8", "#D9C9A8", "#C9C9C4", "#A8A196", "#D7A27E", "#BFD3DD", "#B5C2A5"],
    "base": ["#B5582F", "#C4683A", "#9C9B93", "#3FA39A", "#EBC03F", "#E07A8C", "#6FB3D9", "#8FD0B0",
             "#E8893A", "#EFE1C0", "#EDEBE4", "#F0A07A"],
    "door": ["#2E5FA8", "#3E7D4F", "#7A4E2D", "#A33A2C", "#ECEAE4", "#5E6B66", "#D9A441", "#26282A"],
    "shutter": ["#3E7D4F", "#2F6EA5", "#ECEAE4", "#7A3B2A", "#2F8C86", "#C9A24A"],
    "roof": ["#B2552F", "#8E3B25", "#6E4B36", "#7C7B74"],
    "trim": ["#E9E5D8", "#F4F2EC", "#D8C7A2", "#C9C9C4", "#EBC03F"],
    "accent": ["#C8372D", "#2E5FA8", "#3E7D4F", "#EBC03F", "#E8893A", "#A98BC9"],
    "wood": ["#A86B3C", "#7A4E2D", "#C9A878", "#5B4029", "#9C6B42"],
    "paint": ["#4A4C4F", "#1C1D1F", "#F2F2EE", "#B8BCC0", "#C8202A", "#1E4FA8", "#E8B923", "#1E9A48",
              "#E8692A", "#6B2C91", "#0E7C86", "#7A1E28", "#2B3A55", "#8C6A3C", "#D94F8A", "#9FD13B"],
    "rim": ["#1A1A1A", "#B8BCC0", "#C9A24A", "#6E7378", "#F2F2EE", "#C8202A"],
    "caliper": ["#C8202A", "#E8B923", "#1E4FA8", "#1A1A1A", "#E8692A", "#1E9A48"],
    "glass": ["#6F98AE", "#4F7F95", "#7FA79A", "#8A9AA8", "#5E6E7A"],
}


def fpos(face, plane, u, y, d):
    return {"z+": (u, y, plane + d), "z-": (u, y, plane - d),
            "x+": (plane + d, y, u), "x-": (plane - d, y, u)}[face]


def fsize(face, w, h, d):
    return (w, h, d) if face[0] == "z" else (d, h, w)


class B:
    def __init__(s, seed=0):
        s.parts = defaultdict(list)
        s.rng = np.random.default_rng(seed)
        s.colors = {}
        s.anchors = {}
        s.layer = None          # optional floor/layer name -> exported as node "<layer>__<mat>"
        s.pivots = {}           # layer -> (x, y, z): node origin for that layer (e.g. wheels that rotate)

    def anchor(s, name, pos, yaw=0.0):
        """Empty node exported into the glb (e.g. Eingang, Strom_Anschluss)."""
        if name not in s.anchors:
            s.anchors[name] = (np.asarray(pos, float), yaw)

    def normalize(s, grid=2.0):
        """Snap to a lot raster: x centred, front (max z) flush with the lot's +Z edge,
        lot size rounded up to the grid. Pivot = lot centre on the ground."""
        nb = getattr(s, "norm_bounds", None)                 # variants (e.g. lockdown) reuse the base model's lot -> same pivot
        if nb is None:
            nb = trimesh.util.concatenate([m for ms in s.parts.values() for m in ms]).bounds
        (x0, y0, z0), (x1, y1, z1) = nb
        lw = float(np.ceil((x1 - x0 - 1e-6) / grid) * grid)
        ld = float(np.ceil((z1 - z0 - 1e-6) / grid) * grid)
        off = np.array([-(x0 + x1) / 2, 0.0, ld / 2 - z1])  # y stays: 0 = ground
        for ms in s.parts.values():
            for m in ms:
                m.apply_translation(off)
        s.anchors = {k: (p + off, yaw) for k, (p, yaw) in s.anchors.items()}
        s.pivots = {k: tuple(np.asarray(p, float) + off) for k, p in s.pivots.items()}
        return lw, ld

    def slot(s, kind, n, default):
        """Recolourable material: named slot_<kind>_<n>; kind picks the palette."""
        name = f"slot_{kind}_{n}"
        s.colors[name] = default
        return name

    def arch_top(s, mat, face, plane, u, y, w, d0, d1, seg=6):
        r = w / 2
        pts = []
        for a in np.linspace(0, np.pi, seg + 1):
            for d in (d0, d1):
                pts.append(fpos(face, plane, u + r * np.cos(a), y + r * np.sin(a), d))
        return s.hull(mat, pts)

    def arch_window(s, face, plane, u, y0, w, h, glass="glass", frame="trim", sill="trim"):
        hr = h - w / 2
        if frame:
            s.box(frame, fsize(face, w + 0.16, hr, 0.03), fpos(face, plane, u, y0 + hr / 2, 0.015))
            s.arch_top(frame, face, plane, u, y0 + hr, w + 0.16, 0.0, 0.03)
        s.box(glass, fsize(face, w, hr, 0.03), fpos(face, plane, u, y0 + hr / 2, 0.035))
        s.arch_top(glass, face, plane, u, y0 + hr, w, 0.02, 0.05)
        if sill:
            s.box(sill, fsize(face, w + 0.3, 0.08, 0.16), fpos(face, plane, u, y0 - 0.04, 0.08))

    def arch_spandrel(s, mat, face, plane, cx, spring, r, top, d0, d1, seg=8):
        """Wall piece above a round arch opening (between spring line and top)."""
        angs = np.linspace(np.pi, 0, seg + 1)
        for a0, a1 in zip(angs[:-1], angs[1:]):
            p0 = (cx + r * np.cos(a0), spring + r * np.sin(a0))
            p1 = (cx + r * np.cos(a1), spring + r * np.sin(a1))
            pts = []
            for (u, y) in (p0, p1, (p0[0], top), (p1[0], top)):
                for d in (d0, d1):
                    pts.append(fpos(face, plane, u, y, d))
            s.hull(mat, pts)

    def text(s, string, mats, center, height, depth=0.05, rot_y=0.0, simplify=0.012, align="center"):
        """Extruded 3D text (DejaVu Sans Bold). mats: one material per character.
        Text lies in the XY plane facing +Z (before rot_y); center = middle of the text's front face base plane."""
        from matplotlib.textpath import TextPath
        from matplotlib.font_manager import FontProperties
        from shapely.geometry import Polygon
        from functools import reduce
        fp = FontProperties(family="DejaVu Sans", weight="bold")
        if isinstance(mats, str):
            mats = [mats] * len(string)
        glyphs, x = [], 0.0
        for ch, mat in zip(string, mats):
            if ch == " ":
                x += 0.3
                continue
            p = TextPath((0, 0), ch, size=1, prop=fp)
            polys = [Polygon(q) for q in p.to_polygons() if len(q) >= 3]
            g = reduce(lambda a, b: a.symmetric_difference(b), polys).simplify(simplify)
            ext = p.get_extents()
            for poly in getattr(g, "geoms", [g]):
                if poly.area < 1e-4:
                    continue
                m = trimesh.creation.extrude_polygon(poly, 1.0)
                m.apply_translation((x - ext.x0, 0, 0))
                glyphs.append((mat, m))
            x += (ext.x1 - ext.x0) + 0.08
        width = x - 0.08
        k = height / 0.73
        for mat, m in glyphs:
            m.apply_translation((-width / 2 if align == "center" else 0.0, -0.365, 0))
            m.apply_scale((k, k, depth))
            if rot_y:
                m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(rot_y), [0, 1, 0]))
            m.apply_translation(center)
            s.add(mat, m)
        return width * k

    def balconette(s, face, plane, u, y, w=1.2, depth=0.45, mat="metal", slab="concrete_white"):
        s.box(slab, fsize(face, w + 0.2, 0.1, depth), fpos(face, plane, u, y - 0.05, depth / 2))
        s.box(mat, fsize(face, w + 0.2, 0.04, 0.04), fpos(face, plane, u, y + 0.9, depth - 0.02))
        n = max(2, int(w / 0.13))
        for i in range(n + 1):
            uu = u - (w + 0.2) / 2 + (w + 0.2) * i / n
            s.box(mat, fsize(face, 0.025, 0.9, 0.025), fpos(face, plane, uu, y + 0.45, depth - 0.02))
        for sg in (-1, 1):
            for k in range(3):
                dd = depth * (k + 0.5) / 3
                s.box(mat, fsize(face, 0.025, 0.9, 0.025), fpos(face, plane, u + sg * (w + 0.2) / 2, y + 0.45, dd))
            s.box(mat, fsize(face, 0.04, 0.04, depth), fpos(face, plane, u + sg * (w + 0.2) / 2, y + 0.9, depth / 2))

    def stairs(s, mat, x0, x1, z_start, y0, y1, run=0.26, direction=-1, solid=True, alt=None):
        """Straight stair along z. Returns z where it ends."""
        n = max(1, int(round((y1 - y0) / 0.2)))
        rise = (y1 - y0) / n
        xc, w = (x0 + x1) / 2, abs(x1 - x0)
        for i in range(n):
            h = y0 + (i + 1) * rise
            zc = z_start + direction * (i * run + run / 2)
            m = alt if (alt and i % 2) else mat
            if solid:
                s.box(m, (w, h, run), (xc, h / 2, zc))
            else:
                s.box(m, (w, 0.04, run), (xc, h, zc))
        z_end = z_start + direction * n * run
        if not solid:
            for x in (min(x0, x1), max(x0, x1)):
                s.beam(mat, (x, y0, z_start), (x, y1, z_end), 0.06)
        return z_end

    def add(s, mat, m):
        key = (s.layer, mat) if getattr(s, "layer", None) else mat
        s.parts[key].append(m)
        return m

    def box(s, mat, size, center, rot_y=0.0, rot_x=0.0, rot_z=0.0):
        m = trimesh.creation.box(extents=size)
        for ang, ax in ((rot_x, [1, 0, 0]), (rot_z, [0, 0, 1]), (rot_y, [0, 1, 0])):
            if ang:
                m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(ang), ax))
        m.apply_translation(center)
        return s.add(mat, m)

    def beam(s, mat, p0, p1, t=0.04):
        p0, p1 = np.asarray(p0, float), np.asarray(p1, float)
        v = p1 - p0
        L = np.linalg.norm(v)
        m = trimesh.creation.box(extents=(t, L, t))
        m.apply_transform(trimesh.geometry.align_vectors([0, 1, 0], v / L))
        m.apply_translation((p0 + p1) / 2)
        return s.add(mat, m)

    def cyl(s, mat, r, h, center, sections=10):
        m = trimesh.creation.cylinder(radius=r, height=h, sections=sections)
        m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
        m.apply_translation(center)
        return s.add(mat, m)

    def hull(s, mat, pts):
        return s.add(mat, trimesh.convex.convex_hull(np.asarray(pts, float)))

    def rock(s, mat, r, center, squash=0.7):
        m = trimesh.creation.icosphere(subdivisions=0, radius=r)
        m.vertices *= s.rng.uniform(0.8, 1.15, (len(m.vertices), 1))
        m.apply_scale((1, squash, 1))
        m.apply_translation(center)
        return s.add(mat, m)

    def tire(s, center, tilt=0.0):
        m = trimesh.creation.torus(major_radius=0.28, minor_radius=0.1, major_sections=10, minor_sections=5)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        if tilt:
            m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(tilt), [1, 0, 0]))
        m.apply_translation(center)
        return s.add("rubber", m)

    def corrugated(s, mat, width, length, ridges, amp, origin, tilt_deg, rot_y=0.0):
        n = ridges * 2 + 1
        xs = np.linspace(-width / 2, width / 2, n)
        ys = np.array([0 if i % 2 == 0 else amp for i in range(n)])
        verts = [(x, y, z) for z in (0.0, length) for x, y in zip(xs, ys)]
        faces = []
        for i in range(n - 1):
            a, b, c, d = i, i + 1, n + i + 1, n + i
            faces += [(a, c, b), (a, d, c)]
        faces = np.array(faces)
        faces = np.vstack([faces, faces[:, ::-1]])
        m = trimesh.Trimesh(np.array(verts), faces, process=False)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(tilt_deg), [1, 0, 0]))
        if rot_y:
            m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(rot_y), [0, 1, 0]))
        m.apply_translation(origin)
        return s.add(mat, m)

    def window(s, face, plane, u, yc, w=1.1, h=1.0, bars=True, frame="trim", glass="glass",
               sill="concrete", shutters=None):
        if frame:
            s.box(frame, fsize(face, w + 0.14, h + 0.14, 0.03), fpos(face, plane, u, yc, 0.015))
        s.box(glass, fsize(face, w, h, 0.03), fpos(face, plane, u, yc, 0.035))
        if sill:
            s.box(sill, fsize(face, w + 0.24, 0.07, 0.16), fpos(face, plane, u, yc - h / 2 - 0.1, 0.08))
        if bars:
            for i in range(4):
                uu = u - w / 2 + w * (i + 0.5) / 4
                s.box("metal", fsize(face, 0.03, h, 0.03), fpos(face, plane, uu, yc, 0.075))
            s.box("metal", fsize(face, w, 0.03, 0.03), fpos(face, plane, u, yc, 0.075))
        if shutters:
            sw = w / 2
            for sgn in (-1, 1):
                s.box(shutters, fsize(face, sw, h + 0.05, 0.04), fpos(face, plane, u + sgn * (w / 2 + 0.08 + sw / 2), yc, 0.04))

    def door(s, face, plane, u, w=0.95, h=2.05, mat="door_blue", y0=0.0, frame="trim"):
        if y0 < 0.7:
            s.anchor("Eingang", fpos(face, plane, u, y0, 0.6), {"z+": 0, "x+": 90, "z-": 180, "x-": -90}[face])
        if frame:
            s.box(frame, fsize(face, w + 0.14, h + 0.07, 0.03), fpos(face, plane, u, y0 + (h + 0.07) / 2, 0.015))
        s.box(mat, fsize(face, w, h, 0.05), fpos(face, plane, u, y0 + h / 2, 0.04))
        s.box("metal", fsize(face, 0.04, 0.12, 0.04), fpos(face, plane, u + w * 0.35, y0 + 1.0, 0.08))

    def wire(s, p0, p1, sag=0.4, segs=6, t=0.022, mat="metal"):
        p0, p1 = np.asarray(p0, float), np.asarray(p1, float)
        pts = []
        for i in range(segs + 1):
            f = i / segs
            p = p0 + (p1 - p0) * f
            p[1] -= sag * 4 * f * (1 - f)
            pts.append(p)
        for a, b in zip(pts[:-1], pts[1:]):
            s.beam(mat, a, b, t)

    def tank(s, x, y, z, r=0.62, h=0.9, mat="tank", lid="tank_lid"):
        s.cyl(mat, r, h, (x, y + h / 2, z), 10)
        s.cyl(lid, r + 0.06, 0.08, (x, y + h + 0.04, z), 10)
        s.cyl(lid, 0.11, 0.06, (x, y + h + 0.11, z), 6)

    def rebar(s, x, y, z, n=3, hmin=0.6, hmax=0.95):
        r = s.rng
        for _ in range(n):
            off = r.uniform(-0.07, 0.07, 2)
            top = np.array([x + off[0], y + r.uniform(hmin, hmax), z + off[1]])
            top[[0, 2]] += r.uniform(-0.08, 0.08, 2)
            s.beam("rebar", (x + off[0], y, z + off[1]), top, 0.025)

    def pot_plant(s, x, y, z, r=0.17):
        s.cyl("pot", r, 0.28, (x, y + 0.14, z), 6)
        ico = trimesh.creation.icosphere(subdivisions=0, radius=r * 1.5)
        ico.apply_scale((1, 0.8, 1))
        ico.apply_translation((x, y + 0.28 + r, z))
        s.add("plant", ico)

    def chair(s, x, y, z, rot=0.0, mat="plastic_white"):
        c, sn = np.cos(np.radians(rot)), np.sin(np.radians(rot))
        def P(dx, dy, dz):
            return (x + dx * c + dz * sn, y + dy, z - dx * sn + dz * c)
        s.box(mat, (0.45, 0.05, 0.45), P(0, 0.44, 0), rot_y=rot)
        s.box(mat, (0.45, 0.45, 0.05), P(0, 0.68, -0.21), rot_y=rot)
        for dx in (-0.19, 0.19):
            for dz in (-0.19, 0.19):
                s.box(mat, (0.04, 0.44, 0.04), P(dx, 0.22, dz), rot_y=rot)

    def table(s, x, y, z, mat="plastic_red", size=0.75):
        s.box(mat, (size, 0.04, size), (x, y + 0.72, z))
        for dx in (-1, 1):
            for dz in (-1, 1):
                s.box(mat, (0.04, 0.72, 0.04), (x + dx * (size / 2 - 0.05), y + 0.36, z + dz * (size / 2 - 0.05)))

    def parasol(s, x, y, z, mat="parasol", r=1.1, h=2.3):
        s.beam("metal", (x, y, z), (x, y + h, z), 0.04)
        cone = trimesh.creation.cone(radius=r, height=0.4, sections=8)
        cone.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
        cone.apply_translation((x, y + h - 0.3, z))
        s.add(mat, cone)

    def palm(s, x, z, h=5.5, lean=(0.5, 0.2), y=0.0):
        pts = []
        for i in range(5):
            f = i / 4
            pts.append(np.array([x + lean[0] * f * f, y + h * f, z + lean[1] * f * f]))
        for i, (a, b) in enumerate(zip(pts[:-1], pts[1:])):
            s.beam("palm_trunk", a, b, 0.26 - i * 0.03)
        top = pts[-1]
        for k in range(8):
            ang = k * 2 * np.pi / 8 + s.rng.uniform(-0.2, 0.2)
            d = np.array([np.cos(ang), 0, np.sin(ang)])
            mid = top + d * 1.0 + np.array([0, 0.25, 0])
            tip = top + d * 2.1 + np.array([0, -0.7, 0])
            for a, b, w in ((top, mid, 0.5), (mid, tip, 0.38)):
                v = b - a
                L = np.linalg.norm(v)
                m = trimesh.creation.box(extents=(w, 0.03, L))
                m.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], v / L))
                m.apply_translation((a + b) / 2)
                s.add("palm_leaf", m)

    def lounger(s, x, z, rot=0.0, y=0.0):
        s.box("stone_white", (0.7, 0.12, 1.5), (x, y + 0.32, z), rot_y=rot)
        c, sn = np.cos(np.radians(rot)), np.sin(np.radians(rot))
        bz = -0.7
        s.box("stone_white", (0.7, 0.08, 0.6), (x + bz * sn, y + 0.55, z + bz * c), rot_y=rot, rot_x=35)
        s.box("plastic_white", (0.66, 0.05, 1.45), (x, y + 0.405, z), rot_y=rot)
        for dz in (-0.6, 0.6):
            s.box("metal", (0.6, 0.26, 0.05), (x + dz * sn, y + 0.13, z + dz * c), rot_y=rot)


# ---------------- export ----------------
def hex2rgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)])


def srgb2lin(c):
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


ALPHA = {"glass_rail": 0.4, "glass_shop": 0.35, "fence_net": 0.35}


def material_params(mat):
    if mat in ("mirror", "chrome"):
        return 0.25, 0.45
    if mat.startswith("glass") or mat == "pool":
        return 0.25, 0.1
    if mat in ("metal", "tin", "tin_rust", "tank", "tank_lid", "gate_metal", "shutter", "solar", "frame_black", "metal_red"):
        return 0.55, (0.5 if mat in ("tin", "shutter") else 0.15)
    return 0.92, 0.0


# ---------------------------------------------------------------- hitboxes
# Every export gets an invisible, simplified collision layer:
#   <Ebene>__kollision    one merged mesh per layer (solid hitbox, MeshCollider non-convex)
#   <Ebene>__trigger_<n>  one convex volume per laser / pool / water (MeshCollider convex + isTrigger)
# Not solid: light beams, water jets, underwater lights; tiny parts (< 0.3 m: rings, gems, bottles, letters);
# flat decals (< 2.5 cm: rugs, inlays). Small curved parts (> 30 tris, < 3 m) become a single box.
NO_COLLIDE = {"water_jet", "uw_light", "diamond", "palm_leaf"}
TRIGGER_MATS = {"laser_red", "pool", "flood_water", "kanal_wasser"}
PICKUP_TAGS = ("_Beute",)          # movable nodes with this in the name = stealable: no solid hitbox, one pick-up trigger (AABB + 0.25 m)


def _bar_groups(boxes, gap=0.3):
    """union-find over AABBs closer than gap; returns lists of indices"""
    par = list(range(len(boxes)))
    def find(i):
        while par[i] != i:
            par[i] = par[par[i]]
            i = par[i]
        return i
    cell = {}
    for i, (lo, hi) in enumerate(boxes):
        for cx in range(int(np.floor(lo[0] / 1.0)), int(np.floor(hi[0] / 1.0)) + 1):
            for cz in range(int(np.floor(lo[2] / 1.0)), int(np.floor(hi[2] / 1.0)) + 1):
                cell.setdefault((cx, cz), []).append(i)
    for ids in cell.values():
        for a_ in range(len(ids)):
            i = ids[a_]
            for j in ids[a_ + 1:]:
                (l1, h1), (l2, h2) = boxes[i], boxes[j]
                if np.all(l1 - gap <= h2) and np.all(l2 - gap <= h1):
                    ri, rj = find(i), find(j)
                    if ri != rj:
                        par[ri] = rj
    groups = {}
    for i in range(len(boxes)):
        groups.setdefault(find(i), []).append(i)
    return list(groups.values())


def build_collision(b):
    kol, trig, thin, allb, pick = {}, {}, {}, {}, {}
    tags = getattr(b, "pickup_tags", PICKUP_TAGS)
    for key, meshes in b.parts.items():
        layer, mat = key if isinstance(key, tuple) else (None, key)
        if layer and any(t in layer for t in tags):
            pick.setdefault(layer, []).extend(m.bounds for m in meshes if len(m.faces))
            continue
        if mat in NO_COLLIDE or mat.startswith("beam_"):
            continue
        for m in meshes:
            if len(m.faces) == 0:
                continue
            ext = m.extents
            if mat in TRIGGER_MATS:
                try:
                    convex = m.is_convex or len(m.faces) <= 12
                except Exception:
                    convex = False
                if convex and ext.max() > 0.05:
                    trig.setdefault(layer, []).append(m.copy())
                continue
            se = np.sort(ext)
            if se[2] < 0.3 or se[0] < 0.025:
                continue                                            # tiny parts, flat decals
            allb.setdefault(layer, []).append(m.bounds)
            if se[1] < 0.15 and se[2] < 3.0:
                thin.setdefault(layer, []).append(m.bounds)         # short thin bars/posts/frames: only solid as a grille (below)
                continue
            if len(m.faces) > 12 and se[2] < 3.0:
                try:
                    fill = abs(m.volume) / max(float(np.prod(ext)), 1e-9) if m.is_watertight else 0.0
                except Exception:
                    fill = 0.0
                if fill >= 0.35:                                    # solid curved part -> one box (keeps door frames, rings open)
                    bx = trimesh.creation.box(extents=ext)
                    bx.apply_translation(m.bounds.mean(axis=0))
                    kol.setdefault(layer, []).append(bx)
                    continue
            kol.setdefault(layer, []).append(m)
    for layer, bx in thin.items():                                  # rows of bars (gates, grilles, balustrades) -> one panel box
        for grp in _bar_groups(bx):
            if len(grp) < 4:
                continue
            lo = np.min([bx[i][0] for i in grp], axis=0)
            hi = np.max([bx[i][1] for i in grp], axis=0)
            if np.sort(hi - lo)[1] >= 1.0:
                box_ = trimesh.creation.box(extents=hi - lo)
                box_.apply_translation((lo + hi) / 2)
                kol.setdefault(layer, []).append(box_)
    for layer, bs in pick.items():                                  # stealable items: one trigger box each
        lo = np.min([x[0] for x in bs], axis=0) - 0.25
        hi = np.max([x[1] for x in bs], axis=0) + 0.25
        box_ = trimesh.creation.box(extents=hi - lo)
        box_.apply_translation((lo + hi) / 2)
        trig.setdefault(layer, []).append(box_)
    for layer in getattr(b, "pivots", {}):                          # movable part without any hitbox: use its bounding box
        if layer not in kol and layer not in trig and layer in allb:
            lo = np.min([x[0] for x in allb[layer]], axis=0)
            hi = np.max([x[1] for x in allb[layer]], axis=0)
            box_ = trimesh.creation.box(extents=np.maximum(hi - lo, 0.05))
            box_.apply_translation((lo + hi) / 2)
            kol[layer] = [box_]
    return kol, trig


def export(b, path_noext, name):
    piv_ = getattr(b, "pivots", {})
    if any(k in piv_ for k in getattr(b, "anchors", {})):         # anchor with the same name as a movable node would move that node
        b.anchors = {(k + "_Punkt" if k in piv_ else k): v for k, v in b.anchors.items()}
    scene = trimesh.Scene()
    merged, matof = {}, {}
    for key, meshes in b.parts.items():
        if isinstance(key, tuple):
            node, mat = f"{key[0]}__{key[1]}", key[1]
        else:
            node, mat = key, key
        m = trimesh.util.concatenate(meshes)
        m.merge_vertices()
        m.unmerge_vertices()
        merged[node] = m
        matof[node] = mat
        piv = None
        if isinstance(key, tuple) and key[0] in getattr(b, "pivots", {}):
            piv = np.asarray(b.pivots[key[0]], float)
            m.apply_translation(-piv)
        rough, metal = material_params(mat)
        alpha = ALPHA.get(mat, 0.2 if mat.startswith("beam_") else 1.0)
        pbr = trimesh.visual.material.PBRMaterial(
            name=mat, baseColorFactor=np.append(srgb2lin(hex2rgb(b.colors.get(mat) or PALETTE[mat])), alpha),
            metallicFactor=metal, roughnessFactor=rough, alphaMode="BLEND" if alpha < 1 else None)
        m.visual = trimesh.visual.TextureVisuals(material=pbr)
        if piv is not None:
            layer = key[0]
            if layer not in scene.graph.nodes:
                Tn = np.eye(4)
                Tn[:3, 3] = piv
                scene.graph.update(frame_from=scene.graph.base_frame, frame_to=layer, matrix=Tn)
            scene.add_geometry(m, node_name=node, geom_name=node, parent_node_name=layer)
        else:
            scene.add_geometry(m, node_name=node, geom_name=node)
    kol, trig = build_collision(b)
    ktris = 0
    def add_hidden(layer, nodename, m, mat, color):
        piv = np.asarray(b.pivots[layer], float) if layer in getattr(b, "pivots", {}) else None
        if piv is not None:
            m.apply_translation(-piv)
        m.visual = trimesh.visual.TextureVisuals(material=trimesh.visual.material.PBRMaterial(
            name=mat, baseColorFactor=np.append(srgb2lin(hex2rgb(color)), 0.35), metallicFactor=0.0, roughnessFactor=1.0, alphaMode="BLEND"))
        if piv is not None:
            if layer not in scene.graph.nodes:
                Tn = np.eye(4)
                Tn[:3, 3] = piv
                scene.graph.update(frame_from=scene.graph.base_frame, frame_to=layer, matrix=Tn)
            scene.add_geometry(m, node_name=nodename, geom_name=nodename, parent_node_name=layer)
        else:
            scene.add_geometry(m, node_name=nodename, geom_name=nodename)
    for layer, ms in kol.items():
        m = trimesh.util.concatenate(ms)
        m.merge_vertices()
        ktris += len(m.faces)
        add_hidden(layer, f"{layer or 'Basis'}__kollision", m, "kollision", "#FF00FF")
    for layer, ms in trig.items():
        for i, m in enumerate(ms):
            add_hidden(layer, f"{layer or 'Basis'}__trigger_{i + 1}", m, "trigger", "#FF2020")
    b.kollision_tris = ktris
    b.trigger_count = sum(len(v) for v in trig.values())
    for name, (p, yaw) in getattr(b, "anchors", {}).items():
        T = trimesh.transformations.rotation_matrix(np.radians(yaw), [0, 1, 0])
        T[:3, 3] = p
        scene.graph.update(frame_to=name, frame_from=scene.graph.base_frame, matrix=T)
    scene.export(path_noext + ".glb", include_normals=True)
    base = path_noext.split("/")[-1]
    with open(path_noext + ".mtl", "w") as f:
        for mat in sorted(set(matof.values())):
            r, g, bl = hex2rgb(b.colors.get(mat) or PALETTE[mat])
            dd = ALPHA.get(mat, 0.2 if mat.startswith("beam_") else 1)
            f.write(f"newmtl {mat}\nKd {r:.4f} {g:.4f} {bl:.4f}\nKa 0 0 0\nKs 0.05 0.05 0.05\nNs 10\nd {dd}\nillum 2\n\n")
    with open(path_noext + ".obj", "w") as f:
        f.write(f"# {name} - low-poly, Y up, meters\nmtllib {base}.mtl\n")
        vo = no = 1
        for node, m in merged.items():
            f.write(f"o {node}\nusemtl {matof[node]}\n")
            f.write("".join(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n" for v in m.vertices))
            f.write("".join(f"vn {n[0]:.4f} {n[1]:.4f} {n[2]:.4f}\n" for n in m.face_normals))
            f.write("".join(f"f {a+vo}//{i+no} {bb+vo}//{i+no} {c+vo}//{i+no}\n" for i, (a, bb, c) in enumerate(m.faces)))
            vo += len(m.vertices)
            no += len(m.faces)
    tris = sum(len(m.faces) for m in merged.values())
    bnd = scene.bounds
    slots = sorted(set(k for k in matof.values() if k.startswith("slot_")))
    return tris, len(set(matof.values())), bnd, slots
