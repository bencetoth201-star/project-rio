"""Maya-Kanalisation – modularer Baukasten (wie die Straßenteile) für den Casa-Império-Heist. Fiktiv.

Konventionen
- 1 Einheit = 1 m, Y oben. Pivot = Kachelmitte auf der WASSERLINIE (y 0). Kanalsohle y -1,6, Laufstege y +0,6,
  Kraggewölbe ab 3,4 m, Abdeckung bis 7,6 m, Bodenplatte ab -2,0 m.
- Kacheln 16 x 16 m (Halle 32 x 32). Anschlüsse mittig auf den Kachelkanten: Anker "Anschluss_Kanal_<N|S|E|W>"
  (y 0, lokale +Z zeigt aus der Kachel hinaus). N = -Z, S = +Z, E = +X, W = -X – wie beim Straßenbaukasten.
- Zum Palast: "Anschluss_Palast" (Gang 3 m breit, Boden = Laufsteg y 0,6) passt auf den Palast-Anker "Kanal_Anschluss".
- Senkrechte Teile (Liftschacht, runder Schacht, Gullydeckel, Garage) stapeln über die Anker "Unten" / "Oben".
- Querschnitt Hauptkanal: Wasser 5 m (+-2,5), Laufstege 1,5 m (2,5-4,0), Mauern 0,8 m, Maya-Kraggewölbe 7 Stufen (je 0,45 hoch, 0,5 vor).
Nodes: "Kanal__<mat>" (Sohle, Mauern, Laufstege, Wasser, Deko), "Decke__<mat>" (Kraggewölbe + Abdeckung),
"Schacht__…", "Garage__…", "Dach__…"; bewegliche Teile als eigene Nodes (Kanal_Geheimtor, Kanal_Bootslift, Garage_Tor …)."""
import numpy as np
import trimesh
from shapely.geometry import LineString, Polygon, Point, box as sbox
from shapely.ops import unary_union, triangulate
from lib import B, PALETTE, ALPHA

for _k, _v in {
    "maya_kalk": "#C8B48A", "maya_kalk_dunkel": "#9C8862", "maya_kalk_hell": "#DCCCA4", "maya_rot": "#8E3B2A",
    "maya_jade": "#3E8C6E", "maya_ocker": "#C9973A", "kanal_wasser": "#2F5A50", "algen": "#46603A", "wurzel": "#5C5A34",
    "fackel": "#FF8A2A", "rost": "#7A4A2E", "iron": "#1E1F22", "stahl": "#5B6168", "riffelblech": "#8A9096",
    "hazard": "#1E1E1E", "safety_yellow": "#F2C230", "brick_old": "#8A4A36", "crate": "#9C7A4E", "garage_wand": "#B9B3A6",
    "rolladen": "#7C838A", "rolladen_dunkel": "#4E545A", "bombe": "#4B5236", "bauplan": "#2F5FA8", "water_jet": "#BFE6F5",
    "wood_dark": "#5B4029", "lamp": "#F6E7B8", "led_red": "#FF3B30", "led_green": "#36D46A", "safe": "#3A4046",
    "graffiti_pink": "#E0559A", "graffiti_cyan": "#2FB8D8", "tarp_blue": "#2F6FC0",
}.items():
    PALETTE.setdefault(_k, _v)
ALPHA.update({"kanal_wasser": 0.8, "water_jet": 0.45})

TILE, HT = 16.0, 8.0
WH, WK, WT = 2.5, 4.0, 0.8          # water half width, inner wall (walkway edge), wall thickness
YB, YW, YS = -1.6, 0.6, 3.4         # channel bottom, walkway top, springline
NC, CHH, CI = 7, 0.45, 0.5          # corbel courses, course height, inset per course
YT = YS + NC * CHH                  # 6.55 top of the corbel vault
YSH = 7.6                           # outer top (cover)
FLOOR = -2.0
LEVELS = ["Decke", "Kanal"]
DIRS = {"N": ((0.0, -1.0), 180), "S": ((0.0, 1.0), 0), "E": ((1.0, 0.0), 90), "W": ((-1.0, 0.0), -90)}
SHAFT = (2.6, 4.6)                  # boat lift shaft inner half size (x, z)


def neu(seed):
    b = B(seed)
    b.pickup_tags = ("_Beute", "_Ausruestung")
    b.fackeln = 0
    return b


def geoms(g):
    if g is None or g.is_empty:
        return []
    if g.geom_type == "Polygon":
        return [g]
    return [p for p in getattr(g, "geoms", []) if p.geom_type == "Polygon"]


def flat(b, mat, poly, y0, y1):
    """(x, z) polygon -> prism from y0 to y1."""
    for p in geoms(poly):
        if p.area < 1e-3:
            continue
        if not p.is_valid:
            p = p.buffer(0)
            if p.geom_type != "Polygon":
                for q in geoms(p):
                    flat(b, mat, q, y0, y1)
                continue
        q = Polygon([(x, -z) for x, z in p.exterior.coords], [[(x, -z) for x, z in r.coords] for r in p.interiors])
        m = trimesh.creation.extrude_polygon(q, y1 - y0)
        m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))
        b.add(mat, m.apply_translation((0, y0, 0)))


def box(b, mat, x0, x1, y0, y1, z0, z1, **kw):
    if abs(x1 - x0) < 1e-4 or abs(y1 - y0) < 1e-4 or abs(z1 - z0) < 1e-4:
        return
    b.box(mat, (abs(x1 - x0), abs(y1 - y0), abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)


def ring(cx, cz, r0, r1, n=12):
    return Point(cx, cz).buffer(r1, n // 4).difference(Point(cx, cz).buffer(r0, n // 4))


class Weg:
    """Channel axis (polyline in x, z). hw = inner half width (wall face), wh = water half width."""

    def __init__(s, pts, hw=WK, wasser=True, wh=WH):
        s.pts = [tuple(map(float, p)) for p in pts]
        s.hw, s.wasser, s.wh = hw, wasser, wh
        s.ls = LineString(s.pts)

    def buf(s, r):
        if r <= 0.02:
            return Polygon()
        return s.ls.buffer(r, cap_style=2, join_style=2, mitre_limit=4.0)

    def at(s, d):
        """point + unit tangent + left normal at arc length d"""
        L = s.ls.length
        d = min(max(d, 0.0), L)
        p = np.array(s.ls.interpolate(d).coords[0])
        q = np.array(s.ls.interpolate(min(d + 0.05, L)).coords[0]) if d + 0.05 <= L else p
        o = np.array(s.ls.interpolate(max(d - 0.05, 0.0)).coords[0])
        t = (q - o) / max(np.linalg.norm(q - o), 1e-9)
        return p, t, np.array((-t[1], t[0]))


def _offs(pts, r):
    P = np.array(pts, float)
    n = len(P)
    L, R = [], []
    for i in range(n):
        if i == 0:
            t = P[1] - P[0]
        elif i == n - 1:
            t = P[-1] - P[-2]
        else:
            t1 = (P[i] - P[i - 1]) / np.linalg.norm(P[i] - P[i - 1])
            t2 = (P[i + 1] - P[i]) / np.linalg.norm(P[i + 1] - P[i])
            t = t1 + t2
        t = t / np.linalg.norm(t)
        nr = np.array((-t[1], t[0]))
        s = r
        if 0 < i < n - 1:
            s = r / max(float(np.dot(nr, np.array((-t1[1], t1[0])))), 0.3)
        L.append(tuple(P[i] + nr * s))
        R.append(tuple(P[i] - nr * s))
    return L, R


def _konvex(p):
    out = []
    for q in geoms(p):
        if q.area < 1e-3:
            continue
        q = q.simplify(0.002)
        if q.convex_hull.area - q.area < 1e-3 * max(1.0, q.area):
            out.append(q)
        else:
            out.extend(t for t in triangulate(q) if t.representative_point().within(q) and t.area > 1e-4)
    return out


def wasser_stuecke(wege):
    """Water as non-overlapping convex pieces (every piece = one trigger volume)."""
    acc, out = Polygon(), []
    for w in wege:
        if not w.wasser:
            continue
        L, R = _offs(w.pts, w.wh)
        for i in range(len(w.pts) - 1):
            q = Polygon([L[i], L[i + 1], R[i + 1], R[i]])
            if not q.is_valid:
                q = q.buffer(0)
            out.extend(_konvex(q.difference(acc)))
            acc = acc.union(q)
    return out


def anschluss(b, d, dist=HT, y=0.0, typ="Kanal"):
    (dx, dz), yaw = DIRS[d]
    b.anchor(f"Anschluss_{typ}_{d}", (dx * dist, y, dz * dist), yaw)


# ------------------------------------------------------------------ core: channel network from axis polylines
def kanal(b, wege, extra_outer=(), schaechte=(), extra_wasser=()):
    outer = unary_union([w.buf(w.hw + WT) for w in wege] + list(extra_outer))
    inner = unary_union([w.buf(w.hw) for w in wege])
    ww = [w for w in wege if w.wasser]
    water = unary_union([w.buf(w.wh) for w in ww] + list(extra_wasser)) if ww or extra_wasser else Polygon()
    sch = unary_union(list(schaechte)) if schaechte else Polygon()
    b.layer = "Kanal"
    flat(b, "maya_kalk_dunkel", outer, FLOOR, YB)
    flat(b, "maya_kalk", inner.difference(water), YB, YW)
    if ww:
        kerb = unary_union([w.buf(w.wh + 0.25) for w in ww]).difference(water).intersection(inner)
        flat(b, "maya_kalk_dunkel", kerb, YW, YW + 0.08)
        flat(b, "algen", water.difference(unary_union([w.buf(w.wh - 0.03) for w in ww])), -0.05, 0.22)
        for p in wasser_stuecke(ww):
            flat(b, "kanal_wasser", p, YB, 0.0)
    flat(b, "maya_kalk", outer.difference(inner), YB, YS)
    fuge = inner.difference(unary_union([w.buf(w.hw - 0.03) for w in wege]))
    for yj in (1.55, 2.5):
        flat(b, "maya_kalk_dunkel", fuge, yj, yj + 0.05)
    mauerwerk(b, wege, outer, inner, water)
    b.layer = "Decke"
    ops = []
    for k in range(NC):
        op = unary_union([w.buf(w.hw - (k + 1) * CI) for w in wege] + [sch])
        ops.append(op)
        flat(b, "maya_kalk_hell" if k % 2 else "maya_kalk", outer.difference(op), YS + k * CHH, YS + (k + 1) * CHH)
    flat(b, "maya_kalk_dunkel", outer.difference(sch), YT, YSH)
    for w in wege:                                                            # vertical joints on the lower vault steps
        for k in range(4):
            rk = w.hw - (k + 1) * CI
            if rk < 0.6:
                continue
            solid = outer.difference(ops[k])
            for sd in (-1, 1):
                for d in np.arange(0.35 + 0.6 * (k % 2), w.ls.length - 0.1, 1.2):
                    p, t, nr = w.at(d)
                    if not solid.contains(Point(*(p + nr * sd * (rk + 0.15)))) or not ops[k].contains(Point(*(p + nr * sd * (rk - 0.15)))):
                        continue
                    q, u = p + nr * sd * rk, -nr * sd
                    b.box("maya_kalk_dunkel", (0.05, CHH - 0.02, 0.03), (q[0] + u[0] * 0.015, YS + (k + 0.5) * CHH, q[1] + u[1] * 0.015),
                          rot_y=float(np.degrees(np.arctan2(u[0], u[1]))))
    b.layer = "Kanal"
    return outer, inner, water


def mauerwerk(b, wege, outer, inner, water):
    """staggered vertical joints, a few lighter/darker blocks, drain pipes with a trickle into the channel"""
    rng = np.random.default_rng(len(b.parts) + 31)
    walls = outer.difference(inner)
    bands = [(YW, 1.55), (1.6, 2.5), (2.55, YS)]
    for w in wege:
        L = w.ls.length
        for sd in (-1, 1):
            for bi, (y0, y1) in enumerate(bands):
                for d in np.arange(0.3 + (0.6 if bi % 2 else 0.0), L - 0.1, 1.2):
                    r = wand_punkt(w, d, sd, walls, inner)
                    if r is None:
                        continue
                    q, u = r
                    yaw = float(np.degrees(np.arctan2(u[0], u[1])))
                    b.box("maya_kalk_dunkel", (0.05, y1 - y0, 0.03), (q[0] + u[0] * 0.015, (y0 + y1) / 2, q[1] + u[1] * 0.015), rot_y=yaw)
                    if rng.random() < 0.2 and d + 1.1 < L:
                        r2 = wand_punkt(w, d + 0.6, sd, walls, inner)
                        if r2:
                            q2, u2 = r2
                            b.box("maya_kalk_hell" if rng.random() < 0.6 else "maya_kalk_dunkel", (0.9, y1 - y0 - 0.1, 0.02),
                                  (q2[0] + u2[0] * 0.01, (y0 + y1) / 2, q2[1] + u2[1] * 0.01), rot_y=float(np.degrees(np.arctan2(u2[0], u2[1]))))
            if w.wasser and L > 6:                                            # one drain per side
                d = rng.uniform(0.25, 0.75) * L
                p, t, nr = w.at(d)
                q, u = p + nr * sd * w.wh, -nr * sd
                if inner.contains(Point(*(q - u * 0.3))) and water.contains(Point(*(q + u * 0.3))) and not water.contains(Point(*(q - u * 0.3))):
                    b.beam("rost", (q[0] - u[0] * 0.05, 0.32, q[1] - u[1] * 0.05), (q[0] + u[0] * 0.22, 0.32, q[1] + u[1] * 0.22), 0.2)
                    b.beam("water_jet", (q[0] + u[0] * 0.25, 0.28, q[1] + u[1] * 0.25), (q[0] + u[0] * 0.42, 0.0, q[1] + u[1] * 0.42), 0.12)


# ------------------------------------------------------------------ decoration
def fackel(b, q, u, y0=YW + 2.0):
    """wall torch at wall point q (x, z), u = unit vector from the wall into the room"""
    u = np.asarray(u, float)
    yaw = float(np.degrees(np.arctan2(u[0], u[1])))
    b.box("iron", (0.22, 0.32, 0.06), (q[0] + u[0] * 0.03, y0, q[1] + u[1] * 0.03), rot_y=yaw)
    p0 = np.array((q[0] + u[0] * 0.05, y0 - 0.06, q[1] + u[1] * 0.05))
    p1 = np.array((q[0] + u[0] * 0.36, y0 + 0.3, q[1] + u[1] * 0.36))
    b.beam("wood_dark", p0, p1, 0.07)
    b.hull("iron", [p1 + (dx, dy, dz) for dx in (-0.08, 0.08) for dz in (-0.08, 0.08) for dy in (-0.06, 0.04)])
    b.hull("fackel", [p1 + (dx, 0.04, dz) for dx in (-0.055, 0.055) for dz in (-0.055, 0.055)] + [p1 + (0.0, 0.3, 0.0), p1 + (0.025, 0.18, -0.04)])
    b.fackeln += 1
    b.anchor(f"Fackel_{b.fackeln}", tuple(np.round(p1 + (0, 0.22, 0), 3)), 0)


def glyphe(b, q, u, zahl=13, yc=YW + 1.35, mat="maya_rot"):
    """Maya numeral panel (bars = 5, dots = 1) on the wall at q facing u"""
    u = np.asarray(u, float)
    s = np.array((u[1], -u[0]))
    yaw = float(np.degrees(np.arctan2(u[0], u[1])))
    c = np.array((q[0] + u[0] * 0.03, yc, q[1] + u[1] * 0.03))
    b.box("maya_kalk_dunkel", (1.2, 1.3, 0.05), (c[0] - u[0] * 0.005, yc, c[2] - u[1] * 0.005), rot_y=yaw)
    b.box(mat, (1.0, 1.1, 0.07), tuple(c), rot_y=yaw)
    bars, dots = zahl // 5, zahl % 5
    f = c + np.array((u[0], 0.0, u[1])) * 0.045
    for i in range(bars):
        b.box("maya_jade", (0.72, 0.12, 0.05), (f[0], yc - 0.36 + i * 0.22, f[2]), rot_y=yaw)
    yd = yc - 0.36 + bars * 0.22 + 0.05
    for j in range(dots):
        o = (j - (dots - 1) / 2) * 0.2
        b.box("maya_jade", (0.13, 0.13, 0.05), (f[0] + s[0] * o, yd, f[2] + s[1] * o), rot_y=yaw)


def wand_punkt(w, d, seite, walls, inner, y=None):
    """wall face point on side (+1 left / -1 right) of path w at arc length d, or None if there is no wall"""
    p, t, nr = w.at(d)
    hinten = p + nr * seite * (w.hw + 0.3)
    vorne = p + nr * seite * (w.hw - 0.3)
    if not walls.contains(Point(*hinten)) or not inner.contains(Point(*vorne)):
        return None
    return p + nr * seite * w.hw, -nr * seite


def deko(b, w, outer, inner, fackeln=(), glyphen=(), rohr=None, wurzeln=0, seed=0):
    walls = outer.difference(inner)
    rng = np.random.default_rng(seed)
    for (d, sd) in fackeln:
        r = wand_punkt(w, d, sd, walls, inner)
        if r:
            fackel(b, r[0], r[1])
    for (d, sd, zahl) in glyphen:
        r = wand_punkt(w, d, sd, walls, inner)
        if r:
            glyphe(b, r[0], r[1], zahl)
    if rohr:                                                      # rusty pipe under the springline (later addition)
        sd = rohr
        ok = []
        for d in np.linspace(0.02, w.ls.length - 0.02, max(2, int(w.ls.length / 2.0) + 1)):
            r = wand_punkt(w, d, sd, walls, inner)
            ok.append(None if r is None else np.array(r[0]) + np.array(r[1]) * 0.17)
        for a, c in zip(ok[:-1], ok[1:]):
            if a is not None and c is not None:
                b.beam("rost", (a[0], YS - 0.25, a[1]), (c[0], YS - 0.25, c[1]), 0.16)
        for d in np.arange(1.0, w.ls.length, 3.0):
            r = wand_punkt(w, d, sd, walls, inner)
            if r:
                q, u = np.array(r[0]), np.array(r[1])
                b.beam("iron", (q[0], YS - 0.25, q[1]), (q[0] + u[0] * 0.26, YS - 0.25, q[1] + u[1] * 0.26), 0.05)
    for _ in range(wurzeln):                                      # roots hanging out of the vault slot
        d = rng.uniform(0.15, 0.85) * w.ls.length
        p, t, nr = w.at(d)
        o = rng.uniform(-0.3, 0.3)
        top = np.array((p[0] + nr[0] * o, YT - 0.05, p[1] + nr[1] * o))
        for k in range(3):
            ln = rng.uniform(0.8, 2.2)
            end = top + (rng.uniform(-0.35, 0.35), -ln, rng.uniform(-0.35, 0.35))
            b.beam("wurzel", top, end, 0.045)


def medaillon(b, x=0.0, z=0.0):
    b.layer = "Decke"
    b.cyl("maya_jade", 0.62, 0.1, (x, YT - 0.05, z), 12)
    b.cyl("maya_rot", 0.32, 0.06, (x, YT - 0.13, z), 10)
    b.layer = "Kanal"


# ------------------------------------------------------------------ pieces
def gerade():
    b = neu(101)
    w = Weg([(0, HT), (0, -HT)])
    o, i, _ = kanal(b, [w])
    deko(b, w, o, i, fackeln=((4.0, 1), (12.0, -1)), glyphen=((8.5, 1, 13),), rohr=-1, wurzeln=3, seed=1)
    anschluss(b, "S"), anschluss(b, "N")
    b.layer = None
    return b


def _bogen():
    return [(8 + 8 * np.cos(a), 8 + 8 * np.sin(a)) for a in np.linspace(np.pi, 1.5 * np.pi, 7)]


def kurve():
    b = neu(102)
    w = Weg(_bogen())
    o, i, _ = kanal(b, [w])
    L = w.ls.length
    deko(b, w, o, i, fackeln=((L * 0.2, -1), (L * 0.8, -1), (L * 0.5, 1)), glyphen=((L * 0.5, -1, 9),), rohr=-1, wurzeln=3, seed=2)
    anschluss(b, "S"), anschluss(b, "E")
    b.layer = None
    return b


def t_stueck():
    b = neu(103)
    w1, w2 = Weg([(0, HT), (0, -HT)]), Weg([(0, 0), (HT, 0)])
    o, i, _ = kanal(b, [w1, w2])
    deko(b, w1, o, i, fackeln=((3.0, -1), (13.0, -1), (1.8, 1), (14.2, 1)), glyphen=((8.0, -1, 7),), wurzeln=2, seed=3)
    medaillon(b)
    anschluss(b, "S"), anschluss(b, "N"), anschluss(b, "E")
    b.layer = None
    return b


def kreuzung():
    b = neu(104)
    w1, w2 = Weg([(0, HT), (0, -HT)]), Weg([(-HT, 0), (HT, 0)])
    o, i, _ = kanal(b, [w1, w2])
    deko(b, w1, o, i, fackeln=((1.8, 1), (1.8, -1), (14.2, 1), (14.2, -1)), wurzeln=2, seed=4)
    medaillon(b)
    for d in "NSEW":
        anschluss(b, d)
    b.layer = None
    return b


def maske(b, zf, yb=1.0):
    """Rain-god mask relief (generic Maya style) on a wall face at z = zf facing +Z"""
    def bx(mat, x0, x1, y0, y1, d0, d1):
        box(b, mat, x0, x1, y0, y1, zf + d0, zf + d1)
    bx("maya_kalk_hell", -2.0, 2.0, yb, yb + 3.7, 0.0, 0.2)                     # face
    bx("maya_rot", -2.1, 2.1, yb + 2.95, yb + 3.25, 0.0, 0.35)                 # brow
    for sx in (-1, 1):
        bx("iron", sx * 0.45, sx * 1.35, yb + 2.0, yb + 2.8, 0.0, 0.3)                 # eye sockets
        xa, xb_ = sorted((sx * 0.7, sx * 1.1))
        bx("maya_jade", xa, xb_, yb + 2.2, yb + 2.6, 0.0, 0.38)                 # pupils
        xa, xb_ = sorted((sx * 1.95, sx * 2.65))
        bx("maya_kalk_dunkel", xa, xb_, yb + 1.45, yb + 2.15, 0.0, 0.3)
        xa, xb_ = sorted((sx * 2.15, sx * 2.45))
        bx("maya_rot", xa, xb_, yb + 1.65, yb + 1.95, 0.0, 0.34)
    bx("maya_kalk_dunkel", -0.3, 0.3, yb + 0.9, yb + 2.6, 0.0, 0.6)           # long nose
    bx("maya_kalk_dunkel", -0.3, 0.3, yb + 2.4, yb + 2.95, 0.6, 0.8)          # curl
    bx("maya_kalk_dunkel", -0.3, 0.3, yb + 2.95, yb + 3.15, 0.35, 0.8)
    bx("iron", -1.2, 1.2, yb + 0.3, yb + 0.8, 0.0, 0.28)                      # mouth
    for k in range(5):
        x = -0.9 + k * 0.45
        bx("maya_kalk_hell", x - 0.1, x + 0.1, yb + 0.5, yb + 0.8, 0.28, 0.36)
    for sx in (-1, 1):
        xa, xb_ = sorted((sx * 1.05, sx * 1.35))
        bx("maya_kalk_hell", xa, xb_, yb + 0.05, yb + 0.8, 0.2, 0.42)          # fangs
    bx("maya_rot", -1.4, 1.4, yb + 3.7, yb + 4.55, 0.0, 0.25)                 # headdress
    for k in range(5):
        x = -1.1 + k * 0.55
        bx("maya_jade" if k % 2 else "maya_ocker", x - 0.18, x + 0.18, yb + 4.55, yb + 4.95, 0.0, 0.2)


def ende():
    b = neu(105)
    ZE = -5.0
    w = Weg([(0, HT), (0, ZE)])
    o, i, _ = kanal(b, [w], extra_outer=[sbox(-WK - WT, ZE - WT, WK + WT, ZE)])
    deko(b, w, o, i, fackeln=((11.0, 1), (11.0, -1)), glyphen=((5.0, 1, 4), (5.0, -1, 11)), wurzeln=2, seed=5)
    maske(b, ZE)
    b.beam("water_jet", (0.0, 1.35, ZE + 0.45), (0.0, 0.02, ZE + 0.9), 0.5)  # water out of the mouth
    for sx in (-1, 1):                                                      # offering bowls on the walkway ends
        b.cyl("maya_ocker", 0.28, 0.25, (sx * 3.25, YW + 0.125, ZE + 0.6), 10)
        b.cyl("fackel", 0.1, 0.08, (sx * 3.25, YW + 0.29, ZE + 0.6), 6)
    b.anchor("Maske", (0.0, 0.0, ZE + 2.0), 180)
    anschluss(b, "S")
    b.layer = None
    return b


def halle():
    """32 x 32 m hall: water ring around a stepped pyramid on an island, 12 columns, painted frieze, 4 arms."""
    b = neu(106)
    RI, RO, BAS, INS, YD = 13.0, 13.8, 10.0, 4.5, 7.0
    arms = [Weg([(0, 0), (0, 16)]), Weg([(0, 0), (0, -16)]), Weg([(0, 0), (16, 0)]), Weg([(0, 0), (-16, 0)])]
    room_i, room_o = sbox(-RI, -RI, RI, RI), sbox(-RO, -RO, RO, RO)
    outer = room_o.union(unary_union([w.buf(WK + WT) for w in arms]))
    inner = room_i.union(unary_union([w.buf(WK) for w in arms]))
    island = sbox(-INS, -INS, INS, INS)
    pieces = [sbox(-BAS, -BAS, BAS, -INS), sbox(-BAS, INS, BAS, BAS), sbox(-BAS, -INS, -INS, INS), sbox(INS, -INS, BAS, INS),
              sbox(-WH, -16, WH, -BAS), sbox(-WH, BAS, WH, 16), sbox(-16, -WH, -BAS, WH), sbox(BAS, -WH, 16, WH)]
    water = unary_union(pieces)
    edge = unary_union([sbox(-16.5, -16.5, 16.5, -15.9), sbox(-16.5, 15.9, 16.5, 16.5), sbox(-16.5, -16.5, -15.9, 16.5), sbox(15.9, -16.5, 16.5, 16.5)])
    b.layer = "Kanal"
    flat(b, "maya_kalk_dunkel", outer, FLOOR, YB)
    flat(b, "maya_kalk", inner.difference(water), YB, YW)
    flat(b, "maya_kalk_dunkel", water.buffer(0.25, join_style=2).difference(water).intersection(inner).difference(edge), YW, YW + 0.08)
    flat(b, "algen", water.difference(water.buffer(-0.03, join_style=2)).difference(edge), -0.05, 0.22)
    for p in pieces:
        flat(b, "kanal_wasser", p, YB, 0.0)
    flat(b, "maya_kalk", outer.difference(inner), YB, YS)
    mauerwerk(b, arms + [Weg([(0, -RI), (0, RI)], hw=RI, wasser=False), Weg([(-RI, 0), (RI, 0)], hw=RI, wasser=False)], outer, inner, water)
    shr = room_i.buffer(-0.03, join_style=2).union(unary_union([w.buf(WK - 0.03) for w in arms]))
    for yj in (1.55, 2.5):
        flat(b, "maya_kalk_dunkel", inner.difference(shr), yj, yj + 0.05)
    b.layer = "Decke"
    for k in range(NC):
        op = room_i.union(unary_union([w.buf(WK - (k + 1) * CI) for w in arms]))
        flat(b, "maya_kalk_hell" if k % 2 else "maya_kalk", outer.difference(op), YS + k * CHH, YS + (k + 1) * CHH)
    flat(b, "maya_kalk", outer.difference(room_i), YT, YD)
    flat(b, "maya_kalk_dunkel", outer, YD, YSH)
    for k, (inset, mat) in enumerate(((0.45, "maya_kalk_hell"), (0.9, "maya_rot"), (1.35, "maya_kalk_hell"))):  # stepped cornice + frieze
        flat(b, mat, room_i.difference(room_i.buffer(-inset, join_style=2)), YD - 0.9 + k * 0.3, YD - 0.6 + k * 0.3)
    for x in np.arange(-11.0, 11.1, 2.75):                                   # frieze glyph blocks
        for (cx, cz, along) in ((x, -RI + 0.92, "x"), (x, RI - 0.92, "x"), (-RI + 0.92, x, "z"), (RI - 0.92, x, "z")):
            if along == "x":
                box(b, "maya_jade", cx - 0.3, cx + 0.3, YD - 0.55, YD - 0.35, cz - 0.03 * np.sign(cz), cz + 0.03 * np.sign(cz))
            else:
                box(b, "maya_jade", cx - 0.03 * np.sign(cx), cx + 0.03 * np.sign(cx), YD - 0.55, YD - 0.35, cz - 0.3, cz + 0.3)
    b.layer = "Kanal"
    # columns on the walkway ring
    cols = [(sx * 11.5, sz * 11.5) for sx in (-1, 1) for sz in (-1, 1)]
    cols += [(u, sv * 11.5) for u in (-6.5, 6.5) for sv in (-1, 1)] + [(sv * 11.5, u) for u in (-6.5, 6.5) for sv in (-1, 1)]
    for (x, z) in cols:
        box(b, "maya_kalk_dunkel", x - 0.65, x + 0.65, YW, YW + 0.4, z - 0.65, z + 0.65)
        box(b, "maya_kalk", x - 0.45, x + 0.45, YW + 0.4, YD - 0.6, z - 0.45, z + 0.45)
        box(b, "maya_rot", x - 0.47, x + 0.47, YW + 2.6, YW + 3.0, z - 0.47, z + 0.47)
        box(b, "maya_kalk_hell", x - 0.7, x + 0.7, YD - 0.6, YD - 0.25, z - 0.7, z + 0.7)
        box(b, "maya_kalk_hell", x - 0.85, x + 0.85, YD - 0.25, YD, z - 0.85, z + 0.85)
        if abs(x) == 11.5 and abs(z) == 11.5:
            continue
        nrm = np.array((-np.sign(x), 0.0)) if abs(x) > abs(z) else np.array((0.0, -np.sign(z)))
        fackel(b, (x + nrm[0] * 0.45, z + nrm[1] * 0.45), nrm, YW + 2.2)
    # glyph panels on the room walls
    for u in (-9.0, 9.0):
        glyphe(b, (u, -RI), (0, 1), 12)
        glyphe(b, (u, RI), (0, -1), 17)
        glyphe(b, (-RI, u), (1, 0), 6)
        glyphe(b, (RI, u), (-1, 0), 19)
    # stepped pyramid on the island + temple
    tiers = [(4.2, 0.9), (3.4, 0.9), (2.6, 0.9), (1.8, 0.9)]
    y = YW
    for k, (hs, h) in enumerate(tiers):
        box(b, "maya_kalk" if k % 2 == 0 else "maya_kalk_hell", -hs, hs, y, y + h, -hs, hs)
        box(b, "maya_rot", -hs - 0.02, hs + 0.02, y + h - 0.15, y + h - 0.05, -hs - 0.02, hs + 0.02)
        y += h
    ytop = y                                                                  # 4.2
    n = 12
    for k in range(n):                                                        # steep stair on the south face
        z1 = INS - k * (INS - 1.8) / n
        z0 = INS - (k + 1) * (INS - 1.8) / n
        box(b, "maya_kalk_hell", -0.9, 0.9, YW, YW + (k + 1) * (ytop - YW) / n, z0, z1)
    for sx in (-1, 1):
        xa, xb_ = sorted((sx * 0.9, sx * 1.25))
        b.hull("maya_kalk_dunkel", [(x_, y_, z_) for x_ in (xa, xb_) for (y_, z_) in ((YW, INS), (YW + 0.3, INS), (ytop + 0.25, 1.8), (ytop, 1.8))])
    for sx in (-1, 1):                                                        # feathered-serpent heads at the foot of the stair
        xa, xb_ = sorted((sx * 0.85, sx * 1.35))
        box(b, "maya_kalk_hell", xa, xb_, YW, YW + 0.75, INS - 0.1, INS + 0.7)
        box(b, "iron", xa + 0.06, xb_ - 0.06, YW + 0.25, YW + 0.45, INS + 0.4, INS + 0.72)     # open jaw
        box(b, "maya_rot", xa + 0.15, xb_ - 0.15, YW + 0.27, YW + 0.31, INS + 0.6, INS + 0.85)  # tongue
        for xx in (xa + 0.08, xb_ - 0.12):
            box(b, "maya_kalk_hell", xx, xx + 0.04, YW + 0.32, YW + 0.45, INS + 0.62, INS + 0.68)  # fangs
            box(b, "maya_jade", xx - 0.03 if xx < (xa + xb_) / 2 else xx + 0.04, xx + 0.01 if xx < (xa + xb_) / 2 else xx + 0.08, YW + 0.55, YW + 0.65, INS + 0.25, INS + 0.4)  # eyes
        box(b, "maya_rot", xa - 0.02, xb_ + 0.02, YW + 0.75, YW + 0.85, INS - 0.1, INS + 0.55)     # crest
    box(b, "maya_rot", -1.4, 1.4, ytop, ytop + 1.4, -1.4, 1.4)              # temple
    box(b, "iron", -0.4, 0.4, ytop, ytop + 1.1, 1.4, 1.42)                  # doorway (dark)
    box(b, "maya_kalk_hell", -1.55, 1.55, ytop + 1.4, ytop + 1.62, -1.55, 1.55)
    box(b, "maya_rot", -0.9, 0.9, ytop + 1.62, ytop + 2.15, -0.12, 0.12)    # roof comb
    for x in (-0.6, 0.0, 0.6):
        box(b, "maya_jade", x - 0.12, x + 0.12, ytop + 1.75, ytop + 1.95, 0.12, 0.15)
    box(b, "maya_kalk_dunkel", -0.6, 0.6, ytop, ytop + 0.7, 1.55, 2.0)       # altar in front of the temple
    b.layer = "Kanal_Beute_Jademaske"                                          # Maya treasure: jade mask on the altar
    b.pivots[b.layer] = (0.0, ytop + 0.7, 1.78)
    box(b, "maya_jade", -0.22, 0.22, ytop + 0.7, ytop + 1.12, 1.66, 1.82)
    box(b, "iron", -0.15, -0.05, ytop + 0.92, ytop + 0.98, 1.82, 1.84)
    box(b, "iron", 0.05, 0.15, ytop + 0.92, ytop + 0.98, 1.82, 1.84)
    box(b, "maya_ocker", -0.25, 0.25, ytop + 1.12, ytop + 1.18, 1.64, 1.84)
    b.layer = "Kanal"
    b.anchor("Pyramide_Altar", (0.0, ytop, 2.6), 180)
    for x in (-1.0, 1.0):
        b.cyl("maya_ocker", 0.18, 0.2, (x, ytop + 0.1, 1.9), 8)
        b.cyl("fackel", 0.08, 0.1, (x, ytop + 0.25, 1.9), 6)
    rng = np.random.default_rng(66)
    for _ in range(10):                                                       # roots from the ceiling
        x, z = rng.uniform(-11, 11, 2)
        if abs(x) < 5 and abs(z) < 5:
            continue
        for k in range(3):
            b.beam("wurzel", (x, YD - 0.9, z), (x + rng.uniform(-0.4, 0.4), YD - 0.9 - rng.uniform(1.0, 2.6), z + rng.uniform(-0.4, 0.4)), 0.05)
    for d in "NSEW":
        anschluss(b, d, dist=16.0)
    b.layer = None
    return b


def anschluss_palast():
    """Main channel N-S + 3 m corridor to the west edge = palace UG3 (Kanalwand). Boat parking next to the corridor."""
    b = neu(107)
    w = Weg([(0, HT), (0, -HT)])
    g = Weg([(-HT, 0), (0, 0)], hw=1.5, wasser=False)
    o, i, _ = kanal(b, [w, g])
    deko(b, w, o, i, fackeln=((3.0, -1), (13.0, -1), (4.0, 1), (12.0, 1)), glyphen=((8.0, 1, 10),), rohr=1, wurzeln=2, seed=7)
    deko(b, g, o, i, fackeln=((2.6, 1), (2.6, -1)), glyphen=((1.0, 1, 3),))
    for z in (-3.6, 3.6):                                                     # mooring bollards
        b.cyl("iron", 0.16, 0.55, (-2.95, YW + 0.275, z), 8)
        b.cyl("iron", 0.22, 0.08, (-2.95, YW + 0.58, z), 8)
    for z in np.arange(-2.4, 2.5, 1.2):                                       # old fenders on the walkway edge
        box(b, "rubber", -2.62, -2.5, -0.3, 0.45, z - 0.25, z + 0.25)
    b.anchor("Anschluss_Palast", (-HT, YW, 0.0), -90)
    b.anchor("Boot_Parkplatz", (-0.9, 0.0, 0.0), 180)
    b.anchor("Kanal_Einstieg_Boot", (-3.2, YW, 0.0), 90)
    anschluss(b, "S"), anschluss(b, "N")
    b.layer = None
    return b


def bootsversteck():
    """Secret boat hideout: entry arm from S, stone gate (slides up), chamber with boat lift, shaft opening in the ceiling."""
    b = neu(108)
    ZG0, ZG1 = 3.0, 3.6                                                       # gate zone
    CZ0, YD = -7.6, 7.0
    SZ = -3.0                                                                 # shaft centre z
    SX, SZH = SHAFT
    slot = sbox(-WK - 0.05, ZG0 + 0.05, WK + 0.05, ZG1 - 0.05)
    w = Weg([(0, HT), (0, ZG0)])
    o, i, _ = kanal(b, [w], schaechte=[slot])
    deko(b, w, o, i, fackeln=((2.0, -1),), wurzeln=1, seed=8)
    b.layer = "Decke"                                                         # lintel faces in front of / behind the gate slot
    for (z0, z1) in ((ZG0, ZG0 + 0.05), (ZG1 - 0.05, ZG1)):
        box(b, "maya_kalk", -WK, WK, YS, YSH, z0, z1)
    box(b, "maya_kalk_dunkel", -WK - 0.05, WK + 0.05, YSH - 0.15, YSH, ZG0, ZG1)
    b.layer = "Kanal"
    # chamber
    ch_o = sbox(-WK - WT, CZ0 - WT, WK + WT, ZG0)
    ch_i = sbox(-WK, CZ0, WK, ZG0)
    wat = sbox(-3.2, CZ0, 3.2, ZG0)
    flat(b, "maya_kalk_dunkel", ch_o, FLOOR, YB)
    flat(b, "maya_kalk", ch_i.difference(wat), YB, YW)
    flat(b, "kanal_wasser", wat, YB, 0.0)
    flat(b, "maya_kalk", ch_o.difference(ch_i), YB, YD)
    hole = sbox(-SX, SZ - SZH, SX, SZ + SZH)
    b.layer = "Decke"
    flat(b, "maya_kalk_dunkel", ch_o.difference(hole), YD, YSH)
    b.layer = "Kanal"
    for yj in (1.55, 2.5, 4.2, 5.6):
        flat(b, "maya_kalk_dunkel", ch_i.difference(sbox(-WK + 0.03, CZ0 + 0.03, WK - 0.03, ZG0 + 1)), yj, yj + 0.05)
    # guide posts at the platform corners, ladder on the back wall (continues in the shaft pieces)
    for sx in (-1, 1):
        for zc in (SZ - SZH + 0.15, SZ + SZH - 0.15):
            box(b, "stahl", sx * 2.45 - 0.08, sx * 2.45 + 0.08, YB, YSH, zc - 0.08, zc + 0.08)
    for y in np.arange(YW + 0.3, YSH, 0.3):
        box(b, "iron", -0.3, 0.3, y, y + 0.04, CZ0, CZ0 + 0.16)
    for x in (-0.32, 0.32):
        box(b, "iron", x - 0.03, x + 0.03, YW, YSH, CZ0, CZ0 + 0.18)
    for (sx, z) in ((-1, -1.0), (1, -5.0), (-1, -6.0), (1, 1.5)):            # work lamps (later addition of the gang)
        box(b, "frame_black", sx * WK, sx * (WK - 0.15), 4.6, 4.95, z - 0.2, z + 0.2)
        box(b, "lamp", sx * (WK - 0.15), sx * (WK - 0.27), 4.62, 4.9, z - 0.16, z + 0.16)
    b.beam("rubber", (-3.95, 5.0, -7.4), (-3.95, 5.0, 2.8), 0.04)
    b.beam("rubber", (3.95, 5.0, -7.4), (3.95, 5.0, 2.8), 0.04)
    for (x, z) in ((-3.6, -7.2), (-3.6, -6.5), (3.6, -7.2)):                  # crates + fuel cans on the ledges
        box(b, "crate", x - 0.3, x + 0.3, YW, YW + 0.55, z - 0.25, z + 0.25)
    box(b, "metal_red", 3.4, 3.8, YW, YW + 0.5, -6.6, -6.3)
    box(b, "tarp_blue", -3.95, -3.25, YW, YW + 0.35, -4.5, -2.5)
    # secret gate: stone slab, slides +Y into the lintel slot (looks like a dead end from the network side)
    b.layer = "Kanal_Geheimtor"
    b.pivots[b.layer] = (0.0, YS, (ZG0 + ZG1) / 2)
    box(b, "maya_kalk", -WH, WH, -0.5, YS, ZG0 + 0.1, ZG1 - 0.1)
    for sx in (-1, 1):
        xa, xb_ = sorted((sx * WH, sx * WK))
        box(b, "maya_kalk", xa, xb_, YW, YS, ZG0 + 0.1, ZG1 - 0.1)
    for yj in (1.55, 2.5):
        box(b, "maya_kalk_dunkel", -WK, WK, yj, yj + 0.05, ZG1 - 0.1, ZG1 - 0.07)
    for bi, (y0, y1) in enumerate(((YW, 1.55), (1.6, 2.5), (2.55, YS))):
        for xj in np.arange(-3.3 + 0.6 * (bi % 2), WK, 1.2):
            box(b, "maya_kalk_dunkel", xj - 0.025, xj + 0.025, y0, y1, ZG1 - 0.1, ZG1 - 0.07)
    box(b, "algen", -WH, WH, -0.05, 0.22, ZG1 - 0.1, ZG1 - 0.07)
    glyphe(b, (0.0, ZG1 - 0.1), (0, 1), 20, yc=2.55)
    b.layer = "Kanal"
    # hidden switch: loose jade stone in the east wall of the entry arm
    b.layer = "Kanal_Geheimtor_Schalter"
    b.pivots[b.layer] = (WK, YW + 1.2, 4.8)
    box(b, "maya_jade", WK - 0.08, WK, YW + 1.05, YW + 1.35, 4.65, 4.95)
    box(b, "maya_rot", WK - 0.1, WK - 0.08, YW + 1.15, YW + 1.25, 4.75, 4.85)
    b.layer = "Kanal"
    # boat lift platform (moves up the shaft to the garage)
    b.layer = "Kanal_Bootslift"
    b.pivots[b.layer] = (0.0, -1.0, SZ)
    box(b, "riffelblech", -2.3, 2.3, -1.3, -1.0, SZ - SZH + 0.4, SZ + SZH - 0.4)
    for z in (SZ - SZH + 0.4, SZ + SZH - 0.65):
        box(b, "safety_yellow", -2.3, 2.3, -1.0, -0.98, z, z + 0.25)
    for sx in (-1, 1):
        for zc in (SZ - SZH + 0.15, SZ + SZH - 0.15):
            box(b, "stahl", sx * 2.45 - 0.14, sx * 2.45 + 0.14, -1.45, -0.85, zc - 0.14, zc + 0.14)
            zi = zc + (0.25 if zc < SZ else -0.25)
            box(b, "stahl", sx * 2.2 - 0.1, sx * 2.2 + 0.1, -1.3, -1.05, min(zc, zi), max(zc, zi))
        box(b, "stahl", sx * 2.3 - 0.1, sx * 2.3 + 0.1, -1.6, -1.3, SZ - SZH + 0.4, SZ + SZH - 0.4)
    for z in (SZ - 2.0, SZ + 2.0):                                            # boat chocks
        box(b, "rubber", -0.9, 0.9, -1.0, -0.75, z - 0.15, z + 0.15)
    b.layer = "Kanal"
    b.anchor("Bootslift_Unten", (0.0, -1.0, SZ), 0)
    b.anchor("Boot_Versteck", (0.0, 0.0, SZ), 180)
    b.anchor("Geheimtor_Schalter", (3.3, YW, 4.8), 90)
    b.anchor("Geheimtor", (0.0, 0.0, ZG1 + 2.0), 180)
    b.anchor("Oben", (0.0, YSH, SZ), 0)
    anschluss(b, "S")
    b.layer = None
    return b


def liftschacht(h=4.0):
    b = neu(110 + int(h))
    SX, SZH = SHAFT
    T = 0.6
    b.layer = "Schacht"
    rng_ = sbox(-SX - T, -SZH - T, SX + T, SZH + T).difference(sbox(-SX, -SZH, SX, SZH))
    flat(b, "concrete", rng_, 0.0, h)
    for yj in np.arange(1.0, h, 1.0):
        flat(b, "concrete_dk", sbox(-SX, -SZH, SX, SZH).difference(sbox(-SX + 0.03, -SZH + 0.03, SX - 0.03, SZH - 0.03)), yj, yj + 0.04)
    for sx in (-1, 1):
        for sz in (-1, 1):
            box(b, "stahl", sx * 2.45 - 0.08, sx * 2.45 + 0.08, 0.0, h, sz * (SZH - 0.15) - 0.08, sz * (SZH - 0.15) + 0.08)
    for y in np.arange(0.1, h - 0.01, 0.3):
        box(b, "iron", -0.3, 0.3, y, y + 0.04, -SZH, -SZH + 0.16)
    for x in (-0.32, 0.32):
        box(b, "iron", x - 0.03, x + 0.03, 0.0, h, -SZH, -SZH + 0.18)
    if h >= 2.0:
        box(b, "lamp", SX - 0.12, SX, h - 1.2, h - 0.9, -0.3, 0.3)
        for (y0, y1) in ((0.0, 0.25),):
            for k in range(int(2 * SZH / 0.5)):
                z = -SZH + k * 0.5
                box(b, "safety_yellow" if k % 2 == 0 else "hazard", SX - 0.02, SX, y0, y1, z, z + 0.5)
    b.anchor("Unten", (0.0, 0.0, 0.0), 0)
    b.anchor("Oben", (0.0, h, 0.0), 0)
    b.layer = None
    return b


def versteck_garage():
    """Street-level hideout disguised as a workshop: boat lift opening with floor hatches, roller door, escape car spot,
    heist equipment (blueprint, 2 night-vision goggles, 2 big bombs), safe for the loot."""
    b = neu(120)
    GX, GZ = -3.2, -2.4                                                      # lift/shaft centre
    SX, SZH = SHAFT
    X0, X1, Z0, Z1, T, HW = -7.0, 7.0, -8.0, 8.0, 0.3, 5.0
    hole = sbox(GX - SX, GZ - SZH, GX + SX, GZ + SZH)
    b.layer = "Garage"
    flat(b, "concrete", sbox(X0, Z0, X1, Z1).difference(hole), -0.5, -0.02)
    flat(b, "concrete_light" if "concrete_light" in PALETTE else "concrete", sbox(X0 + T, Z0 + T, X1 - T, Z1 - T).difference(hole), -0.02, 0.0)
    for k in range(int(2 * SX / 0.5)):                                       # hazard frame around the hatch
        x = GX - SX + k * 0.5
        for z0 in (GZ - SZH - 0.25, GZ + SZH):
            box(b, "safety_yellow" if k % 2 == 0 else "hazard", x, x + 0.5, 0.0, 0.01, z0, z0 + 0.25)
    walls = sbox(X0, Z0, X1, Z1).difference(sbox(X0 + T, Z0 + T, X1 - T, Z1 - T))
    door = sbox(-6.0, Z1 - T - 0.01, 6.0, Z1 + 0.01)
    side = sbox(X1 - T - 0.01, 3.6, X1 + 0.01, 4.6)
    flat(b, "garage_wand", walls.difference(door).difference(side), 0.0, HW)
    box(b, "garage_wand", -6.0, 6.0, 4.4, HW, Z1 - T, Z1)
    box(b, "garage_wand", X1 - T, X1, 2.2, HW, 3.6, 4.6)
    for (x0, x1) in ((-6.6, -5.0), (5.0, 6.6)):                              # high windows (frosted)
        box(b, "glass_big" if "glass_big" in PALETTE else "iron", x0, x1, 3.2, 4.0, Z0 - 0.02, Z0 + 0.02)
    box(b, "rolladen_dunkel", -6.3, 6.3, 4.2, 4.65, Z1 - 0.05, Z1 + 0.35)     # roller door housing
    b.text("OFICINA", "safety_yellow", (0.0, 4.27, Z1 + 0.37), 0.3, 0.03, simplify=0.01)
    box(b, "graffiti_pink", X0 - 0.02, X0, 0.6, 1.8, -5.0, -1.5)               # graffiti outside
    box(b, "graffiti_cyan", X0 - 0.03, X0 - 0.01, 0.9, 1.5, -4.4, -2.2)
    b.layer = "Dach"
    flat(b, "dach", sbox(X0 - 0.1, Z0 - 0.1, X1 + 0.1, Z1 + 0.1), HW, HW + 0.3)
    flat(b, "dach", sbox(X0 - 0.1, Z0 - 0.1, X1 + 0.1, Z1 + 0.1).difference(sbox(X0 + 0.15, Z0 + 0.15, X1 - 0.15, Z1 - 0.15)), HW + 0.3, HW + 0.7)
    box(b, "ac" if "ac" in PALETTE else "concrete", 2.0, 3.4, HW + 0.3, HW + 1.2, -5.0, -3.6)
    b.layer = "Garage"
    for (x, z) in ((-3.5, -4.0), (-3.5, 3.5), (3.5, -4.0), (3.5, 3.5)):       # ceiling lamps
        box(b, "lamp", x - 0.6, x + 0.6, HW - 0.12, HW - 0.04, z - 0.12, z + 0.12)
    # workbench + pegboard (back wall, right), shelves (right wall), safe
    box(b, "wood_dark", 0.6, 4.6, 0.85, 0.95, Z0 + T, Z0 + T + 0.75)
    for x in (0.7, 4.5):
        box(b, "iron", x - 0.05, x + 0.05, 0.0, 0.85, Z0 + T + 0.05, Z0 + T + 0.7)
    box(b, "plywood" if "plywood" in PALETTE else "wood_dark", 0.6, 4.6, 1.3, 2.5, Z0 + T, Z0 + T + 0.03)
    for (x, y, w_, h_) in ((1.0, 1.6, 0.5, 0.08), (1.8, 1.5, 0.08, 0.6), (2.6, 1.7, 0.6, 0.1), (3.6, 1.5, 0.3, 0.5)):
        box(b, "metal_red" if "metal_red" in PALETTE else "iron", x, x + w_, y, y + h_, Z0 + T + 0.03, Z0 + T + 0.08)
    for zs in (-5.2, -2.6):
        box(b, "iron", X1 - T - 0.6, X1 - T, 0.0, 2.4, zs - 1.2, zs - 1.15)
        box(b, "iron", X1 - T - 0.6, X1 - T, 0.0, 2.4, zs + 1.15, zs + 1.2)
        for y in (0.3, 1.1, 1.9):
            box(b, "stahl", X1 - T - 0.6, X1 - T, y, y + 0.05, zs - 1.2, zs + 1.2)
            box(b, "crate", X1 - T - 0.55, X1 - T - 0.05, y + 0.05, y + 0.5, zs - 1.0, zs - 0.2)
            box(b, "cardboard" if "cardboard" in PALETTE else "crate", X1 - T - 0.5, X1 - T - 0.1, y + 0.05, y + 0.4, zs + 0.1, zs + 0.9)
    for (x, z, n) in ((6.15, 5.4, 4), (6.15, 6.6, 3), (5.25, 6.6, 2)):        # tyre stacks, oil drums
        for k in range(n):
            b.tire((x, 0.1 + k * 0.2, z))
    for z in (0.6, 1.4):
        b.cyl("metal_red" if "metal_red" in PALETTE else "iron", 0.3, 0.9, (6.25, 0.45, z), 10)
        b.cyl("iron", 0.31, 0.04, (6.25, 0.88, z), 10)
    box(b, "safe", 5.0, 6.6, 0.0, 1.8, Z0 + T, Z0 + T + 1.0)                  # safe for the loot (post-heist)
    b.cyl("chrome" if "chrome" in PALETTE else "stahl", 0.16, 0.06, (5.8, 1.0, Z0 + T + 1.03), 10)
    for k in range(3):                                                        # empty pallets for loot
        box(b, "wood_dark", -0.4 + k * 1.3, 0.8 + k * 1.3, 0.0, 0.15, -6.6, -5.6)
    # equipment table along the left wall
    box(b, "wood_dark", X0 + T, X0 + T + 1.0, 0.85, 0.92, 3.2, 6.8)
    for z in (3.3, 6.7):
        box(b, "iron", X0 + T + 0.05, X0 + T + 0.95, 0.0, 0.85, z - 0.05, z + 0.05)
    box(b, "lamp", X0 + T + 0.1, X0 + T + 0.5, 1.5, 1.6, 4.8, 5.2)
    b.layer = "Garage_Ausruestung_Bauplan"                                    # blueprint of the Casa Império
    b.pivots[b.layer] = (X0 + T + 0.5, 0.92, 4.0)
    box(b, "bauplan", X0 + T + 0.12, X0 + T + 0.88, 0.92, 0.93, 3.6, 4.5)
    for k in range(4):
        box(b, "paint_white" if "paint_white" in PALETTE else "lamp", X0 + T + 0.2 + k * 0.17, X0 + T + 0.22 + k * 0.17, 0.93, 0.935, 3.7, 4.4)
    for k in range(3):
        box(b, "paint_white" if "paint_white" in PALETTE else "lamp", X0 + T + 0.2, X0 + T + 0.8, 0.93, 0.935, 3.75 + k * 0.3, 3.77 + k * 0.3)
    box(b, "bauplan", X0 + T + 0.15, X0 + T + 0.85, 0.92, 1.0, 4.55, 4.63)      # rolled-up copy
    for n_, z in ((1, 5.4), (2, 6.1)):                                        # night-vision goggles
        b.layer = f"Garage_Ausruestung_Nachtsicht_{n_}"
        b.pivots[b.layer] = (X0 + T + 0.5, 0.92, z)
        box(b, "iron", X0 + T + 0.35, X0 + T + 0.65, 0.92, 1.04, z - 0.1, z + 0.1)
        for dz in (-0.06, 0.06):
            box(b, "iron", X0 + T + 0.62, X0 + T + 0.78, 0.95, 1.03, z + dz - 0.035, z + dz + 0.035)
            box(b, "led_green", X0 + T + 0.78, X0 + T + 0.79, 0.97, 1.01, z + dz - 0.02, z + dz + 0.02)
        box(b, "rubber", X0 + T + 0.3, X0 + T + 0.36, 0.94, 1.02, z - 0.16, z + 0.16)
    for n_, z in ((1, 4.7), (2, 6.0)):                                        # 2 big bombs on the floor
        b.layer = f"Garage_Ausruestung_Bombe_{n_}"
        x = X0 + T + 1.75
        b.pivots[b.layer] = (x, 0.0, z)
        m = trimesh.creation.cylinder(radius=0.32, height=1.0, sections=12)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
        b.add("bombe", m.apply_translation((x, 0.34, z)))
        for dx in (-0.3, 0.3):
            m = trimesh.creation.cylinder(radius=0.335, height=0.08, sections=12)
            m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
            b.add("iron", m.apply_translation((x + dx, 0.34, z)))
        box(b, "iron", x - 0.2, x + 0.2, 0.62, 0.78, z - 0.14, z + 0.14)
        box(b, "led_red", x - 0.12, x + 0.12, 0.78, 0.785, z - 0.06, z + 0.06)
        b.beam("metal_red" if "metal_red" in PALETTE else "led_red", (x - 0.15, 0.7, z + 0.14), (x - 0.45, 0.5, z + 0.3), 0.02)
        b.beam("door_blue" if "door_blue" in PALETTE else "iron", (x + 0.15, 0.7, z + 0.14), (x + 0.45, 0.5, z + 0.3), 0.02)
        box(b, "wood_dark", x - 0.55, x + 0.55, 0.0, 0.05, z - 0.25, z + 0.25)
    # floor hatches over the lift shaft (hinges on the long edges, swing up)
    b.layer = "Garage_Bodenklappe_L"
    b.pivots[b.layer] = (GX - SX, 0.0, GZ)
    box(b, "riffelblech", GX - SX, GX - 0.01, -0.08, 0.0, GZ - SZH, GZ + SZH)
    b.layer = "Garage_Bodenklappe_R"
    b.pivots[b.layer] = (GX + SX, 0.0, GZ)
    box(b, "riffelblech", GX + 0.01, GX + SX, -0.08, 0.0, GZ - SZH, GZ + SZH)
    for (lay, x) in (("Garage_Bodenklappe_L", GX - SX + 0.3), ("Garage_Bodenklappe_R", GX + SX - 0.3)):
        b.layer = lay
        for z in (GZ - SZH + 0.8, GZ + SZH - 0.8):
            box(b, "stahl", x - 0.15, x + 0.15, 0.0, 0.03, z - 0.3, z + 0.3)
    # roller door (pivot at the top: scale Y to open) + side door
    b.layer = "Garage_Tor"
    b.pivots[b.layer] = (0.0, 4.4, Z1 - 0.15)
    box(b, "rolladen", -6.0, 6.0, 0.0, 4.4, Z1 - 0.2, Z1 - 0.1)
    for y in np.arange(0.4, 4.4, 0.4):
        box(b, "rolladen_dunkel", -6.0, 6.0, y - 0.02, y + 0.02, Z1 - 0.1, Z1 - 0.08)
    b.layer = "Garage_Seitentuer"
    b.pivots[b.layer] = (X1 - 0.15, 0.0, 3.6)
    box(b, "door_metal" if "door_metal" in PALETTE else "stahl", X1 - 0.2, X1 - 0.1, 0.0, 2.15, 3.62, 4.58)
    box(b, "chrome" if "chrome" in PALETTE else "stahl", X1 - 0.08, X1 - 0.03, 1.0, 1.06, 4.3, 4.45)
    b.layer = None
    b.anchor("Unten", (GX, -0.5, GZ), 0)
    b.anchor("Bootslift_Ziel", (GX, 0.0, GZ), 0)
    b.anchor("Fluchtauto", (3.4, 0.0, -1.0), 0)
    b.anchor("Garage_Eingang", (0.0, 0.0, Z1 + 1.5), 180)
    b.anchor("Garage_Tresor", (5.8, 0.0, Z0 + T + 1.8), 180)
    b.anchor("Beute_Ablage", (0.9, 0.0, -6.0), 180)
    b.anchor("Ausruestung_Tisch", (X0 + T + 1.6, 0.0, 5.0), -90)
    return b


def einstieg():
    """Straight channel with a side niche + round shaft with ladder (walk in/out through a manhole)."""
    b = neu(112)
    w = Weg([(0, HT), (0, -HT)])
    g = Weg([(0, 0), (6.6, 0)], hw=1.2, wasser=False)
    kreis = Point(5.9, 0.0).buffer(0.7, 3)
    o, i, _ = kanal(b, [w, g], extra_outer=[sbox(6.6, -2.0, 7.4, 2.0)], schaechte=[kreis])
    deko(b, w, o, i, fackeln=((4.0, -1), (12.0, -1), (3.0, 1), (13.0, 1)), glyphen=((8.0, -1, 2),), wurzeln=2, seed=12)
    for y in np.arange(YW + 0.3, YSH, 0.3):
        box(b, "iron", 6.44, 6.6, y, y + 0.04, -0.28, 0.28)
    for z in (-0.3, 0.3):
        box(b, "iron", 6.42, 6.6, YW, YSH, z - 0.03, z + 0.03)
    b.anchor("Einstieg_Unten", (5.0, YW, 0.0), 90)
    b.anchor("Oben", (5.9, YSH, 0.0), 0)
    anschluss(b, "S"), anschluss(b, "N")
    b.layer = None
    return b


def schacht_rund(h=4.0):
    b = neu(113)
    b.layer = "Schacht"
    flat(b, "brick_old", Point(0, 0).buffer(1.2, 3).difference(Point(0, 0).buffer(0.7, 3)), 0.0, h)
    for y in np.arange(0.1, h - 0.01, 0.3):
        box(b, "iron", 0.54, 0.7, y, y + 0.04, -0.28, 0.28)
    for z in (-0.3, 0.3):
        box(b, "iron", 0.52, 0.7, 0.0, h, z - 0.03, z + 0.03)
    b.anchor("Unten", (0.0, 0.0, 0.0), 0)
    b.anchor("Oben", (0.0, h, 0.0), 0)
    b.layer = None
    return b


def gullydeckel():
    b = neu(114)
    H = 1.5
    b.layer = "Schacht"
    flat(b, "brick_old", Point(0, 0).buffer(1.2, 3).difference(Point(0, 0).buffer(0.7, 3)), -H, -0.3)
    flat(b, "concrete_dk", sbox(-1.0, -1.0, 1.0, 1.0).difference(Point(0, 0).buffer(0.7, 3)), -0.3, -0.06)
    flat(b, "iron", Point(0, 0).buffer(0.86, 4).difference(Point(0, 0).buffer(0.7, 4)), -0.06, 0.0)
    for y in np.arange(-H + 0.1, -0.35, 0.3):
        box(b, "iron", 0.54, 0.7, y, y + 0.04, -0.28, 0.28)
    for z in (-0.3, 0.3):
        box(b, "iron", 0.52, 0.7, -H, -0.3, z - 0.03, z + 0.03)
    b.layer = "Schacht_Gullydeckel"
    b.pivots[b.layer] = (0.0, 0.0, 0.0)
    b.cyl("iron", 0.69, 0.05, (0.0, -0.025, 0.0), 16)
    for k in range(-2, 3):
        box(b, "stahl", -0.5, 0.5, 0.0, 0.008, k * 0.2 - 0.02, k * 0.2 + 0.02)
        box(b, "stahl", k * 0.2 - 0.02, k * 0.2 + 0.02, 0.0, 0.008, -0.5, 0.5)
    b.layer = None
    b.anchor("Unten", (0.0, -H, 0.0), 0)
    b.anchor("Einstieg_Oben", (0.0, 0.0, 1.2), 180)
    return b


def auslass_meer():
    """Channel end with a stone portal + double grate (swings outwards) into the sea; open channel with quay walls."""
    b = neu(115)
    ZP = -3.6
    w = Weg([(0, HT), (0, ZP)])
    o, i, _ = kanal(b, [w])
    deko(b, w, o, i, fackeln=((3.0, 1), (9.0, -1)), wurzeln=1, seed=15)
    b.layer = "Kanal"
    D0, D1 = ZP - 0.8, ZP                                                      # portal facade
    PW = 7.0
    box(b, "maya_kalk_dunkel", -PW, PW, FLOOR, YB, -HT, ZP)                   # outside slab
    for sx in (-1, 1):
        xa, xb_ = sorted((sx * WH, sx * PW))
        box(b, "maya_kalk", xa, xb_, YB, YW, D0, D1)
        xa, xb_ = sorted((sx * WK, sx * PW))
        box(b, "maya_kalk", xa, xb_, YW, YS, D0, D1)
        for k in range(NC):
            xa, xb_ = sorted((sx * (WK - (k + 1) * CI), sx * PW))
            box(b, "maya_kalk_hell" if k % 2 else "maya_kalk", xa, xb_, YS + k * CHH, YS + (k + 1) * CHH, D0, D1)
    box(b, "maya_kalk_dunkel", -PW, PW, YT, YSH + 0.6, D0, D1)
    box(b, "maya_rot", -PW - 0.05, PW + 0.05, YSH + 0.1, YSH + 0.35, D0 - 0.05, D1)
    for x in (-5.5, -3.3, -1.1, 1.1, 3.3, 5.5):
        box(b, "maya_jade", x - 0.3, x + 0.3, YSH + 0.4, YSH + 0.55, D0 - 0.05, D0)
    maske_klein = [(-5.6, 4.6), (5.6, 4.6)]
    for (x, y) in maske_klein:
        box(b, "maya_kalk_hell", x - 0.6, x + 0.6, y - 0.7, y + 0.7, D0 - 0.15, D0)
        box(b, "iron", x - 0.4, x - 0.1, y, y + 0.3, D0 - 0.2, D0 - 0.15)
        box(b, "iron", x + 0.1, x + 0.4, y, y + 0.3, D0 - 0.2, D0 - 0.15)
    # open channel to the tile edge: water + quays + rocks
    flat(b, "kanal_wasser", sbox(-WH, -HT, WH, ZP), YB, 0.0)
    for sx in (-1, 1):
        xa, xb_ = sorted((sx * WH, sx * (WK + WT)))
        box(b, "maya_kalk", xa, xb_, YB, YW, -HT, D0)
        xa, xb_ = sorted((sx * (WK + 0.3), sx * (WK + WT)))
        box(b, "maya_kalk_dunkel", xa, xb_, YW, YW + 0.6, -HT, D0)
        for z in np.arange(-7.4, D0 - 0.4, 1.3):
            b.rock("rock" if "rock" in PALETTE else "stone", 0.7, (sx * 5.9, 0.0, z), 0.8)
    box(b, "algen", -WH, -WH + 0.03, -0.05, 0.22, -HT, ZP)
    box(b, "algen", WH - 0.03, WH, -0.05, 0.22, -HT, ZP)
    # grate: the boat passage (channel, x +-2.5) is a double gate hinged at x +-2.5 (swings outwards, -Z);
    # walkway sides and the vault tympanum above 4.3 m are fixed bars
    def bar_top(x):
        return YS + CHH * sum(1 for k in range(NC) if WK - (k + 1) * CI > abs(x) + 0.03)
    YG = YS + 2 * CHH                                                          # 4.3 = top of the gate leaves
    ZG = ZP - 0.08
    for sx in (-1, 1):
        for x in (2.75, 3.0, 3.25, 3.5, 3.75):
            box(b, "iron", sx * x - 0.03, sx * x + 0.03, YW, bar_top(x), ZG - 0.03, ZG + 0.03)
        for y in (YW + 0.4, 2.0, YS - 0.1):
            xa, xb_ = sorted((sx * WH, sx * WK))
            box(b, "iron", xa, xb_, y - 0.04, y + 0.04, ZG - 0.04, ZG + 0.04)
    for x in np.arange(-2.25, 2.26, 0.25):
        if bar_top(x) > YG + 0.05:
            box(b, "iron", x - 0.03, x + 0.03, YG, bar_top(x), ZG - 0.03, ZG + 0.03)
    box(b, "iron", -WH, WH, YG - 0.04, YG + 0.04, ZG - 0.04, ZG + 0.04)
    for (lay, sx) in (("Kanal_Auslassgitter_L", -1), ("Kanal_Auslassgitter_R", 1)):
        b.layer = lay
        b.pivots[lay] = (sx * WH, 0.0, ZG)
        for x in np.arange(0.125, WH, 0.25):
            box(b, "iron", sx * x - 0.03, sx * x + 0.03, YB, YG - 0.05, ZG - 0.03, ZG + 0.03)
        for y in (YB + 0.4, YW + 0.3, 2.0, YS - 0.1, YG - 0.15):
            xa, xb_ = sorted((sx * 0.02, sx * (WH - 0.02)))
            box(b, "iron", xa, xb_, y - 0.05, y + 0.05, ZG - 0.045, ZG + 0.045)
        box(b, "rost", sx * 0.08 - 0.06, sx * 0.08 + 0.06, 1.0, 1.4, ZG - 0.09, ZG + 0.09)
    b.layer = None
    b.anchor("Auslass", (0.0, 0.0, ZP - 1.0), 180)
    b.anchor("Meer", (0.0, 0.0, -HT), 180)
    anschluss(b, "S")
    return b


# ------------------------------------------------------------------ demo network (pieces placed by anchors)
def _setze(v, src, pos, deg, anker=True, skip=("Anschluss_Kanal_",)):
    M = trimesh.transformations.rotation_matrix(np.radians(deg), [0, 1, 0])
    M[:3, 3] = pos
    piv = getattr(src, "pivots", {})
    for key, meshes in src.parts.items():
        for m in meshes:
            m2 = m.copy()
            m2.apply_transform(M)
            v.parts[key].append(m2)
    for lay, p in piv.items():
        v.pivots[lay] = tuple(trimesh.transformations.transform_points([p], M)[0])
    if anker:
        for k, (p, yaw) in src.anchors.items():
            if any(k.startswith(s) for s in skip) or k in ("Oben", "Unten"):
                continue
            q = trimesh.transformations.transform_points([p], M)[0]
            if k.startswith("Fackel_"):
                v.fackeln += 1
                k = f"Fackel_{v.fackeln}"
            n, j = k, 2
            while n in v.anchors:
                n, j = f"{k}_{j}", j + 1
            v.anchors[n] = (np.asarray(q, float), yaw + deg)


def _anker(b, name, deg=0.0):
    p, yaw = b.anchors[name]
    M = trimesh.transformations.rotation_matrix(np.radians(deg), [0, 1, 0])
    return np.asarray(trimesh.transformations.transform_points([p], M)[0])


def beispielnetz():
    """Demo: palace connector at the origin (same anchor as the single piece -> fits the palace without touching it),
    hall with pyramid, crossing with sea outlet, loop with T-pieces/curves, boat hideout with 13 m lift shaft + garage on the
    street (y 21,1 = palace ground level), manhole shaft with ladder, dead ends with masks."""
    v = neu(199)
    T = [(anschluss_palast, (0, 0), 0), (gerade, (0, -16), 0), (gerade, (0, -32), 0), (halle, (0, -56), 0), (bootsversteck, (0, -80), 0),
         (einstieg, (-24, -56), 90), (ende, (-40, -56), 90), (kreuzung, (24, -56), 0), (ende, (40, -56), -90),
         (auslass_meer, (24, -72), 0), (ende, (24, -40), 180),
         (t_stueck, (0, 16), 0), (kurve, (16, 16), -90), (gerade, (16, 32), 0), (kurve, (16, 48), 180),
         (t_stueck, (0, 48), 90), (gerade, (0, 32), 0), (ende, (-16, 48), 90)]
    for fn, (x, z), deg in T:
        src = fn()
        _setze(v, src, (x, 0.0, z), deg)
        if fn is bootsversteck:
            top = _anker(src, "Oben", deg) + (x, 0, z)
        if fn is einstieg:
            mtop = _anker(src, "Oben", deg) + (x, 0, z)
    y = top[1]
    for h in (4.0, 4.0, 4.0, 1.0):                                            # 13 m lift shaft
        _setze(v, liftschacht(h), (top[0], y, top[2]), 0)
        y += h
    g = versteck_garage()
    u = _anker(g, "Unten")
    _setze(v, g, (top[0] - u[0], y - u[1], top[2] - u[2]), 0)
    y = mtop[1]
    for _ in range(3):
        _setze(v, schacht_rund(4.0), tuple(mtop[:1]) + (y,) + tuple(mtop[2:]), 90)
        y += 4.0
    _setze(v, gullydeckel(), (mtop[0], y + 1.5, mtop[2]), 90)
    v.layer = None
    return v


TEILE = [
    # slug, name, builder, levels, gallery lift
    ("10_kanal_beispielnetz", "Maya-Kanal – Beispielnetz", beispielnetz, ["Dach", "Decke", "Kanal", "Garage", "Schacht"], 2.0),
    ("11_kanal_gerade", "Kanal gerade 16 m", gerade, LEVELS, 2.0),
    ("12_kanal_kurve", "Kanal Kurve 90°", kurve, LEVELS, 2.0),
    ("13_kanal_t", "Kanal T-Stück", t_stueck, LEVELS, 2.0),
    ("14_kanal_kreuzung", "Kanal Kreuzung", kreuzung, LEVELS, 2.0),
    ("15_kanal_ende", "Kanal Ende (Maske)", ende, LEVELS, 2.0),
    ("16_kanal_halle", "Maya-Halle mit Pyramide 32 m", halle, LEVELS, 2.0),
    ("17_kanal_anschluss_palast", "Anschluss Palast + Boot-Parkplatz", anschluss_palast, LEVELS, 2.0),
    ("18_kanal_bootsversteck", "Boot-Versteck (Geheimtor + Bootslift)", bootsversteck, LEVELS, 2.0),
    ("19_kanal_liftschacht_4m", "Liftschacht 4 m", lambda: liftschacht(4.0), ["Schacht"], 0.0),
    ("20_kanal_liftschacht_1m", "Liftschacht 1 m", lambda: liftschacht(1.0), ["Schacht"], 0.0),
    ("21_kanal_versteck_garage", "Versteck-Garage (Straße)", versteck_garage, ["Dach", "Garage"], 0.5),
    ("22_kanal_einstieg", "Kanal mit Einstiegsnische", einstieg, LEVELS, 2.0),
    ("23_kanal_schacht_rund_4m", "Einstiegsschacht rund 4 m", lambda: schacht_rund(4.0), ["Schacht"], 0.0),
    ("24_kanal_gullydeckel", "Gullydeckel (Straße)", gullydeckel, ["Schacht"], 1.5),
    ("25_kanal_auslass_meer", "Auslass zum Meer (Gitter)", auslass_meer, LEVELS, 2.0),
]
