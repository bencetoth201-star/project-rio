import json, numpy as np, trimesh
import car
from lib import export, SLOT_PALETTES
b = car.valente_gt()
tris, mats, bnd, slots = export(b, 'out_cars/valente_gt', 'Valente GT')
geo = trimesh.util.concatenate([m for ms in b.parts.values() for m in ms]).bounds
size = geo[1] - geo[0]
combos = int(np.prod([len(SLOT_PALETTES[s.split('_')[1]]) for s in slots]))
meta = dict(houses=[dict(slug='valente_gt', name='Valente GT', cls='Sport-Coupé', tris=tris, mats=mats, slots=slots, combos=combos,
                         size=[round(float(v), 2) for v in size], lot=[round(float(size[0]), 2), round(float(size[2]), 2)],
                         anchors={k: [round(float(c), 3) for c in p] + [yaw] for k, (p, yaw) in b.anchors.items()})],
            palettes=SLOT_PALETTES, rows={'Sport-Coupé': 0}, lotLabel='Maße', allLabel='Fahrzeuge', allHint='',
            title='Valente GT', subtitle='Fiktives Sport-Coupé für GTA Mobile · Lack, Felgen und Bremssättel würfelbar · Räder drehbar')
json.dump(meta, open('out_cars/meta.json', 'w'), indent=1, ensure_ascii=False)
print(tris, np.round(size, 2), combos)
