"""Garagem 021 – Tuning-Werkstatt (Oficina) in der Zona Norte.
Außen: alte Halle mit Satteldach aus Wellblech, Graffiti, Neonschild, 3 Rolltore, Vorhof mit 2 Abholplätzen.
Innen (Zonen mit Ankern): Einfahrt/Annahme, Lackierkabine, Felgen + Reifen, 2 Scherenhebebühnen,
Leistungsprüfstand, Werkbank/Teileregale, Büro (EG) + Lounge (OG).
Front +Z, Pivot Grundstücksmitte. Nodes <Ebene>__<Material>: Aussen, EG, OG, Dach, Tor_1..3 (Pivot oben, zum Öffnen Y skalieren)."""
import numpy as np
import trimesh
from lib import B, PALETTE

PALETTE.update({
    "floor_epoxy": "#8E9296", "wall_inner": "#D9D6CF", "booth_white": "#ECEDEA", "booth_floor": "#55595D",
    "neon_orange": "#FF8A1F", "carbon": "#26282B", "tool_red": "#C62A28", "safety_yellow": "#F2C230",
    "rim_gold": "#C9A23A", "rim_black": "#1C1C1E", "rim_red": "#B3242A", "screen": "#2FE0F0",
    "block": "#B9B5AC", "mural_a": "#E8452E", "mural_b": "#2EA8E8", "mural_c": "#F2C230", "mural_d": "#9B4DFF",
    "drum_blue": "#2457A8", "drum_red": "#B3352B", "sofa_black": "#2B2B2E", "lift_red": "#C0332B",
    "dach_stahl": "#5B6168", "dach_kabine": "#E4E6E3", "dach_tin": "#8E969A", "engine_grey": "#4A4D52",
})

X0, X1 = -12.0, 12.0
BZ0, BZ1 = -14.0, 6.0          # building
YZ1 = 14.0                      # yard front edge
T = 0.3
IX0, IX1, IZ0, IZ1 = X0 + T, X1 - T, BZ0 + T, BZ1 - T
F = 0.15
H = 6.5                         # eaves
RIDGE = 8.3
DOORS = [(-7.0, "Tor_1"), (0.0, "Tor_2"), (7.0, "Tor_3")]
DW, DH = 4.2, 4.2
OGY = 3.25                      # office mezzanine floor top


def tuning():
    b = B(2102)

    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def wall_x(mat, z, x0, x1, y0, y1, holes=(), t=T):
        z0, z1 = z - t / 2, z + t / 2
        xs = [x0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [x1]
        for a, c in zip(xs[0::2], xs[1::2]):
            if c - a > 1e-3:
                box(mat, a, c, y0, y1, z0, z1)
        for (xa, xb, ya, yb) in holes:
            if ya > y0:
                box(mat, xa, xb, y0, ya, z0, z1)
            if yb < y1:
                box(mat, xa, xb, yb, y1, z0, z1)

    def wall_z(mat, x, z0, z1, y0, y1, holes=(), t=T):
        x0, x1 = x - t / 2, x + t / 2
        zs = [z0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [z1]
        for a, c in zip(zs[0::2], zs[1::2]):
            if c - a > 1e-3:
                box(mat, x0, x1, y0, y1, a, c)
        for (za, zb, ya, yb) in holes:
            if ya > y0:
                box(mat, x0, x1, y0, ya, za, zb)
            if yb < y1:
                box(mat, x0, x1, yb, y1, za, zb)

    def cyl_x(mat, r, length, c, sections=12):
        m = trimesh.creation.cylinder(radius=r, height=length, sections=sections)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
        b.add(mat, m.apply_translation(c))

    def cyl_z(mat, r, length, c, sections=12):
        m = trimesh.creation.cylinder(radius=r, height=length, sections=sections)
        b.add(mat, m.apply_translation(c))

    def rim_on_wall(x, y, z, mat, face=+1):
        """Display rim hanging on a wall that runs along Z (face = +1 → visible from +X)."""
        cyl_x("rubber", 0.34, 0.2, (x + face * 0.12, y, z), 14)
        cyl_x(mat, 0.26, 0.22, (x + face * 0.13, y, z), 10)
        cyl_x("metal", 0.06, 0.24, (x + face * 0.14, y, z), 6)
        for k in range(5):
            a = k * 2 * np.pi / 5
            b.box(mat, (0.03, 0.05, 0.24), (x + face * 0.25, y + 0.12 * np.sin(a), z + 0.12 * np.cos(a)), rot_x=np.degrees(-a))

    def tire_stack(x, z, n, y=0.0):
        for k in range(n):
            m = trimesh.creation.annulus(r_min=0.22, r_max=0.34, height=0.22, sections=12)
            m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
            b.add("rubber", m.apply_translation((x, y + 0.11 + k * 0.23, z)))

    wall = b.slot("wall", 1, "#C9D4C0")       # lower facade paint

    # =================================================================
    # AUSSEN
    # =================================================================
    b.layer = "Aussen"
    box("concrete", X0, X1, 0, 0.12, BZ1, YZ1)                                         # yard
    for x, z, w, d in [(-3.0, 9.0, 2.4, 1.4), (4.5, 11.5, 1.6, 1.0), (-8.0, 12.6, 1.2, 0.8)]:
        box("asphalt", x - w / 2, x + w / 2, 0.12, 0.125, z - d / 2, z + d / 2)       # patched spots
    for x, z in [(-1.5, 10.5), (6.0, 8.6), (-6.4, 9.6)]:
        b.rock("frame_black", 0.5, (x, 0.12, z), 0.02)                                 # oil stains
    for (xa, xb) in [(-11.9, -9.4), (9.4, 11.9)]:                                      # pick-up spots
        for x in (xa, xb):
            box("paint_white", x - 0.06, x + 0.06, 0.12, 0.13, 7.0, 12.6)
        box("paint_white", xa, xb, 0.12, 0.13, 7.0, 7.12)
    box("concrete_dk", X0, X1, 0, 0.16, YZ1 - 0.25, YZ1)                               # lowered curb (driveway)

    # front wall with 3 door openings + gable
    holes = [(cx - DW / 2, cx + DW / 2, 0.0, DH) for cx, _ in DOORS]
    wall_x(wall, BZ1 - T / 2, X0, X1, 0, 3.0, holes)
    wall_x("block", BZ1 - T / 2, X0, X1, 3.0, H, [(xa, xb, 3.0, DH) for (xa, xb, _, _) in holes])
    for y in np.arange(3.4, H, 0.4):                                                   # block courses
        box("concrete_dk", X0, X1, y, y + 0.02, BZ1, BZ1 + 0.01)
    for z in (BZ1 - T / 2, BZ0 + T / 2):
        b.hull("block", [(x, H, z + dz) for x in (X0, X1) for dz in (-T / 2, T / 2)] + [(0, RIDGE, z + dz) for dz in (-T / 2, T / 2)])
    for cx, _ in DOORS:                                                                # door frames + roll boxes
        box("frame_black", cx - DW / 2 - 0.15, cx - DW / 2, 0, DH, BZ1 - 0.05, BZ1 + 0.12)
        box("frame_black", cx + DW / 2, cx + DW / 2 + 0.15, 0, DH, BZ1 - 0.05, BZ1 + 0.12)
        box("metal", cx - DW / 2 - 0.15, cx + DW / 2 + 0.15, DH, DH + 0.45, BZ1, BZ1 + 0.5)
        box("safety_yellow", cx - DW / 2 - 0.15, cx - DW / 2, 0, 1.0, BZ1 + 0.12, BZ1 + 0.14)
        box("safety_yellow", cx + DW / 2, cx + DW / 2 + 0.15, 0, 1.0, BZ1 + 0.12, BZ1 + 0.14)
    # neon sign
    box("sign_dark", -6.2, 6.2, 4.7, 6.35, BZ1 + 0.5, BZ1 + 0.62)
    box("frame_black", -6.3, 6.3, 4.65, 4.72, BZ1 + 0.45, BZ1 + 0.7)
    for x in (-5.0, 5.0):
        b.beam("frame_black", (x, 6.2, BZ1), (x, 6.2, BZ1 + 0.55), 0.05)
    b.text("GARAGEM", ["neon_orange"] * 7, (-1.95, 5.72, BZ1 + 0.62), 0.78, 0.06, simplify=0.02)
    b.text("021", ["led_cyan"] * 3, (3.2, 5.72, BZ1 + 0.62), 0.78, 0.06, simplify=0.02)
    b.text("TUNING · PERFORMANCE", ["paint_white"] * 20, (0.0, 4.98, BZ1 + 0.62), 0.28, 0.03, simplify=0.02)
    for x in (-10.4, 10.4):                                                            # floodlights
        b.box("frame_black", (0.5, 0.3, 0.3), (x, 5.2, BZ1 + 0.3), rot_x=-25)
        b.box("lamp", (0.42, 0.04, 0.22), (x, 5.06, BZ1 + 0.38), rot_x=-25)

    # side + back walls (high strip windows)
    win = [(z, z + 2.4, 4.4, 5.8) for z in (-12.0, -7.0, -2.0, 2.4)]
    for x in (X0 + T / 2, X1 - T / 2):
        wall_z(wall, x, BZ0, BZ1 - T, 0, 3.0)
        wall_z("block", x, BZ0, BZ1 - T, 3.0, H, win)
        for (za, zb, ya, yb) in win:
            box("glass", x - 0.03, x + 0.03, ya, yb, za, zb)
            for zz in np.arange(za, zb + 0.01, 0.6):
                box("frame_black", x - 0.06, x + 0.06, ya, yb, zz - 0.03, zz + 0.03)
    wall_x(wall, BZ0 + T / 2, X0 + T, X1 - T, 0, 3.0)
    wall_x("block", BZ0 + T / 2, X0 + T, X1 - T, 3.0, H)
    box("door_metal", 8.0, 9.0, F, 2.3, BZ0 - 0.06, BZ0)                                # back door
    # graffiti mural on the left side wall + big "021"
    rng = np.random.default_rng(21)
    for k in range(14):
        zc, yc = rng.uniform(-12.5, 4.5), rng.uniform(0.4, 2.7)
        b.box(f"mural_{'abcd'[k % 4]}", (0.01, rng.uniform(0.4, 1.0), rng.uniform(1.0, 3.0)), (X0 - 0.01, yc, zc), rot_x=rng.uniform(-15, 15))
    b.text("021", ["mural_c", "mural_a", "mural_b"], (X0 - 0.03, 1.6, -4.0), 2.2, 0.05, rot_y=-90, simplify=0.02)
    # yard props: oil drums, tire stack, meter + conduit
    for (x, z, m) in [(-11.2, 6.6, "drum_blue"), (-10.5, 6.5, "drum_red"), (-11.3, 7.3 - 0.6, "drum_blue")]:
        b.cyl(m, 0.3, 0.9, (x, 0.12 + 0.45, z + 0.1), 10)
    tire_stack(11.3, 6.6, 5, 0.12)
    tire_stack(10.6, 6.5, 3, 0.12)
    box("meter", 2.8, 3.4, 1.3, 2.0, BZ1, BZ1 + 0.18)
    box("frame_black", 3.05, 3.15, 2.0, 3.0, BZ1, BZ1 + 0.08)
    b.anchor("Strom_Anschluss", (3.1, 3.0, BZ1 + 0.05), 0)
    # exhaust duct of the paint booth above the roof
    b.cyl("metal", 0.4, 2.0, (-8.0, 8.0, -9.0), 10)
    b.cyl("metal", 0.55, 0.15, (-8.0, 9.05, -9.0), 10)

    # =================================================================
    # TORE – roll-up doors (pivot at the top, scale Y to open)
    # =================================================================
    for cx, name in DOORS:
        b.layer = name
        b.pivots[name] = (cx, DH, BZ1 - 0.1)
        box("shutter", cx - DW / 2, cx + DW / 2, 0.02, DH, BZ1 - 0.14, BZ1 - 0.06)
        for y in np.arange(0.2, DH, 0.18):
            box("metal", cx - DW / 2, cx + DW / 2, y, y + 0.03, BZ1 - 0.06, BZ1 - 0.04)
        box("frame_black", cx - DW / 2, cx + DW / 2, 0.02, 0.14, BZ1 - 0.16, BZ1 - 0.02)
        box("metal", cx - 0.2, cx + 0.2, 0.3, 0.38, BZ1 - 0.04, BZ1 + 0.02)            # handle

    # =================================================================
    # EG
    # =================================================================
    b.layer = "EG"
    box("floor_epoxy", IX0, IX1, 0, F, IZ0, IZ1)
    # inner lining (light) – front with door holes, sides with window holes
    wall_x("wall_inner", IZ1 - 0.03, IX0, IX1, F, H, [(xa, xb, 0, DH + 0.1) for (xa, xb, _, _) in holes], t=0.05)
    for x in (IX0 + 0.03, IX1 - 0.03):
        wall_z("wall_inner", x, IZ0, IZ1, F, H, win, t=0.05)
    wall_x("wall_inner", IZ0 + 0.03, IX0, IX1, F, H, [(8.0, 9.0, 0, 2.3)], t=0.05)
    # safety lines + lane arrows
    for cx, _ in DOORS:
        for x in (cx - DW / 2 + 0.1, cx + DW / 2 - 0.1):
            box("safety_yellow", x - 0.06, x + 0.06, F, F + 0.01, -0.2, IZ1)
    box("safety_yellow", -2.3, 2.3, F, F + 0.01, 0.8, 0.92)
    box("safety_yellow", -2.3, 2.3, F, F + 0.01, 4.6, 4.72)
    for x in (-2.3, 2.3):
        box("safety_yellow", x - 0.06, x + 0.06, F, F + 0.01, 0.8, 4.72)
    box("paint_white", -1.6, 1.6, F, F + 0.012, 2.6, 2.8)                              # Einfahrt stop line

    # --- 1) LACKIERKABINE (back-left)
    LX0, LX1, LZ0, LZ1, LH = IX0, -4.6, IZ0, -4.0, 3.9
    box("booth_floor", LX0, LX1, F, F + 0.05, LZ0, LZ1)
    for z in np.arange(LZ0 + 0.4, LZ1, 0.5):                                           # floor grating
        box("frame_black", LX0 + 0.5, LX1 - 0.5, F + 0.05, F + 0.06, z, z + 0.04)
    wall_z("booth_white", LX1 - 0.06, LZ0, LZ1, F, LH, [(-12.0, -9.5, 1.0, 2.6), (-8.0, -5.5, 1.0, 2.6)], t=0.12)
    for (za, zb) in [(-12.0, -9.5), (-8.0, -5.5)]:
        box("glass_shop", LX1 - 0.08, LX1 - 0.04, 1.0, 2.6, za, zb)
    wall_x("booth_white", LZ1 - 0.06, LX0, LX1, F, LH, [(-10.4, -5.6, F, 3.5)], t=0.12)
    for x0, x1 in ((-10.4, -8.0), (-8.0, -5.6)):                                       # glass double door (closed)
        box("glass_shop", x0 + 0.05, x1 - 0.05, F, 3.45, LZ1 - 0.09, LZ1 - 0.03)
        box("frame_black", x0, x0 + 0.08, F, 3.5, LZ1 - 0.12, LZ1)
    box("frame_black", -10.4, -5.6, 3.42, 3.5, LZ1 - 0.12, LZ1)
    box("frame_black", -5.68, -5.6, F, 3.5, LZ1 - 0.12, LZ1)
    for x in (LX0 + 0.03,):
        box("booth_white", x, x + 0.05, F, LH, LZ0, LZ1)
    box("booth_white", LX0, LX1, F, LH, LZ0 + 0.02, LZ0 + 0.06)
    b.layer = "EG"
    box("led_red", -6.0, -5.3, 3.6, 3.8, LZ1 + 0.01, LZ1 + 0.04)                       # "in use" light
    b.cyl("metal", 0.35, 0.3, (-8.0, LH + 0.15, -9.0), 10)                              # duct start
    b.beam("metal", (-8.0, LH + 0.3, -9.0), (-8.0, H + 1.0, -9.0), 0.3)
    # paint gun on hook, mixing table + paint cans outside the booth
    b.beam("metal", (LX0 + 0.2, 2.2, -7.0), (LX0 + 0.5, 2.2, -7.0), 0.03)
    b.box("frame_black", (0.12, 0.25, 0.2), (LX0 + 0.5, 2.0, -7.0))
    b.cyl("metal", 0.07, 0.15, (LX0 + 0.5, 2.2, -6.9), 8)
    box("metal", -4.4, -3.2, F, 0.95, -13.4, -10.6)
    box("shelf", -4.4, -3.2, 1.6, 1.65, -13.6, -10.6)
    cans = ["mural_a", "rim_red", "drum_blue", "safety_yellow", "paint_white", "rim_black", "led_purple", "brick"]
    for k, z in enumerate(np.arange(-13.3, -10.7, 0.32)):
        b.cyl(cans[k % len(cans)] if k % len(cans) else "neon_orange", 0.12, 0.25, (-3.8, 1.1, z), 8)
        b.cyl(cans[(k + 3) % len(cans)] if (k + 3) % len(cans) else "mural_b", 0.12, 0.25, (-3.8, 1.78, z), 8)
    b.anchor("Lackieren", ((LX0 + LX1) / 2, F, (LZ0 + LZ1) / 2), 180)

    # --- 2) FELGEN + REIFEN (front-left wall)
    for row, y in enumerate((1.0, 1.8, 2.6, 3.4)):
        for col, z in enumerate((-2.8, -1.9, -1.0, -0.1, 0.8)):
            rim_on_wall(IX0 + 0.05, y, z, ["chrome", "rim_gold", "rim_black", "rim_red"][(row + col) % 4], +1)
    box("led_cyan", IX0 + 0.05, IX0 + 0.08, 4.0, 4.08, -3.3, 1.3)
    b.text("RODAS", ["led_cyan"] * 5, (IX0 + 0.08, 4.4, -1.0), 0.4, 0.03, rot_y=90)
    for (z, n) in [(2.0, 6), (2.8, 5), (3.6, 4)]:
        tire_stack(IX0 + 0.55, z, n, F)
    box("lift_red", -10.0, -9.2, F, 1.0, 4.3, 5.1)                                     # wheel balancer
    cyl_x("metal", 0.05, 0.5, (-9.0, 1.0, 4.7), 6)
    b.box("frame_black", (0.5, 0.35, 0.6), (-9.6, 1.25, 4.7))
    box("screen", -9.75, -9.45, 1.15, 1.35, 5.02, 5.06)
    b.anchor("Felgen", (-7.0, F, 0.5), 180)

    # --- 3) EINFAHRT / ANNAHME (middle front)
    box("frame_black", 2.7, 3.0, F, 1.1, 3.6, 4.2)                                     # reception stand + tablet
    b.box("screen", (0.36, 0.25, 0.03), (2.85, 1.2, 3.9), rot_x=-30, rot_y=-90)
    b.anchor("Einfahrt", (0.0, F, 2.7), 180)

    # --- 4) LEISTUNGSPRÜFSTAND (middle back)
    PZ = -8.5
    box("frame_black", -1.6, 1.6, F - 0.02, F + 0.01, PZ + 0.8, PZ + 2.0)               # roller pit
    for dz in (1.15, 1.65):
        cyl_x("metal", 0.17, 2.8, (0.0, F - 0.05, PZ + dz), 12)
    for x in (-2.6, 2.6):
        box("safety_yellow", x - 0.08, x + 0.08, F, F + 0.01, -13.0, -4.6)
    for z in (-13.0, -4.6):
        box("safety_yellow", -2.6, 2.6, F, F + 0.01, z - 0.08, z + 0.08)
    for z in np.arange(-13.0, -4.6, 1.0):                                              # hatching
        b.box("frame_black", (0.12, 0.012, 0.5), (-2.6, F + 0.012, z + 0.4), rot_y=45)
        b.box("frame_black", (0.12, 0.012, 0.5), (2.6, F + 0.012, z + 0.4), rot_y=45)
    box("frame_black", -1.1, 1.1, F, 0.35, -13.3, -12.6)                                # cooling fan
    b.add("frame_black", trimesh.creation.annulus(r_min=0.85, r_max=1.0, height=0.4, sections=16)
          .apply_translation((0, 0, 0)).apply_transform(np.eye(4)).apply_translation((0, 1.35, -12.95)))
    cyl_z("metal", 0.12, 0.4, (0, 1.35, -12.95), 8)
    for k in range(5):
        b.box("frame_black", (0.14, 0.75, 0.04), (0, 1.35, -12.85), rot_z=k * 36)
    for x in (-1.1, 1.1):
        b.beam("frame_black", (x, 0.35, -12.95), (x * 0.6, 1.0, -12.95), 0.05)
    box("frame_black", -3.4, -3.2, F, 1.6, -9.4, -9.2)                                  # monitor
    b.box("frame_black", (0.1, 0.8, 1.3), (-3.25, 2.0, -9.3), rot_y=-20)
    b.box("screen", (0.03, 0.68, 1.18), (-3.19, 2.0, -9.28), rot_y=-20)
    for (x, z) in [(-1.6, -12.0), (1.6, -12.0), (-1.6, -5.2), (1.6, -5.2)]:              # strap anchors
        box("safety_yellow", x - 0.08, x + 0.08, F, F + 0.08, z - 0.08, z + 0.08)
    b.anchor("Pruefstand", (0.0, F, PZ), 180)

    # --- 5) HEBEBÜHNEN (right): scissor lifts, #1 raised, #2 down
    for i, (lx, h) in enumerate([(5.6, 1.7), (9.4, 0.0)]):
        z0, z1 = -6.8, -2.2
        box("frame_black", lx - 1.1, lx + 1.1, F, F + 0.08, z0, z1)
        for sx in (-1, 1):
            rx = lx + sx * 0.7
            top = F + 0.18 + h
            box("lift_red", rx - 0.3, rx + 0.3, top - 0.12, top, z0, z1)                # runway
            box("safety_yellow", rx - 0.3, rx + 0.3, top, top + 0.005, z0 + 0.1, z0 + 0.4)
            b.hull("lift_red", [(rx - 0.31, top - 0.12, z0 - 0.5 + dz) for dz in (0.0, 0.5)] + [(rx + 0.31, top - 0.12, z0 - 0.5 + dz) for dz in (0.0, 0.5)]
                   + [(rx - 0.3, top - 0.12 - 0.02, z0 - 0.6), (rx + 0.3, top - 0.12 - 0.02, z0 - 0.6)])  # ramp lip
            if h > 0.3:
                for (za, zb) in [(z0 + 0.4, z1 - 0.4), (z1 - 0.4, z0 + 0.4)]:
                    b.beam("lift_red", (rx, F + 0.1, za), (rx, top - 0.12, zb), 0.12)
                cyl_x("metal", 0.1, 1.6, (lx, F + 0.1 + h / 2, (z0 + z1) / 2), 8)        # hydraulic cylinder
        box("frame_black", lx + 1.3, lx + 1.6, F, 1.2, z1 - 0.3, z1)                    # control box
        box("led_green", lx + 1.32, lx + 1.36, 1.0, 1.08, z1 - 0.2, z1 - 0.1)
        b.anchor(f"Hebebuehne_{i + 1}", (lx, F + 0.18 + h, (z0 + z1) / 2), 180)

    # --- 6) WERKBANK, WERKZEUGWAND, TEILEREGALE (right wall), Motor, Kompressor
    box("wood_dark", IX1 - 0.75, IX1 - 0.05, 0.95, 1.0, 1.0, 5.2)                       # workbench
    box("tool_red", IX1 - 0.7, IX1 - 0.1, F, 0.95, 1.0, 2.6)                            # tool chest
    for y in np.arange(0.3, 0.95, 0.16):
        box("metal", IX1 - 0.71, IX1 - 0.69, y, y + 0.02, 1.05, 2.55)
    box("frame_black", IX1 - 0.7, IX1 - 0.1, F, 0.95, 4.6, 5.2)
    box("plywood", IX1 - 0.08, IX1 - 0.05, 1.3, 2.6, 1.0, 5.2)                          # pegboard
    for k, z in enumerate(np.arange(1.2, 5.0, 0.25)):
        b.box("metal" if k % 3 else "tool_red", (0.03, 0.35 + 0.1 * (k % 3), 0.06), (IX1 - 0.1, 1.95 + 0.1 * (k % 2), z), rot_x=10 * (k % 3 - 1))
    box("led_cyan", IX1 - 0.4, IX1 - 0.2, 2.7, 2.74, 1.0, 5.2)
    for z0 in (-8.6, -6.2, -3.8, -1.4):                                                 # part shelves
        for y in (F, 0.9, 1.7, 2.5):
            box("shelf", IX1 - 0.7, IX1 - 0.05, y, y + 0.04, z0, z0 + 2.2)
        for x_, z_ in ((IX1 - 0.7, z0), (IX1 - 0.7, z0 + 2.2), (IX1 - 0.05, z0), (IX1 - 0.05, z0 + 2.2)):
            box("metal", x_ - 0.03, x_ + 0.03, F, 2.6, z_ - 0.03, z_ + 0.03)
        for j, y in enumerate((0.94, 1.74)):
            for zz in np.arange(z0 + 0.2, z0 + 2.1, 0.45):
                box(["cardboard", "tool_red", "frame_black"][int(zz * 3 + j) % 3], IX1 - 0.6, IX1 - 0.2, y, y + 0.3 + 0.1 * ((j + int(zz)) % 2), zz, zz + 0.35)
        tire_stack(IX1 - 0.38, z0 + 0.6, 1, F + 0.04) if z0 > -5 else None
        cyl_z("chrome", 0.07, 1.9, (IX1 - 0.38, 2.68, z0 + 1.1), 8)                      # exhausts on top shelf
        cyl_z("chrome", 0.1, 0.5, (IX1 - 0.38, 2.68, z0 + 1.9), 8)
    # engine on stand
    ex, ez = 3.6, -0.6
    box("lift_red", ex - 0.06, ex + 0.06, F, 0.9, ez - 0.4, ez + 0.4)
    b.beam("lift_red", (ex - 0.6, F + 0.05, ez), (ex + 0.6, F + 0.05, ez), 0.08)
    box("engine_grey", ex + 0.1, ex + 0.9, 0.6, 1.25, ez - 0.35, ez + 0.35)
    box("metal", ex + 0.15, ex + 0.85, 1.25, 1.45, ez - 0.4, ez + 0.4)
    box("tool_red", ex + 0.2, ex + 0.8, 1.45, 1.55, ez - 0.3, ez + 0.3)
    cyl_x("chrome", 0.14, 0.3, (ex + 1.0, 1.2, ez + 0.2), 10)                            # turbo
    # compressor
    m = trimesh.creation.cylinder(radius=0.35, height=1.5, sections=12)
    b.add("tool_red", m.apply_translation((IX1 - 0.55, 0.55, -10.0)))
    b.box("frame_black", (0.5, 0.35, 0.5), (IX1 - 0.55, 0.98, -9.95))

    # --- 7) BÜRO (back-right, glass) + stairs to the lounge
    OX0, OX1, OZ0, OZ1 = 5.0, IX1, IZ0, -9.6
    box("tile_floor", OX0, OX1, F, F + 0.02, OZ0, OZ1)
    wall_x("glass_shop", OZ1, OX0, OX1, F + 0.02, OGY - 0.25, t=0.04)
    wall_z("glass_shop", OX0, OZ0, OZ1, F + 0.02, OGY - 0.25, [(-12.4, -11.4, F, 2.3)], t=0.04)
    for x in np.arange(OX0, OX1 + 0.01, 1.35):
        box("frame_black", x - 0.04, x + 0.04, F, OGY - 0.25, OZ1 - 0.04, OZ1 + 0.04)
    for z in (OZ0, -12.4, -11.4, OZ1):
        box("frame_black", OX0 - 0.04, OX0 + 0.04, F, OGY - 0.25, z - 0.04, z + 0.04)
    box("frame_black", OX0, OX1, OGY - 0.3, OGY - 0.25, OZ1 - 0.05, OZ1 + 0.05)
    box("counter", 6.0, 9.0, F, 1.05, -10.6, -10.0)   # counter
    box("counter", 5.9, 9.1, 1.05, 1.1, -10.7, -9.95)
    b.box("frame_black", (0.5, 0.35, 0.05), (7.2, 1.35, -10.35), rot_x=-10)
    box("screen", 7.0, 7.4, 1.25, 1.45, -10.31, -10.28)
    box("wood_dark", 9.4, 11.4, F, 0.78, -13.4, -12.4)                                  # desk
    box("frame_black", 10.2, 10.7, 0.78, 1.1, -13.3, -13.2)
    box("screen", 10.23, 10.67, 0.82, 1.07, -13.2, -13.18)
    box("shelf", IX1 - 0.4, IX1 - 0.05, 1.4, 1.44, -13.6, -10.0)                        # trophy shelf
    box("shelf", IX1 - 0.4, IX1 - 0.05, 2.1, 2.14, -13.6, -10.0)
    for y in (1.44, 2.14):
        for z in np.arange(-13.3, -10.2, 0.6):
            b.cyl("gold", 0.08, 0.06, (IX1 - 0.22, y + 0.03, z), 8)
            b.cyl("gold", 0.025, 0.2, (IX1 - 0.22, y + 0.16, z), 6)
            b.rock("gold", 0.1, (IX1 - 0.22, y + 0.3, z), 0.9)
    b.anchor("Buero", (7.5, F, -9.0), 180)
    # stairs along the office front, rising towards +X
    n = 20
    for k in range(n):
        x = 5.0 + 6.4 * k / n
        y = F + (OGY - F) * (k + 1) / n
        box("metal", x, x + 6.4 / n + 0.01, y - 0.06, y, -9.55, -8.45)
        b.beam("frame_black", (x, F, -8.45), (x, y - 0.06, -8.45), 0.02) if k % 5 == 0 else None
    b.beam("metal", (5.0, F + 1.0, -8.42), (11.4, OGY + 1.0, -8.42), 0.03)
    for k in range(0, n, 4):
        x = 5.0 + 6.4 * k / n
        b.beam("metal", (x, F + (OGY - F) * k / n, -8.42), (x, F + (OGY - F) * k / n + 1.0, -8.42), 0.02)
    # big wall art on the back wall between booth and office
    for k, (x, y, w, h) in enumerate([(-1.5, 4.8, 3.0, 1.4), (1.8, 4.2, 2.2, 1.0), (0.2, 3.0, 4.0, 0.6)]):
        box(f"mural_{'bdac'[k]}", x - w / 2, x + w / 2, y - h / 2, y + h / 2, IZ0 + 0.06, IZ0 + 0.07)
    b.text("021", ["neon_orange"] * 3, (0.0, 4.4, IZ0 + 0.08), 1.6, 0.05, simplify=0.02)
    for x in (-3.0, 3.0):                                                               # spoilers on the wall
        box("carbon", x - 0.9, x + 0.9, 3.0, 3.06, IZ0 + 0.1, IZ0 + 0.4)
        for dx in (-0.9, 0.9):
            box("carbon", x + dx - 0.02, x + dx + 0.02, 2.85, 3.2, IZ0 + 0.08, IZ0 + 0.45)

    # =================================================================
    # OG – lounge on top of the office
    # =================================================================
    b.layer = "OG"
    box("wood_dark", OX0, OX1, OGY - 0.25, OGY, OZ0, OZ1)
    for (a, c) in [((OX0, OZ1), (10.0, OZ1)), ((OX0, OZ0), (OX0, OZ1))]:
        x0, x1, z0, z1 = min(a[0], c[0]), max(a[0], c[0]), min(a[1], c[1]), max(a[1], c[1])
        box("glass_rail", x0 - 0.03, x1 + 0.03, OGY, OGY + 1.0, z0 - 0.03, z1 + 0.03)
        box("metal", x0 - 0.04, x1 + 0.04, OGY + 1.0, OGY + 1.05, z0 - 0.04, z1 + 0.04)
    box("sofa_black", 6.0, 9.2, OGY, OGY + 0.45, -13.6, -12.8)                          # sofa
    box("sofa_black", 6.0, 9.2, OGY + 0.45, OGY + 0.95, -13.6, -13.35)
    box("glass_shop", 6.8, 8.4, OGY + 0.4, OGY + 0.44, -12.3, -11.5)                    # coffee table
    for x, z in [(6.85, -12.25), (8.35, -12.25), (6.85, -11.55), (8.35, -11.55)]:
        box("metal", x - 0.02, x + 0.02, OGY, OGY + 0.4, z - 0.02, z + 0.02)
    box("fridge", IX1 - 0.7, IX1 - 0.05, OGY, OGY + 1.8, -11.4, -10.6)                  # drinks fridge
    box("glass_shop", IX1 - 0.72, IX1 - 0.7, OGY + 0.1, OGY + 1.7, -11.35, -10.65)
    box("counter", IX1 - 0.6, IX1 - 0.05, OGY, OGY + 0.95, -13.4, -12.2)                # coffee bar
    b.box("frame_black", (0.35, 0.4, 0.35), (IX1 - 0.3, OGY + 1.15, -12.8))
    box("frame_black", 9.6, 11.4, OGY + 1.2, OGY + 2.2, IZ0 + 0.06, IZ0 + 0.1)         # TV
    box("screen", 9.7, 11.3, OGY + 1.28, OGY + 2.12, IZ0 + 0.1, IZ0 + 0.11)
    b.anchor("Lounge", (7.6, OGY, -12.0), 0)

    # =================================================================
    # DACH – roof (tin), trusses, hanging lights; booth ceiling (hidden when looking inside)
    # =================================================================
    b.layer = "Dach"
    for s in (-1, 1):
        pts = []
        for z in (BZ0 - 0.4, BZ1 + 0.4):
            for (x, y) in ((0.0, RIDGE + 0.15), (s * (X1 + 0.4), H - 0.15)):
                pts += [(x, y, z), (x, y - 0.1, z)]
        b.hull("dach", pts)
        for z in np.arange(BZ0 - 0.3, BZ1 + 0.4, 0.5):
            b.beam("dach_tin", (0.0, RIDGE + 0.17, z), (s * (X1 + 0.4), H - 0.13, z), 0.04)
    box("dach", -0.25, 0.25, RIDGE + 0.1, RIDGE + 0.3, BZ0 - 0.4, BZ1 + 0.4)            # ridge cap
    for z in (-10.0, -4.0, 2.0):                                                        # steel trusses
        b.beam("dach_stahl", (X0 + T, H - 0.2, z), (X1 - T, H - 0.2, z), 0.18)
        for s in (-1, 1):
            b.beam("dach_stahl", (s * (X1 - T), H - 0.2, z), (0.0, RIDGE - 0.1, z), 0.14)
            for f in (0.33, 0.66):
                x = s * (X1 - T) * (1 - f)
                b.beam("dach_stahl", (x, H - 0.2, z), (x, H - 0.2 + (RIDGE - H) * f, z), 0.08)
    for z in (-12.0, -7.0, -1.0, 4.0):                                                   # hanging tube lights
        for x in (-6.0, 0.0, 6.0):
            b.beam("dach_stahl", (x, H + 0.3, z), (x, 5.2, z), 0.015)
            box("dach_licht", x - 1.2, x + 1.2, 5.1, 5.2, z - 0.12, z + 0.12)
    box("dach_kabine", LX0, LX1, LH, LH + 0.08, LZ0, LZ1)                                # paint booth ceiling
    for x in (LX0 + 0.6, LX1 - 0.6):
        box("dach_licht", x - 0.25, x + 0.25, LH - 0.06, LH, LZ0 + 0.4, LZ1 - 0.4)

    b.layer = None
    b.anchor("Eingang", (0.0, 0, BZ1 + 1.5), 0)
    b.anchor("Auto_Abholen_1", (-10.65, 0.12, 9.8), 0)
    b.anchor("Auto_Abholen_2", (10.65, 0.12, 9.8), 0)
    return b
