"""Luxus-Villen: R$ 20 Mio. (Mansão Leblon) und R$ 50 Mio. (Mansão Joatinga).
Front (Tor) zeigt nach +Z. Y-up, Meter."""
import numpy as np
import trimesh
from lib import B


def _wall(b, mat, x0, x1, z0, z1, y0, y1):
    b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2))


def _glass_rail(b, x0, x1, z0, z1, y, h=1.05, sides="nsew"):
    t = 0.04
    if "s" in sides:
        b.box("glass_rail", (x1 - x0, h, t), ((x0 + x1) / 2, y + h / 2, z1))
    if "n" in sides:
        b.box("glass_rail", (x1 - x0, h, t), ((x0 + x1) / 2, y + h / 2, z0))
    if "e" in sides:
        b.box("glass_rail", (t, h, z1 - z0), (x1, y + h / 2, (z0 + z1) / 2))
    if "w" in sides:
        b.box("glass_rail", (t, h, z1 - z0), (x0, y + h / 2, (z0 + z1) / 2))


def _glass_front(b, x0, x1, z, y0, h, step=1.6, face=+1):
    b.box("glass_big", (x1 - x0, h, 0.04), ((x0 + x1) / 2, y0 + h / 2, z + face * 0.03))
    xs = list(np.arange(x0 + 0.05, x1 - 0.04, step)) + [x1 - 0.05]
    for x in xs:
        b.box("frame_black", (0.06, h, 0.08), (x, y0 + h / 2, z + face * 0.05))


def _pool(b, x0, x1, z0, z1, y=0.0, coping=0.45):
    b.box("pool", (x1 - x0, 0.04, z1 - z0), ((x0 + x1) / 2, y + 0.05, (z0 + z1) / 2))
    c = coping
    for (sx, sz, cx, cz) in [(x1 - x0 + 2 * c, c, (x0 + x1) / 2, z0 - c / 2), (x1 - x0 + 2 * c, c, (x0 + x1) / 2, z1 + c / 2),
                             (c, z1 - z0, x0 - c / 2, (z0 + z1) / 2), (c, z1 - z0, x1 + c / 2, (z0 + z1) / 2)]:
        b.box("stone_white", (sx, 0.14, sz), (cx, y + 0.07, cz))


def _lamps(b, pts):
    for x, z in pts:
        b.cyl("frame_black", 0.08, 0.6, (x, 0.3, z), 6)
        b.cyl("lamp", 0.09, 0.12, (x, 0.66, z), 6)


def _sofa(b, x, z, w=2.4, rot=0.0, y=0.0):
    c, s = np.cos(np.radians(rot)), np.sin(np.radians(rot))
    b.box("stone_white", (w, 0.42, 0.9), (x, y + 0.21, z), rot_y=rot)
    b.box("stone_white", (w, 0.45, 0.2), (x - 0.35 * s, y + 0.62, z - 0.35 * c), rot_y=rot)
    b.box("plastic_white", (w - 0.1, 0.12, 0.7), (x + 0.05 * s, y + 0.48, z + 0.05 * c), rot_y=rot)


def _cabana(b, x, z, mat, y=0.0):
    for dx in (-1.1, 1.1):
        for dz in (-1.1, 1.1):
            b.beam("frame_black", (x + dx, y, z + dz), (x + dx, y + 2.6, z + dz), 0.08)
    b.box(mat, (2.5, 0.12, 2.5), (x, y + 2.65, z))
    for dz in (-1.1,):
        b.box(mat, (2.3, 1.6, 0.03), (x, y + 1.8, z + dz))
    b.box("stone_white", (1.9, 0.45, 1.9), (x, y + 0.22, z))
    b.box("plastic_white", (1.8, 0.12, 1.8), (x, y + 0.5, z))


# =====================================================================
# R$ 20 MIO. – Mansão Leblon
# =====================================================================
def mansao_leblon():
    b = B(2020)
    n1 = b.slot("nwall", 1, "#F2F0EA")
    n2 = b.slot("nwall", 2, "#D9C9A8")
    wd = b.slot("wood", 1, "#A86B3C")
    a1 = b.slot("accent", 1, "#EBC03F")
    LX, LZ = 18.0, 15.0
    b.box("grass", (2 * LX, 0.04, 2 * LZ), (0, 0.02, 0))

    # privacy: tall hedges left/right/back, front wall with wood gate + guarita
    b.box("hedge", (1.2, 2.6, 2 * LZ), (-LX + 0.6, 1.3, 0))
    b.box("hedge", (1.2, 2.6, 2 * LZ), (LX - 0.6, 1.3, 0))
    b.box("hedge", (2 * LX - 2.4, 2.6, 1.2), (0, 1.3, -LZ + 0.6))
    for x0, x1 in ((-LX + 1.2, -11.0), (-5.0, LX - 1.2)):
        _wall(b, n2, x0, x1, LZ - 0.35, LZ, 0, 1.8)
        b.box("stone_white", (x1 - x0, 0.1, 0.4), ((x0 + x1) / 2, 1.85, LZ - 0.2))
    b.box(wd, (6.0, 2.2, 0.1), (-8.0, 1.1, LZ - 0.17))
    for k in range(20):
        b.box("wood_dark", (0.05, 2.2, 0.14), (-10.85 + k * 0.3, 1.1, LZ - 0.15))
    b.box(n1, (2.4, 2.8, 2.4), (-13.2, 1.4, LZ - 1.6))                                   # guarita
    b.box("glass_big", (2.0, 1.1, 0.04), (-13.2, 1.7, LZ - 0.38))
    b.box("concrete_white", (2.8, 0.15, 2.8), (-13.2, 2.88, LZ - 1.6))
    b.anchor("Eingang", (-8.0, 0, LZ + 0.4), 0)
    # driveway to the garage
    b.box("tile_floor", (6.0, 0.05, 9.0), (-8.0, 0.045, LZ - 4.6))
    b.box("tile_floor", (8.5, 0.05, 5.0), (-12.5, 0.045, 5.0))

    # garage wing (3 cars) with green roof
    GX0, GX1, GZ0, GZ1, GH = -17.0, -8.0, -4.0, 2.5, 3.2
    _wall(b, n1, GX0, GX1, GZ0, GZ1, 0, GH)
    for x in (-15.5, -12.5, -9.5):
        b.box("frame_black", (2.7, 2.6, 0.04), (x, 1.3, GZ1 + 0.02))
        for k in range(9):
            b.box(wd, (2.6, 0.24, 0.03), (x, 0.17 + k * 0.28, GZ1 + 0.05))
    b.box("concrete_white", (GX1 - GX0 + 0.6, 0.25, GZ1 - GZ0 + 0.6), ((GX0 + GX1) / 2, GH + 0.12, (GZ0 + GZ1) / 2))
    b.box("grass", (GX1 - GX0, 0.1, GZ1 - GZ0), ((GX0 + GX1) / 2, GH + 0.3, (GZ0 + GZ1) / 2))

    # main house: glass ground floor + cantilevered wooden upper floor + roof terrace
    X0, X1, Z0, Z1, G = -8.0, 8.0, -12.0, -2.0, 3.6
    _wall(b, n1, X0, X1, Z0, Z1 - 0.3, 0, G)
    _glass_front(b, X0 + 0.3, X1 - 0.3, Z1 - 0.3, 0.1, G - 0.4)
    b.box("door_wood", (1.6, 3.0, 0.08), (-5.5, 1.5, Z1 - 0.22))
    b.box("stone_white", (X1 - X0 + 1.0, 0.12, 1.6), (0, 0.06, Z1 + 0.5))
    UX0, UX1, UZ0, UZ1, UY, UH = -10.0, 10.0, -13.0, 0.5, G + 0.3, 3.4
    b.box("concrete_white", (UX1 - UX0 + 0.3, 0.3, UZ1 - UZ0 + 0.3), (0, G + 0.15, (UZ0 + UZ1) / 2))
    _wall(b, wd, UX0, UX1, UZ0, UZ1, UY, UY + UH)
    _glass_front(b, UX0 + 0.6, UX1 - 0.6, UZ1, UY + 0.5, 2.2, 1.8)
    for face_x in (UX0, UX1):
        b.box("glass_big", (0.04, 2.2, 6.0), (face_x + (0.03 if face_x > 0 else -0.03), UY + 1.6, -6.0))
    for x in np.arange(UX0 + 0.2, UX1 - 0.1, 0.4):                                   # vertical brise-soleil
        b.box("wood_dark", (0.07, UH - 0.3, 0.12), (x, UY + UH / 2, UZ1 + 0.45))
    b.box("concrete_white", (UX1 - UX0 + 1.6, 0.3, 1.0), (0, UY + UH + 0.15, UZ1 + 0.5))
    RY = UY + UH
    b.box("concrete_white", (UX1 - UX0 + 0.8, 0.3, UZ1 - UZ0 + 0.8), (0, RY + 0.15, (UZ0 + UZ1) / 2))
    RY += 0.3
    b.box("deck", (11.0, 0.06, 8.0), (3.5, RY + 0.03, -4.0))
    _glass_rail(b, UX0 - 0.3, UX1 + 0.3, UZ0 - 0.3, UZ1 + 0.3, RY)
    b.box(n1, (6.0, 2.8, 5.0), (-6.0, RY + 1.4, -9.0))                                   # roof pavilion
    b.box("glass_big", (5.0, 2.2, 0.04), (-6.0, RY + 1.3, -6.47))
    b.box("concrete_white", (7.0, 0.2, 6.0), (-6.0, RY + 2.9, -8.6))
    for k in range(2):
        _sofa(b, 2.0 + k * 3.0, -6.0, 2.4, 180, RY)
    b.parasol(4.0, RY, -2.0, a1, 1.4, 2.5)
    for x in (-1.0, 8.5):
        b.pot_plant(x, RY, -1.5, 0.3)
    # side wing (bedrooms) connecting garage and house
    _wall(b, n2, -10.0, -8.0, -10.0, -4.0, 0, G)

    # infinity pool + deck + loungers
    b.box("deck", (20.0, 0.08, 9.0), (2.0, 0.06, 3.0))
    for z in np.arange(-1.3, 7.5, 0.35):
        b.box("wood_dark", (20.0, 0.01, 0.02), (2.0, 0.105, z))
    _pool(b, -3.0, 11.0, 2.0, 6.0, 0.08)
    b.box("stone_white", (2.6, 0.5, 2.6), (12.5, 0.25, 2.0))                            # jacuzzi
    b.cyl("pool", 1.05, 0.06, (12.5, 0.52, 2.0), 12)
    for x in (-2.0, -0.6, 0.8, 2.2, 3.6, 5.0):
        b.lounger(x, 0.0, 0)
    for x in (1.5, 6.0):
        b.parasol(x, 0.1, -1.0, a1, 1.2, 2.4)

    # gourmet pavilion (Espaço Gourmet) right
    PX0, PX1, PZ0, PZ1 = 10.5, 16.5, -11.0, -3.0
    b.box("stone_white", (PX1 - PX0, 0.15, PZ1 - PZ0), ((PX0 + PX1) / 2, 0.075, (PZ0 + PZ1) / 2))
    for x in (PX0 + 0.2, PX1 - 0.2):
        for z in (PZ0 + 0.2, PZ1 - 0.2):
            b.box(n1, (0.3, 3.2, 0.3), (x, 1.6, z))
    b.box("concrete_white", (PX1 - PX0 + 1.0, 0.3, PZ1 - PZ0 + 1.0), ((PX0 + PX1) / 2, 3.35, (PZ0 + PZ1) / 2))
    b.box(n2, (5.0, 1.0, 0.8), ((PX0 + PX1) / 2, 0.5, PZ0 + 0.7))                     # grill counter
    b.box("wood_dark", (5.2, 0.06, 0.9), ((PX0 + PX1) / 2, 1.03, PZ0 + 0.7))
    b.box("brick", (1.2, 2.2, 0.8), (PX1 - 1.3, 2.2, PZ0 + 0.7))
    b.box("metal", (1.0, 0.05, 0.6), (PX1 - 1.3, 1.08, PZ0 + 0.7))
    b.box("wood_warm", (1.2, 0.08, 3.6), ((PX0 + PX1) / 2, 0.85, -6.5))                 # dining table
    for dz in (-1.2, 0.0, 1.2):
        for sx in (-1, 1):
            b.chair((PX0 + PX1) / 2 + sx * 0.9, 0.15, -6.5 + dz, -90 * sx, "frame_black")
    b.box("wood_warm", (0.08, 0.8, 3.2), ((PX0 + PX1) / 2, 0.45, -6.5))
    for (x, z, h, lean) in [(-15.0, 9.0, 6.5, (-0.3, 0.3)), (15.0, 10.5, 7.0, (0.4, 0.3)), (15.5, 2.0, 6.0, (0.3, 0)),
                            (-3.5, 11.0, 5.5, (-0.2, 0.4)), (9.0, 12.0, 6.2, (0.3, 0.3))]:
        b.palm(x, z, h, lean)
    _lamps(b, [(-6.0, 9.0), (-10.0, 9.0), (-6.0, 13.0), (-10.0, 13.0), (0.0, 8.0), (8.0, 8.0)])
    b.box("hedge", (6.0, 0.8, 0.8), (4.0, 0.4, 9.0))
    return b


# =====================================================================
# R$ 50 MIO. – Mansão Joatinga
# =====================================================================
def _helipad(b, x, y, z, r=4.8):
    b.cyl("concrete", r, 0.15, (x, y + 0.075, z), 16)
    b.cyl("paint_white", r - 0.25, 0.02, (x, y + 0.16, z), 16)
    b.cyl("concrete", r - 0.55, 0.03, (x, y + 0.165, z), 16)
    hm = trimesh.creation.box(extents=(0.6, 0.04, 3.0))
    for dx in (-1.0, 1.0):
        m = hm.copy()
        m.apply_translation((x + dx, y + 0.2, z))
        b.add("cloth_yellow", m)
    b.box("cloth_yellow", (2.0, 0.04, 0.6), (x, y + 0.2, z))
    for a in np.linspace(0, 2 * np.pi, 9)[:-1]:
        b.cyl("lamp", 0.12, 0.12, (x + (r - 0.1) * np.cos(a), y + 0.2, z + (r - 0.1) * np.sin(a)), 6)


def _tennis(b, x0, x1, z0, z1):
    cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
    b.box("court_green", (x1 - x0, 0.05, z1 - z0), (cx, 0.045, cz))
    W, L = 10.97, 23.77
    b.box("court_blue", (W, 0.02, L), (cx, 0.08, cz))
    t = 0.06
    for dx in (-W / 2, -W / 2 + 1.37, W / 2 - 1.37, W / 2):
        b.box("paint_white", (t, 0.01, L), (cx + dx, 0.095, cz))
    for dz in (-L / 2, L / 2):
        b.box("paint_white", (W, 0.01, t), (cx, 0.095, cz + dz))
    for dz in (-6.4, 6.4):
        b.box("paint_white", (W - 2.74, 0.01, t), (cx, 0.095, cz + dz))
    b.box("paint_white", (t, 0.01, 12.8), (cx, 0.095, cz))
    for dx in (-W / 2 - 0.9, W / 2 + 0.9):                                             # net
        b.beam("frame_black", (cx + dx, 0, cz), (cx + dx, 1.07, cz), 0.08)
    b.box("fence_net", (W + 1.8, 0.95, 0.03), (cx, 0.52, cz))
    b.box("paint_white", (W + 1.8, 0.06, 0.05), (cx, 1.0, cz))
    H = 3.2                                                                            # fence
    for (ax, az, bx, bz) in [(x0, z0, x1, z0), (x0, z1, x1, z1), (x0, z0, x0, z1), (x1, z0, x1, z1)]:
        n = int(max(abs(bx - ax), abs(bz - az)) / 3.0)
        for k in range(n + 1):
            f = k / n
            b.beam("frame_black", (ax + (bx - ax) * f, 0, az + (bz - az) * f), (ax + (bx - ax) * f, H, az + (bz - az) * f), 0.07)
        b.beam("frame_black", (ax, H, az), (bx, H, bz), 0.06)
        if az == bz:
            b.box("fence_net", (abs(bx - ax), H, 0.03), ((ax + bx) / 2, H / 2, az))
        else:
            b.box("fence_net", (0.03, H, abs(bz - az)), (ax, H / 2, (az + bz) / 2))


def mansao_joatinga():
    b = B(5050)
    n1 = b.slot("nwall", 1, "#F2F0EA")
    n2 = b.slot("nwall", 2, "#A8A196")
    wd = b.slot("wood", 1, "#7A4E2D")
    gl = b.slot("glass", 1, "#4F7F95")
    a1 = b.slot("accent", 1, "#F2F0EA")
    LX, LZ = 26.0, 22.0
    b.box("grass", (2 * LX, 0.04, 2 * LZ), (0, 0.02, 0))

    # perimeter: tall stone walls, cameras, big gate + 2-storey guard house
    WH = 2.8
    for (x0, x1, z0, z1) in [(-LX, -12.5, LZ - 0.4, LZ), (-3.5, LX, LZ - 0.4, LZ), (-LX, LX, -LZ, -LZ + 0.4),
                             (-LX, -LX + 0.4, -LZ, LZ), (LX - 0.4, LX, -LZ, LZ)]:
        _wall(b, n2, x0, x1, z0, z1, 0, WH)
        b.box("stone_white", (x1 - x0, 0.12, z1 - z0), ((x0 + x1) / 2, WH + 0.06, (z0 + z1) / 2))
    b.box("gate_metal", (9.0, 2.6, 0.12), (-8.0, 1.3, LZ - 0.2))
    for k in range(30):
        b.box(wd, (0.18, 2.6, 0.16), (-12.3 + k * 0.3, 1.3, LZ - 0.12))
    for x in (-12.7, -3.3):
        b.box(n1, (0.8, 3.6, 0.8), (x, 1.8, LZ - 0.4))
        b.cyl("lamp", 0.16, 0.35, (x, 3.8, LZ - 0.4), 8)
    b.box(n1, (3.0, 5.4, 3.0), (-15.5, 2.7, LZ - 2.0))                                 # guard house
    b.box("glass_big", (2.4, 1.2, 0.04), (-15.5, 4.0, LZ - 0.47))
    b.box("glass_big", (2.4, 1.2, 0.04), (-15.5, 1.6, LZ - 0.47))
    b.box("concrete_white", (3.6, 0.2, 3.6), (-15.5, 5.5, LZ - 2.0))
    for (x, z) in [(-LX + 0.2, LZ - 0.2), (LX - 0.2, LZ - 0.2), (-LX + 0.2, -LZ + 0.2), (LX - 0.2, -LZ + 0.2), (-3.3, LZ - 0.2)]:
        b.box("keypad", (0.18, 0.18, 0.35), (x, WH + 0.35, z))                         # cameras
        b.box("led_green", (0.05, 0.05, 0.02), (x, WH + 0.37, z + 0.18))
    b.anchor("Eingang", (-8.0, 0, LZ + 0.5), 0)

    # palm alley driveway + forecourt with fountain
    b.box("tile_floor", (7.0, 0.05, 14.0), (-8.0, 0.045, LZ - 7.4))
    b.cyl("tile_floor", 7.0, 0.05, (-8.0, 0.045, 5.5), 16)
    for z in (18.5, 15.0, 11.5):
        for x in (-12.2, -3.8):
            b.palm(x, z, 7.0, (0.0, 0.2))
    b.cyl("stone_white", 2.6, 0.6, (-8.0, 0.3, 5.5), 16)
    b.cyl("pool", 2.3, 0.05, (-8.0, 0.6, 5.5), 16)
    b.cyl("stone_white", 0.5, 1.4, (-8.0, 1.1, 5.5), 8)
    b.cyl("stone_white", 1.0, 0.15, (-8.0, 1.85, 5.5), 10)
    b.cyl("pool", 0.25, 0.6, (-8.0, 2.2, 5.5), 8)
    b.box("tile_floor", (12.0, 0.05, 5.0), (-17.0, 0.045, 5.0))                         # to garage

    # garage (6 cars) with green roof
    GX0, GX1, GZ0, GZ1, GH = -25.0, -15.0, -8.0, 2.5, 3.4
    _wall(b, n2, GX0, GX1, GZ0, GZ1, 0, GH)
    for x in (-23.4, -20.0, -16.6):
        b.box("frame_black", (2.9, 2.7, 0.04), (x, 1.35, GZ1 + 0.02))
        for k in range(9):
            b.box(wd, (2.8, 0.26, 0.03), (x, 0.17 + k * 0.29, GZ1 + 0.05))
    b.box("concrete_white", (GX1 - GX0 + 0.6, 0.3, GZ1 - GZ0 + 0.6), ((GX0 + GX1) / 2, GH + 0.15, (GZ0 + GZ1) / 2))
    b.box("grass", (GX1 - GX0, 0.1, GZ1 - GZ0), ((GX0 + GX1) / 2, GH + 0.35, (GZ0 + GZ1) / 2))

    # main house: 3 stacked levels
    # L0: stone base with full glass front
    L0 = (-16.0, 12.0, -16.0, -4.0, 4.0)
    x0, x1, z0, z1, h0 = L0
    _wall(b, n2, x0, x1, z0, z1, 0, h0)
    _glass_front(b, x0 + 0.5, x1 - 0.5, z1, 0.15, h0 - 0.5, 2.0)
    b.box(wd, (2.2, 3.6, 0.1), (-8.0, 1.8, z1 + 0.08))                                  # pivot door
    b.box("concrete_white", (6.0, 0.25, 3.0), (-8.0, 3.9, z1 + 1.4))                    # entrance canopy
    b.box("stone_white", (x1 - x0, 0.15, 2.0), ((x0 + x1) / 2, 0.075, z1 + 1.0))
    # L1: white, cantilevered, long balcony
    L1 = (-14.0, 18.0, -18.0, -2.5, 4.0)
    ux0, ux1, uz0, uz1, h1 = L1
    y1 = h0 + 0.35
    b.box("concrete_white", (ux1 - ux0 + 0.6, 0.35, uz1 - uz0 + 2.6), ((ux0 + ux1) / 2, h0 + 0.17, (uz0 + uz1) / 2 + 1.0))
    _wall(b, n1, ux0, ux1, uz0, uz1, y1, y1 + h1)
    b.box(gl, (ux1 - ux0 - 1.0, 2.8, 0.04), ((ux0 + ux1) / 2, y1 + 1.5, uz1 + 0.03))
    for x in np.arange(ux0 + 0.5, ux1 - 0.4, 2.0):
        b.box("frame_black", (0.06, 2.8, 0.08), (x, y1 + 1.5, uz1 + 0.05))
    _glass_rail(b, ux0 - 0.3, ux1 + 0.3, uz1, uz1 + 2.2, y1, sides="sew")
    for x in (-6.0, 0.0, 6.0, 12.0):
        _sofa(b, x, uz1 + 1.3, 2.4, 180, y1)
    b.box("glass_big", (0.04, 2.8, 12.0), (ux1 + 0.03, y1 + 1.5, (uz0 + uz1) / 2))
    y2 = y1 + h1
    b.box("concrete_white", (ux1 - ux0 + 0.8, 0.35, uz1 - uz0 + 0.8), ((ux0 + ux1) / 2, y2 + 0.17, (uz0 + uz1) / 2))
    y2 += 0.35
    _glass_rail(b, ux0 - 0.4, ux1 + 0.4, uz0 - 0.4, uz1 + 0.4, y2)
    # helipad on the right part of the L1 roof
    _helipad(b, 12.0, y2, -10.2, 4.8)
    b.anchor("Helipad", (12.0, y2 + 0.2, -10.2), 0)
    b.cyl("cloth_red", 0.06, 2.2, (17.4, y2 + 1.1, -15.4), 6)                           # wind sock
    b.box("gas", (0.18, 0.18, 0.9), (17.4, y2 + 2.1, -14.95))
    # L2: glass penthouse with wooden fins
    px0, px1, pz0, pz1, h2 = -10.0, 4.0, -15.0, -6.0, 3.6
    b.box(gl, (px1 - px0, h2, pz1 - pz0), ((px0 + px1) / 2, y2 + h2 / 2, (pz0 + pz1) / 2))
    for x in np.arange(px0 + 0.3, px1 - 0.2, 0.6):
        b.box(wd, (0.1, h2, 0.3), (x, y2 + h2 / 2, pz1 + 0.15))
    y3 = y2 + h2
    b.box("concrete_white", (px1 - px0 + 1.2, 0.35, pz1 - pz0 + 1.2), ((px0 + px1) / 2, y3 + 0.17, (pz0 + pz1) / 2))
    y3 += 0.35
    # rooftop infinity pool on L2
    _pool(b, px0 + 0.8, px1 - 0.8, pz0 + 0.8, pz0 + 4.2, y3, 0.35)
    b.box("deck", (px1 - px0, 0.06, 3.6), ((px0 + px1) / 2, y3 + 0.03, pz1 - 2.0))
    for k in range(4):
        b.lounger(px0 + 2.0 + k * 1.2, pz1 - 1.6, 180, y3 + 0.06)
    _glass_rail(b, px0 - 0.6, px1 + 0.6, pz0 - 0.6, pz1 + 0.6, y3)
    # terrace on L1 roof (left part): lounge + parasols
    for x in (-12.0, -12.0):
        pass
    _sofa(b, -12.5, -4.5, 2.6, 180, y2)
    _sofa(b, 6.0, -4.5, 2.6, 180, y2)
    b.parasol(-12.5, y2, -6.5, a1, 1.4, 2.5)

    # big pool with cabanas + loungers
    b.box("stone_white", (16.0, 0.1, 11.0), (4.0, 0.05, 2.5))
    _pool(b, -2.0, 10.0, -0.5, 6.5, 0.1)
    for x in (-1.0, 0.4, 1.8, 3.2, 4.6, 6.0, 7.4, 8.8):
        b.lounger(x, -1.8, 0, 0.1)
    _cabana(b, -2.0, 9.5, a1, 0.1)
    _cabana(b, 10.0, 9.5, a1, 0.1)

    # tennis court (right)
    _tennis(b, 11.5, 25.0, -5.5, 21.0)

    # guest house (back right)
    _wall(b, n1, 18.5, 25.0, -21.0, -12.0, 0, 3.4)
    _glass_front(b, 19.0, 24.5, -12.0, 0.15, 2.8, 1.8)
    b.box("concrete_white", (7.4, 0.25, 9.8), (21.75, 3.5, -16.5))
    b.box("deck", (6.5, 0.08, 2.0), (21.75, 0.06, -10.9))
    b.anchor("Gaestehaus", (21.75, 0, -10.0), 0)

    # gardens
    for (x, z, h, lean) in [(-22.0, 14.0, 7.5, (-0.4, 0.3)), (-23.0, -14.0, 6.5, (0.3, 0.3)), (10.5, -19.5, 7.2, (0.3, -0.2)),
                            (-19.0, -19.0, 6.0, (0.0, 0.3))]:
        b.palm(x, z, h, lean)
    for (x, z, w, d) in [(-20.0, 10.0, 8.0, 1.0), (4.0, 12.0, 14.0, 1.0), (-0.5, -19.0, 18.0, 1.2)]:
        b.box("hedge", (w, 1.0, d), (x, 0.5, z))
    _lamps(b, [(-12.2, 8.5), (-3.8, 8.5), (-1.0, 12.5), (9.0, 12.5), (-14.0, 0.0), (-22.0, 6.0)])
    return b
