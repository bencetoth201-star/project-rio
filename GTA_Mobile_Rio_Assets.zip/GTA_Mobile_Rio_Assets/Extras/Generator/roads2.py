"""Straßenbaukasten Teil 2: Bögen (15°/30°), Avenida-T, Übergang Avenida→Rua, Copacabana-Bogen,
Stützmauern und Böschungen.

BÖGEN: Pivot = Start-Anschluss (Anschluss_..._S) im Ursprung, Fahrtrichtung -Z (Norden).
Der Bogen dreht nach links (−X). Rückwärts befahren ist er ein Rechtsbogen – eine Variante reicht.
End-Anschluss = Anker "Anschluss_<Typ>_Ende" mit exakter Position und Drehung (yaw = 180° + Winkel).
"""
import numpy as np
import trimesh
from shapely.geometry import Polygon, LineString, box as sbox
from shapely.ops import unary_union
from lib import B
import roads
from roads import ext, lamp, old_lamp, tree, zebra, traffic_light, paint, streets, ave_markings, rua_markings, L, AVE, RUA, connector, tile_box, closing, Q


# ------------------------------------------------------------------ arc geometry
def arc_pos(R, t, d, turn):
    """Point on an arc that starts at the origin heading -Z. turn=+1 left, -1 right. d = offset to the right (+X at start)."""
    return np.array([-turn * R + turn * (R + turn * d) * np.cos(t), -(R + turn * d) * np.sin(t)])


def arc_strip(R, theta, d0, d1, turn=+1, t0=0.0, t1=None, step_deg=2.0):
    t1 = theta if t1 is None else t1
    n = max(2, int(np.ceil(np.degrees(t1 - t0) / step_deg)) + 1)
    ts = np.linspace(t0, t1, n)
    a = [arc_pos(R, t, d0, turn) for t in ts]
    c = [arc_pos(R, t, d1, turn) for t in ts[::-1]]
    return Polygon([tuple(p) for p in a + c])


def arc_dashes(R, theta, d, w, dash, gap, turn=+1):
    r = R + turn * d
    L_ = r * theta
    out, s = [], 0.0
    while s < L_ - 0.1:
        e = min(s + dash, L_)
        out.append(arc_strip(R, theta, d - w / 2, d + w / 2, turn, s / r, e / r, 1.0))
        s += dash + gap
    return unary_union(out)


def arc_anchors(b, typ, R, theta, turn=+1):
    b.anchor(f"Anschluss_{typ}_S", (0, 0, 0), 0)
    p = arc_pos(R, theta, 0, turn)
    b.anchor(f"Anschluss_{typ}_Ende", (p[0], 0, p[1]), 180 + turn * np.degrees(theta))


def arc_lamps(b, R, theta, d, turn, every, face_in=True):
    r = R + turn * d
    n = max(1, int(r * theta // every))
    for k in range(n):
        t = (k + 0.5) * theta / n
        p = arc_pos(R, t, d, turn)
        c = arc_pos(R, t, 0, turn)
        face = np.degrees(np.arctan2(c[0] - p[0], c[1] - p[1]))
        lamp(b, p[0], p[1], face, h=7 if abs(d) > 8 else 6.5)


# ------------------------------------------------------------------ RUA / AVENIDA BÖGEN
def rua_bogen(deg):
    def f():
        b = B(700 + deg)
        R, th, turn = 40.0, np.radians(deg), +1
        ext(b, "road_asphalt", arc_strip(R, th, -3.5, 3.5, turn), -0.1, 0.0)
        for s in (-1, 1):
            ext(b, "curb", arc_strip(R, th, s * 3.5, s * 3.72, turn), -0.1, 0.17)
            ext(b, "sidewalk", arc_strip(R, th, s * 3.72, s * 6.0, turn), -0.1, 0.15)
            ext(b, "paint_white", arc_strip(R, th, s * 3.09, s * 3.21, turn), 0.0, 0.012)
        ext(b, "paint_yellow", arc_dashes(R, th, 0.0, 0.15, 3.0, 3.0, turn), 0.0, 0.012)
        arc_lamps(b, R, th, 5.4, turn, 14.0)
        arc_anchors(b, "Rua", R, th, turn)
        return b
    return f


def avenida_bogen(deg):
    def f():
        b = B(800 + deg)
        R, th, turn = 60.0, np.radians(deg), +1
        ext(b, "road_asphalt", arc_strip(R, th, -9.0, 9.0, turn), -0.1, 0.0)
        ext(b, "curb", arc_strip(R, th, -2.0, 2.0, turn), 0.0, 0.18)
        ext(b, "grass", arc_strip(R, th, -1.75, 1.75, turn), 0.0, 0.2)
        for s in (-1, 1):
            ext(b, "curb", arc_strip(R, th, s * 9.0, s * 9.22, turn), -0.1, 0.17)
            ext(b, "sidewalk", arc_strip(R, th, s * 9.22, s * 12.0, turn), -0.1, 0.15)
            ext(b, "paint_white", arc_dashes(R, th, s * 5.5, 0.12, 3.0, 3.0, turn), 0.0, 0.012)
            for d in (8.7, 2.3):
                ext(b, "paint_white", arc_strip(R, th, s * d - 0.05, s * d + 0.05, turn), 0.0, 0.012)
        r = R
        n = max(1, int(r * th // 12))
        for k in range(n):
            t = (k + 0.5) * th / n
            p = arc_pos(R, t, 0, turn)
            b.palm(p[0], p[1], 7.0, (0.1, 0.1), y=0.2)
        arc_lamps(b, R, th, 10.8, turn, 16.0)
        arc_lamps(b, R, th, -10.8, turn, 16.0)
        arc_anchors(b, "Avenida", R, th, turn)
        return b
    return f


def copacabana_bogen():
    """15° curve of the beach avenue. Turns RIGHT, beach on the inner (right) side – follows the bay."""
    b = B(915)
    R, th, turn = 120.0, np.radians(15), -1
    ext(b, "sidewalk", arc_strip(R, th, -12.0, -9.22, turn), -0.1, 0.15)
    ext(b, "curb", arc_strip(R, th, -9.22, -9.0, turn), -0.1, 0.17)
    ext(b, "road_asphalt", arc_strip(R, th, -9.0, 9.0, turn), -0.1, 0.0)
    ext(b, "curb", arc_strip(R, th, -2.0, 2.0, turn), 0.0, 0.18)
    ext(b, "grass", arc_strip(R, th, -1.75, 1.75, turn), 0.0, 0.2)
    for s in (-1, 1):
        ext(b, "paint_white", arc_dashes(R, th, s * 5.5, 0.12, 3.0, 3.0, turn), 0.0, 0.012)
    ext(b, "curb", arc_strip(R, th, 9.0, 9.22, turn), -0.1, 0.17)
    ext(b, "calcadao_white", arc_strip(R, th, 9.22, 17.0, turn), -0.1, 0.15)
    # wave stripes along the calçadão (same pattern as the straight Copacabana tile)
    rc = R - 13.0
    Ls = rc * th
    ss = np.linspace(0, Ls, int(Ls / 0.6) + 1)
    for k in range(3):
        c0 = 10.6 + k * 2.3
        left = [arc_pos(R, s / rc, c0 + 0.55 * np.sin(s * 2 * np.pi / 6.0), turn) for s in ss]
        right = [arc_pos(R, s / rc, c0 + 0.9 + 0.55 * np.sin(s * 2 * np.pi / 6.0), turn) for s in ss[::-1]]
        poly = Polygon([tuple(p) for p in left + right]).intersection(arc_strip(R, th, 9.22, 17.0, turn))
        ext(b, "calcadao_black", poly, 0.15, 0.16)
    ext(b, "sea_wall", arc_strip(R, th, 17.0, 17.4, turn), -0.6, 0.15)
    ext(b, "sand", arc_strip(R, th, 17.4, 24.0, turn), -0.6, -0.45)
    for t in (0.3, 0.75):
        p = arc_pos(R, t * th, 15.6, turn)
        b.palm(p[0], p[1], 7.5, (0.3, 0.1), y=0.15)
        q = arc_pos(R, t * th, 0, turn)
        b.palm(q[0], q[1], 7.0, (0.1, 0.1), y=0.2)
    for t, col in ((0.2, "cloth_yellow"), (0.55, "cloth_red"), (0.85, "plaster_blue")):
        p = arc_pos(R, t * th, 21.5, turn)
        b.parasol(p[0], -0.45, p[1], col, 1.3, 2.3)
    arc_lamps(b, R, th, -10.8, turn, 15.0)
    arc_lamps(b, R, th, 10.0, turn, 15.0)
    arc_anchors(b, "Avenida", R, th, turn)
    b.anchor("Strand", tuple(np.r_[arc_pos(R, th / 2, 23.0, turn)[0], -0.45, arc_pos(R, th / 2, 23.0, turn)[1]]), 90)
    return b


# ------------------------------------------------------------------ AVENIDA T + ÜBERGANG
def avenida_t():
    b = B(410)
    W, D = 24, 24
    ln = [L((0, -14), (0, 14)), L((0, 0), (14, 0))]
    streets(b, ln, W, D, **AVE)
    ave_markings(b, ln, W, D)
    zebra(b, (10.6, 0), 90, 18.0, 2.4)
    zebra(b, (0, 10.6), 0, 18.0, 2.4)
    zebra(b, (0, -10.6), 0, 18.0, 2.4)
    for (x, z, f) in [(10.6, -10.6, -45), (10.6, 10.6, -135), (-10.8, 0.0, 90)]:
        traffic_light(b, x, z, f)
    b.palm(-6.0, 0, 7.0, (0.0, 0.1), y=0.15) if False else None
    for s in "NSE":
        connector(b, "Avenida", s, W, D)
    return b


def uebergang_avenida_rua():
    """Avenida (24 m, south edge) narrows to a Rua (12 m, north edge) over 24 m."""
    b = B(411)
    W, D = 24, 24

    def taper(h_s, h_n):
        return Polygon([(-h_s, 12), (h_s, 12), (h_n, -12), (-h_n, -12)])
    road = taper(9.0, 3.5)
    walk = taper(12.0, 6.0).difference(road)
    curb = road.buffer(0.22, join_style=2).intersection(walk)
    ext(b, "road_asphalt", road, -0.1, 0)
    ext(b, "sidewalk", walk.difference(curb), -0.1, 0.15)
    ext(b, "curb", curb, -0.1, 0.17)
    med = Polygon([(-2.0, 12), (2.0, 12), (0.0, 2.0)])
    ext(b, "curb", med, 0, 0.18)
    ext(b, "grass", med.buffer(-0.25, join_style=2), 0, 0.2)
    ext(b, "paint_white", Polygon([(-0.08, 2.0), (0.08, 2.0), (0.08, -1.0), (-0.08, -1.0)]), 0, 0.012)
    paint(b, [L((0, -1.5), (0, -14))], "paint_yellow", 0.15, tile_box(W, D), dashed=True)
    for s in (-1, 1):                                                                   # lane merge arrows-ish lines
        paint(b, [L((s * 5.5, 12), (s * 2.0, -2.0))], "paint_white", 0.12, tile_box(W, D), dashed=True)
    for s in (-1, 1):
        lamp(b, s * 9.5, 4.0, -90 * s, h=7)
    b.anchor("Anschluss_Avenida_S", (0, 0, 12), 0)
    b.anchor("Anschluss_Rua_N", (0, 0, -12), 180)
    return b


# ------------------------------------------------------------------ STÜTZMAUERN / BÖSCHUNG
def _wall_face(b, x0, x1, H, mat="concrete", seed=0, stone=False):
    """Front face at z = 0 .. hill behind (-z). Adds joints, weep holes, moss."""
    r = np.random.default_rng(seed)
    T0 = 0.8
    b.hull(mat, [(x, 0, z) for x in (x0, x1) for z in (0.0, -T0)] + [(x, H, z) for x in (x0, x1) for z in (-0.25, -T0)])
    joint = "stone" if stone else "concrete_dk"
    if stone:
        for y in np.arange(0.5, H, 0.5):
            zf = -0.25 * y / H
            b.box(joint, (x1 - x0, 0.03, 0.03), ((x0 + x1) / 2, y, zf + 0.01))
            off = 0.6 if int(y * 2) % 2 else 0.0
            for x in np.arange(x0 + 0.6 + off, x1, 1.2):
                b.box(joint, (0.03, 0.5, 0.03), (x, y - 0.25, zf + 0.015))
    else:
        for x in np.arange(x0 + 3.0, x1 - 0.1, 3.0):
            b.beam(joint, (x, 0.0, 0.01), (x, H, -0.24), 0.05)
    for x in np.arange(x0 + 1.5, x1, 3.0):
        for y in (0.6, H * 0.55):
            zf = -0.25 * y / H
            b.cyl("tunnel_dark", 0.06, 0.02, (x, y, zf + 0.01), 6) if False else b.box("tunnel_dark", (0.12, 0.12, 0.04), (x, y, zf + 0.01))
            b.box("hedge", (0.18, y * 0.3, 0.02), (x, y - y * 0.15 - 0.1, -0.25 * (y - y * 0.15) / H + 0.02))


def _top_ground(b, x0, x1, z0, z1, H, rail=True):
    b.box("grass", (x1 - x0, 0.3, z1 - z0), ((x0 + x1) / 2, H - 0.15, (z0 + z1) / 2))
    b.box("concrete", (x1 - x0, 0.2, 0.4), ((x0 + x1) / 2, H + 0.1, -0.45))
    if rail:
        for x in np.arange(x0 + 0.2, x1, 1.5):
            b.beam("metal", (x, H + 0.2, -0.45), (x, H + 1.1, -0.45), 0.05)
        b.beam("metal", (x0, H + 1.1, -0.45), (x1, H + 1.1, -0.45), 0.05)
        b.beam("metal", (x0, H + 0.65, -0.45), (x1, H + 0.65, -0.45), 0.04)


def _shift(b, dz):
    for ms in b.parts.values():
        for m in ms:
            m.apply_translation((0, 0, dz))
    b.anchors = {k: (p + np.array([0, 0, dz]), yaw) for k, (p, yaw) in b.anchors.items()}


def mauer(H, stone=False):
    def f():
        b = B(950 + H)
        W, D = 12, 4
        _wall_face(b, -6, 6, H, "stone" if stone else "concrete", seed=H, stone=stone)
        _top_ground(b, -6, 6, -D, -0.6, H)
        r = b.rng
        for x in (-3.5, 2.0):
            b.rock("plant", 0.8, (x + r.uniform(-1, 1), H + 0.3, -2.5), 0.8)
        b.anchor("Oben", (0, H, -2.0), 180)
        b.anchor("Unten", (0, 0, 0.5), 0)
        _shift(b, D / 2)
        return b
    return f


def mauer_ecke(aussen=True):
    """4 x 4 m corner piece for the 4 m walls (face of straight walls = +Z edge of their tile).
    Außen: convex corner – walls on the +Z and +X faces, plateau behind.
    Innen: concave corner – two straight walls meet in a point; this piece fills the plateau gap + corner column."""
    def f():
        b = B(960 + aussen)
        H = 4.0
        if aussen:
            s1 = B(1)
            _wall_face(s1, -2, 2, H, "concrete", seed=1)
            s2 = B(2)
            _wall_face(s2, -2, 2, H, "concrete", seed=2)
            Rz = trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0])
            for k, ms in s1.parts.items():
                for m in ms:
                    m.apply_translation((0, 0, 2))
                    b.add(k, m)
            for k, ms in s2.parts.items():
                for m in ms:
                    m.apply_transform(Rz)
                    m.apply_translation((2, 0, 0))
                    b.add(k, m)
            b.box("grass", (3.4, 0.3, 3.4), (-0.3, H - 0.15, -0.3))
            b.box("concrete", (4.0, 0.2, 0.4), (0, H + 0.1, 1.55))
            b.box("concrete", (0.4, 0.2, 4.0), (1.55, H + 0.1, 0))
            for p in [(-1.8, 1.55), (0.0, 1.55), (1.55, 1.55), (1.55, 0.0), (1.55, -1.8)]:
                b.beam("metal", (p[0], H + 0.2, p[1]), (p[0], H + 1.1, p[1]), 0.05)
            b.beam("metal", (-2, H + 1.1, 1.55), (1.55, H + 1.1, 1.55), 0.05)
            b.beam("metal", (1.55, H + 1.1, 1.55), (1.55, H + 1.1, -2), 0.05)
            b.box("concrete_dk", (0.5, H + 0.3, 0.5), (1.85, (H + 0.3) / 2, 1.85))
        else:
            b.box("rock", (4.0, H - 0.3, 4.0), (0, (H - 0.3) / 2, 0))
            b.box("grass", (4.0, 0.3, 4.0), (0, H - 0.15, 0))
            b.box("concrete_dk", (0.6, H + 0.3, 0.6), (-1.9, (H + 0.3) / 2, 1.9))
            b.rock("plant", 0.8, (0.5, H + 0.3, -0.5), 0.8)
        b.anchor("Ecke", (0, 0, 0), 0)
        return b
    return f


def boeschung():
    """Grass embankment rising 4 m over 8 m, with rocks, bushes and a small tree."""
    b = B(970)
    W, D, H = 12, 10, 4.0
    b.hull("grass", [(x, 0, z) for x in (-6, 6) for z in (0, -D)] + [(x, H, z) for x in (-6, 6) for z in (-8, -D)])
    b.box("concrete", (12, 0.35, 0.4), (0, 0.17, 0.2))
    r = b.rng
    for k in range(9):
        x, z = r.uniform(-5.3, 5.3), r.uniform(-7.5, -0.8)
        y = H * min(1, -z / 8)
        if k % 3 == 0:
            b.rock("rock", r.uniform(0.4, 0.8), (x, y + 0.1, z), 0.6)
        else:
            b.rock("hedge", r.uniform(0.5, 0.9), (x, y + 0.2, z), 0.7)
    for x in (-3.5, 3.0):
        tree(b, x, -8.8, y=H, h=3.2, r=1.5)
    b.anchor("Oben", (0, H, -9.0), 180)
    b.anchor("Unten", (0, 0, 0.6), 0)
    _shift(b, D / 2)
    return b


def mauer_treppe():
    """4 m retaining wall with a staircase leading up into the hill (connects to Beco/Escadaria)."""
    b = B(980)
    W, D, H = 12, 8, 4.0
    _wall_face(b, -6, -1.6, H, "concrete", seed=5)
    _wall_face(b, 1.6, 6, H, "concrete", seed=6)
    _top_ground(b, -6, -1.6, -D, -0.6, H)
    _top_ground(b, 1.6, 6, -D, -0.6, H)
    for sx in (-1, 1):                                                                   # side walls of the cut
        b.box("concrete", (0.3, H, D), (sx * 1.65, H / 2, -D / 2))
    n, run = 20, (D - 0.5) / 20
    cols = ["cloth_yellow", "plaster_up", "cloth_red", "plaster_blue", "cloth_green", "plaster_pink"]
    for i in range(n):
        top = (i + 1) * H / n
        z1 = 0.2 - i * run
        b.box("beco_concrete", (3.0, top, run), (0, top / 2, z1 - run / 2))
        b.box(cols[i % 6], (3.0, H / n, 0.03), (0, top - H / n / 2, z1 - 0.015))
    b.beam("metal", (-1.3, 1.1, 0.0), (-1.3, H + 1.0, -D + 0.6), 0.05)
    b.box("beco_concrete", (3.0, 0.1, 0.6), (0, H - 0.05, -D + 0.3))
    b.anchor("Anschluss_Beco_Unten", (0, 0, 0.6), 0)
    b.anchor("Anschluss_Beco_Oben", (0, H, -D), 180)
    _shift(b, D / 2)
    return b


ROADS2 = [
    ("21_rua_bogen_15", "Rua – Bogen 15°", "Rua", rua_bogen(15), None),
    ("22_rua_bogen_30", "Rua – Bogen 30°", "Rua", rua_bogen(30), None),
    ("23_avenida_bogen_15", "Avenida – Bogen 15°", "Avenida", avenida_bogen(15), None),
    ("24_avenida_bogen_30", "Avenida – Bogen 30°", "Avenida", avenida_bogen(30), None),
    ("25_copacabana_bogen_15", "Copacabana – Bogen 15°", "Avenida", copacabana_bogen, None),
    ("26_avenida_t", "Avenida – T-Kreuzung", "Avenida", avenida_t, (24, 24)),
    ("27_uebergang_avenida_rua", "Übergang Avenida → Rua", "Avenida", uebergang_avenida_rua, (24, 24)),
    ("28_stuetzmauer_4m", "Stützmauer 4 m", "Gelände", mauer(4), (12, 4)),
    ("29_stuetzmauer_8m", "Stützmauer 8 m (Naturstein)", "Gelände", mauer(8, True), (12, 4)),
    ("30_mauer_ecke_aussen", "Stützmauer – Ecke außen", "Gelände", mauer_ecke(True), (4, 4)),
    ("31_mauer_ecke_innen", "Stützmauer – Ecke innen", "Gelände", mauer_ecke(False), (4, 4)),
    ("32_boeschung", "Böschung 4 m", "Gelände", boeschung, (12, 10)),
    ("33_mauer_treppe", "Stützmauer mit Treppe", "Gelände", mauer_treppe, (12, 8)),
]
