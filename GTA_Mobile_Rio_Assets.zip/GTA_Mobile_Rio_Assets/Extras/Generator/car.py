"""Valente GT – eigenes, fiktives Sport-Coupé im Low-Poly-Stil (kein reales Vorbild).
Front = +Z, links (Fahrerseite) = +X im glTF, Boden y = 0, Pivot = Mitte zwischen den Achsen.
Räder sind eigene Objekte mit Drehpunkt in der Radmitte: Rad_VL, Rad_VR, Rad_HL, Rad_HR."""
import numpy as np
import trimesh
from lib import B, PALETTE

PALETTE.update({
    "car_trim": "#151617", "car_glass": "#1C2730", "car_light": "#F4F6FA", "car_tail": "#C8161E",
    "car_interior": "#26272A", "car_rubber": "#1B1B1B", "car_disc": "#8A8D91", "car_plate": "#E9E9E4",
})

WB_F, WB_R = 1.25, -1.35      # front / rear axle z
WR, WT, TRACK = 0.36, 0.27, 0.84


def sec(z, hw, yb, yt):
    """Octagon-ish cross-section of the lower body."""
    mid = (yb + yt) / 2
    lo, hi = min(yb + 0.12, mid - 0.01), max(yt - 0.14, mid + 0.01)
    top_in = min(yt - 0.03, max(hi + 0.02, yt - 0.03))
    pts = []
    for s in (-1, 1):
        pts += [(s * (hw - 0.06), yb, z), (s * hw, lo, z), (s * hw, hi, z),
                (s * (hw - 0.09), top_in, z), (s * (hw - 0.24), yt, z)]
    return pts


BODY = [  # z, half width, bottom y, top y
    (-2.40, 0.86, 0.30, 0.78), (-2.30, 0.92, 0.26, 0.96), (-2.00, 0.97, 0.26, 0.99),
    (-1.80, 0.99, 0.30, 0.99), (-1.60, 1.00, 0.62, 1.00), (-1.35, 1.00, 0.77, 1.00),
    (-1.10, 0.99, 0.62, 0.97), (-0.92, 0.97, 0.26, 0.96), (-0.40, 0.95, 0.22, 0.94),
    (0.30, 0.95, 0.22, 0.90), (0.80, 0.96, 0.26, 0.87), (1.00, 0.97, 0.62, 0.87),
    (1.25, 0.97, 0.77, 0.86), (1.50, 0.96, 0.62, 0.81), (1.70, 0.94, 0.28, 0.75),
    (2.05, 0.90, 0.22, 0.70), (2.30, 0.82, 0.22, 0.62), (2.42, 0.72, 0.26, 0.52),
]

CABIN = [  # z, bottom hw, bottom y, top hw, top y
    (0.66, 0.80, 0.86, 0.80, 0.865), (0.0, 0.86, 0.92, 0.64, 1.36),
    (-0.75, 0.88, 0.955, 0.62, 1.36), (-1.58, 0.80, 0.985, 0.78, 0.99),
]


def cab_sec(z, hb, yb, ht, yt):
    return [(s * hb, yb, z) for s in (-1, 1)] + [(s * ht, yt, z) for s in (-1, 1)]


def mirror_pts(pts):
    return [(-x, y, z) for (x, y, z) in pts]


def body_y_top(z):
    zs = [s[0] for s in BODY]
    return float(np.interp(z, zs, [s[3] for s in BODY]))


def wheel(b, name, x, z, side):
    """side = +1 (left, +X) / -1 (right, -X). Built in world space, exported with pivot at the hub."""
    b.layer = name
    b.pivots[name] = (x, WR, z)
    rot = trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0])     # cylinder axis -> X

    def cylx(mat, r, h, cx, sections=18):
        m = trimesh.creation.cylinder(radius=r, height=h, sections=sections)
        m.apply_transform(rot)
        m.apply_translation((cx, WR, z))
        b.add(mat, m)
    cylx("car_rubber", WR, WT, x, 18)
    cylx("car_rubber", WR - 0.03, WT + 0.02, x, 18)                        # sidewall bulge
    face = x + side * (WT / 2 + 0.005)
    cylx("slot_rim_1", 0.255, 0.02, face - side * 0.035, 16)                # rim barrel face (recessed)
    for k in range(10):                                                     # 10 spokes
        a = k * 2 * np.pi / 10
        p0 = np.array([face, WR + 0.05 * np.sin(a), z + 0.05 * np.cos(a)])
        p1 = np.array([face - side * 0.02, WR + 0.245 * np.sin(a), z + 0.245 * np.cos(a)])
        b.beam("slot_rim_1", p0, p1, 0.045)
    cylx("slot_rim_1", 0.07, 0.04, face, 8)                                 # hub
    cylx("car_trim", 0.03, 0.05, face + side * 0.01, 6)
    cylx("car_disc", 0.21, 0.025, x - side * 0.02, 14)                      # brake disc
    b.layer = None
    # caliper (does not rotate) – part of the body
    b.box("slot_caliper_1", (0.06, 0.16, 0.1), (x - side * 0.0, WR + 0.12, z + 0.14), rot_x=-35)


def valente_gt():
    b = B(77)
    b.colors["slot_paint_1"] = "#4A4C4F"
    b.colors["slot_rim_1"] = "#1A1A1A"
    b.colors["slot_caliper_1"] = "#C8202A"
    P = "slot_paint_1"

    # ---------------- lower body ----------------
    for s0, s1 in zip(BODY[:-1], BODY[1:]):
        b.hull(P, sec(*s0) + sec(*s1))
    # hood power-dome + spoiler lip
    b.hull(P, [(sx, 0.86, 0.7) for sx in (-0.3, 0.3)] + [(sx, 0.75, 1.95) for sx in (-0.26, 0.26)] +
           [(sx, 0.885, 0.75) for sx in (-0.22, 0.22)] + [(sx, 0.775, 1.9) for sx in (-0.2, 0.2)])
    b.hull("car_trim", [(sx, 0.985, -2.18) for sx in (-0.78, 0.78)] + [(sx, 1.045, -2.33) for sx in (-0.8, 0.8)] +
           [(sx, 0.96, -2.33) for sx in (-0.8, 0.8)])

    # ---------------- cabin (glass) + roof + pillars ----------------
    for s0, s1 in zip(CABIN[:-1], CABIN[1:]):
        b.hull("car_glass", cab_sec(*s0) + cab_sec(*s1))
    b.hull(P, [(sx, 1.345, z) for sx in (-0.67, 0.67) for z in (0.02, -0.77)] +
           [(sx, 1.39, z) for sx in (-0.6, 0.6) for z in (-0.05, -0.7)])
    for s in (-1, 1):
        b.beam(P, (s * 0.82, 0.87, 0.64), (s * 0.655, 1.36, 0.0), 0.07)                       # A-pillar
        b.beam("car_trim", (s * 0.875, 0.95, -0.55), (s * 0.64, 1.35, -0.55), 0.06)           # B-pillar
        c = [(s * 0.885, 0.957, -0.78), (s * 0.63, 1.355, -0.78), (s * 0.805, 0.985, -1.56)]  # C-pillar
        b.hull(P, c + [(x - s * 0.06, y, z) for (x, y, z) in c])
        b.beam("car_trim", (s * 0.86, 0.925, 0.6), (s * 0.885, 0.955, -0.8), 0.03)            # belt trim

    # ---------------- interior (seen through tinted glass) ----------------
    b.box("car_interior", (1.6, 0.25, 0.35), (0, 0.78, 0.5))
    for s in (-1, 1):
        x = s * 0.38
        b.hull("car_interior", [(x + dx, 0.32, z) for dx in (-0.24, 0.24) for z in (-0.15, -0.65)] +
               [(x + dx, 0.48, z) for dx in (-0.24, 0.24) for z in (-0.15, -0.65)])
        b.hull("car_interior", [(x + dx, 0.45, -0.62) for dx in (-0.22, 0.22)] + [(x + dx, 1.08, -0.8) for dx in (-0.2, 0.2)] +
               [(x + dx, 0.45, -0.75) for dx in (-0.22, 0.22)] + [(x + dx, 1.08, -0.9) for dx in (-0.2, 0.2)])
    sw = trimesh.creation.torus(major_radius=0.17, minor_radius=0.025, major_sections=12, minor_sections=4)
    sw.apply_transform(trimesh.transformations.rotation_matrix(np.radians(-70), [1, 0, 0]))
    sw.apply_translation((0.38, 0.88, 0.22))
    b.add("car_interior", sw)
    b.box("car_interior", (0.25, 0.3, 1.0), (0, 0.45, -0.1))
    b.box("car_interior", (1.4, 0.35, 0.4), (0, 0.5, -1.25))

    # ---------------- front (own design: one wide low intake + slim slot) ----------------
    b.box("car_trim", (0.95, 0.1, 0.05), (0, 0.47, 2.41))
    b.hull("car_trim", [(sx, 0.40, 2.395) for sx in (-0.62, 0.62)] + [(sx, 0.27, 2.39) for sx in (-0.72, 0.72)] +
           [(sx, 0.40, 2.43) for sx in (-0.62, 0.62)] + [(sx, 0.27, 2.43) for sx in (-0.72, 0.72)])
    for k in range(5):
        b.box("car_disc", (1.3 - k * 0.04, 0.012, 0.02), (0, 0.29 + k * 0.025, 2.435))
    for s in (-1, 1):
        tri = [(s * 0.66, 0.43, 2.36), (s * 0.82, 0.43, 2.27), (s * 0.80, 0.28, 2.27)]
        b.hull("car_trim", tri + [(x, y, z + 0.035) for (x, y, z) in tri])
        hl = [(s * 0.38, 0.585, 2.37), (s * 0.80, 0.655, 2.2), (s * 0.82, 0.61, 2.22), (s * 0.42, 0.555, 2.385)]
        b.hull("car_light", hl + [(x, y + 0.012, z + 0.012) for (x, y, z) in hl])
        b.beam("lamp", (s * 0.45, 0.54, 2.39), (s * 0.78, 0.585, 2.25), 0.02)
    b.box("car_trim", (1.75, 0.035, 0.32), (0, 0.205, 2.3))                                 # splitter
    b.box("car_plate", (0.5, 0.11, 0.02), (0, 0.36, 2.445))

    # ---------------- rear ----------------
    b.box("car_tail", (1.62, 0.07, 0.04), (0, 0.885, -2.355))
    for s in (-1, 1):
        b.hull("car_tail", [(s * 0.62, 0.85, -2.34), (s * 0.88, 0.86, -2.29), (s * 0.88, 0.94, -2.29), (s * 0.62, 0.92, -2.35),
                            (s * 0.62, 0.85, -2.37), (s * 0.62, 0.92, -2.38)])
    b.box("car_trim", (1.45, 0.16, 0.22), (0, 0.31, -2.33))                                  # diffuser
    for x in (-0.36, -0.12, 0.12, 0.36):
        b.box("car_trim", (0.025, 0.12, 0.2), (x, 0.3, -2.4))
    rot = trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0])
    for x in (-0.62, -0.5, 0.5, 0.62):                                                         # quad exhaust
        m = trimesh.creation.cylinder(radius=0.045, height=0.16, sections=8)
        m.apply_transform(rot)
        m.apply_translation((x, 0.31, -2.42))
        b.add("metal", m)
        m2 = trimesh.creation.cylinder(radius=0.03, height=0.162, sections=8)
        m2.apply_transform(rot)
        m2.apply_translation((x, 0.31, -2.421))
        b.add("car_trim", m2)
    b.box("car_plate", (0.5, 0.11, 0.02), (0, 0.6, -2.39))

    # ---------------- sides ----------------
    for s in (-1, 1):
        b.box("car_trim", (0.05, 0.1, 1.75), (s * 0.95, 0.25, -0.05))                         # side skirt
        for z in (0.36, -0.78):                                                                # door seams
            b.box("car_trim", (0.01, 0.6, 0.012), (s * 0.957, 0.6, z))
        b.box("car_trim", (0.01, 0.012, 1.14), (s * 0.957, 0.3, -0.21))
        b.box("car_trim", (0.03, 0.035, 0.16), (s * 0.958, 0.82, -0.5))                       # handle
        b.box("car_trim", (0.02, 0.2, 0.06), (s * 0.968, 0.6, 0.72), rot_x=-20)               # fender vent
        b.beam(P, (s * 0.86, 0.94, 0.47), (s * 1.0, 0.96, 0.45), 0.04)                         # mirror
        b.hull(P, [(s * 0.98, 0.92, 0.38), (s * 1.12, 0.93, 0.42), (s * 1.12, 1.03, 0.42), (s * 0.98, 1.04, 0.38),
                   (s * 0.98, 0.92, 0.5), (s * 1.08, 0.94, 0.5), (s * 1.08, 1.02, 0.5), (s * 0.98, 1.03, 0.5)])
        b.box("car_glass", (0.12, 0.08, 0.01), (s * 1.05, 0.98, 0.375))
        for z in (WB_F, WB_R):                                                                 # arch liners
            b.cyl("car_trim", WR + 0.06, 0.01, (s * 0.7, WR + 0.02, z), 8) if False else None

    # ---------------- wheels ----------------
    wheel(b, "Rad_VL", TRACK, WB_F, +1)
    wheel(b, "Rad_VR", -TRACK, WB_F, -1)
    wheel(b, "Rad_HL", TRACK, WB_R, +1)
    wheel(b, "Rad_HR", -TRACK, WB_R, -1)

    # ---------------- anchors ----------------
    b.anchor("Fahrertuer", (1.35, 0, -0.15), 90)
    b.anchor("Beifahrertuer", (-1.35, 0, -0.15), -90)
    b.anchor("Sitz_Fahrer", (0.38, 0.48, -0.4), 0)
    b.anchor("Sitz_Beifahrer", (-0.38, 0.48, -0.4), 0)
    b.anchor("Kofferraum", (0, 0.5, -2.9), 180)
    b.anchor("Motorhaube", (0, 0.8, 1.6), 0)
    b.anchor("Auspuff", (0, 0.31, -2.5), 180)
    b.anchor("Scheinwerfer", (0, 0.6, 2.5), 0)
    return b
