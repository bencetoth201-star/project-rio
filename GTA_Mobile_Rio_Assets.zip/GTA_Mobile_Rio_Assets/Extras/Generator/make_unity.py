"""Generates RioHausDaten.cs from out/meta.json and assembles the Unity package folder."""
import json, os, shutil

meta = json.load(open("out/meta.json"))
H = meta["houses"]
P = meta["palettes"]

rows = ",\n".join(
    f'        new Haus("{h["slug"]}", "{h["name"]}", "{h["cls"]}", {h["lot"][0]:.0f}f, {h["lot"][1]:.0f}f, {h["tris"]})'
    for h in H)
pals = ",\n".join(f'        {{ "{k}", new[] {{ {", ".join(chr(34) + c + chr(34) for c in v)} }} }}' for k, v in P.items())

cs = f'''// Automatisch erzeugt von make_unity.py aus out/meta.json – nicht von Hand ändern.
using System.Collections.Generic;

public static class RioHausDaten
{{
    public struct Haus
    {{
        public string slug, name, klasse;
        public float lotBreite, lotTiefe;   // Grundstück in Metern (X, Z), 2-m-Raster
        public int dreiecke;

        public Haus(string slug, string name, string klasse, float lotBreite, float lotTiefe, int dreiecke)
        {{
            this.slug = slug; this.name = name; this.klasse = klasse;
            this.lotBreite = lotBreite; this.lotTiefe = lotTiefe; this.dreiecke = dreiecke;
        }}
    }}

    public static readonly Haus[] Haeuser =
    {{
{rows}
    }};

    public static readonly Dictionary<string, string[]> Paletten = new Dictionary<string, string[]>
    {{
{pals}
    }};

    public static bool Finde(string modellName, out Haus haus)
    {{
        foreach (var h in Haeuser)
            if (modellName.StartsWith(h.slug)) {{ haus = h; return true; }}
        haus = default(Haus);
        return false;
    }}
}}
'''
os.makedirs("unity/Scripts", exist_ok=True)
open("unity/Scripts/RioHausDaten.cs", "w").write(cs)

root = "pack/RioHaeuser_Unity"
shutil.rmtree(root, ignore_errors=True)
A = f"{root}/Assets/RioHaeuser"
os.makedirs(f"{A}/Modelle")
os.makedirs(f"{A}/Scripts")
os.makedirs(f"{A}/Editor")
os.makedirs(f"{root}/Extras/OBJ")
os.makedirs(f"{root}/Extras/Generator")
for h in H:
    shutil.copy(f"out/{h['slug']}.glb", f"{A}/Modelle/")
    for ext in ("obj", "mtl"):
        shutil.copy(f"out/{h['slug']}.{ext}", f"{root}/Extras/OBJ/")
for f in ("RioHausFarben.cs", "RioHausDaten.cs"):
    shutil.copy(f"unity/Scripts/{f}", f"{A}/Scripts/")
shutil.copy("unity/Editor/RioHausPlatzierer.cs", f"{A}/Editor/")
shutil.copytree("unity/Gemeinsam", f"{root}/Assets/RioGemeinsam", dirs_exist_ok=True)   # RioKollision (Hitboxen)
shutil.copy("out/meta.json", f"{A}/haeuser.json")
for f in ("lib.py", "houses.py", "make_unity.py", "tankstelle.py", "luxus.py", "bank.py", "buildings2.py", "nightclub.py", "tuning.py", "loja.py", "stadion.py", "juwelier.py", "roads.py"):
    shutil.copy(f, f"{root}/Extras/Generator/")
shutil.copy("LIESMICH.md", f"{root}/LIESMICH.md")
print("ok", root)
