"""Build the 20 beach objects → out_beach/*.glb/.obj/.mtl + meta.json"""
import json, os
import numpy as np
from lib import export, SLOT_PALETTES
import beach

os.makedirs("out_beach", exist_ok=True)
meta = []
for slug, name, cls, fn in beach.BEACH:
    b = fn()
    lot = b.normalize()
    tris, mats, bnd, slots = export(b, f"out_beach/{slug}", name)
    size = bnd[1] - bnd[0]
    combos = int(np.prod([len(SLOT_PALETTES[s.split("_")[1]]) for s in slots])) if slots else 1
    meta.append(dict(slug=slug, name=name, cls=cls, tris=tris, mats=mats, slots=slots, combos=combos,
                     size=[round(float(v), 1) for v in size], lot=[lot[0], lot[1]],
                     anchors={k: [round(float(c), 3) for c in p] + [yaw] for k, (p, yaw) in b.anchors.items()}))
    print(f"{slug:24s} tris={tris:5d} size={np.round(size, 1).tolist()} lot={lot}")
json.dump(dict(houses=meta, palettes=SLOT_PALETTES, rows={"Natur": 0, "Rettung": 1, "Essen": 2, "Freizeit": 3, "Sport": 4}, gap=2,
               title="Rio-Strand", subtitle="20 Strandobjekte für Copacabana & Ipanema · Schirme und Tücher würfelbar",
               lotLabel="Fläche", allLabel="Strandobjekte", allHint="Strand-Set nebeneinander"),
          open("out_beach/meta.json", "w"), indent=1, ensure_ascii=False)
