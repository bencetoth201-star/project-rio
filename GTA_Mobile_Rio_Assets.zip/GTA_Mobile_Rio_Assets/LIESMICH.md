# GTA Mobile – Rio-Assets (alles in einem Ordner)

127 Modelle im Low-Poly-Stil für Rio de Janeiro: Häuser und Spezialgebäude, Straßen, Strand, Hafen mit Containerschiff, Fahrzeuge.
Die Heist-Schauplätze (Casa Império + Megayacht SOBERANA) sind **nicht** mehr hier drin – sie liegen im eigenen Paket **RioHeists**. Einheiten: 1 = 1 m, Y oben. Import über **glTFast**.

## Installation
1. Paket **glTFast** in Unity installieren (Package Manager ▸ `com.unity.cloud.gltfast`).
2. Den Ordner **`Assets`** aus diesem Paket in dein Projekt ziehen (alles landet unter `Assets/Rio…`).
3. **Tools ▸ Rio ▸ Hitboxen einrichten** für platzierte Modelle ausführen (Häuser-Platzierer macht das selbst).

## Inhalt
| Paket | Ordner | Modelle | Anleitung |
|---|---|---|---|
| Häuser & Spezialgebäude | `Assets/RioHaeuser/` | 33 | `Docs/ANLEITUNG_HAEUSER.md` |
| Straßennetz | `Assets/RioStrassen/` | 56 | `Docs/ANLEITUNG_STRASSEN.md` |
| Strand | `Assets/RioStrand/` | 20 | `Docs/ANLEITUNG_STRAND.md` |
| Hafen | `Assets/RioHafen/` | 17 | `Docs/ANLEITUNG_HAFEN.md` |
| Fahrzeuge | `Assets/RioFahrzeuge/` | 1 | `Docs/ANLEITUNG_FAHRZEUGE.md` |
| Gemeinsame Skripte (Hitboxen) | `Assets/RioGemeinsam/` | – | dieses Dokument |

`Extras/OBJ/<Paket>/` – dieselben Modelle als .obj/.mtl (ohne Anker, ohne Hitboxen) · `Extras/Generator/` – Python-Generatoren.

## Hitboxen (gilt für alle Modelle)
Jedes GLB bringt unsichtbare Zusatz-Nodes mit:
- **`<Ebene>__kollision`** – vereinfachte feste Hitbox pro Ebene: Wände, Böden, Treppen, Geländer-Handläufe, Möbel und Fahrzeuge
  als einfache Blöcke. **Nicht fest:** Kleinkram unter 30 cm (Ringe, Edelsteine, Flaschen, Schrift), flache Teppiche und
  Markierungen, dünne Stäbe (Geländerstäbe, Gitterstäbe, Fensterrahmen, Stuhlbeine), Lichtkegel, Wasserfontänen, Palmwedel.
- **`<Ebene>__trigger_<n>`** – Auslöser ohne feste Wand: Laserstrahlen, Pools, Flutwasser (convex, `isTrigger`).
- **Bewegliche Teile** (Türen, Tore, Vitrinen-Hauben, Laser, Aufzüge, Tresortüren, Boote, Hubschrauber …) sind eigene Nodes
  mit Pivot am Scharnier/Drehpunkt; ihre `…__kollision`/`…__trigger_<n>`-Kinder bewegen sich mit.

**In Unity einrichten:** Menü **Tools ▸ Rio ▸ Hitboxen einrichten (Auswahl | ganze Szene)** (Skripte in `Assets/RioGemeinsam`).
Das macht die Zusatz-Nodes unsichtbar, setzt `MeshCollider` (Trigger: convex + isTrigger), entfernt alte Voll-MeshCollider,
gibt beweglichen Teilen einen kinematischen `Rigidbody` und markiert alles andere als statisch (bewegliche Teile nie – sonst
bewegt sich die Grafik nicht mit). Der Häuser-Platzierer (`Tools ▸ Rio Häuser ▸ Platzhalter ersetzen`) erledigt das automatisch.
- **Wichtig:** keine eigenen MeshCollider auf die Grafik-Meshes legen (teuer und falsch bei Lasern/Lichtkegeln).
- **Zur Laufzeit gespawnt:** `RioKollision.Einrichten(instanz);` aufrufen. Dafür im glTFast-Importer „Read/Write“ der Meshes
  aktivieren (sonst kann Unity die Collider zur Laufzeit nicht bauen). Im Editor platzierte Modelle brauchen das nicht.
- **Heist-Logik:** Laser aus = Laser-Node deaktivieren (Trigger geht mit). Alarm = `OnTriggerEnter` am Trigger
  (der Spieler braucht `CharacterController` oder `Rigidbody`). Tür auf = beweglichen Node drehen/verschieben.
  Bewegliche Teile findet man mit `RioKollision.IstBeweglich(transform)`.
- **Fahrzeuge** (BMW M4) bekommen weiter BoxCollider + WheelCollider wie in ihrer Anleitung.
- **Kosten:** Hitboxen haben zusammen ~50 % der Grafik-Dreiecke (Containerschiff ~28.000, Stadion ~23.000, Kleiderladen ~18.000,
  normale Häuser 700–4.500, Straßenteile meist < 1.500).
