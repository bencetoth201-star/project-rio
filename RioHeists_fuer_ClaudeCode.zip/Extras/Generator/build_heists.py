"""Build the special heist set → out_heists/*.glb/.obj/.mtl + meta.json
Casa Império (Mega-Heist-Palast, "Megabank") + Megayacht SOBERANA – raus aus Häuser- und Hafen-Paket."""
import json, os, sys
import numpy as np
from lib import export, SLOT_PALETTES
from palacio import palacio, LEVELS as PALACIO_LEVELS
from yacht import yacht, LEVELS as YACHT_LEVELS
import kanal

HEISTS = [
    # slug, name, class, builder, levels, groundHide, normalize (2-m lot like the houses)
    ("01_casa_imperio", "Casa Império (Mega-Heist-Palast)", "Heist", palacio, PALACIO_LEVELS, None, True),
    ("02_yacht_soberana", "Megayacht SOBERANA (150 m)", "Heist", yacht, YACHT_LEVELS, "Unterdeck", False),
    ("03_casa_imperio_abgeriegelt", "Casa Império – abgeriegelt", "Heist", lambda: palacio(abgeriegelt=True), PALACIO_LEVELS, None, True),
]
SCHACHT = ("liftschacht", "versteck_garage", "schacht_rund", "gullydeckel")
for slug, name, fn, lv, lift in kanal.TEILE:                     # Maya sewer kit: pivot = tile centre on the water line (no lot snapping)
    cls = "Kanal-Beispiel" if slug.startswith("10_") else ("Kanal-Schacht" if any(k in slug for k in SCHACHT) else "Kanalisation")
    start = "Kanal" if "Kanal" in lv else ("Garage" if "Garage" in lv else None)
    HEISTS.append((slug, name, cls, fn, lv, None, False, dict(lift=lift, noOutline=True, **({"startLevel": start} if start else {}))))

if __name__ == "__main__":
    os.makedirs("out_heists", exist_ok=True)
    only = [a for a in sys.argv[1:] if not a.startswith("--")]
    old = {h["slug"]: h for h in json.load(open("out_heists/meta.json"))["houses"]} if only and os.path.exists("out_heists/meta.json") else {}
    meta = []
    for slug, name, cls, fn, levels, ghide, norm, *extra in HEISTS:
        if only and not any(o in slug for o in only):
            if slug in old:
                meta.append(old[slug])
            continue
        b = fn()
        lot = b.normalize() if norm else None
        tris, mats, bnd, slots = export(b, f"out_heists/{slug}", name)
        size = bnd[1] - bnd[0]
        if lot is None:
            lot = (float(2 * np.ceil(size[0] / 2)), float(2 * np.ceil(size[2] / 2)))
        combos = int(np.prod([len(SLOT_PALETTES[s.split("_")[1]]) for s in slots])) if slots else 1
        h = dict(slug=slug, name=name, cls=cls, tris=tris, mats=mats, slots=slots, combos=combos,
                 size=[round(float(v), 1) for v in size], lot=[lot[0], lot[1]], levels=levels,
                 kollision=int(getattr(b, "kollision_tris", 0)), trigger=int(getattr(b, "trigger_count", 0)),
                 anchors={k: [round(float(c), 3) for c in p] + [yaw] for k, (p, yaw) in b.anchors.items()},
                 beweglich=sorted(b.pivots),
                 beute=sorted(k for k in b.pivots if any(t in k for t in getattr(b, "pickup_tags", ("_Beute",)))))
        if not norm:
            h["offset"] = [round(float(-(bnd[0][0] + bnd[1][0]) / 2), 2), round(float(-(bnd[0][2] + bnd[1][2]) / 2), 2)]
        if ghide:
            h["groundHide"] = ghide
        if extra:
            h.update(extra[0])
        meta.append(h)
        print(f"{slug:22s} tris={tris:6d} kollision={h['kollision']:6d} trigger={h['trigger']:3d} size={np.round(size, 1).tolist()} anchors={len(b.anchors)}")
    json.dump(dict(houses=meta, palettes=SLOT_PALETTES, rows={"Heist": 0, "Kanal-Beispiel": 1, "Kanalisation": 2, "Kanal-Schacht": 3}, gap=10,
                   title="Rio-Heists",
                   subtitle="Casa Império (Mega-Heist-Palast, normal + abgeriegelt) · Megayacht SOBERANA · Maya-Kanalisation als Baukasten (15 Teile + Beispielnetz)",
                   lotLabel="Fläche", allLabel="Teile", allHint="Heist-Schauplätze + Kanal-Baukasten"),
              open("out_heists/meta.json", "w"), indent=1, ensure_ascii=False)
