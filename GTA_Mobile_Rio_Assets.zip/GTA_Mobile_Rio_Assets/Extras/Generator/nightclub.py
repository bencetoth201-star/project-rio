"""Clube Subsolo – Nachtclub, der von außen wie ein heruntergekommener Häuserblock aussieht.
Innen: eine einzige 8,5 m hohe Halle mit LED-Tanzfläche, Discokugel, DJ-Bühne mit LED-Wand, 3 Bars,
Go-go-Podeste, Lounge-Sofas, Toiletten; Galerie (OG) mit VIP-Lounge, VIP-Bar und 5 Privatkabinen mit Stange.
Front +Z, Pivot Grundstücksmitte. Nodes <Ebene>__<Material>: Aussen, EG, OG, Dach (+ Licht = Lichtkegel)."""
import numpy as np
import trimesh
from lib import B, PALETTE

PALETTE.update({
    "club_wall": "#2B2335", "club_floor": "#1C1822", "club_velvet": "#7C1631", "club_purple": "#4B2B6E",
    "club_sofa": "#2A1E33", "club_neon": "#FF3FA4", "led_pink": "#FF3FA4", "led_cyan": "#2FE0F0",
    "led_purple": "#9B4DFF", "led_yellow": "#FFD23F", "mirror": "#DCE0E6", "chrome": "#C9CED6",
    "bar_top": "#2C2A30", "bottle": "#2F6B3B", "bottle_b": "#7A4A1E", "speaker": "#151515", "speaker_cone": "#3A3A3E",
    "beam_pink": "#FF5FB8", "beam_cyan": "#5FEFFF", "beam_purple": "#B07CFF", "dach_innen": "#0F0D13",
    "graffiti_a": "#E8452E", "graffiti_b": "#2EA8E8", "graffiti_c": "#F2C230", "graffiti_d": "#52C46B",
    "rope": "#9E1B2E",
})

LED = ["led_pink", "led_cyan", "led_purple", "led_yellow"]

X0, X1, Z0, Z1 = -12.0, 12.0, -16.0, 16.0        # outer footprint
T = 0.3                                         # wall thickness
IX0, IX1, IZ0, IZ1 = X0 + T, X1 - T, Z0 + T, Z1 - T
F = 0.15                                        # club floor top
M0, M1 = 4.2, 4.5                               # mezzanine slab bottom/top
C = 8.5                                         # hall ceiling
R = 9.0                                         # roof top


def nightclub():
    b = B(2401)

    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def wall_x(mat, z, x0, x1, y0, y1, holes=(), t=T):
        z0, z1 = z - t / 2, z + t / 2
        xs = [x0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [x1]
        for a, c in zip(xs[0::2], xs[1::2]):
            if c - a > 1e-3:
                box(mat, a, c, y0, y1, z0, z1)
        for (xa, xb, ya, yb) in holes:
            if ya > y0:
                box(mat, xa, xb, y0, ya, z0, z1)
            if yb < y1:
                box(mat, xa, xb, yb, y1, z0, z1)

    wa = b.slot("wall", 1, "#D9A0A6")      # faded pink
    wb = b.slot("wall", 2, "#E3C77A")      # faded yellow
    wc = b.slot("wall", 3, "#8FB3C4")      # faded blue

    # =================================================================
    # AUSSEN – three shabby "houses" glued together, nothing hints at a club
    # =================================================================
    b.layer = "Aussen"
    box("concrete", X0 - 0.5, X1 + 0.5, 0, 0.15, Z1, Z1 + 2.6)                        # sidewalk
    box("concrete_dk", X0 - 0.5, X1 + 0.5, 0, 0.18, Z1 + 2.4, Z1 + 2.6)               # curb
    for x, z, w in [(-7.0, 17.2, 1.2), (3.5, 17.8, 0.8), (9.0, 17.0, 1.5)]:           # cracked/patched slabs
        box("concrete_dk", x - w / 2, x + w / 2, 0.15, 0.16, z - 0.4, z + 0.4)

    segs = [(X0, -4.0, 9.8, wa), (-4.0, 5.0, 10.6, wb), (5.0, X1, 9.4, wc)]
    door = (0.0, 1.2)                                                                  # club door: x centre, width
    for (xa, xb, H, col) in segs:
        holes = []
        # ground floor: roll shutter "shops" / club door
        if xa == X0:
            holes.append((-10.6, -6.0, F, 3.0))
        elif xa == 5.0:
            holes.append((6.4, 10.6, F, 3.0))
        else:
            holes.append((door[0] - door[1] / 2, door[0] + door[1] / 2, F, 2.4))
        wall_x(col, Z1 - T / 2, xa, xb, 0, 3.4, holes)
        # upper "floors" (fake): plaster up to 6.4, then raw brick on the middle house (unfinished top floor)
        win = []
        for wx in np.arange(xa + 1.4, xb - 1.0, 2.6):
            win += [(wx, wx + 1.2, 4.3, 5.7), (wx, wx + 1.2, 7.2, 8.5)]
        wall_x(col, Z1 - T / 2, xa, xb, 3.4, 6.6, [h[:2] + (4.3, 5.7) for h in win if h[2] == 4.3])
        upper = "brick_raw" if xa == -4.0 else col
        wall_x(upper, Z1 - T / 2, xa, xb, 6.6, H, [h[:2] + (7.2, 8.5) for h in win if h[2] == 7.2])
        box("concrete_dk", xa, xb, 3.35, 3.5, Z1 - 0.05, Z1 + 0.12)                    # slab edges between "floors"
        box("concrete_dk", xa, xb, 6.55, 6.7, Z1 - 0.05, Z1 + 0.12)
        if xa == -4.0:                                                                 # rebar on the unfinished top
            for rx in np.arange(xa + 0.4, xb, 1.3):
                b.beam("rebar", (rx, H, Z1 - 0.15), (rx + 0.05, H + 0.9, Z1 - 0.15), 0.025)
        else:
            box("concrete_dk", xa, xb, H, H + 0.12, Z1 - 0.3, Z1 + 0.05)
        # windows: closed shutters / boarded / grille – all dark behind
        for k, (wx0, wx1, y0, y1) in enumerate(win):
            kind = (k + int(xa)) % 3
            box("glass_open", wx0, wx1, y0, y1, Z1 - 0.2, Z1 - 0.16)
            if kind == 0:
                box("shutter_green" if xa < 0 else "shutter_blue", wx0 + 0.02, wx1 - 0.02, y0, y1, Z1 - 0.16, Z1 - 0.1)
                for yy in np.arange(y0 + 0.15, y1, 0.2):
                    box("frame_black", wx0 + 0.04, wx1 - 0.04, yy, yy + 0.02, Z1 - 0.1, Z1 - 0.09)
            elif kind == 1:
                for yy in np.arange(y0 + 0.1, y1 - 0.1, 0.32):
                    box("plywood", wx0 - 0.05, wx1 + 0.05, yy, yy + 0.26, Z1 - 0.04, Z1 + 0.0)
                b.box("wood_dark", (1.6, 0.1, 0.04), ((wx0 + wx1) / 2, (y0 + y1) / 2, Z1 + 0.02), rot_z=40)
            else:
                for gx in np.arange(wx0 + 0.1, wx1, 0.2):
                    box("frame_black", gx, gx + 0.03, y0, y1, Z1 - 0.02, Z1 + 0.04)
            box("concrete_dk", wx0 - 0.08, wx1 + 0.08, y0 - 0.1, y0, Z1, Z1 + 0.12)  # sill
        # AC units
        acx = xa + (xb - xa) * 0.7
        box("ac", acx - 0.45, acx + 0.45, 5.9, 6.4, Z1, Z1 + 0.45)
        box("frame_black", acx - 0.3, acx + 0.3, 5.95, 6.35, Z1 + 0.45, Z1 + 0.46)

    # roll shutters with graffiti
    for (xa, xb) in [(-10.6, -6.0), (6.4, 10.6)]:
        box("tin_rust", xa, xb, F, 3.0, Z1 - 0.12, Z1 - 0.05)
        for yy in np.arange(F + 0.2, 3.0, 0.22):
            box("shutter", xa, xb, yy, yy + 0.03, Z1 - 0.05, Z1 - 0.03)
        box("frame_black", xa - 0.1, xb + 0.1, 3.0, 3.35, Z1 - 0.15, Z1 + 0.1)        # shutter box
        rng = np.random.default_rng(int(abs(xa) * 10) + 77)
        for k in range(7):
            gx, gy = rng.uniform(xa + 0.4, xb - 0.6), rng.uniform(0.5, 2.4)
            gw, gh = rng.uniform(0.5, 1.4), rng.uniform(0.2, 0.6)
            b.box(f"graffiti_{'abcd'[k % 4]}", (gw, gh, 0.01), (gx, gy, Z1 - 0.025), rot_z=rng.uniform(-18, 18))
    for k, (gx, gy, gw, gh, rz) in enumerate([(-2.6, 1.3, 1.6, 0.5, 8), (3.6, 1.0, 1.2, 0.7, -12), (-11.0, 4.9, 1.0, 0.4, 0)]):
        b.box(f"graffiti_{'bcda'[k]}", (gw, gh, 0.01), (gx, gy, Z1 + 0.005), rot_z=rz)

    # the club door: plain steel, peephole slot, red bulb, rope + bouncer lectern
    dx0, dx1 = door[0] - door[1] / 2, door[0] + door[1] / 2
    box("door_metal", dx0, dx1, F, 2.4, Z1 - 0.22, Z1 - 0.16)
    box("frame_black", dx0 + 0.35, dx1 - 0.35, 1.6, 1.7, Z1 - 0.16, Z1 - 0.14)
    box("frame_black", dx0 - 0.08, dx1 + 0.08, 2.4, 2.5, Z1 - 0.1, Z1 + 0.05)
    box("frame_black", door[0] - 0.05, door[0] + 0.05, 2.75, 2.9, Z1, Z1 + 0.2)
    b.cyl("led_red", 0.1, 0.18, (door[0], 2.66, Z1 + 0.2), 8)
    box("concrete_dk", dx0 - 0.3, dx1 + 0.3, 0.15, 0.3, Z1, Z1 + 0.5)                 # step
    for px in (1.6, 2.9, 4.2):
        b.cyl("gold", 0.18, 0.05, (px, 0.175, Z1 + 1.3), 8)
        b.cyl("gold", 0.035, 1.0, (px, 0.65, Z1 + 1.3), 6)
        b.rock("gold", 0.07, (px, 1.18, Z1 + 1.3), 1.0)
    for a, c in ((1.6, 2.9), (2.9, 4.2)):
        for k in range(5):
            t0, t1 = k / 5, (k + 1) / 5
            sag = lambda t: 1.05 - 0.22 * np.sin(np.pi * t)
            b.beam("rope", (a + (c - a) * t0, sag(t0), Z1 + 1.3), (a + (c - a) * t1, sag(t1), Z1 + 1.3), 0.03)
    box("wood_dark", -1.9, -1.4, 0.15, 1.15, Z1 + 0.6, Z1 + 1.0)                     # bouncer lectern
    box("frame_black", -2.0, -1.3, 1.15, 1.2, Z1 + 0.55, Z1 + 1.05)
    # electric meter + conduit (no loose cables)
    box("meter", 4.2, 4.8, 1.3, 2.0, Z1, Z1 + 0.18)
    box("frame_black", 4.45, 4.55, 2.0, 3.35, Z1, Z1 + 0.08)
    b.anchor("Strom_Anschluss", (4.5, 3.35, Z1 + 0.05), 0)
    # trash bags
    for (x, z, r) in [(-5.4, 16.6, 0.35), (-5.0, 16.9, 0.3), (11.0, 16.7, 0.4)]:
        b.rock("frame_black", r, (x, r * 0.6 + 0.15, z), 0.75)

    # side + back walls (plain, a few bricked-up windows)
    for x, col in ((X0 + T / 2, wa), (X1 - T / 2, wc)):
        box(col, x - T / 2, x + T / 2, 0, 9.3, Z0, Z1 - T)
        for z in (-10.0, -3.0, 4.0, 11.0):
            for y0 in (4.3, 7.2):
                box("brick", x - T / 2 - 0.03, x + T / 2 + 0.03, y0, y0 + 1.3, z, z + 1.2)
    box("plaster_low", X0, X1, 0, 9.3, Z0, Z0 + T)
    for x in (-8.0, -2.0, 4.0, 9.0):
        box("brick", x, x + 1.2, 4.3, 5.6, Z0 - 0.03, Z0 + T + 0.03)
    box("door_metal", -9.6, -8.4, F, 2.3, Z0 - 0.06, Z0)                              # fire exit (outside)
    b.cyl("ac", 0.45, 0.8, (8.0, 9.7, -12.0), 8)                                     # roof vent visible from the street

    # =================================================================
    # EG – the hall
    # =================================================================
    b.layer = "EG"
    box("club_floor", IX0, IX1, 0, F, IZ0, IZ1)
    for x0, x1, z0, z1 in [(IX0, IX0 + 0.08, IZ0, IZ1), (IX1 - 0.08, IX1, IZ0, IZ1),
                           (IX0, IX1, IZ0, IZ0 + 0.08), (IX0, IX1, IZ1 - 0.08, IZ1)]:
        box("club_wall", x0, x1, F, C, z0, z1)                                         # black inner lining

    # --- entrance vestibule + cash desk + coat check
    for x in (-1.5, 2.0):
        box("club_wall", x - 0.1, x + 0.1, F, M0, 12.0, IZ1)
    box("club_velvet", -1.4, 1.9, F, 3.2, 11.9, 12.0)                                 # curtain panels into the hall
    for k, x in enumerate(np.arange(-1.3, 1.9, 0.35)):
        if 0.1 < x < 0.9:
            continue
        box("club_velvet", x, x + 0.25, F, 3.2, 11.82 - 0.05 * (k % 2), 11.9)
    box("bar_top", -1.4, -0.6, F, 1.1, 13.2, 15.0)                                    # cash desk
    box("led_pink", -0.62, -0.6, 0.25, 0.3, 13.2, 15.0)
    box("club_wall", -6.4, -1.6, F, M0, 11.95, 12.05, )
    box("bar_top", -5.6, -2.0, F, 1.1, 11.3, 11.9)                                    # coat check counter
    box("shelf", -5.6, -2.0, 1.1, 1.15, 11.2, 11.95)
    for k, x in enumerate(np.arange(-5.4, -2.0, 0.45)):
        b.beam("chrome", (x, 2.2, 13.0), (x, 1.6, 13.0), 0.02)
        box(["club_purple", "club_velvet", "frame_black"][k % 3], x - 0.18, x + 0.18, 0.9, 1.6, 12.85, 13.15)
    box("chrome", -5.6, -2.0, 2.18, 2.22, 12.96, 13.04)
    # --- toilets (front-left)
    box("club_wall", -6.5, -6.4, F, M0, 9.5, 12.0)
    box("club_wall", IX0, -6.4, F, M0, 9.4, 9.5)
    box("club_wall", -9.1, -9.0, F, M0, 9.5, IZ1)
    for x in (-10.2, -7.6):
        box("door_metal", x - 0.45, x + 0.45, F, 2.2, 9.35, 9.4)
        box("led_cyan" if x < -9 else "led_pink", x - 0.25, x + 0.25, 2.5, 2.8, 9.33, 9.35)
    for x in (-11.2, -10.3, -8.4, -7.5):
        box("plastic_white", x - 0.2, x + 0.2, F, 0.55, 15.0, 15.5)                    # toilets
    # --- main bar (left, under the VIP gallery)
    BX = -8.6
    box("club_sofa", BX - 0.6, BX, F, 1.05, -11.0, 6.0)                               # counter body
    box("bar_top", BX - 0.75, BX + 0.12, 1.05, 1.12, -11.1, 6.1)
    box("club_neon", BX + 0.01, BX + 0.03, 0.2, 0.26, -11.0, 6.0)                     # LED strip at the foot
    box("bar_top", IX0 + 0.1, IX0 + 0.7, F, 0.95, -11.0, 6.0)                         # back counter
    box("mirror", IX0 + 0.09, IX0 + 0.11, 1.2, 3.6, -10.5, 5.5)
    for y in (1.4, 2.1, 2.8, 3.5):                                                    # bottle shelves, backlit
        box("shelf", IX0 + 0.1, IX0 + 0.45, y - 0.04, y, -10.5, 5.5)
        box("led_purple", IX0 + 0.1, IX0 + 0.12, y + 0.02, y + 0.55, -10.5, 5.5)
        for k, z in enumerate(np.arange(-10.3, 5.4, 0.32)):
            b.cyl("bottle" if k % 3 else "bottle_b", 0.05, 0.3 + 0.06 * (k % 2), (IX0 + 0.28, y + 0.16, z), 6)
    for z in np.arange(-10.0, 5.6, 1.1):                                              # stools
        b.cyl("chrome", 0.04, 0.75, (BX + 0.55, F + 0.375, z), 6)
        b.cyl("club_velvet", 0.22, 0.09, (BX + 0.55, F + 0.8, z), 8)
    for z in np.arange(-10.0, 6.0, 2.0):                                              # pendant lights over the bar
        b.beam("frame_black", (BX - 0.3, M0, z), (BX - 0.3, 3.0, z), 0.015)
        b.cyl("led_yellow", 0.12, 0.2, (BX - 0.3, 2.9, z), 8)
    # --- second bar (front-right, near the entrance)
    box("club_sofa", 2.6, 6.4, F, 1.05, 9.6, 10.2)
    box("bar_top", 2.5, 6.5, 1.05, 1.12, 9.5, 10.3)
    box("club_neon", 2.6, 6.4, 0.2, 0.26, 9.58, 9.6)
    box("bar_top", 2.6, 6.4, F, 0.95, 11.6, 12.2)
    box("mirror", 2.6, 6.4, 1.2, 3.4, 12.2, 12.22)
    box("club_wall", 2.1, 6.5, F, M0, 12.2, 12.3)
    for y in (1.5, 2.3):
        box("shelf", 2.6, 6.4, y - 0.04, y, 11.9, 12.2)
        box("led_cyan", 2.6, 6.4, y + 0.02, y + 0.5, 12.18, 12.2)
        for k, x in enumerate(np.arange(2.8, 6.3, 0.3)):
            b.cyl("bottle_b" if k % 3 else "bottle", 0.05, 0.32, (x, y + 0.16, 12.05), 6)
    for x in np.arange(3.0, 6.2, 1.0):
        b.cyl("chrome", 0.04, 0.75, (x, F + 0.375, 9.0), 6)
        b.cyl("club_velvet", 0.22, 0.09, (x, F + 0.8, 9.0), 8)

    # --- DJ stage + LED wall + speakers
    SZ = -11.0
    box("club_wall", -6.0, 6.0, 0, 1.25, IZ0, SZ)
    box("club_neon", -6.0, 6.0, 1.18, 1.25, SZ, SZ + 0.03)
    for sx in (-1, 1):                                                                 # stage steps
        for k in range(4):
            box("club_wall", sx * 6.0, sx * (6.0 + 1.2), 0, 1.25 - k * 0.3, SZ - 2.5 + k * 0.4, SZ - 2.1 + k * 0.4)
    box("bar_top", -1.8, 1.8, 1.25, 2.25, -13.4, -12.6)                               # DJ desk
    box("led_cyan", -1.8, 1.8, 1.5, 1.6, -12.6, -12.58)
    for x in (-1.1, 1.1):
        b.cyl("speaker_cone", 0.28, 0.04, (x, 2.27, -13.0), 12)
    box("frame_black", -0.4, 0.4, 2.25, 2.32, -13.2, -12.8)
    rng = np.random.default_rng(42)
    for ix in range(12):                                                               # LED wall 12 x 6 panels
        for iy in range(6):
            x0 = -6.0 + ix * 1.0
            y0 = 1.6 + iy * 1.0
            box(LED[int(rng.integers(0, 4))] if (ix + iy) % 3 else "led_purple", x0 + 0.04, x0 + 0.96, y0 + 0.04, y0 + 0.96, IZ0 + 0.08, IZ0 + 0.12)
    box("frame_black", -6.1, 6.1, 1.5, 7.7, IZ0 + 0.06, IZ0 + 0.08)
    for sx in (-1, 1):                                                                 # speaker stacks + line arrays
        x = sx * 7.6
        for k in range(3):
            y0 = F + k * 1.15
            box("speaker", x - 0.7, x + 0.7, y0, y0 + 1.1, -12.5, -11.5)
            for dx in (-0.32, 0.32):
                c = trimesh.creation.cylinder(radius=0.26, height=0.04, sections=12)
                c.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
                b.add("speaker_cone", c.apply_translation((x + dx, y0 + 0.55, -11.48)))
        for k in range(5):
            y0 = 6.9 - k * 0.55
            box("speaker", x - 0.55, x + 0.55, y0, y0 + 0.5, -11.9 + k * 0.06, -11.3 + k * 0.06)
        b.beam("frame_black", (x, C, -11.6), (x, 6.95, -11.6), 0.03)
    for x in (-4.5, -1.5, 1.5, 4.5):                                                   # subwoofers in front of the stage
        box("speaker", x - 0.7, x + 0.7, F, 0.95, SZ - 0.1, SZ + 0.9)
    for x in (-4.5, -1.5, 1.5, 4.5):
        c = trimesh.creation.cylinder(radius=0.35, height=0.04, sections=12)
        c.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        b.add("speaker_cone", c.apply_translation((x, 0.55, SZ + 0.92)))

    # --- LED dance floor 12 x 12
    DX0, DX1, DZ0, DZ1 = -6.0, 6.0, -9.5, 2.5
    box("frame_black", DX0 - 0.1, DX1 + 0.1, F, F + 0.04, DZ0 - 0.1, DZ1 + 0.1)
    for ix in range(12):
        for iz in range(12):
            mat = LED[(ix + 2 * iz) % 4] if (ix + iz) % 2 == 0 else "club_purple"
            box(mat, DX0 + ix + 0.05, DX0 + ix + 0.95, F + 0.04, F + 0.07, DZ0 + iz + 0.05, DZ0 + iz + 0.95)
    # go-go podiums with poles
    for sx in (-1, 1):
        px, pz = sx * 4.6, 4.0
        b.cyl("club_wall", 0.9, 1.0, (px, F + 0.5, pz), 16)
        b.cyl("club_neon", 0.92, 0.06, (px, F + 1.0, pz), 16)
        b.cyl("chrome", 0.04, C - F - 1.0, (px, F + 1.0 + (C - F - 1.0) / 2, pz), 8)
    # lounge sofas (right, under the cabins)
    for z in (-12.5, -8.5, -4.5, -0.5):
        box("club_sofa", 10.4, IX1 - 0.1, F, 1.2, z - 1.4, z + 1.4)                   # U-shaped booth
        box("club_velvet", 9.4, 10.4, F, 0.55, z - 1.4, z + 1.4)
        for dz in (-1.4, 1.4):
            box("club_sofa", 8.6, 10.4, F, 1.0, z + dz - 0.25 * np.sign(dz) - 0.15, z + dz - 0.25 * np.sign(dz) + 0.15)
        b.cyl("bar_top", 0.45, 0.05, (8.7, F + 0.72, z), 12)
        b.cyl("chrome", 0.05, 0.7, (8.7, F + 0.35, z), 6)
        b.cyl("led_yellow", 0.08, 0.15, (8.7, F + 0.82, z), 6)
    # columns under the gallery edges
    for x, zs in ((-6.6, (-13.0, -8.0, -3.0, 2.0, 7.0)), (6.6, (-13.0, -8.0, -3.0, 2.0, 7.0))):
        for z in zs:
            box("frame_black", x - 0.15, x + 0.15, F, M0, z - 0.15, z + 0.15)
            box("led_pink" if x < 0 else "led_cyan", x - 0.16, x + 0.16, 0.3, 0.35, z - 0.16, z + 0.16)
    box("frame_black", 9.3, 9.6, F, M0, 0.85, 1.15)
    # fire exit
    box("door_metal", -9.6, -8.4, F, 2.3, IZ0 + 0.08, IZ0 + 0.12)
    box("led_green", -9.35, -8.65, 2.45, 2.7, IZ0 + 0.08, IZ0 + 0.14)
    # stairs to the gallery (right, along the wall)
    n = 28
    for k in range(n):
        y = F + (M1 - F) * (k + 1) / n
        z = 1.2 + 7.8 * k / n
        box("club_wall", 9.6, IX1, F, y, z, z + 7.8 / n + 0.01)
        box("club_neon", 9.6, IX1, y - 0.01, y + 0.005, z, z + 0.04)
    for k in range(9):
        z = 1.2 + k * 0.97
        b.beam("chrome", (9.65, F + (M1 - F) * (z - 1.2) / 7.8 + 1.0 - 0.9, z), (9.65, F + (M1 - F) * (z - 1.2) / 7.8 + 1.0, z), 0.025)
    b.beam("chrome", (9.65, F + 1.0, 1.2), (9.65, M1 + 1.0, 9.0), 0.03)
    # truss + moving heads above the dance floor
    TY = 7.6
    for (x0, x1, z0, z1) in [(DX0, DX1, DZ0, DZ0), (DX0, DX1, DZ1, DZ1), (DX0, DX0, DZ0, DZ1), (DX1, DX1, DZ0, DZ1)]:
        box("frame_black", min(x0, x1) - 0.15, max(x0, x1) + 0.15, TY - 0.15, TY + 0.15, min(z0, z1) - 0.15, max(z0, z1) + 0.15)
    for (x, z) in [(DX0, DZ0), (DX1, DZ0), (DX0, DZ1), (DX1, DZ1)]:
        b.beam("frame_black", (x, C, z), (x, TY, z), 0.02)
    heads = [(DX0, DZ0 + 3), (DX0, DZ1 - 3), (DX1, DZ0 + 3), (DX1, DZ1 - 3), (-2.0, DZ0), (2.0, DZ0), (-2.0, DZ1), (2.0, DZ1)]
    targets = [(3.0, -1.0), (2.5, -6.5), (-3.0, -6.0), (-2.5, 0.5), (1.5, 1.0), (-1.5, 1.5), (2.0, -8.0), (-2.5, -7.5)]
    beams = ["beam_pink", "beam_cyan", "beam_purple", "beam_cyan", "beam_pink", "beam_purple", "beam_cyan", "beam_pink"]
    lens = {"beam_pink": "led_pink", "beam_cyan": "led_cyan", "beam_purple": "led_purple"}
    for (hx, hz), (tx, tz), bm in zip(heads, targets, beams):
        box("speaker", hx - 0.2, hx + 0.2, TY - 0.55, TY - 0.15, hz - 0.2, hz + 0.2)
        top = np.array([hx, TY - 0.55, hz])
        bot = np.array([tx, F + 0.08, tz])
        d = top - bot
        L = np.linalg.norm(d)
        cone = trimesh.creation.cone(radius=0.9, height=L, sections=10)
        cone.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], d / L))
        cone.apply_translation(bot)
        b.layer = "Licht"
        b.add(bm, cone)
        b.layer = "EG"
        b.rock(lens[bm], 0.14, tuple(top - np.array([0, 0.05, 0])), 1.0)

    # --- disco ball
    ball = trimesh.creation.icosphere(subdivisions=2, radius=1.5)
    b.add("mirror", ball.apply_translation((0.0, 5.9, -3.5)))
    b.beam("chrome", (0.0, C, -3.5), (0.0, 7.35, -3.5), 0.04)
    b.cyl("frame_black", 0.25, 0.15, (0.0, 7.45, -3.5), 8)

    # =================================================================
    # OG – gallery: VIP lounge (left), cabins (right), front bridge
    # =================================================================
    b.layer = "OG"
    slabs = [(IX0, -6.5, -14.0, 9.0), (IX0, IX1, 9.0, IZ1), (6.5, IX1, -14.0, 1.0), (6.5, 9.45, 1.0, 9.0)]
    for (x0, x1, z0, z1) in slabs:
        box("club_floor", x0, x1, M0, M1, z0, z1)
    # glass railings + LED edge
    rails = [((-6.5, -14.0), (-6.5, 9.0)), ((-6.5, 9.0), (6.5, 9.0)), ((6.5, 9.0), (6.5, -14.0)),
             ((IX0, -14.0), (-6.5, -14.0)), ((6.5, -14.0), (IX1, -14.0)), ((9.45, 1.0), (9.45, 9.0)), ((9.45, 1.0), (IX1, 1.0))]
    for (ax, az), (cx, cz) in rails:
        x0, x1, z0, z1 = min(ax, cx), max(ax, cx), min(az, cz), max(az, cz)
        th = 0.05
        box("glass_rail", x0 - (th if x0 == x1 else 0), x1 + (th if x0 == x1 else 0), M1, M1 + 1.05,
            z0 - (th if z0 == z1 else 0), z1 + (th if z0 == z1 else 0))
        box("chrome", x0 - (0.04 if x0 == x1 else 0), x1 + (0.04 if x0 == x1 else 0), M1 + 1.05, M1 + 1.1,
            z0 - (0.04 if z0 == z1 else 0), z1 + (0.04 if z0 == z1 else 0))
        box("club_neon", x0 - (0.06 if x0 == x1 else 0), x1 + (0.06 if x0 == x1 else 0), M0 - 0.06, M0,
            z0 - (0.06 if z0 == z1 else 0), z1 + (0.06 if z0 == z1 else 0))
    # VIP lounge: sofas, tables with champagne buckets, VIP bar, rope
    for z in (-12.0, -7.5, -3.0):
        box("club_purple", IX0 + 0.1, IX0 + 0.9, M1, M1 + 1.1, z - 1.6, z + 1.6)
        box("club_purple", IX0 + 0.9, IX0 + 1.8, M1, M1 + 0.45, z - 1.6, z + 1.6)
        for dz in (-1.6, 1.6):
            box("club_purple", IX0 + 0.9, IX0 + 3.0, M1, M1 + 0.8, z + dz - 0.25 * np.sign(dz) - 0.2, z + dz - 0.25 * np.sign(dz) + 0.2)
        b.cyl("bar_top", 0.55, 0.06, (-8.4, M1 + 0.5, z), 12)
        b.cyl("chrome", 0.06, 0.48, (-8.4, M1 + 0.24, z), 6)
        b.cyl("gold", 0.14, 0.25, (-8.4, M1 + 0.66, z), 8)
        b.cyl("bottle", 0.04, 0.35, (-8.38, M1 + 0.75, z + 0.03), 6)
    box("bar_top", IX0 + 0.1, IX0 + 0.8, M1, M1 + 1.05, 2.0, 7.6)                     # VIP bar
    box("gold", IX0 + 0.8, IX0 + 0.83, M1 + 0.1, M1 + 0.95, 2.0, 7.6)
    box("mirror", IX0 + 0.09, IX0 + 0.11, M1 + 1.2, M1 + 3.0, 2.0, 7.6)
    for y in (M1 + 1.4, M1 + 2.1):
        box("shelf", IX0 + 0.1, IX0 + 0.4, y - 0.04, y, 2.0, 7.6)
        box("led_yellow", IX0 + 0.1, IX0 + 0.12, y + 0.02, y + 0.5, 2.0, 7.6)
        for k, z in enumerate(np.arange(2.2, 7.5, 0.3)):
            b.cyl("gold" if k % 4 == 0 else "bottle", 0.05, 0.3, (IX0 + 0.26, y + 0.16, z), 6)
    for z in (3.0, 4.6, 6.2):
        b.cyl("chrome", 0.04, 0.75, (IX0 + 1.4, M1 + 0.375, z), 6)
        b.cyl("club_purple", 0.22, 0.09, (IX0 + 1.4, M1 + 0.8, z), 8)
    for px in (-7.2, -4.8):                                                            # VIP rope on the bridge
        b.cyl("gold", 0.035, 1.0, (px, M1 + 0.5, 10.6), 6)
    b.beam("rope", (-7.2, M1 + 0.95, 10.6), (-4.8, M1 + 0.95, 10.6), 0.03)
    b.text("VIP", ["led_yellow"] * 3, (-9.0, M1 + 2.6, IZ1 - 0.12), 0.5, 0.04, rot_y=180)
    # private cabins (5) with pole, sofa, curtain, mirror, number
    CX0 = 8.7
    walls = np.linspace(-14.0, 1.0, 6)
    for k in range(5):
        za, zc = walls[k], walls[k + 1]
        zm = (za + zc) / 2
        box("club_velvet", CX0, IX1, M1, C, za - 0.08, za + 0.08)                     # partition
        b.cyl("club_wall", 0.85, 0.25, (10.3, M1 + 0.125, zm), 16)                   # small round stage
        b.cyl("club_neon", 0.87, 0.04, (10.3, M1 + 0.25, zm), 16)
        b.cyl("chrome", 0.04, C - M1 - 0.25, (10.3, M1 + 0.25 + (C - M1 - 0.25) / 2, zm), 8)
        box("club_sofa", CX0 + 0.1, CX0 + 0.8, M1, M1 + 0.45, za + 0.35, zc - 0.35)  # sofa facing the pole
        box("mirror", IX1 - 0.1, IX1 - 0.08, M1 + 0.4, M1 + 3.2, za + 0.4, zc - 0.4)
        box("led_pink", 10.0, 10.6, C - 0.06, C - 0.02, zm - 0.3, zm + 0.3)
        # curtain: two gathered halves, left a gap in the middle
        for side in (-1, 1):
            for j in range(4):
                z0 = za + 0.1 + j * 0.28 if side < 0 else zc - 0.1 - (j + 1) * 0.28
                box("club_velvet", CX0 - 0.06 - 0.06 * (j % 2), CX0 + 0.02 - 0.06 * (j % 2), M1, C - 0.1, z0, z0 + 0.28)
        box("chrome", CX0 - 0.1, CX0 - 0.05, C - 0.15, C - 0.1, za, zc)
        b.text(str(k + 1), ["led_pink"], (CX0 - 0.13, M1 + 3.4, zm), 0.4, 0.03, rot_y=-90)
        b.anchor(f"Kabine_{k + 1}", (9.4, M1, zm), 90)
    # backrests of the cabin sofas
    for k in range(5):
        za, zc = walls[k], walls[k + 1]
        box("club_sofa", CX0 + 0.1, CX0 + 0.3, M1 + 0.45, M1 + 1.0, za + 0.35, zc - 0.35)

    # =================================================================
    # DACH – black ceiling, roof slab, roof clutter (hidden when looking inside)
    # =================================================================
    b.layer = "Dach"
    box("dach_innen", IX0, IX1, C, C + 0.05, IZ0, IZ1)
    box("dach", X0, X1, C + 0.05, R, Z0, Z1)
    for (x, z) in [(-9.0, 12.0), (-7.4, 12.0), (2.0, 13.0)]:                          # blue water tanks
        b.cyl("tank", 0.65, 1.2, (x, R + 0.6, z), 10)
        b.cyl("tank_lid", 0.68, 0.1, (x, R + 1.25, z), 10)
    for (x, z) in [(5.0, -6.0), (6.4, -6.0), (-3.0, -10.0), (-4.4, -10.0)]:            # condenser units (club AC)
        box("ac", x - 0.6, x + 0.6, R, R + 1.1, z - 0.45, z + 0.45)
        b.cyl("frame_black", 0.4, 0.04, (x, R + 1.12, z), 10)
    b.cyl("plastic_white", 0.45, 0.05, (10.0, R + 1.2, 6.0), 10)                     # satellite dish
    b.beam("frame_black", (10.0, R, 6.0), (10.0, R + 1.2, 6.0), 0.03)
    box("tin_rust", -1.0, 3.0, R, R + 2.2, -2.0, 1.0)                                 # rooftop shack (stair housing)
    box("tin", -1.2, 3.2, R + 2.2, R + 2.3, -2.2, 1.2)
    box("door_metal", 0.3, 1.2, R, R + 2.0, 1.0, 1.04)

    b.layer = None
    b.anchor("Eingang", (door[0], 0, Z1 + 1.0), 0)
    b.anchor("Tanzflaeche", (0, F, -3.5), 0)
    b.anchor("DJ", (0, 1.25, -13.8), 0)
    b.anchor("Bar_Haupt", (BX + 0.8, F, -2.0), 90)
    b.anchor("Bar_Eingang", (4.5, F, 8.8), 180)
    b.anchor("VIP_Lounge", (-8.0, M1, -6.0), 90)
    b.anchor("Notausgang", (-9.0, 0, Z0 - 0.5), 180)
    return b
