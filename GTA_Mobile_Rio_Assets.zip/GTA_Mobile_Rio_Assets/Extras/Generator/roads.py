"""Rio-Straßenbaukasten: 20 modulare Straßenteile im Low-Poly-Stil der Häuser.

Konventionen
- 1 Einheit = 1 m, Y oben, Pivot = Kachelmitte. Fahrbahn-Oberfläche y = 0, Gehweg y = +0.15.
- Kacheln sind Vielfache von 2 m. Anschlüsse liegen mittig auf den Kachelkanten
  (Ausnahmen stehen als Anker im Modell: "Anschluss_<Typ>_<Richtung>", Z zeigt aus der Kachel hinaus).
- Querschnitte:  Rua 12 m (2,5 Gehweg | 7 Fahrbahn | 2,5 Gehweg)
                 Avenida 24 m (3 | 7 | 4 Mittelstreifen | 7 | 3)
                 Beco 4 m (3 m Gasse)
"""
import numpy as np
import trimesh
from shapely.geometry import LineString, Point, Polygon, box as sbox
from shapely.ops import unary_union, substring
from lib import B, PALETTE

PALETTE.update({
    "road_asphalt": "#4A4B4F", "road_patch": "#3B3C3F", "sidewalk": "#BDB7AC", "curb": "#8F8C86",
    "paint_yellow": "#E8B923", "cobble": "#7D7268", "cobble_line": "#5A524A", "calcadao_black": "#2B2B2B",
    "calcadao_white": "#EFEDE6", "sand": "#E6D3A3", "rock": "#7A7468", "tunnel_dark": "#2B2B2E",
    "beco_concrete": "#A9A39A", "gutter": "#6F6A62", "traffic_amber": "#F2A81D", "sea_wall": "#CFC8B8",
})

Q = 4   # arc resolution (low poly)
RUA = dict(half_road=3.5, half_total=6.0)
AVE = dict(half_road=9.0, half_total=12.0)
DIRS = {"N": (0, -1, 180), "S": (0, 1, 0), "E": (1, 0, 90), "W": (-1, 0, -90)}


# ------------------------------------------------------------------ helpers
def ext(b, mat, geom, y0, y1):
    if geom is None or geom.is_empty:
        return
    for g in getattr(geom, "geoms", [geom]):
        if g.geom_type != "Polygon" or g.area < 1e-3:
            continue
        m = trimesh.creation.extrude_polygon(g, y1 - y0)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        m.apply_translation((0, y1, 0))
        b.add(mat, m)


def tile_box(W, D):
    return sbox(-W / 2, -D / 2, W / 2, D / 2)


def L(*pts):
    return LineString(pts)


def closing(g, r):
    return g.buffer(r, quad_segs=Q, join_style=1).buffer(-r, quad_segs=Q, join_style=1)


def connector(b, typ, side, W, D, offset=0.0, y=0.0):
    dx, dz, yaw = DIRS[side]
    if dx:
        p = (dx * W / 2, y, offset)
    else:
        p = (offset, y, dz * D / 2)
    b.anchor(f"Anschluss_{typ}_{side}", p, yaw)


def dashes(line, dash=3.0, gap=3.0):
    out, s = [], 0.0
    while s < line.length:
        out.append(substring(line, s, min(s + dash, line.length)))
        s += dash + gap
    return out


def paint(b, lines, mat, width, clip, cut=None, dashed=False, dash=3.0, gap=3.0, y=0.012):
    geoms = []
    for ln in lines:
        g = ln.intersection(clip)
        if cut is not None:
            g = g.difference(cut)
        for part in getattr(g, "geoms", [g]):
            if part.is_empty or part.geom_type != "LineString":
                continue
            for p in (dashes(part, dash, gap) if dashed else [part]):
                if p.length > 0.05:
                    geoms.append(p.buffer(width / 2, quad_segs=1, cap_style=2))
    if geoms:
        ext(b, mat, unary_union(geoms), 0.0, y)


def streets(b, lines, W, D, half_road, half_total, road_mat="road_asphalt", walk_mat="sidewalk", fillet=2.0):
    """Asphalt + curbs + sidewalks for a set of centrelines, clipped to the tile."""
    T = tile_box(W, D)
    road = closing(unary_union([l.buffer(half_road, quad_segs=Q, cap_style=2) for l in lines]), fillet).intersection(T)
    walk = closing(unary_union([l.buffer(half_total, quad_segs=Q, cap_style=2) for l in lines]), fillet).intersection(T)
    walk = walk.difference(road)
    curb = road.buffer(0.22, quad_segs=Q).intersection(walk)
    ext(b, road_mat, road, -0.1, 0.0)
    ext(b, walk_mat, walk.difference(curb), -0.1, 0.15)
    ext(b, "curb", curb, -0.1, 0.17)
    return road, walk


def junction_zone(lines, r):
    zones = []
    for i in range(len(lines)):
        for j in range(i + 1, len(lines)):
            a, c = lines[i].buffer(r, cap_style=2), lines[j].buffer(r, cap_style=2)
            if a.intersects(c):
                zones.append(a.intersection(c))
    return unary_union(zones) if zones else None


def zebra(b, center, angle_deg, road_width, depth=2.4):
    """Crosswalk across a road; angle = travel direction (deg, 0 = along +z)."""
    a = np.radians(angle_deg)
    t = np.array([np.sin(a), np.cos(a)])            # travel dir (x, z)
    n = np.array([t[1], -t[0]])                       # across
    bars = []
    k = -road_width / 2 + 0.45
    while k < road_width / 2 - 0.3:
        c = np.array(center) + n * k
        p = [c + n * 0.25 + t * depth / 2, c - n * 0.25 + t * depth / 2, c - n * 0.25 - t * depth / 2, c + n * 0.25 - t * depth / 2]
        bars.append(Polygon(p))
        k += 1.0
    ext(b, "paint_white", unary_union(bars), 0.0, 0.012)


def lamp(b, x, z, face_deg, y=0.15, h=6.5):
    """Modern street lamp; arm points towards face_deg (0 = +z)."""
    a = np.radians(face_deg)
    d = np.array([np.sin(a), 0, np.cos(a)])
    base = np.array([x, y, z])
    b.cyl("frame_black", 0.09, h, (x, y + h / 2, z), 6)
    top = base + np.array([0, h, 0])
    b.beam("frame_black", top, top + d * 1.6 + np.array([0, 0.3, 0]), 0.08)
    hp = top + d * 1.7 + np.array([0, 0.22, 0])
    b.box("frame_black", (0.5, 0.12, 0.25), tuple(hp), rot_y=face_deg)
    b.box("lamp", (0.44, 0.04, 0.2), tuple(hp + np.array([0, -0.07, 0])), rot_y=face_deg)


def old_lamp(b, x, z, y=0.15):
    b.cyl("frame_black", 0.18, 0.4, (x, y + 0.2, z), 8)
    b.cyl("frame_black", 0.07, 3.4, (x, y + 2.0, z), 6)
    b.box("lamp", (0.32, 0.5, 0.32), (x, y + 3.95, z))
    b.hull("frame_black", [(x - 0.26, y + 4.2, z - 0.26), (x + 0.26, y + 4.2, z - 0.26), (x - 0.26, y + 4.2, z + 0.26),
                           (x + 0.26, y + 4.2, z + 0.26), (x, y + 4.5, z)])


def traffic_light(b, x, z, face_deg, y=0.15):
    a = np.radians(face_deg)
    b.cyl("frame_black", 0.08, 3.2, (x, y + 1.6, z), 6)
    hx, hz = x + 0.0 * np.sin(a), z
    b.box("frame_black", (0.36, 1.0, 0.3), (hx, y + 3.5, hz), rot_y=face_deg)
    for k, mat in enumerate(("led_red", "traffic_amber", "led_green")):
        b.box(mat, (0.2, 0.2, 0.04), (hx + 0.16 * np.sin(a), y + 3.82 - k * 0.3, hz + 0.16 * np.cos(a)), rot_y=face_deg)


def tree(b, x, z, y=0.15, h=3.0, r=1.4):
    b.box("curb", (1.0, 0.04, 1.0), (x, y + 0.02, z))
    b.cyl("palm_trunk", 0.12, h, (x, y + h / 2, z), 6)
    for dx, dy, dz, s in [(0, 0, 0, 1.0), (0.5, -0.3, 0.3, 0.7), (-0.5, -0.2, -0.3, 0.75)]:
        b.rock("plant", r * s, (x + dx, y + h + dy, z + dz), 0.8)


def manhole(b, x, z):
    b.cyl("metal", 0.35, 0.02, (x, 0.01, z), 8)


def bench(b, x, z, rot=0.0, y=0.15):
    b.box("wood_b", (1.6, 0.06, 0.45), (x, y + 0.45, z), rot_y=rot)
    for dx in (-0.65, 0.65):
        c, s = np.cos(np.radians(rot)), np.sin(np.radians(rot))
        b.box("frame_black", (0.06, 0.45, 0.4), (x + dx * c, y + 0.22, z - dx * s), rot_y=rot)


def rua_markings(b, lines, W, D, center=True, edge=True):
    T = tile_box(W, D)
    jz = junction_zone(lines, RUA["half_road"] + 0.6)
    if center:
        paint(b, lines, "paint_yellow", 0.15, T, jz, dashed=True)
    if edge:
        offs = []
        for l in lines:
            for d in (3.15, -3.15):
                offs.append(l.offset_curve(d))
        paint(b, offs, "paint_white", 0.12, T, jz.buffer(0.3) if jz is not None else None)


def ave_markings(b, lines, W, D):
    """Median islands + lane dividers for avenues."""
    T = tile_box(W, D)
    jz = junction_zone(lines, AVE["half_road"] + 0.8)
    med = unary_union([l.buffer(2.0, quad_segs=Q, cap_style=2) for l in lines]).intersection(T)
    if jz is not None:
        med = med.difference(jz)
    ext(b, "curb", med, 0.0, 0.18)
    ext(b, "grass", med.buffer(-0.25, quad_segs=Q), 0.0, 0.2)
    offs = [l.offset_curve(d) for l in lines for d in (5.5, -5.5)]
    paint(b, offs, "paint_white", 0.12, T, jz, dashed=True)
    edge = [l.offset_curve(d) for l in lines for d in (8.7, -8.7, 2.3, -2.3)]
    paint(b, edge, "paint_white", 0.1, T, jz.buffer(0.4) if jz is not None else None)
    return med


def embankment(b, W, D, rise, mat="concrete"):
    """Solid wedge under a sloped tile so it never floats (added before shear_z, which lifts its top)."""
    hw, hd = W / 2, D / 2
    pts = [(sx * hw, -0.1, sz * hd) for sx in (-1, 1) for sz in (-1, 1)] + [(sx * hw, -0.1 - rise, -hd) for sx in (-1, 1)]
    m = trimesh.convex.convex_hull(np.array(pts))
    b.add(mat, m)


def shear_z(b, rise, D):
    """Slope a tile: +rise at z = -D/2 (north), 0 at z = +D/2 (south)."""
    for ms in b.parts.values():
        for m in ms:
            v = m.vertices.copy()
            v[:, 1] += (D / 2 - v[:, 0] * 0 - v[:, 2]) / D * rise
            m.vertices = v
    b.anchors = {k: (p + np.array([0, (D / 2 - p[2]) / D * rise, 0]), yaw) for k, (p, yaw) in b.anchors.items()}


# ================================================================== RUA
def rua_gerade():
    b = B(301)
    W, D = 12, 12
    ln = [L((0, -8), (0, 8))]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    lamp(b, -5.4, -3.0, 90)
    lamp(b, 5.4, 3.0, -90)
    tree(b, 4.8, -3.5, r=1.0)
    manhole(b, 1.6, 2.0)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    return b


def rua_kurve():
    b = B(302)
    W, D = 12, 12
    arc = [(6 + 6 * np.cos(a), 6 + 6 * np.sin(a)) for a in np.linspace(np.pi, 1.5 * np.pi, 9)]
    ln = [LineString([(0, 8)] + arc[::-1][::-1] if False else [(0, 8)] + [(6 + 6 * np.cos(a), 6 + 6 * np.sin(a)) for a in np.linspace(np.pi, 1.5 * np.pi, 9)] + [(8, 0)])]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    lamp(b, -5.2, -5.2, 135)
    for s in "SE":
        connector(b, "Rua", s, W, D)
    return b


def rua_t():
    b = B(303)
    W, D = 12, 12
    ln = [L((0, -8), (0, 8)), L((0, 0), (8, 0))]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    zebra(b, (4.9, 0), 90, 7.0, 1.8)
    lamp(b, -5.4, 0.0, 90)
    for s in "NSE":
        connector(b, "Rua", s, W, D)
    return b


def rua_kreuzung():
    b = B(304)
    W, D = 12, 12
    ln = [L((0, -8), (0, 8)), L((-8, 0), (8, 0))]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D, edge=False)
    for (cx, cz, ang) in [(0, 4.85, 0), (0, -4.85, 0), (4.85, 0, 90), (-4.85, 0, 90)]:
        zebra(b, (cx, cz), ang, 7.0, 1.7)
    for (x, z, f) in [(-4.9, -4.9, 45), (4.9, 4.9, -135)]:
        traffic_light(b, x, z, f)
    for s in "NSEW":
        connector(b, "Rua", s, W, D)
    return b


def rua_sackgasse():
    b = B(305)
    W, D = 18, 20
    c = (0, -1.5)
    T = tile_box(W, D)
    road = closing(unary_union([L((0, c[1]), (0, 12)).buffer(3.5, cap_style=2), Point(c).buffer(6.0, quad_segs=Q)]), 2.0).intersection(T)
    walk = closing(unary_union([L((0, c[1]), (0, 12)).buffer(6.0, cap_style=2), Point(c).buffer(8.5, quad_segs=Q)]), 2.0).intersection(T).difference(road)
    curb = road.buffer(0.22, quad_segs=Q).intersection(walk)
    ext(b, "road_asphalt", road, -0.1, 0)
    ext(b, "sidewalk", walk.difference(curb), -0.1, 0.15)
    ext(b, "curb", curb, -0.1, 0.17)
    island = Point(c).buffer(2.2, quad_segs=Q)
    ext(b, "curb", island, 0, 0.18)
    ext(b, "grass", island.buffer(-0.25, quad_segs=Q), 0, 0.2)
    tree(b, 0, c[1], 0.2, 2.6, 1.2)
    paint(b, [L((0, 4.5), (0, 12))], "paint_yellow", 0.15, T, dashed=True)
    lamp(b, -7.4, -1.5, 90)
    lamp(b, 7.4, 5.0, -90)
    connector(b, "Rua", "S", W, D)
    return b


def rua_steigung():
    b = B(306)
    W, D = 12, 24
    ln = [L((0, -14), (0, 14))]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    for z in (-8, 8):
        lamp(b, -5.4 if z < 0 else 5.4, z, 90 if z < 0 else -90)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    embankment(b, W, D, 3.0)
    shear_z(b, 3.0, D)
    return b


def rua_bushaltestelle():
    b = B(307)
    W, D = 12, 24
    ln = [L((0, -14), (0, 14))]
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    # bus box marking
    T = tile_box(W, D)
    zone = sbox(0.3, -6, 3.4, 6)
    ext(b, "paint_yellow", zone.exterior.buffer(0.08, quad_segs=1).intersection(T), 0, 0.012)
    b.text("ÔNIBUS", "paint_yellow", (1.85, 0.0, 0.0), 0.55, 1.0, rot_y=-90)
    for ms in list(b.parts.get("paint_yellow", [])):
        pass
    # shelter on the east sidewalk
    sx = 5.3
    for z in (-1.8, 1.8):
        b.beam("frame_black", (sx + 0.5, 0.15, z), (sx + 0.5, 2.6, z), 0.08)
        b.beam("frame_black", (sx - 0.3, 0.15, z), (sx - 0.3, 2.5, z), 0.06)
    b.box("glass_rail", (0.04, 2.0, 3.6), (sx + 0.55, 1.3, 0))
    b.box("paint_white", (1.3, 0.1, 4.2), (sx + 0.15, 2.65, 0), rot_z=-5)
    b.box("cloth_yellow", (1.32, 0.12, 4.22), (sx + 0.15, 2.58, 0), rot_z=-5)
    bench(b, sx + 0.2, 0.0, 90)
    b.cyl("frame_black", 0.05, 2.8, (sx - 0.4, 1.55, 3.0), 6)
    b.box("atm_blue", (0.05, 0.5, 0.5), (sx - 0.4, 2.75, 3.0))
    for z in (-8, 8):
        lamp(b, -5.4, z, 90)
    tree(b, 5.0, -8.0)
    tree(b, 5.0, 8.0)
    b.anchor("Bushaltestelle", (sx - 0.8, 0.15, 0), -90)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    return b


def rua_kopfstein():
    """Santa Teresa: cobblestones + tram (bonde) rails + old lamps."""
    b = B(308)
    W, D = 12, 12
    ln = [L((0, -8), (0, 8))]
    road, walk = streets(b, ln, W, D, road_mat="cobble", walk_mat="calcadao_white", **RUA)
    for x in np.arange(-3.3, 3.31, 0.55):
        b.box("cobble_line", (0.04, 0.008, D), (x, 0.004, 0))
    for z in np.arange(-5.8, 5.81, 0.55):
        b.box("cobble_line", (7.0, 0.008, 0.04), (0, 0.004, z))
    for x in (-0.5, 0.5):
        b.box("metal", (0.08, 0.03, D), (x, 0.015, 0))
    for z in np.arange(-5.0, 5.1, 2.5):                                             # pavement diamonds
        for x in (-4.75, 4.75):
            b.box("calcadao_black", (0.5, 0.01, 0.5), (x, 0.155, z), rot_y=45)
    old_lamp(b, -5.3, -3.0)
    old_lamp(b, 5.3, 3.0)
    b.anchor("Bonde_Schienen", (0, 0, 0), 0)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    return b


# ================================================================== AVENIDA
def ave_gerade():
    b = B(401)
    W, D = 24, 24
    ln = [L((0, -14), (0, 14))]
    streets(b, ln, W, D, **AVE)
    ave_markings(b, ln, W, D)
    b.palm(0, -6, 7.0, (0.2, 0.1), y=0.2)
    b.palm(0, 6, 7.5, (-0.2, 0.1), y=0.2)
    for (x, z, f) in [(-10.8, -6, 90), (10.8, 6, -90)]:
        lamp(b, x, z, f, h=8)
    for (x, z) in [(-10.6, 6), (10.6, -6)]:
        tree(b, x, z, h=3.5)
    for s in "NS":
        connector(b, "Avenida", s, W, D)
    return b


def ave_kreuzung():
    b = B(402)
    W, D = 24, 24
    ln = [L((0, -14), (0, 14)), L((-14, 0), (14, 0))]
    streets(b, ln, W, D, **AVE)
    ave_markings(b, ln, W, D)
    for (cx, cz, ang) in [(0, 10.6, 0), (0, -10.6, 0), (10.6, 0, 90), (-10.6, 0, 90)]:
        zebra(b, (cx, cz), ang, 18.0, 2.4)
    for (x, z, f) in [(-10.6, -10.6, 45), (10.6, -10.6, -45), (-10.6, 10.6, 135), (10.6, 10.6, -135)]:
        traffic_light(b, x, z, f)
    for s in "NSEW":
        connector(b, "Avenida", s, W, D)
    return b


def ave_einmuendung():
    """Avenida N-S with a Rua branching to the east (T)."""
    b = B(403)
    W, D = 24, 24
    ave = L((0, -14), (0, 14))
    rua = L((0, 0), (14, 0))
    T = tile_box(W, D)
    road = closing(unary_union([ave.buffer(9, cap_style=2), rua.buffer(3.5, cap_style=2)]), 2.0).intersection(T)
    walk = closing(unary_union([ave.buffer(12, cap_style=2), rua.buffer(6, cap_style=2)]), 2.0).intersection(T).difference(road)
    curb = road.buffer(0.22, quad_segs=Q).intersection(walk)
    ext(b, "road_asphalt", road, -0.1, 0)
    ext(b, "sidewalk", walk.difference(curb), -0.1, 0.15)
    ext(b, "curb", curb, -0.1, 0.17)
    cut = rua.buffer(4.5, cap_style=2)
    med = ave.buffer(2.0, cap_style=2).intersection(T).difference(cut)
    ext(b, "curb", med, 0, 0.18)
    ext(b, "grass", med.buffer(-0.25, quad_segs=Q), 0, 0.2)
    paint(b, [ave.offset_curve(d) for d in (5.5, -5.5)], "paint_white", 0.12, T, rua.buffer(4.0, cap_style=2), dashed=True)
    paint(b, [rua], "paint_yellow", 0.15, T, ave.buffer(9.5, cap_style=2), dashed=True)
    zebra(b, (10.6, 0), 90, 7.0, 2.4)
    traffic_light(b, 10.0, -4.0, -90)
    traffic_light(b, -10.6, 4.0, 90)
    b.palm(0, -8, 7.0, (0.2, 0.1), y=0.2)
    b.palm(0, 8, 7.2, (-0.2, 0.1), y=0.2)
    lamp(b, -10.8, -6, 90, h=8)
    for s in "NS":
        connector(b, "Avenida", s, W, D)
    connector(b, "Rua", "E", W, D)
    return b


def ave_kurve():
    b = B(404)
    W, D = 36, 36
    pts = [(0, 20)] + [(18 + 18 * np.cos(a), 18 + 18 * np.sin(a)) for a in np.linspace(np.pi, 1.5 * np.pi, 13)] + [(20, 0)]
    ln = [LineString(pts)]
    streets(b, ln, W, D, **AVE)
    ave_markings(b, ln, W, D)
    for a in np.linspace(np.pi * 1.08, np.pi * 1.42, 3):
        b.palm(18 + 18 * np.cos(a), 18 + 18 * np.sin(a), 7.0, (0.1, 0.1), y=0.2)
    for a in np.linspace(np.pi * 1.1, np.pi * 1.4, 3):
        x, z = 18 + 29.2 * np.cos(a), 18 + 29.2 * np.sin(a)
        lamp(b, x, z, np.degrees(np.arctan2(18 - x, 18 - z)), h=8)
    for s in "SE":
        connector(b, "Avenida", s, W, D)
    return b


def kreisverkehr():
    """Roundabout with 4 Rua arms and a fountain."""
    b = B(405)
    W, D = 36, 36
    T = tile_box(W, D)
    arms = [L((0, 0), (0, 20)), L((0, 0), (0, -20)), L((0, 0), (20, 0)), L((0, 0), (-20, 0))]
    ring_out = Point(0, 0).buffer(13, quad_segs=6)
    island = Point(0, 0).buffer(6, quad_segs=6)
    road = closing(unary_union([a.buffer(3.5, cap_style=2) for a in arms] + [ring_out]), 3.0).intersection(T).difference(island)
    walk = closing(unary_union([a.buffer(6, cap_style=2) for a in arms] + [Point(0, 0).buffer(15.5, quad_segs=6)]), 3.0).intersection(T)
    walk = walk.difference(road).difference(island)
    curb = road.buffer(0.22, quad_segs=Q).intersection(walk)
    ext(b, "road_asphalt", road, -0.1, 0)
    ext(b, "sidewalk", walk.difference(curb), -0.1, 0.15)
    ext(b, "curb", curb, -0.1, 0.17)
    ext(b, "curb", island, 0, 0.25)
    ext(b, "grass", island.buffer(-0.35, quad_segs=6), 0, 0.28)
    b.cyl("stone_white", 2.4, 0.6, (0, 0.55, 0), 12)
    b.cyl("pool", 2.1, 0.05, (0, 0.86, 0), 12)
    b.cyl("stone_white", 0.4, 1.4, (0, 1.3, 0), 8)
    b.cyl("pool", 0.25, 0.8, (0, 2.3, 0), 8)
    for a in np.linspace(0, 2 * np.pi, 5)[:-1] + np.pi / 4:
        b.palm(4.2 * np.cos(a), 4.2 * np.sin(a), 6.0, (0.3 * np.cos(a), 0.3 * np.sin(a)), y=0.28)
    ring_c = LineString([(9.5 * np.cos(a), 9.5 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 33)])
    paint(b, [ring_c], "paint_white", 0.12, T, unary_union([a.buffer(3.6, cap_style=2).difference(Point(0, 0).buffer(13.2)) for a in arms]).buffer(0.1), dashed=True, dash=2.0, gap=2.0)
    for (cx, cz, ang) in [(0, 15.5, 0), (0, -15.5, 0), (15.5, 0, 90), (-15.5, 0, 90)]:
        zebra(b, (cx, cz), ang, 7.0, 1.8)
    for (x, z, f) in [(-11.6, -11.6, 45), (11.6, -11.6, -45), (-11.6, 11.6, 135), (11.6, 11.6, -135)]:
        lamp(b, x, z, f, h=7)
    for s in "NSEW":
        connector(b, "Rua", s, W, D)
    return b


def copacabana():
    """Avenida + Calçadão with the black/white wave pavement + beach."""
    b = B(406)
    W, D = 36, 24
    T = tile_box(W, D)
    ax = -6.0                                                                         # avenue centre x
    ln = [L((ax, -14), (ax, 14))]
    road = ln[0].buffer(9, cap_style=2).intersection(T)
    walk_city = sbox(-18, -12, -15, 12)
    ext(b, "road_asphalt", road, -0.1, 0)
    ext(b, "sidewalk", walk_city.difference(sbox(-15.22, -12, -15, 12)), -0.1, 0.15)
    ext(b, "curb", sbox(-15.22, -12, -15, 12), -0.1, 0.17)
    ext(b, "curb", sbox(3, -12, 3.22, 12), -0.1, 0.17)
    med = ln[0].buffer(2.0, cap_style=2).intersection(T)
    ext(b, "curb", med, 0, 0.18)
    ext(b, "grass", med.buffer(-0.25), 0, 0.2)
    paint(b, [ln[0].offset_curve(d) for d in (5.5, -5.5)], "paint_white", 0.12, T, dashed=True)
    # calçadão with waves (x 3.22 .. 11)
    cal = sbox(3.22, -12, 11.0, 12)
    ext(b, "calcadao_white", cal, -0.1, 0.15)
    zz = np.linspace(-12, 12, 41)
    for k in range(3):
        c0 = 4.6 + k * 2.3
        left = [(c0 + 0.55 * np.sin(z * 2 * np.pi / 6.0), z) for z in zz]
        right = [(c0 + 0.9 + 0.55 * np.sin(z * 2 * np.pi / 6.0), z) for z in zz[::-1]]
        ext(b, "calcadao_black", Polygon(left + right).intersection(cal), 0.15, 0.16)
    # sea wall step + beach
    ext(b, "sea_wall", sbox(11.0, -12, 11.4, 12), -0.6, 0.15)
    ext(b, "sand", sbox(11.4, -12, 18, 12), -0.6, -0.45)
    for z in (-7.0, 6.0):
        b.palm(9.6, z, 7.5, (0.4, 0.1), y=0.15)
    # kiosk (quiosque) on the calçadão
    kz = 0.0
    b.cyl("hedge", 1.4, 2.4, (8.0, 0.15 + 1.2, kz), 8)
    b.cyl("paint_white", 2.4, 0.2, (8.0, 2.65, kz), 8)
    b.hull("cloth_green", [(8.0 + 2.4 * np.cos(a), 2.75, kz + 2.4 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] + [(8.0, 3.5, kz)])
    for (x, z) in [(5.5, -2.5), (5.5, 2.5)]:
        b.table(x, 0.15, z, "plastic_white", 0.7)
        b.parasol(x, 0.15, z, "parasol", 1.2, 2.4)
    for z in (-4.0, 4.0):                                                               # beach umbrellas
        b.parasol(14.5, -0.45, z, "cloth_yellow" if z < 0 else "cloth_red", 1.3, 2.3)
    for (x, z, f) in [(-16.8, -6, 90), (4.0, 6, -90), (-16.8, 6, 90)]:
        lamp(b, x, z, f, h=8)
    b.palm(ax, -5, 7.0, (0.1, 0.1), y=0.2)
    b.palm(ax, 7, 7.3, (-0.1, 0.1), y=0.2)
    b.anchor("Anschluss_Avenida_N", (ax, 0, -D / 2), 180)
    b.anchor("Anschluss_Avenida_S", (ax, 0, D / 2), 0)
    b.anchor("Strand", (14.5, -0.45, 0), 90)
    return b


# ================================================================== FAVELA
def beco():
    b = B(501)
    W, D = 4, 12
    ext(b, "beco_concrete", sbox(-1.5, -6, 1.5, 6), -0.1, 0.05)
    ext(b, "gutter", sbox(-0.12, -6, 0.12, 6), 0.0, 0.055)
    for z in (-3.0, 3.0):
        b.box("metal", (0.4, 0.02, 0.5), (0, 0.065, z))
    b.anchor("Anschluss_Beco_N", (0, 0.05, -D / 2), 180)
    b.anchor("Anschluss_Beco_S", (0, 0.05, D / 2), 0)
    return b


def escadaria():
    """Favela stairs, +4 m over 12 m, coloured risers + handrail."""
    b = B(502)
    W, D = 4, 12
    n, run = 20, 0.6
    rise = 4.0 / n
    cols = ["cloth_yellow", "plaster_up", "cloth_red", "plaster_blue", "cloth_green", "plaster_pink"]
    for i in range(n):
        top = (i + 1) * rise
        z1 = D / 2 - i * run
        b.box("beco_concrete", (3.0, top - 0.04, run), (0, (top - 0.04) / 2, z1 - run / 2))
        b.box(cols[i % 6], (3.0, rise, 0.04), (0, top - rise / 2, z1 - 0.02))
        b.box("curb", (3.02, 0.04, run), (0, top - 0.02, z1 - run / 2))
    for x in (-1.45,):
        pts = [(x, 1.0 + 0.2, D / 2 - 0.3), (x, 4.0 + 1.0, -D / 2 + 0.3)]
        b.beam("metal", pts[0], pts[1], 0.05)
        for k in range(5):
            f = k / 4
            z = D / 2 - 0.3 - f * (D - 0.6)
            y = (D / 2 - z) / D * 4.0
            b.beam("metal", (x, y + 0.05, z), (x, y + 1.0, z), 0.04)
    b.anchor("Anschluss_Beco_S", (0, 0.0, D / 2), 0)
    b.anchor("Anschluss_Beco_N", (0, 4.0, -D / 2), 180)
    return b


def beco_gabelung():
    b = B(503)
    W, D = 12, 12
    T = tile_box(W, D)
    ln = [L((0, -8), (0, 8)), L((0, 0), (8, 0))]
    path = closing(unary_union([l.buffer(1.5, cap_style=2) for l in ln]), 0.8).intersection(T)
    ext(b, "beco_concrete", path, -0.1, 0.05)
    gut = unary_union([l.buffer(0.12, cap_style=2) for l in ln]).intersection(T)
    ext(b, "gutter", gut, 0.0, 0.055)
    b.box("metal", (0.5, 0.02, 0.5), (0, 0.065, 0))
    b.anchor("Anschluss_Beco_N", (0, 0.05, -D / 2), 180)
    b.anchor("Anschluss_Beco_S", (0, 0.05, D / 2), 0)
    b.anchor("Anschluss_Beco_E", (W / 2, 0.05, 0), 90)
    return b


def hangstrasse():
    """Steep, worn favela road (Rua cross-section): patches, potholes, faded paint, +4 m."""
    b = B(504)
    r = b.rng
    W, D = 12, 24
    ln = [L((0, -14), (0, 14))]
    streets(b, ln, W, D, walk_mat="beco_concrete", **RUA)
    T = tile_box(W, D)
    for _ in range(7):                                                                # asphalt patches
        cx, cz = r.uniform(-2.5, 2.5), r.uniform(-10, 10)
        poly = Polygon([(cx + r.uniform(0.6, 1.6) * np.cos(a), cz + r.uniform(0.6, 1.6) * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 7)[:-1]])
        ext(b, "road_patch", poly.intersection(ln[0].buffer(3.4)), 0.0, 0.01)
    for _ in range(5):                                                                # potholes
        b.cyl("tunnel_dark", r.uniform(0.25, 0.45), 0.012, (r.uniform(-2.8, 2.8), 0.008, r.uniform(-11, 11)), 7)
    paint(b, ln, "paint_yellow", 0.12, T, dashed=True, dash=1.5, gap=5.0)
    ext(b, "gutter", unary_union([ln[0].offset_curve(d).buffer(0.2, cap_style=2) for d in (3.25, -3.25)]).intersection(T), 0.0, 0.01)
    b.cyl("wood_dark", 0.12, 7.0, (-5.3, 0.15 + 3.5, 2.0), 6)                        # wooden pole with lamp
    b.box("wood_dark", (1.4, 0.1, 0.1), (-4.7, 6.9, 2.0))
    b.box("lamp", (0.3, 0.12, 0.2), (-4.1, 6.82, 2.0))
    b.tire((5.0, 0.25, -6.0))
    b.cyl("tank", 0.3, 0.8, (5.2, 0.55, 8.0), 8)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    embankment(b, W, D, 4.0, "rock")
    shear_z(b, 4.0, D)
    return b


# ================================================================== SPEZIAL
def viadukt():
    """Elevated Rua deck at +6 m on pillars (free space below for a crossing street)."""
    b = B(601)
    W, D, H = 12, 24, 6.0
    b.box("concrete", (W, 0.8, D), (0, H - 0.4 - 0.1, 0))
    b.box("road_asphalt", (7.0, 0.1, D), (0, H - 0.05, 0))
    for sx in (-1, 1):
        b.box("sidewalk", (2.5, 0.25, D), (sx * 4.75, H + 0.025, 0))
        b.box("curb", (0.22, 0.27, D), (sx * 3.61, H + 0.035, 0))
        b.box("concrete", (0.3, 1.0, D), (sx * 5.85, H + 0.65, 0))
    paint_lines = [L((0, -12), (0, 12))]
    T = tile_box(W, D)
    for ms in []:
        pass
    sub = B(0)
    paint(sub, paint_lines, "paint_yellow", 0.15, T, dashed=True)
    paint(sub, [l.offset_curve(d) for l in paint_lines for d in (3.15, -3.15)], "paint_white", 0.12, T)
    for k, ms in sub.parts.items():
        for m in ms:
            m.apply_translation((0, H, 0))
            b.add(k, m)
    for z in (-6.0, 6.0):
        b.box("concrete", (8.0, 0.9, 1.6), (0, H - 1.25, z))
        for x in (-2.8, 2.8):
            b.cyl("concrete", 0.6, H - 1.7, (x, (H - 1.7) / 2, z), 10)
    for z in (-6.0, 6.0):
        lamp(b, -5.4, z, 90, y=H + 0.15, h=5.5)
    for s in "NS":
        connector(b, "Rua", s, W, D, y=H)
    b.anchor("Unterfahrt", (0, 0, 0), 90)
    return b


def tunnel():
    """Tunnel portal into a rocky hill (Rio style). South half open road, north half inside the hill."""
    b = B(602)
    W, D = 12, 24
    ln = [L((0, -14), (0, 14))]
    T = tile_box(W, D)
    streets(b, ln, W, D, **RUA)
    rua_markings(b, ln, W, D)
    PZ = 0.0
    # tunnel tube (inside, north half)
    for sx in (-1, 1):
        b.box("tunnel_dark", (0.6, 6.4, 12), (sx * 5.7, 3.2, -6.0))
    b.box("tunnel_dark", (12, 0.4, 12), (0, 6.6, -6.0))
    for z in (-2.0, -6.0, -10.0):
        b.box("lamp", (1.2, 0.06, 0.25), (0, 6.37, z))
    # portal face with round arch (opening 10 m)
    for sx in (-1, 1):
        b.box("concrete", (1.0, 9.0, 1.0), (sx * 5.5, 4.5, PZ - 0.5))
    b.box("concrete", (12.0, 1.0, 1.0), (0, 8.5, PZ - 0.5))
    b.arch_spandrel("concrete", "z+", PZ - 1.0, 0, 3.0, 5.0, 8.0, 0.0, 1.0)
    b.box("frame_black", (12.0, 0.3, 1.1), (0, 9.0, PZ - 0.5))
    # rocky hill (stays inside the tile)
    r = b.rng
    pts = []
    for x in np.linspace(-6, 6, 5):
        for z in np.linspace(-12, PZ - 0.8, 4):
            pts.append((np.clip(x + r.uniform(-0.4, 0.4), -6, 6), 9.5 + 2.5 * (1 - abs(x) / 8) + r.uniform(-0.8, 0.8) - 0.12 * (z - PZ), z))
    pts += [(-6, 0, -12), (6, 0, -12), (-6, 0, PZ - 0.8), (6, 0, PZ - 0.8)]
    b.add("rock", trimesh.convex.convex_hull(np.array(pts)))
    for (x, z, s) in [(-3.5, -4.0, 1.5), (3.0, -8.0, 1.8), (0.0, -10.5, 1.3)]:
        b.rock("plant", s, (x, 11.8 - 0.12 * (z - PZ), z), 0.7)
    lamp(b, -5.4, 6.0, 90)
    b.anchor("Tunnel_Eingang", (0, 0, PZ), 0)
    for s in "NS":
        connector(b, "Rua", s, W, D)
    return b


ROADS = [
    ("01_rua_gerade", "Rua – Gerade", "Rua", rua_gerade, (12, 12)),
    ("02_rua_kurve", "Rua – Kurve", "Rua", rua_kurve, (12, 12)),
    ("03_rua_t", "Rua – T-Kreuzung", "Rua", rua_t, (12, 12)),
    ("04_rua_kreuzung", "Rua – Kreuzung", "Rua", rua_kreuzung, (12, 12)),
    ("05_rua_sackgasse", "Rua – Wendehammer", "Rua", rua_sackgasse, (18, 20)),
    ("06_rua_steigung", "Rua – Steigung +3 m", "Rua", rua_steigung, (12, 24)),
    ("07_rua_bushaltestelle", "Rua – Bushaltestelle", "Rua", rua_bushaltestelle, (12, 24)),
    ("08_rua_kopfstein", "Rua – Kopfstein + Bonde", "Rua", rua_kopfstein, (12, 12)),
    ("09_avenida_gerade", "Avenida – Gerade", "Avenida", ave_gerade, (24, 24)),
    ("10_avenida_kreuzung", "Avenida – Kreuzung", "Avenida", ave_kreuzung, (24, 24)),
    ("11_avenida_einmuendung", "Avenida – Einmündung Rua", "Avenida", ave_einmuendung, (24, 24)),
    ("12_avenida_kurve", "Avenida – Kurve", "Avenida", ave_kurve, (36, 36)),
    ("13_kreisverkehr", "Kreisverkehr", "Avenida", kreisverkehr, (36, 36)),
    ("14_copacabana", "Copacabana-Promenade", "Avenida", copacabana, (36, 24)),
    ("15_beco", "Beco – Gasse", "Favela", beco, (4, 12)),
    ("16_escadaria", "Escadaria – Treppe +4 m", "Favela", escadaria, (4, 12)),
    ("17_beco_gabelung", "Beco – Gabelung", "Favela", beco_gabelung, (12, 12)),
    ("18_hangstrasse", "Favela-Hangstraße +4 m", "Favela", hangstrasse, (12, 24)),
    ("19_viadukt", "Viadukt (+6 m)", "Spezial", viadukt, (12, 24)),
    ("20_tunnel", "Tunnel-Einfahrt", "Spezial", tunnel, (12, 24)),
]
