"""Esmeralda Joias – edler Juwelier (fiktiv) mit Sicherheitsschleuse, Vitrinen, Tresorraum.
Grundstück 12 x 22 m (inkl. 2 m Gehweg). Front +Z.
Ebenen (Nodes): Aussen (Fassade, Gehweg, Wände EG), EG (Verkaufsraum + Personalbereich), OG (Decke EG, Kronleuchter,
Werkstatt, Überwachungsraum, Büro, obere Wände), UG (Tresorraum, Lager), Dach.
Eigene Nodes zum Animieren/Zerstören: Vitrine_1..6 (Glashauben), Tuer_Aussen/Tuer_Innen (Schiebetüren der Schleuse),
Tresortuer (Drehpunkt = Scharnier)."""
import numpy as np
import trimesh
from lib import B, PALETTE

PALETTE.update({
    "marble_white": "#EEEAE2", "marble_green": "#1F4D3A", "marble_dark": "#2B2B2E", "brass": "#C9A23A",
    "velvet_blue": "#1E2A4A", "velvet_red": "#7A1631", "lacquer": "#17171A", "cream": "#E9E1D0",
    "gem_green": "#2ECC71", "gem_red": "#E0115F", "gem_blue": "#2F6FE0", "diamond": "#E6F4FF", "silver": "#C9CED6",
    "vault_steel": "#8E959C", "gold_bar": "#D4AF37", "stone_cream": "#DCCFB4", "carpet": "#5A1E2A",
})
for k, v in {"gold": "#C9A23A", "screen": "#2FE0F0", "glass_shop": "#9FC3D6", "chrome": "#C9CED6"}.items():
    PALETTE.setdefault(k, v)

X0, X1, Z0, Z1 = -6.0, 6.0, -10.0, 10.0
T = 0.25
IX0, IX1, IZ0, IZ1 = X0 + T, X1 - T, Z0 + T, Z1 - T
UF = -3.25          # UG floor top
F = 0.15            # EG floor top
C = 3.8             # EG ceiling
O = 4.1             # OG floor top
OC = 7.2            # OG ceiling / roof bottom
SP = (4.3, -8.2)    # spiral stair centre
GEMS = ["gem_green", "gem_red", "gem_blue", "diamond"]


def juwelier():
    b = B(1968)
    rng = np.random.default_rng(1968)

    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def wall_x(mat, z, x0, x1, y0, y1, holes=(), t=T):
        z0, z1 = z - t / 2, z + t / 2
        xs = [x0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [x1]
        for a, c in zip(xs[0::2], xs[1::2]):
            if c - a > 1e-3:
                box(mat, a, c, y0, y1, z0, z1)
        for (xa, xb, ya, yb) in holes:
            if ya > y0:
                box(mat, xa, xb, y0, ya, z0, z1)
            if yb < y1:
                box(mat, xa, xb, yb, y1, z0, z1)

    def wall_z(mat, x, z0, z1, y0, y1, holes=(), t=T):
        x0, x1 = x - t / 2, x + t / 2
        zs = [z0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [z1]
        for a, c in zip(zs[0::2], zs[1::2]):
            if c - a > 1e-3:
                box(mat, x0, x1, y0, y1, a, c)
        for (za, zb, ya, yb) in holes:
            if ya > y0:
                box(mat, x0, x1, y0, ya, za, zb)
            if yb < y1:
                box(mat, x0, x1, yb, y1, za, zb)

    def slab(mat, y0, y1, hole=None):
        """Floor slab over the inner footprint, optionally with a rectangular hole (x0, x1, z0, z1)."""
        if not hole:
            box(mat, IX0, IX1, y0, y1, IZ0, IZ1)
            return
        hx0, hx1, hz0, hz1 = hole
        box(mat, IX0, hx0, y0, y1, IZ0, IZ1)
        box(mat, hx1, IX1, y0, y1, IZ0, IZ1) if hx1 < IX1 else None
        box(mat, hx0, hx1, y0, y1, hz1, IZ1)
        box(mat, hx0, hx1, y0, y1, IZ0, hz0) if hz0 > IZ0 else None

    # --- jewellery helpers -------------------------------------------------------------
    def octa(r):
        return trimesh.convex.convex_hull(np.array([(r, 0, 0), (-r, 0, 0), (0, r * 1.3, 0), (0, -r * 1.3, 0), (0, 0, r), (0, 0, -r)]))
    def ring(x, y, z, gem=None, rot=0.0):
        m = trimesh.creation.annulus(r_min=0.026, r_max=0.036, height=0.012, sections=6)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(rot), [0, 1, 0]))
        b.add("gold" if rng.random() < 0.7 else "silver", m.apply_translation((x, y + 0.036, z)))
        b.add(gem or GEMS[int(rng.integers(0, 4))], octa(0.015).apply_translation((x, y + 0.078, z)))

    def watch(x, y, z, rot=0.0):
        b.box("lacquer" if rng.random() < 0.5 else "silver", (0.04, 0.012, 0.2), (x, y + 0.006, z), rot_y=rot)
        b.cyl("gold" if rng.random() < 0.5 else "silver", 0.03, 0.016, (x, y + 0.018, z), 6)

    def bust(x, y, z, rot=0.0, gem=None):
        r = np.radians(rot)
        def P(dx, yy, dz):
            return (x + dx * np.cos(r) + dz * np.sin(r), y + yy, z - dx * np.sin(r) + dz * np.cos(r))
        b.hull("velvet_blue", [P(sx * 0.16, 0.0, sz * 0.08) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.12, 0.22, sz * 0.06) for sx in (-1, 1) for sz in (-1, 1)])
        b.hull("velvet_blue", [P(sx * 0.045, 0.22, sz * 0.045) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.04, 0.4, sz * 0.04) for sx in (-1, 1) for sz in (-1, 1)])
        m = trimesh.creation.torus(major_radius=0.07, minor_radius=0.008, major_sections=10, minor_sections=3)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2 - 0.5, [1, 0, 0]))
        m.apply_transform(trimesh.transformations.rotation_matrix(r, [0, 1, 0]))
        b.add("gold", m.apply_translation(P(0, 0.25, 0.015)))
        b.add(gem or GEMS[int(rng.integers(0, 4))], octa(0.03).apply_translation(P(0, 0.17, 0.075)))

    def tray_fill(x0, x1, z0, z1, y, kind="mix"):
        box("velvet_blue", x0, x1, y, y + 0.02, z0, z1)
        for x in np.arange(x0 + 0.12, x1 - 0.05, 0.22):
            for z in np.arange(z0 + 0.12, z1 - 0.05, 0.22):
                k = rng.random()
                if kind == "watch" or (kind == "mix" and k < 0.25):
                    watch(x, y + 0.02, z, rng.uniform(-10, 10))
                else:
                    ring(x, y + 0.02, z, rot=rng.uniform(0, 180))

    def vitrine(n, x, z, w=1.6, d=0.7, rot=0.0):
        """Island showcase: lacquered base + brass trim (EG); glass hood = own node Vitrine_n."""
        sw, sd = (w, d) if rot == 0 else (d, w)
        box("lacquer", x - sw / 2, x + sw / 2, F, F + 0.85, z - sd / 2, z + sd / 2)
        box("brass", x - sw / 2 - 0.01, x + sw / 2 + 0.01, F + 0.85, F + 0.9, z - sd / 2 - 0.01, z + sd / 2 + 0.01)
        box("brass", x - sw / 2 + 0.05, x + sw / 2 - 0.05, F, F + 0.05, z - sd / 2 + 0.05, z + sd / 2 - 0.05)
        tray_fill(x - sw / 2 + 0.06, x + sw / 2 - 0.06, z - sd / 2 + 0.06, z + sd / 2 - 0.06, F + 0.9, "watch" if n % 3 == 0 else "mix")
        prev = b.layer
        name = f"Vitrine_{n}"
        b.layer = name
        b.pivots[name] = (x, F + 1.15, z)
        box("glass_shop", x - sw / 2, x + sw / 2, F + 0.9, F + 1.4, z - sd / 2, z + sd / 2)
        for (a, c) in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
            box("brass", x + a * sw / 2 - 0.015, x + a * sw / 2 + 0.015, F + 0.9, F + 1.42, z + c * sd / 2 - 0.015, z + c * sd / 2 + 0.015)
        box("brass", x - sw / 2, x + sw / 2, F + 1.4, F + 1.43, z - sd / 2, z + sd / 2)
        b.layer = prev
        b.anchor(name, (x, F, z), rot)

    # =================================================================
    # AUSSEN – facade, sidewalk with bollards, EG walls, alarm box, back door
    # =================================================================
    b.layer = "Aussen"
    box("concrete", X0, X1, 0, 0.15, Z1, Z1 + 2.0)
    box("concrete_dk", X0, X1, 0, 0.18, Z1 + 1.8, Z1 + 2.0)
    for x in (-4.5, -2.0, 2.0, 4.5):                                                     # anti-ram bollards
        b.cyl("lacquer", 0.12, 0.9, (x, 0.6, Z1 + 1.35), 10)
        b.cyl("brass", 0.13, 0.06, (x, 0.95, Z1 + 1.35), 10)
    win = [(-5.4, -1.8, 0.6, 3.2), (1.8, 5.4, 0.6, 3.2)]
    door = (-1.1, 1.1, F, 2.8)
    wall_x("marble_green", IZ1 + T / 2, X0, X1, 0, 3.2, win + [door])
    box("marble_green", X0, X1, 0, 0.6, Z1, Z1 + 0.05)
    box("lacquer", X0, X1, 3.2, 3.8, IZ1, Z1 + 0.12)                                     # sign band
    box("brass", X0, X1, 3.78, 3.84, IZ1, Z1 + 0.16)
    box("brass", X0, X1, 3.16, 3.22, IZ1, Z1 + 0.16)
    b.text("ESMERALDA", ["brass"] * 9, (-0.4, 3.5, Z1 + 0.12), 0.42, 0.04, simplify=0.008)
    b.text("JOIAS", ["gold"] * 5, (3.7, 3.5, Z1 + 0.12), 0.26, 0.03, simplify=0.006)
    g = trimesh.creation.icosphere(subdivisions=0, radius=0.22)
    g.apply_scale((1.0, 1.3, 0.5))
    b.add("gem_green", g.apply_translation((-3.6, 3.5, Z1 + 0.2)))
    for (x0, x1, y0, y1) in win + [door]:                                                # brass frames
        for (a, c, ya, yb) in [(x0 - 0.08, x0, y0, y1), (x1, x1 + 0.08, y0, y1), (x0 - 0.08, x1 + 0.08, y1, y1 + 0.08)]:
            box("brass", a, c, ya, yb, Z1 - 0.02, Z1 + 0.06)
    for (x0, x1, y0, y1) in win:
        box("glass_shop", x0, x1, y0, y1, IZ1 + 0.05, IZ1 + 0.09)
        box("brass", x0 - 0.08, x1 + 0.08, y0 - 0.08, y0, Z1 - 0.02, Z1 + 0.1)
        b.text("JOIAS · RELÓGIOS · DESDE 1968", ["gold"] * 29, ((x0 + x1) / 2, 0.38, Z1 + 0.06), 0.1, 0.01, simplify=0.004) if x0 < 0 else None
    for x in (-5.75, 5.75):                                                              # brass wall lamps
        box("brass", x - 0.1, x + 0.1, 2.4, 2.9, Z1 + 0.05, Z1 + 0.25)
        box("lamp", x - 0.07, x + 0.07, 2.45, 2.85, Z1 + 0.25, Z1 + 0.27)
    for x in (-1.6, 1.6):                                                                # planters with topiary
        box("lacquer", x - 0.25, x + 0.25, 0.15, 0.75, Z1 + 0.3, Z1 + 0.8)
        b.rock("hedge", 0.33, (x, 1.05, Z1 + 0.55), 1.0)
    box("lacquer", 5.2, 5.6, 2.9, 3.1, Z1 + 0.06, Z1 + 0.16)                             # facade camera
    b.cyl("glass", 0.05, 0.08, (5.4, 2.95, Z1 + 0.2), 8)
    # EG side/back walls, back door
    for x in (X0 + T / 2, X1 - T / 2):
        box("stone_cream", x - T / 2, x + T / 2, 0, O, Z0, IZ1)
    wall_x("stone_cream", Z0 + T / 2, X0 + T, X1 - T, 0, O, [(-2.6, -1.4, F, 2.3)])
    box("door_metal", -2.6, -1.4, F, 2.3, Z0, Z0 + 0.06)
    box("frame_black", -1.25, -1.05, 1.2, 1.5, Z0 - 0.05, Z0)                            # keypad
    box("frame_black", -3.2, -2.8, 2.6, 2.8, Z0 - 0.12, Z0)                              # back camera
    box("meter", 3.5, 4.1, 1.2, 1.9, Z0 - 0.15, Z0)
    box("frame_black", 3.75, 3.85, 1.9, O, Z0 - 0.08, Z0)
    b.anchor("Strom_Anschluss", (3.8, O, Z0 - 0.04), 180)
    b.anchor("Hintereingang", (-2.0, 0.0, Z0 - 0.8), 180)

    # =================================================================
    # EG – sales floor, airlock, vitrines, counter, staff zone
    # =================================================================
    b.layer = "EG"
    slab("marble_white", -0.25, F, hole=(3.0, 5.6, -9.5, -6.9))
    for (x0, x1, z0, z1) in [(-5.2, 5.2, -4.4, -4.25), (-5.2, 5.2, 7.2, 7.35), (-5.2, -5.05, -4.4, 7.35), (5.05, 5.2, -4.4, 7.35)]:
        box("marble_dark", x0, x1, F, F + 0.003, z0, z1)                                 # floor inlay
    box("carpet", -1.8, 1.8, F, F + 0.01, -2.4, 3.2)
    for x0, x1 in ((IX0, IX0 + 0.03), (IX1 - 0.03, IX1)):
        box("cream", x0, x1, F, C, -5.0, IZ1)
    # airlock: glass vestibule, metal detector, two sliding doors (own nodes)
    for x in (-1.2, 1.2):
        box("glass_shop", x - 0.03, x + 0.03, F, 2.8, 7.4, IZ1)
        box("brass", x - 0.05, x + 0.05, 2.8, 2.9, 7.4, IZ1)
    box("cream", -1.25, 1.25, 2.8, C, 7.35, 7.45)
    box("vault_steel", -0.6, -0.5, F, 2.3, 8.5, 8.7)
    box("vault_steel", 0.5, 0.6, F, 2.3, 8.5, 8.7)
    box("vault_steel", -0.6, 0.6, 2.2, 2.4, 8.5, 8.7)
    box("led_green", -0.15, 0.15, 2.25, 2.35, 8.7, 8.71)
    for name, z in (("Tuer_Aussen", IZ1 + 0.02), ("Tuer_Innen", 7.4)):
        b.layer = name
        b.pivots[name] = (0.0, F, z)
        box("glass_shop", -1.05, 1.05, F, 2.75, z - 0.03, z + 0.03)
        box("brass", -1.05, 1.05, F, F + 0.08, z - 0.04, z + 0.04)
        box("brass", -0.02, 0.02, 1.0, 1.4, z - 0.06, z + 0.06)
        b.layer = "EG"
    b.anchor("Eingang", (0.0, 0.0, Z1 + 1.0), 0)
    b.anchor("Schleuse", (0.0, F, 8.6), 0)
    # window displays
    for (x0, x1) in ((-5.4, -1.8), (1.8, 5.4)):
        box("velvet_red", x0, x1, F, 0.6, 8.7, IZ1)
        box("velvet_red", x0, x1, F, 1.9, 8.6, 8.7)
        for k, x in enumerate(np.linspace(x0 + 0.6, x1 - 0.6, 3)):
            h = 0.25 if k == 1 else 0.0
            box("velvet_blue", x - 0.3, x + 0.3, 0.6, 0.6 + h, 9.0, 9.5)
            bust(x, 0.6 + h, 9.25, 0.0)
        for x in np.linspace(x0 + 0.3, x1 - 0.3, 6):
            ring(x, 0.6, 9.62)
    # wall cabinets (both sides), backlit
    for s in (-1, 1):
        xw = s * (IX1 - 0.03)
        xi = xw - s * 0.5
        a, c = sorted((xw, xi))
        box("lacquer", a, c, F, 0.95, -3.6, 6.8)
        box("velvet_blue", s * IX1 - s * 0.05 - 0.01, s * IX1 - s * 0.05 + 0.01, 0.95, 2.45, -3.6, 6.8)
        box("glass_shop", xi - 0.02, xi + 0.02, 0.95, 2.45, -3.6, 6.8)
        box("lacquer", a, c, 2.45, 2.7, -3.6, 6.8)
        box("brass", a, c, 2.7, 2.74, -3.6, 6.8)
        for z in np.arange(-3.6, 6.85, 2.08):
            box("brass", xi - 0.025, xi + 0.025, 0.95, 2.45, z - 0.02, z + 0.02)
        for y in (1.25, 1.65, 2.05):
            box("glass", a, c, y - 0.01, y, -3.6, 6.8)
            box("lamp", s * IX1 - s * 0.1 - 0.02, s * IX1 - s * 0.1 + 0.02, y + 0.33, y + 0.35, -3.5, 6.7)
            for z in np.arange(-3.3, 6.6, 0.6):
                k = rng.random()
                xx = (a + c) / 2
                if k < 0.4:
                    ring(xx, y, z)
                elif k < 0.7:
                    watch(xx, y, z, 90)
                else:
                    b.cyl("velvet_blue", 0.05, 0.15, (xx, y + 0.075, z), 6)
                    ring(xx, y + 0.12, z, rot=90)
    # island vitrines + sales counter (counter glass = vitrines 4..6)
    vitrine(1, 0.0, 4.6)
    vitrine(2, -2.6, 0.8, rot=90)
    vitrine(3, 2.6, 0.8, rot=90)
    for n, x in ((4, -2.4), (5, 0.0), (6, 2.4)):
        vitrine(n, x, -3.0, w=2.3, d=0.75)
    for x in (-2.4, 0.0, 2.4):                                                           # customer chairs
        b.cyl("brass", 0.03, 0.45, (x, F + 0.225, -1.9), 6)
        b.cyl("velvet_red", 0.22, 0.12, (x, F + 0.5, -1.9), 10)
        box("velvet_red", x - 0.2, x + 0.2, F + 0.56, F + 0.95, -1.72, -1.66)
    for x in (-2.0, 0.6):                                                                # card terminal / mirror on the counter
        box("frame_black", x - 0.08, x + 0.08, F + 1.43, F + 1.5, -3.2, -3.0)
    b.box("mirror" if "mirror" in PALETTE else "glass", (0.35, 0.45, 0.03), (1.4, F + 1.66, -3.15), rot_x=-12)
    wall_x("cream", -5.0, IX0, IX1, F, C, [(3.4, 4.4, F, 2.3)], t=0.12)                  # partition to the staff zone
    box("lacquer", -5.6, 3.2, F, 2.6, -4.94, -4.6)                                       # back cabinets (staff side)
    box("brass", -5.6, 3.2, 2.6, 2.64, -4.94, -4.6)
    box("door_wood", 3.4, 4.4, F, 2.3, -5.02, -4.98)
    box("frame_black", 4.55, 4.75, 1.2, 1.5, -4.92, -4.88)                               # keypad
    b.anchor("Theke", (0.0, F, -3.9), 0)
    # VIP corner + guard post
    for z in (5.6, 6.6):
        box("velvet_red", 3.9, 4.6, F, F + 0.45, z - 0.35, z + 0.35)
        box("velvet_red", 4.5, 4.7, F + 0.45, F + 1.0, z - 0.35, z + 0.35)
    b.cyl("brass", 0.3, 0.04, (3.3, F + 0.55, 6.1), 10)
    b.cyl("brass", 0.04, 0.55, (3.3, F + 0.275, 6.1), 6)
    b.cyl("glass", 0.03, 0.3, (3.25, F + 0.72, 6.1), 6)
    box("lacquer", -3.1, -2.4, F, F + 1.1, 6.3, 6.8)                                     # guard podium + stool
    b.cyl("frame_black", 0.18, 0.7, (-2.75, F + 0.35, 5.9), 8)
    b.anchor("Wachmann", (-2.75, F, 6.0), 180)
    for k, (x, z, yaw) in enumerate([(-5.5, 7.0, 135), (5.5, 7.0, -135), (-5.5, -4.6, 45), (5.5, -4.6, -45)]):
        box("cloth_white", x - 0.12, x + 0.12, 3.35, 3.55, z - 0.12, z + 0.12)
        b.box("frame_black", (0.14, 0.14, 0.25), (x, 3.3, z), rot_y=yaw, rot_x=-25)
        b.anchor(f"Kamera_{k + 1}", (x, 3.3, z), yaw)
    # staff zone: lockers, WC, alarm panel, back door
    for k in range(4):
        box("vault_steel", -1.0 + k * 0.55, -0.5 + k * 0.55, F, 1.9, IZ0, IZ0 + 0.5)
        box("frame_black", -0.8 + k * 0.55, -0.7 + k * 0.55, 1.4, 1.5, IZ0 + 0.5, IZ0 + 0.52)
    wall_x("cream", -7.4, IX0, -3.4, F, C, [(-4.6, -3.8, F, 2.2)], t=0.12)
    wall_z("cream", -3.4, IZ0, -7.4, F, C, t=0.12)
    b.cyl("plastic_white", 0.2, 0.45, (-5.2, F + 0.225, -9.3), 10)
    box("frame_black", 0.4, 0.8, 1.3, 1.8, -5.06, -5.04)                                 # alarm panel
    box("led_red", 0.5, 0.6, 1.6, 1.65, -5.08, -5.06)
    b.anchor("Alarm", (0.6, F, -5.6), 0)

    # spiral stair UG → OG (layer by height)
    for k in range(42):
        y = UF + (k + 1) * (O - UF) / 42
        a = np.radians(k * 30.0)
        b.layer = "UG" if y < F + 0.01 else ("EG" if y < O - 0.01 else "OG")
        cx, cz = SP[0] + 0.6 * np.cos(a), SP[1] + 0.6 * np.sin(a)
        b.box("brass" if k % 6 == 0 else "marble_dark", (1.05, 0.06, 0.42), (cx, y - 0.03, cz), rot_y=-np.degrees(a))
    for lay, y0, y1 in (("UG", UF, F), ("EG", F, O), ("OG", O, O + 1.0)):
        b.layer = lay
        b.cyl("brass", 0.08, y1 - y0, (SP[0], (y0 + y1) / 2, SP[1]), 8)
    b.layer = "EG"

    # =================================================================
    # UG – vault room + storage
    # =================================================================
    b.layer = "UG"
    box("concrete", IX0, IX1, UF - 0.15, UF, IZ0, IZ1)
    for x in (X0 + T / 2, X1 - T / 2):
        box("concrete", x - T / 2, x + T / 2, UF - 0.15, 0.0, Z0, Z1)
    for z in (Z0 + T / 2, Z1 - T / 2):
        box("concrete", X0, X1, UF - 0.15, 0.0, z - T / 2, z + T / 2)
    VX, VZ = 1.0, -1.0                                                                  # vault: x IX0..1, z IZ0..-1, 0.6 m walls
    wall_z("vault_steel", VX + 0.3, IZ0, VZ + 0.6, UF, -0.25, [(-6.5, -4.3, UF, UF + 2.3)], t=0.6)
    wall_x("vault_steel", VZ + 0.3, IX0, VX + 0.6, UF, -0.25, t=0.6)
    b.layer = "EG"                                                                      # vault ceiling belongs to the EG floor (hidden in UG view)
    box("vault_steel", IX0, VX + 0.6, -0.85, -0.25, IZ0, VZ + 0.6)
    b.layer = "UG"
    for i in range(9):                                                                   # safe-deposit box wall
        for j in range(5):
            z0 = IZ0 + 0.3 + i * 0.85
            y0 = UF + 0.2 + j * 0.5
            if z0 + 0.8 > VZ:
                continue
            box("vault_steel", IX0, IX0 + 0.45, y0, y0 + 0.46, z0, z0 + 0.81)
            box("brass", IX0 + 0.45, IX0 + 0.47, y0 + 0.2, y0 + 0.26, z0 + 0.36, z0 + 0.45)
    box("lacquer", -2.6, -1.0, UF, UF + 0.9, -6.6, -4.2)                                 # table with gems + gold
    box("velvet_blue", -2.5, -1.1, UF + 0.9, UF + 0.92, -6.5, -4.3)
    for k in range(12):
        g = trimesh.creation.icosphere(subdivisions=0, radius=0.03)
        b.add(GEMS[k % 4], g.apply_translation((-2.4 + (k % 4) * 0.35, UF + 0.95, -6.3 + (k // 4) * 0.5)))
    for st in range(3):                                                                  # gold bar stacks on shelves
        z = -8.6 + st * 1.5
        box("vault_steel", -0.3, 0.7, UF, UF + 0.6, z - 0.5, z + 0.5)
        for layer in range(4):
            for i in range(3):
                for j in range(2):
                    x = -0.1 + i * 0.3 + (0.15 if layer % 2 else 0)
                    zz = z - 0.2 + j * 0.4
                    if x > 0.65:
                        continue
                    b.hull("gold_bar", [(x + dx, UF + 0.6 + layer * 0.07, zz + dz) for dx in (-0.12, 0.12) for dz in (-0.06, 0.06)] +
                           [(x + dx, UF + 0.6 + layer * 0.07 + 0.065, zz + dz) for dx in (-0.1, 0.1) for dz in (-0.045, 0.045)])
    b.anchor("Tresor", (-1.8, UF, -5.4), 90)
    # vault door (own node, hinge at z = -6.5)
    b.layer = "Tresortuer"
    b.pivots["Tresortuer"] = (VX + 0.65, UF + 1.15, -6.5)
    m = trimesh.creation.cylinder(radius=1.15, height=0.5, sections=16)
    m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 0, 1]))
    b.add("vault_steel", m.apply_translation((VX + 0.85, UF + 1.15, -5.4)))
    for k in range(4):
        b.box("chrome", (0.06, 0.06, 0.9), (VX + 1.15, UF + 1.15, -5.4), rot_x=k * 45)
    m = trimesh.creation.cylinder(radius=0.12, height=0.2, sections=8)
    m.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 0, 1]))
    b.add("chrome", m.apply_translation((VX + 1.15, UF + 1.15, -5.4)))
    b.layer = "UG"
    b.anchor("Tresor_Tuer", (VX + 1.4, UF, -5.4), 90)
    box("frame_black", VX + 0.6, VX + 0.7, UF + 1.4, UF + 1.8, -3.9, -3.6)              # keypad + time lock
    # storage + security recorder
    for z in np.arange(1.0, 9.0, 1.9):
        box("shelf", 4.8, IX1, UF, UF + 2.2, z, z + 1.6)
        for y in (UF + 0.5, UF + 1.2, UF + 1.9):
            box("cardboard", 4.9, IX1 - 0.05, y, y + 0.3, z + 0.1, z + 0.7)
            box("cardboard", 4.9, IX1 - 0.05, y, y + 0.25, z + 0.85, z + 1.45)
    box("frame_black", -5.6, -5.0, UF, UF + 1.8, 7.5, 8.3)
    for y in np.arange(UF + 0.3, UF + 1.7, 0.25):
        box("led_green", -5.0, -4.98, y, y + 0.03, 7.6, 7.7)
    b.anchor("Server_Ueberwachung", (-4.7, UF, 7.9), -90)

    # =================================================================
    # OG – EG ceiling + chandelier + spots, workshop, CCTV room, office, upper walls
    # =================================================================
    b.layer = "OG"
    slab("concrete", C, O, hole=(3.0, 5.6, -9.5, -6.9))
    box("cream", IX0, IX1, C - 0.02, C, -5.0, IZ1)
    for x in (-3.5, -1.2, 1.2, 3.5):
        for z in (-3.5, -0.5, 2.5, 5.5):
            b.cyl("lamp", 0.07, 0.02, (x, C - 0.03, z), 8)
    cx, cz = 0.0, 1.2                                                                    # crystal chandelier
    b.beam("brass", (cx, C, cz), (cx, 3.0, cz), 0.02)
    for r, y, n in ((0.55, 2.9, 10), (0.38, 2.7, 8), (0.2, 2.5, 6)):
        t = trimesh.creation.torus(major_radius=r, minor_radius=0.02, major_sections=12, minor_sections=3)
        t.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        b.add("brass", t.apply_translation((cx, y, cz)))
        for k in range(n):
            a = k * 2 * np.pi / n
            g = trimesh.creation.icosphere(subdivisions=0, radius=0.05)
            g.apply_scale((0.6, 1.6, 0.6))
            b.add("diamond", g.apply_translation((cx + r * np.cos(a), y - 0.1, cz + r * np.sin(a))))
    b.cyl("lamp", 0.12, 0.25, (cx, 2.85, cz), 8)
    # upper walls (hide with OG so the shop can be seen from above)
    for x in (X0 + T / 2, X1 - T / 2):
        box("stone_cream", x - T / 2, x + T / 2, O, OC + 0.8, Z0, IZ1)
    box("stone_cream", X0 + T, X1 - T, O, OC + 0.8, Z0, Z0 + T)
    owin = [(x - 0.8, x + 0.8, 5.0, 6.6) for x in (-4.0, 0.0, 4.0)]
    wall_x("stone_cream", IZ1 + T / 2, X0, X1, O, OC + 0.8, owin)
    box("brass", X0, X1, OC + 0.25, OC + 0.4, Z1, Z1 + 0.2)                              # cornice
    for (x0, x1, y0, y1) in owin:
        box("glass", x0, x1, y0, y1, IZ1 + 0.08, IZ1 + 0.12)
        box("stone_cream", x0 - 0.1, x1 + 0.1, y0 - 0.12, y0, Z1, Z1 + 0.12)
        for x in np.arange(x0 + 0.15, x1, 0.22):
            box("frame_black", x, x + 0.025, y0, y1, Z1 + 0.02, Z1 + 0.05)
    box("lighthouse_red" if "lighthouse_red" in PALETTE else "led_red", 4.9, 5.5, 4.6, 5.1, Z1, Z1 + 0.2)   # alarm bell box
    b.text("ALARME", ["paint_white"] * 6, (5.2, 4.85, Z1 + 0.2), 0.1, 0.01, simplify=0.004)
    b.anchor("Alarmglocke", (5.2, 4.85, Z1 + 0.2), 0)
    box("ac", -2.0, -1.0, 6.9, 7.3, Z1, Z1 + 0.45)
    # rooms: partitions
    wall_x("cream", 1.0, IX0, IX1, O, OC, [(-1.0, 0.0, O, O + 2.2), (2.5, 3.5, O, O + 2.2)], t=0.12)
    wall_z("cream", 1.5, 1.0, IZ1, O, OC, [(3.0, 4.0, O, O + 2.2)], t=0.12)
    # goldsmith workshop (front-left)
    for k, x in enumerate((-4.6, -2.6, -0.6)):
        box("wood_a", x - 0.75, x + 0.75, O, O + 0.95, 8.6, 9.5)
        box("wood_dark", x - 0.2, x + 0.2, O + 0.85, O + 0.95, 8.5, 8.7)                # bench pin cut-out
        b.beam("frame_black", (x + 0.5, O + 0.95, 9.4), (x + 0.3, O + 1.6, 9.0), 0.02)
        box("lamp", x + 0.15, x + 0.45, O + 1.55, O + 1.62, 8.85, 9.1)
        b.cyl("frame_black", 0.2, 0.5, (x, O + 0.25, 8.0), 8)
        for t_ in range(4):
            b.box("silver", (0.02, 0.01, 0.16), (x - 0.4 + t_ * 0.08, O + 0.96, 9.2))
        ring(x + 0.1, O + 0.95, 8.95, rot=30)
    box("vault_steel", -5.6, -4.8, O, O + 1.3, 2.0, 2.8)                                 # small safe
    box("frame_black", -4.82, -4.78, O + 0.6, O + 0.8, 2.3, 2.5)
    box("frame_black", -2.0, -1.2, O, O + 0.9, 1.3, 1.9)                                 # polishing machine
    b.cyl("cloth_white", 0.12, 0.05, (-1.6, O + 1.05, 1.6), 10)
    b.anchor("Werkstatt", (-2.6, O, 8.0), 0)
    # CCTV room (front-right)
    box("lacquer", 2.0, 5.6, O, O + 0.75, 8.4, 9.4)
    for i in range(4):
        for j in range(3):
            x = 2.4 + i * 0.85
            y = O + 1.0 + j * 0.55
            box("frame_black", x - 0.4, x + 0.4, y, y + 0.5, 9.5, 9.6)
            box("screen", x - 0.36, x + 0.36, y + 0.04, y + 0.46, 9.48, 9.5)
    for x in (3.0, 4.6):
        b.cyl("frame_black", 0.25, 0.5, (x, O + 0.25, 7.7), 8)
    b.anchor("Ueberwachung", (3.8, O, 7.6), 0)
    # manager office (back-left)
    box("wood_dark", -4.5, -2.0, O, O + 0.78, -7.0, -6.0)
    box("frame_black", -3.5, -2.9, O + 0.78, O + 1.15, -6.9, -6.8)
    b.cyl("velvet_red", 0.3, 0.9, (-3.25, O + 0.45, -7.6), 8)
    box("wood_dark", IX0, IX0 + 0.4, O, O + 2.2, -9.4, -5.0)
    for y in (O + 0.5, O + 1.0, O + 1.5, O + 2.0):
        box("cardboard", IX0 + 0.05, IX0 + 0.35, y - 0.35, y - 0.05, -9.2, -5.3)
    box("vault_steel", -1.6, -0.8, O, O + 1.1, -9.6, -8.9)
    box("gold", -5.7, -5.68, O + 1.2, O + 2.0, -2.0, -0.6)                               # framed picture
    b.anchor("Buero", (-3.25, O, -7.2), 180)

    # =================================================================
    # DACH
    # =================================================================
    b.layer = "Dach"
    box("dach", X0, X1, OC, OC + 0.25, Z0, Z1)
    for (x, z) in [(-3.0, -6.0), (-1.5, -6.0)]:
        box("ac", x - 0.6, x + 0.6, OC + 0.25, OC + 1.1, z - 0.4, z + 0.4)
    b.cyl("tank", 0.55, 1.0, (3.0, OC + 0.75, -3.0), 10)
    b.beam("metal", (4.5, OC + 0.25, 5.0), (4.5, OC + 2.5, 5.0), 0.03)

    b.layer = None
    return b
