"""Gebäude Teil 2: Hochhäuser (Centro), Kirche, Lagerhalle, Eckgebäude, Praça, Park.
Konventionen wie bei den Häusern: Pivot = Grundstücksmitte am Boden, Vorderseite +Z.
Eckgebäude: zweite Straßenseite = +X, abgeschrägte Ecke bei (+X, +Z)."""
import numpy as np
import trimesh
from shapely.geometry import Point, Polygon, LineString, box as sbox
from shapely.ops import unary_union
from lib import B, fpos, fsize, PALETTE
from roads import ext, lamp, old_lamp, tree, bench

PALETTE.update({"container_a": "#C8372D", "container_b": "#1E4FA8", "container_c": "#E8B923", "container_d": "#2E8B57",
                "bell": "#B08D3A", "playground": "#E8692A"})


def box(b, mat, x0, x1, y0, y1, z0, z1, **kw):
    b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)


# =====================================================================
# HOCHHÄUSER (Centro)
# =====================================================================
def torre_centro(H=116.0):
    """Glass office tower ~116 m (+ antenna 15 m) on a stone podium."""
    def f():
        b = B(1100)
        st = b.slot("nwall", 1, "#C9C9C4")
        gl = b.slot("glass", 1, "#4F7F95")
        b.box("concrete_light", (32, 0.1, 32), (0, 0.05, 0))
        # podium (4 floors, 16 m)
        PH = 16.0
        box(b, st, -14, 14, 0, PH, -14, 14)
        for z in (14.0,):
            b.box(gl, (24, 5.2, 0.05), (0, 3.1, z + 0.03))
            for x in np.arange(-12, 12.1, 3.0):
                b.box("frame_black", (0.12, 5.2, 0.1), (x, 3.1, z + 0.06))
        for face, plane in (("z+", 14.0), ("z-", -14.0), ("x+", 14.0), ("x-", -14.0)):
            for y in (8.0, 12.0):
                b.box(gl, fsize(face, 26, 2.4, 0.05), fpos(face, plane, 0, y, 0.03))
        b.box("frame_black", (12, 0.4, 4.0), (0, 6.0, 16.0))                       # entrance canopy
        b.box(st, (32, 0.6, 32), (0, PH + 0.3, 0)) if False else None
        # tower shaft
        TW = 11.0
        box(b, gl, -TW, TW, PH, H, -TW, TW)
        for y in np.arange(PH + 4.0, H, 4.0):                                       # floor bands
            for face, plane in (("z+", TW), ("z-", -TW), ("x+", TW), ("x-", -TW)):
                b.box(st, fsize(face, 2 * TW + 0.2, 0.45, 0.12), fpos(face, plane, 0, y, 0.06))
        for k in np.arange(-TW, TW + 0.1, 2.75):                                    # vertical mullions
            for face, plane in (("z+", TW), ("z-", -TW), ("x+", TW), ("x-", -TW)):
                b.box("frame_black", fsize(face, 0.15, H - PH, 0.14), fpos(face, plane, k, (PH + H) / 2, 0.07))
        # setback crown
        box(b, st, -TW - 0.3, TW + 0.3, H, H + 1.0, -TW - 0.3, TW + 0.3)
        box(b, gl, -8.5, 8.5, H + 1.0, H + 7.0, -8.5, 8.5)
        box(b, st, -9.0, 9.0, H + 7.0, H + 8.0, -9.0, 9.0)
        box(b, "dach_technik", -5.0, 5.0, H + 8.0, H + 10.5, -5.0, 5.0)
        b.cyl("concrete", 4.2, 0.3, (0, H + 10.65, 0), 12)                         # helipad
        b.cyl("paint_white", 3.9, 0.02, (0, H + 10.81, 0), 12)
        b.cyl("concrete", 3.6, 0.03, (0, H + 10.82, 0), 12)
        for dx in (-0.8, 0.8):
            b.box("cloth_yellow", (0.45, 0.03, 2.4), (dx, H + 10.85, 0))
        b.box("cloth_yellow", (1.6, 0.03, 0.45), (0, H + 10.85, 0))
        b.beam("metal", (7.0, H + 8.0, 7.0), (7.0, H + 23.0, 7.0), 0.25)            # antenna
        for y in (H + 8.2, H + 15.0, H + 23.0):
            b.cyl("led_red", 0.25, 0.3, (7.0, y, 7.0), 6)
        for (x, z) in [(-TW, -TW), (TW, -TW), (-TW, TW), (TW, TW)]:
            b.cyl("led_red", 0.2, 0.3, (x, H + 1.2, z), 6)
        for x in (-12, 12):
            tree(b, x, 15.0, y=0.1, h=4.0, r=1.6)
        b.anchor("Eingang", (0, 0, 16.5), 0)
        b.anchor("Helipad", (0, H + 10.85, 0), 0)
        return b
    return f


def edificio_70er(H=104.0):
    """1970s concrete slab tower with vertical brise-soleil fins on pilotis, ~104 m."""
    def f():
        b = B(1200)
        cn = b.slot("nwall", 1, "#A8A196")
        b.box("concrete_light", (40, 0.1, 22), (0, 0.05, 0))
        LX, LZ = 17.0, 8.0
        PIL = 7.0
        for x in np.linspace(-LX + 1, LX - 1, 7):                                   # pilotis
            for z in (-LZ + 1, LZ - 1):
                b.box(cn, (1.2, PIL, 1.6), (x, PIL / 2, z))
        box(b, "glass_big", -10, 10, 0.1, PIL - 0.5, -5, 5)                           # glass lobby under the slab
        box(b, cn, -LX, LX, PIL, PIL + 1.5, -LZ, LZ)
        box(b, "glass", -LX + 0.4, LX - 0.4, PIL + 1.5, H, -LZ + 0.4, LZ - 0.4)
        for y in np.arange(PIL + 1.5, H, 3.2):                                       # slab edges
            box(b, cn, -LX, LX, y - 0.35, y, -LZ, LZ)
        for x in np.arange(-LX + 0.6, LX, 1.6):                                      # vertical fins on long faces
            for z in (LZ - 0.25, -LZ + 0.25):
                box(b, cn, x - 0.12, x + 0.12, PIL + 1.5, H, z - 0.4, z + 0.4)
        for z in np.arange(-LZ + 0.8, LZ, 1.6):                                      # short faces: solid with slots
            for x in (LX, -LX):
                box(b, cn, x - 0.2, x + 0.2, PIL + 1.5, H, z - 0.5, z + 0.5)
        box(b, cn, -LX - 0.3, LX + 0.3, H, H + 1.2, -LZ - 0.3, LZ + 0.3)
        box(b, cn, -6, 6, H + 1.2, H + 6.0, -4, 4)                                    # machine house
        for x in (-4.0, 0.0, 4.0):
            b.cyl("tank_white", 1.2, 2.0, (x, H + 7.0, 0), 10)
        b.beam("metal", (-10, H + 1.2, 4), (-10, H + 14.0, 4), 0.2)
        b.cyl("led_red", 0.25, 0.3, (-10, H + 14.0, 4), 6)
        b.cyl("led_red", 0.2, 0.3, (LX, H + 1.4, LZ), 6)
        b.cyl("led_red", 0.2, 0.3, (-LX, H + 1.4, -LZ), 6)
        b.anchor("Eingang", (0, 0, 10.0), 0)
        return b
    return f


# =====================================================================
# KIRCHE
# =====================================================================
def igreja():
    """Brazilian colonial church: two bell towers, curved gable, nave with tile roof, churchyard."""
    b = B(1300)
    wl = b.slot("nwall", 1, "#F2F0EA")
    tr = b.slot("trim", 1, "#D8C7A2")
    dr = b.slot("door", 1, "#2E5FA8")
    ro = b.slot("roof", 1, "#B2552F")
    b.box("tile_floor", (22, 0.06, 34), (0, 0.03, 0))
    # churchyard (adro): platform + steps
    box(b, "stone_white", -9, 9, 0, 0.9, 9, 14)
    for k in range(3):
        box(b, "stone_white", -4, 4, 0, 0.3 * (k + 1), 16.5 - k * 0.8 - 0.8, 16.5 - k * 0.8) if False else None
    for k in range(3):
        box(b, "stone_white", -4, 4, 0, 0.3 * (3 - k), 14 + k * 0.6, 14.6 + k * 0.6)
    for x0, x1 in ((-10, -4), (4, 10)):
        box(b, tr, x0, x1, 0, 1.1, 16.3, 16.6)
    # nave
    NW, NZ0, NZ1, NH = 5.0, -14.0, 8.0, 12.0
    box(b, wl, -NW, NW, 0.9, NH, NZ0, NZ1)
    box(b, tr, -NW - 0.1, NW + 0.1, NH - 0.6, NH, NZ0 - 0.1, NZ1)
    b.hull(ro, [(x, NH, z) for x in (-NW - 0.6, NW + 0.6) for z in (NZ0 - 0.6, NZ1)] + [(0, NH + 4.5, z) for z in (NZ0 - 0.6, NZ1)])
    for face, plane in (("x+", NW), ("x-", -NW)):
        for z in (-10.0, -5.0, 0.0, 5.0):
            b.arch_window(face, plane, z, 4.5, 1.4, 3.6, glass="glass", frame=tr, sill=tr)
    # chancel (apse) at the back
    box(b, wl, -3.5, 3.5, 0.9, 9.0, NZ0 - 4.0, NZ0)
    b.hull(ro, [(x, 9.0, z) for x in (-4.0, 4.0) for z in (NZ0 - 4.4, NZ0)] + [(0, 12.0, z) for z in (NZ0 - 4.4, NZ0)])
    # façade (z = 8 .. 9) with towers
    FZ = 9.0
    box(b, wl, -NW, NW, 0.9, NH + 1.0, NZ1, FZ)
    for x in (-NW, NW):                                                          # pilasters
        box(b, tr, x - 0.35, x + 0.35, 0.9, NH + 1.0, FZ - 0.1, FZ + 0.15)
    box(b, tr, -NW, NW, NH - 0.2, NH + 0.4, FZ - 0.1, FZ + 0.2)                     # cornice
    # curved gable (frontão) – stepped volutes approximated by hulls
    gy = NH + 0.4
    prof = [(-NW, 0.0), (-3.6, 1.2), (-2.4, 1.6), (-1.6, 3.2), (0.0, 4.2), (1.6, 3.2), (2.4, 1.6), (3.6, 1.2), (NW, 0.0)]
    for (xa, ya), (xc, yc) in zip(prof[:-1], prof[1:]):
        b.hull(wl, [(xa, gy, FZ - 0.6), (xc, gy, FZ - 0.6), (xa, gy + ya, FZ - 0.6), (xc, gy + yc, FZ - 0.6),
                    (xa, gy, FZ), (xc, gy, FZ), (xa, gy + ya, FZ), (xc, gy + yc, FZ)])
        b.beam(tr, (xa, gy + ya + 0.1, FZ + 0.05), (xc, gy + yc + 0.1, FZ + 0.05), 0.25)
    b.beam(tr, (0, gy + 4.3, FZ - 0.3), (0, gy + 6.3, FZ - 0.3), 0.18)            # cross
    b.beam(tr, (-0.6, gy + 5.6, FZ - 0.3), (0.6, gy + 5.6, FZ - 0.3), 0.18)
    # round window + door
    rw = trimesh.creation.cylinder(radius=1.0, height=0.1, sections=12)
    rw.apply_translation((0, 9.6, FZ + 0.02))
    b.add("glass", rw)
    rf = trimesh.creation.cylinder(radius=1.25, height=0.06, sections=12)
    rf.apply_translation((0, 9.6, FZ + 0.0))
    b.add(tr, rf)
    b.arch_window("z+", FZ, 0, 0.9, 2.6, 5.2, glass=dr, frame=tr, sill=None)
    for x in (-3.2, 3.2):
        b.arch_window("z+", FZ, x, 5.2, 1.1, 2.4, glass="glass", frame=tr, sill=tr)
    # bell towers
    for sx in (-1, 1):
        cx = sx * (NW + 1.8)
        box(b, wl, cx - 1.8, cx + 1.8, 0.9, 18.0, FZ - 3.6, FZ)
        box(b, tr, cx - 1.9, cx + 1.9, 13.0, 13.4, FZ - 3.7, FZ + 0.1)
        box(b, tr, cx - 1.9, cx + 1.9, 18.0, 18.4, FZ - 3.7, FZ + 0.1)
        for face, plane, u in (("z+", FZ, cx), ("x+" if sx > 0 else "x-", cx + sx * 1.8, FZ - 1.8)):
            b.arch_window(face, plane, u, 14.0, 1.4, 3.2, glass="tunnel_dark", frame=tr, sill=None)
        b.cyl("bell", 0.5, 0.9, (cx, 15.0, FZ - 1.8), 8)
        b.hull(ro, [(cx + dx, 18.4, FZ - 1.8 + dz) for dx in (-1.9, 1.9) for dz in (-1.9, 1.9)] + [(cx, 21.5, FZ - 1.8)])
        b.cyl(tr, 0.15, 0.6, (cx, 21.8, FZ - 1.8), 6)
        b.arch_window("z+", FZ, cx, 3.0, 1.0, 2.4, glass="glass", frame=tr, sill=tr)
    for (x, z) in [(-9.0, -2.0), (9.0, -6.0), (8.5, 6.0)]:
        b.palm(x, z, 7.5, (0.2, 0.1))
    for x in (-7.0, 7.0):
        old_lamp(b, x, 15.5, 0.9)
    b.anchor("Eingang", (0, 0, 17.0), 0)
    b.anchor("Glockenturm", (NW + 1.8, 15.0, FZ - 1.8), 0)
    return b


# =====================================================================
# LAGERHALLE
# =====================================================================
def lagerhalle():
    """Port / industrial warehouse with barrel roof, loading dock, office annex, containers."""
    b = B(1400)
    wl = b.slot("nwall", 1, "#B8BCC0")
    ac = b.slot("accent", 1, "#1E4FA8")
    b.box("asphalt", (40, 0.06, 32), (0, 0.03, 0))
    X0, X1, Z0, Z1, WH = -16, 16, -12, 8, 9.0
    box(b, wl, X0, X1, 0, WH, Z0, Z1)
    for x in np.arange(X0 + 0.5, X1, 1.0):                                       # corrugation ribs (front/back)
        for z in (Z1 + 0.04, Z0 - 0.04):
            b.box("tin", (0.08, WH - 0.2, 0.08), (x, WH / 2, z))
    for z in np.arange(Z0 + 0.5, Z1, 1.0):
        for x in (X1 + 0.04, X0 - 0.04):
            b.box("tin", (0.08, WH - 0.2, 0.08), (x, WH / 2, z))
    # barrel roof (segments)
    n = 10
    R = (Z1 - Z0) / 2 / np.sin(np.radians(35))
    cz = (Z0 + Z1) / 2
    yc = WH - R * np.cos(np.radians(35))
    angs = np.linspace(-np.radians(35), np.radians(35), n + 1)
    for a0, a1 in zip(angs[:-1], angs[1:]):
        p = [(x, yc + R * np.cos(a), cz + R * np.sin(a)) for x in (X0 - 0.4, X1 + 0.4) for a in (a0, a1)]
        b.hull("tin", p + [(x, y - 0.15, z) for (x, y, z) in p])
    for x in (X0, X1):                                                             # gable ends
        pts = [(x, WH, Z0), (x, WH, Z1)] + [(x, yc + R * np.cos(a), cz + R * np.sin(a)) for a in angs]
        b.hull(wl, pts + [(x - np.sign(x) * 0.2, y, z) for (_, y, z) in pts])
    for x in np.arange(-12, 13, 4.0):                                              # skylights
        b.box("glass_big", (1.2, 0.1, 10.0), (x, yc + R + 0.03, cz), rot_x=0)
    # loading dock + roll-up doors on the front
    box(b, "concrete", -14, 6, 0, 1.2, Z1, Z1 + 3.0)
    for x in (-11.0, -5.0, 1.0):
        box(b, "shutter", x - 2.0, x + 2.0, 1.2, 5.8, Z1, Z1 + 0.08)
        for k in range(11):
            box(b, "metal", x - 2.0, x + 2.0, 1.4 + k * 0.4, 1.43 + k * 0.4, Z1 + 0.08, Z1 + 0.1)
        box(b, ac, x - 2.3, x + 2.3, 5.8, 6.2, Z1, Z1 + 0.2)
        for dx in (-2.1, 2.1):
            box(b, "rubber", x + dx - 0.15, x + dx + 0.15, 0.4, 1.1, Z1 + 3.0, Z1 + 3.2)
        b.box("lamp", (0.4, 0.15, 0.3), (x, 6.6, Z1 + 0.3))
    for k in range(4):                                                             # dock stairs
        box(b, "concrete", 6, 7.2, 0, 0.3 * (k + 1), Z1 + 3.0 - k * 0.35 - 0.35, Z1 + 3.0 - k * 0.35)
    b.box(ac, (14.0, 1.4, 0.1), (-5.0, 7.5, Z1 + 0.06))
    b.box("sign_white", (12.0, 0.25, 0.02), (-5.0, 7.5, Z1 + 0.12))
    # office annex (2 floors) on the right front
    box(b, "concrete_white", 7.5, 16, 0, 6.5, 2, Z1 + 0.01)
    for y in (1.8, 4.8):
        b.box("glass_big", (7.6, 1.4, 0.05), (11.75, y, Z1 + 0.03))
    b.box("door_metal", (1.0, 2.1, 0.06), (14.5, 1.05, Z1 + 0.04))
    b.box("ac", (0.9, 0.5, 0.35), (9.0, 6.0, Z1 + 0.18))
    # containers
    def container(x, y, z, mat, rot=0.0):
        b.box(mat, (6.06, 2.59, 2.44), (x, y + 1.295, z), rot_y=rot)
        c, s = np.cos(np.radians(rot)), np.sin(np.radians(rot))
        for k in np.arange(-2.7, 2.8, 0.45):
            b.box(mat, (0.06, 2.4, 2.5), (x + k * c, y + 1.295, z - k * s), rot_y=rot)
        b.box("metal", (0.05, 2.4, 2.3), (x + 3.04 * c, y + 1.295, z - 3.04 * s), rot_y=rot)
    container(-12.0, 0.0, 13.0, "container_a")
    container(-12.0, 2.6, 13.0, "container_b")
    container(-4.5, 0.0, 13.2, "container_c", 8)
    container(17.0, 0.0, -4.0, "container_d", 90)
    container(17.0, 0.0, -10.5, "container_a", 90)
    container(17.0, 2.6, -7.2, "container_b", 90)
    for k in range(4):                                                             # pallets
        b.box("wood_b", (1.2, 0.15, 1.0), (4.0 + (k % 2) * 1.4, 1.27 + (k // 2) * 0.17, Z1 + 1.6))
        b.box("cardboard", (1.0, 0.8, 0.8), (4.0 + (k % 2) * 1.4, 1.75 + (k // 2) * 0.17, Z1 + 1.6)) if k < 2 else None
    # forklift
    fx, fz = 2.5, 13.0
    b.box("cloth_yellow", (1.2, 1.0, 2.0), (fx, 0.8, fz))
    b.box("frame_black", (1.1, 1.0, 0.8), (fx, 1.8, fz - 0.4))
    for dz in (-0.7, 0.7):
        for dx in (-0.6, 0.6):
            b.cyl("rubber", 0.3, 0.25, (fx + dx, 0.3, fz + dz), 8) if False else b.box("rubber", (0.25, 0.6, 0.6), (fx + dx, 0.3, fz + dz))
    for dx in (-0.4, 0.4):
        b.box("metal", (0.08, 2.6, 0.12), (fx + dx, 1.4, fz + 1.05))
        b.box("metal", (0.12, 0.06, 1.1), (fx + dx, 0.15, fz + 1.6))
    # fence + gate
    for (x0, x1, z0, z1) in [(-20, 20, -16, -15.9), (-20, -19.9, -16, 16), (19.9, 20, -16, 16)]:
        box(b, "fence_net", x0, x1, 0, 2.4, z0, z1)
    for x in np.arange(-20, 20.1, 4.0):
        b.beam("frame_black", (x, 0, -15.95), (x, 2.5, -15.95), 0.06)
    for z in np.arange(-16, 16.1, 4.0):
        for x in (-19.95, 19.95):
            b.beam("frame_black", (x, 0, z), (x, 2.5, z), 0.06)
    for (x, z) in [(-18.0, 15.0), (10.0, 15.0)]:
        lamp(b, x, z, 180, y=0.0, h=8)
    b.anchor("Eingang", (14.5, 0, Z1 + 0.8), 0)
    b.anchor("Laderampe", (-5.0, 1.2, Z1 + 2.0), 0)
    return b


# =====================================================================
# ECKGEBÄUDE (Straßen an +Z und +X, abgeschrägte Ecke)
# =====================================================================
def _corner_shell(b, mat, s, y0, y1, ch):
    """Square footprint -s..s with chamfer ch at (+s, +s)."""
    pts = [(-s, -s), (s, -s), (s, s - ch), (s - ch, s), (-s, s)]
    poly = Polygon(pts)
    ext(b, mat, poly, y0, y1)
    return poly


def _chamfer_face(b, mat, s, ch, y0, y1, d=0.04, w_in=0.0):
    """Thin panel on the chamfer face (normal (1,1)/√2)."""
    c = np.array([s - ch / 2, s - ch / 2]) + np.array([1, 1]) / np.sqrt(2) * d
    L = ch * np.sqrt(2) - w_in
    b.box(mat, (L, y1 - y0, 0.05), (c[0], (y0 + y1) / 2, c[1]), rot_y=45)


def eck_padaria():
    """Corner bakery/bar (2 floors) with wrap-around awning and corner balcony."""
    b = B(1500)
    w1 = b.slot("wall", 1, "#EBC03F")
    w2 = b.slot("wall", 2, "#3FA39A")
    a1 = b.slot("accent", 1, "#C8372D")
    d1 = b.slot("door", 1, "#7A4E2D")
    S, CH, G, U = 6.5, 2.0, 3.6, 3.0
    b.box("sidewalk", (14, 0.15, 14), (0, 0.075, 0))
    _corner_shell(b, w1, S, 0.15, G, CH)
    _corner_shell(b, "concrete", S + 0.15, G, G + 0.25, CH + 0.1)
    _corner_shell(b, w2, S, G + 0.25, G + 0.25 + U, CH)
    _corner_shell(b, "concrete", S + 0.2, G + 0.25 + U, G + 0.55 + U, CH + 0.1)
    # shop fronts on both street faces + corner door
    for face in ("z+", "x+"):
        for u in (-4.2, -0.6):
            b.box("glass_shop", fsize(face, 2.8, 2.4, 0.05), fpos(face, S, u, 1.5, 0.03))
            b.box("frame_black", fsize(face, 2.9, 0.1, 0.08), fpos(face, S, u, 2.75, 0.04))
        b.box(w1, fsize(face, 12.0, 0.1, 0.05), fpos(face, S, -0.5, 0.2, 0.02))
    _chamfer_face(b, d1, S, CH, 0.15, 2.6, w_in=0.8)
    _chamfer_face(b, "frame_black", S, CH, 2.6, 2.7, d=0.05)
    # striped awning wrapping the corner
    for face in ("z+", "x+"):
        for k in range(14):
            u = -S + 0.45 + k * 0.85
            mat = a1 if k % 2 == 0 else "sign_white"
            rx = 22 if face == "z+" else 0
            rz = -22 if face == "x+" else 0
            pos = list(fpos(face, S, u, 3.0, 0.6))
            b.box(mat, fsize(face, 0.86, 0.04, 1.3), tuple(pos), rot_x=rx, rot_z=rz)
    b.box(a1, (10.0, 0.5, 0.06), (-0.8, 3.35, S + 0.03))
    b.box(a1, (0.06, 0.5, 10.0), (S + 0.03, 3.35, -0.8))
    # upper floor windows + corner balcony
    for face in ("z+", "x+"):
        for u in (-4.0, -0.8):
            b.window(face, S, u, G + 1.7, 1.1, 1.2, bars=False, shutters="shutter_green")
    cb = Polygon([(S - CH - 1.2, S + 0.9), (S + 0.9, S - CH - 1.2), (S + 0.9, S - CH + 0.6), (S - CH + 0.6, S + 0.9)])
    _chamfer_face(b, "door_wood", S, CH, G + 0.3, G + 2.5, w_in=0.9)
    ext(b, "concrete", Polygon([(S - CH - 0.6, S), (S, S - CH - 0.6), (S + 0.8, S - CH + 0.2), (S - CH + 0.2, S + 0.8)]), G + 0.15, G + 0.3)
    for t in np.linspace(0, 1, 7):
        p = np.array([S - CH + 0.2, S + 0.8]) * (1 - t) + np.array([S + 0.8, S - CH + 0.2]) * t
        b.beam("frame_black", (p[0], G + 0.3, p[1]), (p[0], G + 1.3, p[1]), 0.04)
    b.beam("frame_black", (S - CH + 0.2, G + 1.3, S + 0.8), (S + 0.8, G + 1.3, S - CH + 0.2), 0.05)
    b.tank(-3.0, G + 0.55 + U, -3.0, 0.6, 0.9)
    b.box("ac", (0.75, 0.42, 0.3), (-5.0, G + 2.4, S + 0.15))
    # tables outside
    for (x, z) in [(-3.0, 7.6), (7.6, -3.0)]:
        b.table(x, 0.15, z, "plastic_red", 0.7)
    b.anchor("Eingang", (S - CH / 2 + 0.7, 0.15, S - CH / 2 + 0.7), 45)
    return b


def eck_sobrado():
    """Colonial corner townhouse (2 floors) with platibanda and balconettes on both faces."""
    b = B(1510)
    w1 = b.slot("wall", 1, "#E07A8C")
    t1 = b.slot("trim", 1, "#F4F2EC")
    d1 = b.slot("door", 1, "#3E7D4F")
    S, CH, F = 6.0, 1.4, 3.6
    b.box("sidewalk", (12, 0.15, 12), (0, 0.075, 0))
    _corner_shell(b, w1, S, 0.15, 2 * F, CH)
    _corner_shell(b, t1, S + 0.05, 0.15, 0.7, CH + 0.05)
    _corner_shell(b, t1, S + 0.15, F, F + 0.2, CH + 0.1)
    _corner_shell(b, t1, S + 0.2, 2 * F, 2 * F + 0.35, CH + 0.12)
    _corner_shell(b, w1, S + 0.05, 2 * F + 0.35, 2 * F + 1.2, CH + 0.05)
    _corner_shell(b, t1, S + 0.2, 2 * F + 1.2, 2 * F + 1.35, CH + 0.12)
    _corner_shell(b, "dach", S - 0.3, 2 * F + 0.35, 2 * F + 0.5, CH)
    for face in ("z+", "x+"):
        for u in (-3.8, -1.2, 1.6):
            if face == "x+" and u > 1.0:
                continue
            b.arch_window(face, S, u, 0.9, 1.0, 2.3, glass="glass", frame=t1)
            b.window(face, S, u, F + 1.45, 0.95, 2.2, bars=False, frame=t1, sill=None, shutters=d1)
            b.balconette(face, S, u, F + 0.3, 1.0, 0.45, "frame_black", t1)
    _chamfer_face(b, d1, S, CH, 0.15, 2.6, w_in=0.4)
    _chamfer_face(b, t1, S, CH, 2.6, 2.9, d=0.05)
    for x, z in [(-S, S), (S, -S)]:
        box(b, t1, x - 0.2, x + 0.2, 0.15, 2 * F + 1.35, z - 0.2, z + 0.2)
    b.anchor("Eingang", (S - CH / 2 + 0.6, 0.15, S - CH / 2 + 0.6), 45)
    return b


def eck_predio():
    """6-floor corner apartment block with shops on both street faces and wrap-around balconies."""
    b = B(1520)
    w1 = b.slot("nwall", 1, "#E9E4D8")
    w2 = b.slot("wall", 1, "#6FB3D9")
    a1 = b.slot("accent", 1, "#3E7D4F")
    S, CH, G, FH, NF = 7.5, 3.0, 4.0, 3.0, 5
    b.box("sidewalk", (16, 0.15, 16), (0, 0.075, 0))
    _corner_shell(b, w1, S, 0.15, G, CH)
    for face in ("z+", "x+"):
        for u in (-5.0, -1.6):
            b.box("glass_shop", fsize(face, 2.9, 2.8, 0.05), fpos(face, S, u, 1.7, 0.03))
            b.box(a1, fsize(face, 3.1, 0.6, 0.08), fpos(face, S, u, 3.45, 0.05))
            b.box("shutter", fsize(face, 3.0, 0.3, 0.3), fpos(face, S, u, 3.0, 0.15))
    _chamfer_face(b, "glass_shop", S, CH, 0.15, 3.0, w_in=0.4)
    _chamfer_face(b, "concrete_white", S, CH, 3.0, G, d=0.05)
    for f in range(NF):
        y = G + f * FH
        _corner_shell(b, w2 if f % 2 == 0 else w1, S - 0.2, y, y + FH, CH)
        ext(b, "concrete_white", Polygon([(-S, S + 1.0), (S - CH + 0.6, S + 1.0), (S + 1.0, S - CH + 0.6), (S + 1.0, -S), (S, -S), (S, S - CH), (S - CH, S), (-S, S)]), y, y + 0.2)
        for face in ("z+", "x+"):
            b.box("glass_rail", fsize(face, 2 * S - CH, 1.0, 0.04), fpos(face, S, -CH / 2, y + 0.7, 1.0))
            for u in (-5.0, -2.0):
                b.box("glass", fsize(face, 1.8, 2.0, 0.05), fpos(face, S - 0.2, u, y + 1.3, 0.03))
            b.box("ac", fsize(face, 0.7, 0.4, 0.3), fpos(face, S - 0.2, 0.5, y + 2.4, 0.15))
        _chamfer_face(b, "glass_rail", S + 1.0 - CH * 0.0, CH, y + 0.2, y + 1.2, d=0.0)
    top = G + NF * FH
    _corner_shell(b, "concrete_white", S, top, top + 0.3, CH)
    box(b, w1, -5.0, 0.0, top + 0.3, top + 3.0, -6.0, -2.0)
    b.tank(2.0, top + 0.3, -4.0, 0.7, 1.0)
    dish = trimesh.creation.cone(radius=0.4, height=0.12, sections=8)
    dish.apply_transform(trimesh.transformations.rotation_matrix(np.radians(-150), [1, 0, 0]))
    dish.apply_translation((4.0, top + 1.2, 2.0))
    b.add("cloth_white", dish)
    b.anchor("Eingang", (S - CH / 2 + 0.8, 0.15, S - CH / 2 + 0.8), 45)
    return b


# =====================================================================
# PRAÇA + PARK
# =====================================================================
def praca():
    """36 x 36 square with Portuguese pavement, coreto (bandstand), trees, benches, newsstand."""
    b = B(1600)
    S = 18.0
    ext(b, "curb", sbox(-S, -S, S, S), -0.1, 0.17)
    ext(b, "calcadao_white", sbox(-S + 0.25, -S + 0.25, S - 0.25, S - 0.25), -0.1, 0.17)
    # radial pavement pattern
    rings = []
    for r0 in (6.5, 10.5, 14.5):
        rings.append(Point(0, 0).buffer(r0 + 0.7, quad_segs=8).difference(Point(0, 0).buffer(r0, quad_segs=8)))
    for a in np.linspace(0, 2 * np.pi, 9)[:-1]:
        rings.append(LineString([(0, 0), (17 * np.cos(a), 17 * np.sin(a))]).buffer(0.35, cap_style=2))
    pat = unary_union(rings).intersection(sbox(-S + 0.4, -S + 0.4, S - 0.4, S - 0.4)).difference(Point(0, 0).buffer(5.5))
    ext(b, "calcadao_black", pat, 0.17, 0.18)
    # coreto (octagonal bandstand)
    b.cyl("stone_white", 5.0, 1.0, (0, 0.67, 0), 8)
    b.cyl("tile_floor", 4.8, 0.05, (0, 1.2, 0), 8)
    for a in np.linspace(0, 2 * np.pi, 9)[:-1] + np.pi / 8:
        x, z = 4.4 * np.cos(a), 4.4 * np.sin(a)
        b.cyl("paint_white", 0.15, 3.0, (x, 2.7, z), 6)
    for a0, a1 in zip(np.linspace(0, 2 * np.pi, 9)[:-1] + np.pi / 8, np.linspace(0, 2 * np.pi, 9)[1:] + np.pi / 8):
        b.beam("paint_white", (4.4 * np.cos(a0), 1.9, 4.4 * np.sin(a0)), (4.4 * np.cos(a1), 1.9, 4.4 * np.sin(a1)), 0.06)
    b.hull("plaster_blue", [(5.2 * np.cos(a), 4.2, 5.2 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1] + np.pi / 8] + [(0, 6.4, 0)])
    b.cyl("paint_white", 5.25, 0.3, (0, 4.1, 0), 8)
    for k in range(3):
        box(b, "stone_white", -1.2, 1.2, 0.17, 0.17 + 0.28 * (k + 1), 5.0 + (2 - k) * 0.4, 5.4 + (2 - k) * 0.4)
    # trees, benches, lamps
    for a in np.linspace(0, 2 * np.pi, 9)[:-1] + np.pi / 8:
        tree(b, 12.5 * np.cos(a), 12.5 * np.sin(a), y=0.17, h=3.6, r=1.9)
    for a in np.linspace(0, 2 * np.pi, 9)[:-1]:
        bench(b, 8.5 * np.cos(a), 8.5 * np.sin(a), np.degrees(-a) + 90, y=0.17)
    for (x, z) in [(-16.5, -16.5), (16.5, -16.5), (-16.5, 16.5), (16.5, 16.5), (0, 16.5), (0, -16.5), (16.5, 0), (-16.5, 0)]:
        old_lamp(b, x, z, 0.17)
    # newsstand (banca de jornal)
    bx, bz = 12.0, 15.0
    box(b, "cloth_green", bx - 1.5, bx + 1.5, 0.17, 2.6, bz - 1.0, bz + 1.0)
    box(b, "paint_white", bx - 1.8, bx + 1.8, 2.6, 2.8, bz - 1.3, bz + 1.3)
    for k in range(5):
        box(b, ["cloth_red", "cloth_yellow", "plaster_blue", "cloth_white", "cloth_red"][k], bx - 1.3 + k * 0.55, bx - 0.85 + k * 0.55, 1.0, 1.7, bz + 1.0, bz + 1.04)
    # small fountain
    b.cyl("stone_white", 1.6, 0.6, (-12.0, 0.47, -12.0), 10)
    b.cyl("pool", 1.4, 0.05, (-12.0, 0.78, -12.0), 10)
    b.cyl("stone_white", 0.3, 1.2, (-12.0, 1.2, -12.0), 6)
    for s in ("N", "S", "E", "W"):
        dx, dz = {"N": (0, -1), "S": (0, 1), "E": (1, 0), "W": (-1, 0)}[s]
        b.anchor(f"Zugang_{s}", (dx * S, 0.17, dz * S), {"N": 180, "S": 0, "E": 90, "W": -90}[s])
    return b


def parque():
    """36 x 36 park: lawn, curved paths, pond, trees, palms, playground, small football pitch."""
    b = B(1700)
    S = 18.0
    ext(b, "curb", sbox(-S, -S, S, S), -0.1, 0.15)
    ext(b, "grass", sbox(-S + 0.3, -S + 0.3, S - 0.3, S - 0.3), -0.1, 0.16)
    path = unary_union([
        LineString([(0, S), (2, 8), (-2, 0), (1, -8), (0, -S)]).buffer(1.2, quad_segs=4),
        LineString([(-S, 2), (-8, 4), (-2, 0), (6, -2), (S, 1)]).buffer(1.2, quad_segs=4),
        LineString([(-S + 1, -S + 1), (-8, -8), (-2, 0)]).buffer(0.9, quad_segs=4),
    ]).intersection(sbox(-S + 0.3, -S + 0.3, S - 0.3, S - 0.3))
    ext(b, "tile_floor", path, -0.1, 0.18)
    pond = Polygon([(8 + 5 * np.cos(a) * (1 + 0.15 * np.sin(3 * a)), 8 + 3.6 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 19)[:-1]])
    ext(b, "stone_white", pond.buffer(0.4, quad_segs=3), -0.1, 0.2)
    ext(b, "pool", pond, -0.1, 0.12)
    # football pitch (campinho)
    fx, fz = -9.0, -9.5
    ext(b, "court_green", sbox(fx - 6.5, fz - 4.5, fx + 6.5, fz + 4.5), 0.16, 0.19)
    for (a, c, d, e) in [(-6, 6, -4, -3.9), (-6, 6, 3.9, 4), (-6, -5.9, -4, 4), (5.9, 6, -4, 4), (-0.05, 0.05, -4, 4)]:
        ext(b, "paint_white", sbox(fx + a, fz + d, fx + c, fz + e), 0.19, 0.2)
    ext(b, "paint_white", Point(fx, fz).buffer(1.5, quad_segs=4).difference(Point(fx, fz).buffer(1.4, quad_segs=4)), 0.19, 0.2)
    for sx in (-1, 1):
        gx = fx + sx * 6.0
        for dz in (-1.5, 1.5):
            b.beam("paint_white", (gx, 0.19, fz + dz), (gx, 2.2, fz + dz), 0.1)
        b.beam("paint_white", (gx, 2.2, fz - 1.5), (gx, 2.2, fz + 1.5), 0.1)
        b.box("fence_net", (0.8, 2.0, 3.0), (gx + sx * 0.4, 1.2, fz))
    # playground
    px, pz = 9.0, -9.0
    ext(b, "sand", Point(px, pz).buffer(4.0, quad_segs=4), 0.16, 0.2)
    for dx in (-1.2, 1.2):
        b.beam("playground", (px - 2.0 + dx, 0.2, pz - 1.0), (px - 2.0 + dx * 0.6, 2.4, pz - 1.0), 0.1)
        b.beam("playground", (px - 2.0 + dx, 0.2, pz + 1.0), (px - 2.0 + dx * 0.6, 2.4, pz + 1.0), 0.1)
    b.beam("playground", (px - 2.7, 2.4, pz - 1.0), (px - 1.3, 2.4, pz - 1.0), 0.1)
    b.beam("playground", (px - 2.7, 2.4, pz + 1.0), (px - 1.3, 2.4, pz + 1.0), 0.1)
    b.beam("playground", (px - 2.0, 2.4, pz - 1.0), (px - 2.0, 2.4, pz + 1.0), 0.1)
    for dz in (-0.5, 0.5):
        b.beam("metal", (px - 2.0, 2.4, pz + dz), (px - 2.0, 0.8, pz + dz), 0.03)
        b.box("plastic_red", (0.5, 0.05, 0.25), (px - 2.0, 0.78, pz + dz))
    box(b, "plaster_blue", px + 0.8, px + 2.2, 0.2, 1.6, pz - 0.7, pz + 0.7)
    b.hull("cloth_yellow", [(px + 2.2, 1.6, pz - 0.5), (px + 2.2, 1.6, pz + 0.5), (px + 4.0, 0.3, pz - 0.5), (px + 4.0, 0.3, pz + 0.5),
                            (px + 2.2, 1.5, pz - 0.5), (px + 2.2, 1.5, pz + 0.5), (px + 4.0, 0.2, pz - 0.5), (px + 4.0, 0.2, pz + 0.5)])
    # trees + palms + benches + lamps
    r = b.rng
    for (x, z) in [(-12, 12), (-6, 14), (-14, 6), (13, -1), (4, 13), (-4, -14), (14, 14), (-15, -2), (5, 3)]:
        tree(b, x, z, y=0.16, h=r.uniform(3.0, 4.2), r=r.uniform(1.6, 2.2))
    for (x, z) in [(15.5, -15.5), (-15.5, 15.5), (2.5, -14.0)]:
        b.palm(x, z, 7.0, (0.3, 0.2), y=0.16)
    for (x, z, rot) in [(3.5, 7.0, 90), (-4.0, 2.5, 0), (4.0, -4.5, 180), (10.5, 1.5, 0), (-10.0, 5.5, 180)]:
        bench(b, x, z, rot, y=0.18)
    for (x, z) in [(1.5, 12.0), (-1.0, -6.0), (-11.0, 3.0), (12.0, -0.5)]:
        lamp(b, x, z, 0, y=0.18, h=4.5)
    # low fence with gaps at the path entrances
    for (x0, x1, z0, z1) in [(-S + 0.3, -1.5, S - 0.45, S - 0.35), (1.5, S - 0.3, S - 0.45, S - 0.35),
                             (-S + 0.3, -1.5, -S + 0.35, -S + 0.45), (1.5, S - 0.3, -S + 0.35, -S + 0.45),
                             (-S + 0.35, -S + 0.45, -S + 0.3, 0.5), (-S + 0.35, -S + 0.45, 3.5, S - 0.3),
                             (S - 0.45, S - 0.35, -S + 0.3, -0.5), (S - 0.45, S - 0.35, 2.5, S - 0.3)]:
        box(b, "frame_black", x0, x1, 0.75, 0.85, z0, z1)
    for s in ("N", "S", "E", "W"):
        dx, dz = {"N": (0, -1), "S": (0, 1), "E": (1, 0), "W": (-1, 0)}[s]
        b.anchor(f"Zugang_{s}", (dx * S, 0.16, dz * S), {"N": 180, "S": 0, "E": 90, "W": -90}[s])
    return b


BUILDINGS2 = [
    ("20_torre_centro", "Torre Centro (116 m)", "Centro", torre_centro()),
    ("21_edificio_70er", "Edifício Anos 70 (104 m)", "Centro", edificio_70er()),
    ("22_igreja", "Igreja (Kirche)", "Spezial", igreja),
    ("23_lagerhalle", "Lagerhalle (Hafen)", "Gewerbe", lagerhalle),
    ("24_eck_padaria", "Eck-Padaria", "Ecke", eck_padaria),
    ("25_eck_sobrado", "Eck-Sobrado", "Ecke", eck_sobrado),
    ("26_eck_predio", "Eck-Prédio", "Ecke", eck_predio),
    ("27_praca", "Praça mit Coreto", "Freifläche", praca),
    ("28_parque", "Park mit Bolzplatz", "Freifläche", parque),
]
