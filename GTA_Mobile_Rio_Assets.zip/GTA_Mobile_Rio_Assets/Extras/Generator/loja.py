"""Mega Moda Popular – billiger, vollgestopfter Kleiderladen (Stil SAARA, Centro).
Schmales Grundstück 8 x 16 m. Laden reicht bis auf den Gehweg (Markise, Puppen, Ständer).
EG: Wandständer doppelstöckig, Mittelständer, Wühltische, Chinelo-Wand, Mützenwand, Kasse, 1 Umkleide,
Deckenhänger, Ventilator. OG: Lager voller Kartons und Säcke. Front +Z.
Nodes <Ebene>__<Material>: Aussen, EG, OG, Dach."""
import numpy as np
import trimesh
from shapely.geometry import Polygon
from lib import B, PALETTE

CLOTH = ["cl_%02d" % i for i in range(1, 15)]
PALETTE.update(dict(zip(CLOTH, ["#E23B3B", "#2E64C8", "#F2C230", "#2FA35A", "#FF7FB0", "#FFFFFF", "#1E1E22",
                                 "#8A4FC8", "#FF8A1F", "#2FC7D8", "#7A5230", "#9AA3AD", "#C8E04A", "#2A3A66"])))
PALETTE.update({"price_yellow": "#FFE02E", "price_red": "#E0262B", "shop_tile": "#C9C2B2", "mannequin": "#E8DCCB",
                "awning_a": "#D7262B", "awning_b": "#F4F1EA", "bin_blue": "#2C6FD0", "bin_green": "#2FA35A",
                "sack": "#1C1C1E", "dach_fan": "#E8E8E4", "dach_decke": "#EDEAE2"})
for k, v in {"speaker": "#151515", "mirror": "#DCE0E6", "screen": "#2FE0F0", "chrome": "#C9CED6"}.items():
    PALETTE.setdefault(k, v)

W2 = 4.0                        # half lot width
BZ0, BZ1 = -8.0, 6.4            # building
SZ1 = 8.0                       # sidewalk front
T = 0.2
IX0, IX1, IZ0, IZ1 = -W2 + T, W2 - T, BZ0 + T, BZ1 - T
F = 0.12
C = 3.6                         # EG ceiling (OG slab bottom)
O = 3.85                        # OG floor top
R = 6.6                         # roof slab bottom

SHAPES = {
    "shirt": [(-0.23, 0), (0.23, 0), (0.23, 0.44), (0.34, 0.5), (0.2, 0.66), (-0.2, 0.66), (-0.34, 0.5), (-0.23, 0.44)],
    "pants": [(-0.21, 0), (-0.03, 0), (0.0, 0.55), (0.03, 0), (0.21, 0), (0.2, 0.85), (-0.2, 0.85)],
    "dress": [(-0.3, 0), (0.3, 0), (0.14, 0.6), (0.16, 0.85), (-0.16, 0.85), (-0.14, 0.6)],
    "short": [(-0.24, 0), (-0.03, 0), (0.0, 0.2), (0.03, 0), (0.24, 0), (0.22, 0.38), (-0.22, 0.38)],
}
_MESH = {}


def garment_mesh(kind):
    if kind not in _MESH:
        pts = SHAPES[kind]
        top = max(p[1] for p in pts)
        m = trimesh.creation.extrude_polygon(Polygon([(x, y - top) for x, y in pts]), 0.035)
        m.apply_translation((0, 0, -0.0175))
        _MESH[kind] = m
    return _MESH[kind].copy()


def loja():
    b = B(1010)
    rng = np.random.default_rng(7)

    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def col():
        return CLOTH[int(rng.integers(0, len(CLOTH)))]

    def hang(kind, x, y, z, yaw, mat=None):
        """Garment hanging with its top at y. yaw 0 = face +Z (seen from the front), 90 = seen from the side."""
        m = garment_mesh(kind)
        m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(yaw + rng.uniform(-6, 6)), [0, 1, 0]))
        b.add(mat or col(), m.apply_translation((x, y, z)))

    def rail(p0, p1, y, kinds, gap=0.1, side=True, hook=True):
        """Chrome rail from p0 to p1 (x, z) at height y, packed with garments."""
        p0, p1 = np.array(p0, float), np.array(p1, float)
        b.beam("chrome", (p0[0], y, p0[1]), (p1[0], y, p1[1]), 0.025)
        d = p1 - p0
        L = np.linalg.norm(d)
        yaw_rail = np.degrees(np.arctan2(d[0], d[1]))          # 0 → rail along +Z
        for t in np.arange(0.08, L - 0.05, gap):
            x, z = p0 + d * t / L
            kind = kinds[int(rng.integers(0, len(kinds)))]
            if side:                                                                    # seen edge-on: a thin slab is enough
                pts = np.array(SHAPES[kind])
                w, h = pts[:, 0].max() - pts[:, 0].min(), pts[:, 1].max()
                b.box(col(), (w, h, 0.035), (x, y - 0.06 - h / 2, z), rot_y=yaw_rail + rng.uniform(-6, 6))
            else:
                hang(kind, x, y - 0.06, z, yaw_rail + 90)

    def folded_stack(x, z, y, n, w=0.32, d=0.26, rot=0.0):
        for k in range(n):
            b.box(col(), (w, 0.055, d), (x + rng.uniform(-0.02, 0.02), y + 0.03 + k * 0.058, z + rng.uniform(-0.02, 0.02)), rot_y=rot + rng.uniform(-6, 6))

    def price(x, y, z, text, rot=0.0, red=False, txt=False):
        b.box("price_red" if red else "price_yellow", (0.42, 0.26, 0.01), (x, y, z), rot_y=rot)
        c, s = np.sin(np.radians(rot)), np.cos(np.radians(rot))
        if not txt:
            b.box("price_yellow" if red else "price_red", (0.3, 0.07, 0.012), (x + c * 0.002, y, z + s * 0.002), rot_y=rot)
            return
        b.text(text, ["price_yellow" if red else "price_red"] * len(text), (x + c * 0.006, y - 0.0, z + s * 0.006), 0.11, 0.008, rot_y=rot, simplify=0.004)

    def chinelo_pair(x, y, z, mat):
        b.box(mat, (0.22, 0.03, 0.26), (x, y + 0.015, z))

    def cap(x, y, z, mat, rot=0.0):
        pts = [(x + 0.11 * np.cos(a), y, z + 0.11 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 7)[:-1]] + [(x, y + 0.09, z)]
        b.hull(mat, pts)
        c, s = np.sin(np.radians(rot)), np.cos(np.radians(rot))
        b.box(mat, (0.17, 0.015, 0.1), (x + c * 0.14, y + 0.005, z + s * 0.14), rot_y=rot)

    def mannequin(x, z, rot=0.0, base_y=0.0):
        top, bottom = col(), col()
        b.cyl("frame_black", 0.22, 0.03, (x, base_y + 0.015, z), 10)
        b.cyl("chrome", 0.025, 0.75, (x, base_y + 0.4, z), 6)
        r = np.radians(rot)
        def P(dx, y, dz):
            return (x + dx * np.cos(r) + dz * np.sin(r), base_y + y, z - dx * np.sin(r) + dz * np.cos(r))
        b.hull(bottom, [P(sx * 0.17, 0.78, sz * 0.1) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.15, 1.0, sz * 0.1) for sx in (-1, 1) for sz in (-1, 1)])
        b.hull(top, [P(sx * 0.15, 1.0, sz * 0.1) for sx in (-1, 1) for sz in (-1, 1)] + [P(sx * 0.2, 1.42, sz * 0.11) for sx in (-1, 1) for sz in (-1, 1)])
        for sx in (-1, 1):
            b.hull(top, [P(sx * 0.2, 1.42, 0), P(sx * 0.26, 1.38, 0), P(sx * 0.27, 1.12, 0.02), P(sx * 0.22, 1.12, -0.02)])
        b.cyl("mannequin", 0.05, 0.1, (*P(0, 1.47, 0)[:1], base_y + 1.47, P(0, 1.47, 0)[2]), 6)
        b.add("mannequin", trimesh.creation.icosphere(subdivisions=1, radius=0.11).apply_translation(P(0, 1.62, 0)))

    wall = b.slot("wall", 1, "#E6B8C9")

    # =================================================================
    # AUSSEN
    # =================================================================
    b.layer = "Aussen"
    box("concrete", -W2, W2, 0, F, BZ1, SZ1)                                            # sidewalk
    box("concrete_dk", -W2, W2, 0, 0.16, SZ1 - 0.2, SZ1)
    # facade: big open shopfront, sign band, upper floor with 2 windows, parapet
    box(wall, -W2, -3.4, 0, R + 0.7, BZ1 - T, BZ1)
    box(wall, 3.4, W2, 0, R + 0.7, BZ1 - T, BZ1)
    box(wall, -3.4, 3.4, 3.0, 3.5, BZ1 - T, BZ1)
    wh = [(-2.8, -0.8), (0.8, 2.8)]
    box(wall, -3.4, 3.4, 5.1, 5.3, BZ1 - T, BZ1)
    box(wall, -3.4, 3.4, 6.3, R + 0.7, BZ1 - T, BZ1)
    for a, c in [(-3.4, wh[0][0]), (wh[0][1], wh[1][0]), (wh[1][1], 3.4)]:
        box(wall, a, c, 5.3, 6.3, BZ1 - T, BZ1)
    box(wall, -3.4, 3.4, 3.5, 5.1, BZ1 - T, BZ1)
    for (a, c) in wh:
        box("glass_open", a, c, 5.3, 6.3, BZ1 - 0.15, BZ1 - 0.12)
        box("shutter_blue", a + 0.05, (a + c) / 2 - 0.02, 5.3, 6.3, BZ1 - 0.1, BZ1 - 0.06)       # one half closed
        box("frame_black", a, c, 5.25, 5.3, BZ1, BZ1 + 0.15)
        for x in np.arange(a + 0.1, c, 0.18):
            box("frame_black", x, x + 0.025, 5.3, 6.0, BZ1 + 0.12, BZ1 + 0.15)          # grille
    box("concrete_dk", -W2, W2, R + 0.6, R + 0.75, BZ1 - T, BZ1 + 0.1)
    box("ac", 1.0, 1.8, 6.35, 6.6, BZ1, BZ1 + 0.4)
    # roll shutter box (open) + side posts
    box("metal", -3.45, 3.45, 2.95, 3.35, BZ1, BZ1 + 0.35)
    for x in (-3.45, 3.35):
        box("frame_black", x, x + 0.1, 0, 2.95, BZ1, BZ1 + 0.08)
    # huge sign
    box("cl_02", -W2 + 0.05, W2 - 0.05, 3.55, 5.05, BZ1 + 0.02, BZ1 + 0.14)
    box("price_yellow", -W2 + 0.05, W2 - 0.05, 3.55, 3.95, BZ1 + 0.14, BZ1 + 0.16)
    b.text("MEGA MODA", ["price_yellow"] * 9, (0.0, 4.68, BZ1 + 0.14), 0.52, 0.04, simplify=0.012)
    b.text("POPULAR", ["paint_white"] * 7, (0.0, 4.2, BZ1 + 0.14), 0.32, 0.03, simplify=0.012)
    b.text("TUDO A PARTIR DE R$ 10", ["price_red"] * 22, (0.0, 3.75, BZ1 + 0.16), 0.24, 0.02, simplify=0.02)
    for x in (-2.8, 2.8):                                                               # sign lamps
        b.beam("frame_black", (x, 5.05, BZ1 + 0.1), (x, 5.25, BZ1 + 0.5), 0.02)
        b.box("lamp", (0.3, 0.06, 0.12), (x, 5.22, BZ1 + 0.52), rot_x=-30)
    # awning over the sidewalk (striped), hanging stuff underneath
    AZ0, AZ1, AY0, AY1 = BZ1, SZ1 - 0.35, 3.0, 2.55
    n = 10
    for k in range(n):
        x0 = -W2 + 2 * W2 * k / n
        x1 = x0 + 2 * W2 / n
        b.hull("awning_a" if k % 2 == 0 else "awning_b",
               [(x, AY0 + dy, AZ0) for x in (x0, x1) for dy in (0, 0.03)] + [(x, AY1 + dy, AZ1) for x in (x0, x1) for dy in (0, 0.03)])
        b.hull("awning_a" if k % 2 == 0 else "awning_b", [(x, AY1, AZ1) for x in (x0, x1)] + [(x, AY1 - 0.25, AZ1 + 0.02) for x in (x0, x1)]
               + [(x, AY1, AZ1 + 0.03) for x in (x0, x1)])
    b.beam("frame_black", (-W2 + 0.05, AY1 - 0.02, AZ1), (W2 - 0.05, AY1 - 0.02, AZ1), 0.03)
    for x in (-W2 + 0.08, W2 - 0.08):
        b.beam("frame_black", (x, AY1, AZ1), (x, 0.16, AZ1 - 0.05), 0.03)
    b.beam("frame_black", (-W2 + 0.1, 2.5, AZ1 - 0.15), (W2 - 0.1, 2.5, AZ1 - 0.15), 0.02)   # hanging line
    for x in np.arange(-3.6, 3.7, 0.42):
        hang(["shirt", "dress", "shirt", "short"][int(rng.integers(0, 4))], x, 2.44, AZ1 - 0.15, 0)
    # sidewalk clutter: mannequins, rolling rack, bins, price stand, speaker, chair
    mannequin(-3.2, 7.2, 10)
    mannequin(-2.5, 7.4, -15)
    mannequin(3.3, 7.25, -10)
    for x in (-1.5, 1.7):
        b.beam("frame_black", (x - 0.7, 0.16, 7.0), (x - 0.7, 1.65, 7.0), 0.025)
        b.beam("frame_black", (x + 0.7, 0.16, 7.0), (x + 0.7, 1.65, 7.0), 0.025)
        for xx in (x - 0.7, x + 0.7):
            b.beam("frame_black", (xx, 0.16, 6.75), (xx, 0.16, 7.25), 0.025)
        rail((x - 0.7, 7.0), (x + 0.7, 7.0), 1.65, ["shirt", "shirt", "dress"], gap=0.07)
    for (x, z, m) in [(0.15, 7.45, "bin_blue"), (0.15, 6.85, "bin_green"), (2.7, 6.75, "bin_blue")]:
        box(m, x - 0.32, x + 0.32, F, 0.62, z - 0.24, z + 0.24)
        for k in range(6):
            chinelo_pair(x + rng.uniform(-0.18, 0.18), 0.6, z + rng.uniform(-0.1, 0.1), col())
        price(x, 0.8, z + 0.25, "R$10", red=k % 2 == 0)
    b.hull("wood_a", [(2.9 + dx, F, 7.65 + dz) for dx in (-0.3, 0.3) for dz in (-0.25, 0.25)] + [(2.9 + dx, 1.1, 7.65) for dx in (-0.3, 0.3)])
    b.box("price_yellow", (0.5, 0.5, 0.01), (2.9, 0.7, 7.65 + 0.13), rot_x=-27)
    box("speaker", 3.3, 3.75, F, 0.9, 6.45, 6.85)
    for y in (0.35, 0.7):
        c = trimesh.creation.cylinder(radius=0.14, height=0.02, sections=10)
        c.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
        b.add("frame_black", c.apply_translation((3.52, y, 6.86)))
    box("plastic_red", -0.9, -0.45, F, 0.55, 7.5, 7.9)                                  # plastic chair
    box("plastic_red", -0.9, -0.45, 0.55, 0.95, 7.85, 7.9)
    # side walls + back
    for x in (-W2 + T / 2, W2 - T / 2):
        box(wall, x - T / 2, x + T / 2, 0, O, BZ0, BZ1 - T)
    box(wall, -W2, W2, 0, O, BZ0, BZ0 + T)
    b.layer = "OG"                                                                      # upper walls hide with the OG level
    for x in (-W2 + T / 2, W2 - T / 2):
        box(wall, x - T / 2, x + T / 2, O, R + 0.7, BZ0, BZ1 - T)
    box(wall, -W2, W2, O, R + 0.7, BZ0, BZ0 + T)
    b.layer = "Aussen"
    box("meter", -3.95, -3.6, 1.3, 1.8, BZ1, BZ1 + 0.15)
    box("frame_black", -3.83, -3.72, 1.8, 2.95, BZ1, BZ1 + 0.06)
    b.anchor("Strom_Anschluss", (-3.78, 2.95, BZ1 + 0.03), 0)

    # =================================================================
    # EG – crammed shop
    # =================================================================
    b.layer = "EG"
    box("shop_tile", IX0, IX1, 0, F, IZ0, BZ1)
    for z in np.arange(IZ0, BZ1, 0.5):
        box("concrete_dk", IX0, IX1, F, F + 0.003, z, z + 0.01)
    for x0, x1 in ((IX0, IX0 + 0.03), (IX1 - 0.03, IX1)):
        box("plaster_cream", x0, x1, F, C, IZ0, IZ1)
    box("plaster_cream", IX0, IX1, F, C, IZ0, IZ0 + 0.03)

    # left wall: double rail full length + folded stacks on top shelf
    rail((IX0 + 0.3, -5.9), (IX0 + 0.3, 6.0), 1.25, ["shirt", "shirt", "dress", "short"], gap=0.07)
    rail((IX0 + 0.3, -5.9), (IX0 + 0.3, 6.0), 2.4, ["shirt", "pants", "shirt"], gap=0.07)
    for z in (-5.9, 0.0, 6.0):
        for y in (1.25, 2.4):
            b.beam("chrome", (IX0 + 0.03, y, z), (IX0 + 0.3, y, z), 0.015)
    box("shelf", IX0 + 0.03, IX0 + 0.5, 2.6, 2.64, -5.9, 6.0)
    for z in np.arange(-5.7, 5.9, 0.36):
        folded_stack(IX0 + 0.27, z, 2.64, int(rng.integers(3, 8)), w=0.4, d=0.3)
    for z in (-4.0, -0.5, 3.0):
        price(IX0 + 0.04, 2.0, z, "R$15", rot=90)
    # right wall front: chinelo + shoe wall, caps above; right wall back: pants rail
    for i, y in enumerate(np.arange(0.35, 2.3, 0.32)):
        box("shelf", IX1 - 0.4, IX1 - 0.03, y - 0.03, y, 1.0, 6.0)
        for z in np.arange(1.2, 5.9, 0.33):
            chinelo_pair(IX1 - 0.2, y, z, col())
    for x0, z0 in [(IX1 - 0.4, 1.0), (IX1 - 0.4, 6.0)]:
        box("shelf", IX1 - 0.4, IX1 - 0.03, F, 2.3, z0 - 0.02, z0 + 0.02)
    box("plywood", IX1 - 0.05, IX1 - 0.03, 2.4, 3.4, 1.0, 6.0)                          # cap pegboard
    for y in (2.6, 2.95, 3.3):
        for z in np.arange(1.25, 5.9, 0.3):
            cap(IX1 - 0.15, y - 0.08, z, col(), rot=-90)
    price(IX1 - 0.42, 2.4, 3.5, "R$10", rot=-90, red=True, txt=True)
    rail((IX1 - 0.3, -2.0), (IX1 - 0.3, 0.8), 1.3, ["pants"], gap=0.065)
    rail((IX1 - 0.3, -2.0), (IX1 - 0.3, 0.8), 2.45, ["pants", "short"], gap=0.065)

    # middle: double-sided rack row (left aisle) + wühltisch row (right aisle)
    for x in (-2.35, -1.75):
        rail((x, -3.8), (x, 4.8), 1.5, ["shirt", "dress", "shirt"], gap=0.07)
    for z in (-3.8, 0.5, 4.8):
        for x in (-2.35, -1.75):
            b.beam("chrome", (x, F, z), (x, 1.5, z), 0.025)
        b.beam("chrome", (-2.35, 1.5, z), (-1.75, 1.5, z), 0.02)
        b.beam("chrome", (-2.6, F + 0.02, z), (-1.5, F + 0.02, z), 0.025)
    for z in (-1.8, 2.6):
        price(-2.05, 1.75, z, "R$19,90", rot=90, red=z > 0, txt=z > 0)
        b.beam("chrome", (-2.05, 1.5, z), (-2.05, 1.62, z), 0.01)
    for (z0, z1) in [(-3.6, -1.0), (-0.4, 2.2), (2.8, 5.4)]:                            # bargain tables
        box("wood_a", -0.75, 0.75, 0.75, 0.8, z0, z1)
        for x in (-0.7, 0.7):
            for z in (z0 + 0.05, z1 - 0.05):
                box("frame_black", x - 0.03, x + 0.03, F, 0.75, z - 0.03, z + 0.03)
        for x in (-0.45, 0.0, 0.45):
            for z in np.arange(z0 + 0.25, z1 - 0.1, 0.4):
                folded_stack(x, z, 0.8, int(rng.integers(2, 6)), w=0.36, d=0.3)
        box("cardboard", -0.7, 0.7, F, 0.65, z0 + 0.1, z1 - 0.1)                       # boxes under the table
        price(0.0, 1.45, (z0 + z1) / 2, "R$10" if z0 < 0 else "R$5", rot=0, red=z0 > 0, txt=z0 > 2)
        b.beam("frame_black", (0.0, C, (z0 + z1) / 2), (0.0, 1.58, (z0 + z1) / 2), 0.008)
    # small rack wedge next to the right wall racks + bins on the floor
    for (x, z, m) in [(1.4, 5.6, "bin_blue"), (1.4, -2.6, "bin_green"), (1.5, -0.2, "bin_blue")]:
        box(m, x - 0.3, x + 0.3, F, 0.6, z - 0.25, z + 0.25)
        for k in range(8):
            b.rock(col(), 0.09, (x + rng.uniform(-0.2, 0.2), 0.62, z + rng.uniform(-0.15, 0.15)), 0.6)
    mannequin(1.6, 3.4, -90, F)
    mannequin(-3.0, -6.6, 30, F)

    # back: counter + register, fitting room, stairs, stock boxes
    box("counter", -1.6, 1.0, F, 1.0, -6.1, -5.5)
    box("price_yellow", -1.6, 1.0, 0.75, 0.95, -5.5, -5.48)
    b.text("CAIXA", ["price_red"] * 5, (-0.3, 0.85, -5.48), 0.14, 0.01, simplify=0.004)
    box("frame_black", -1.0, -0.5, 1.0, 1.25, -6.0, -5.7)                               # old register
    b.box("frame_black", (0.35, 0.22, 0.04), (-0.75, 1.35, -5.95), rot_x=-15)
    box("screen" if "screen" in PALETTE else "glass", -0.9, -0.6, 1.28, 1.42, -5.94, -5.92)
    for x in np.arange(-1.5, 0.9, 0.22):                                                # plastic bags roll behind
        b.box("plastic_white", (0.18, 0.3, 0.02), (x, 1.2, -6.15))
    box("shelf", -1.6, 1.0, 1.7, 1.74, IZ0 + 0.03, IZ0 + 0.45)
    for x in np.arange(-1.4, 0.9, 0.42):
        box("cardboard", x - 0.18, x + 0.18, 1.74, 2.1, IZ0 + 0.08, IZ0 + 0.42)
    box("cardboard", -1.5, -0.7, F, 0.5, IZ0 + 0.1, IZ0 + 0.6)
    box("cardboard", -1.4, -0.8, 0.5, 0.9, IZ0 + 0.1, IZ0 + 0.55)
    b.anchor("Kasse", (-0.3, F, -5.0), 0)
    # fitting room (single cubicle with curtain)
    box("plywood", IX0, -2.2, F, 2.4, -6.25, -6.2)
    box("plywood", -2.25, -2.2, F, 2.4, IZ0, -6.2)
    b.beam("chrome", (IX0, 2.3, -6.15), (-2.2, 2.3, -6.15), 0.015)
    for k, x in enumerate(np.arange(IX0 + 0.05, -2.3, 0.2)):
        box("cl_01", x, x + 0.2, 0.4, 2.25, -6.18 + 0.03 * (k % 2), -6.14 + 0.03 * (k % 2)) if x < -2.9 else None
    box("mirror" if "mirror" in PALETTE else "glass", IX0 + 0.04, IX0 + 0.06, 0.4, 2.0, -7.5, -6.6)
    b.text("PROVADOR", ["paint_white"] * 8, (-3.0, 2.55, -6.17), 0.12, 0.01, simplify=0.004)
    b.anchor("Provador", (-3.0, F, -7.0), 0)
    # stairs to the stock room (back-right, along the wall, rising to -Z)
    n = 22
    for k in range(n):
        z = -2.4 - 5.0 * k / n
        y = F + (O - F) * (k + 1) / n
        box("concrete_dk", 2.95, IX1, y - 0.05, y, z - 5.0 / n - 0.01, z)
        box("cardboard", 3.0, IX1 - 0.05, F, min(y - 0.1, 1.0), z - 5.0 / n * 3, z) if k > 6 and k % 6 == 0 else None
    b.beam("metal", (2.95, F + 0.9, -2.4), (2.95, O + 0.9, -7.4), 0.025)
    for k in range(0, n + 1, 5):
        z = -2.4 - 5.0 * k / n
        y = F + (O - F) * k / n
        b.beam("metal", (2.95, y, z), (2.95, y + 0.9, z), 0.02)
    for (x, z, s) in [(2.0, -7.2, 0.5), (2.3, -6.7, 0.4), (1.7, -6.6, 0.45)]:          # black stock sacks
        b.rock("sack", s, (x, F + s * 0.5, z), 0.8)
    b.anchor("Ladeninnen", (0.0, F, 0.5), 0)

    # =================================================================
    # OG – stock room (+ EG ceiling slab), crammed with boxes and sacks
    # =================================================================
    b.layer = "OG"
    box("concrete", IX0, 2.95, C, O, IZ0, IZ1)                                          # slab with stair hole
    box("concrete", 2.95, IX1, C, O, -2.4, IZ1)
    box("concrete", 2.95, IX1, C, O, IZ0, -7.4)
    b.beam("metal", (2.95, O + 1.0, -2.4), (2.95, O + 1.0, -7.4), 0.025)                # railing around the hole
    b.beam("metal", (2.95, O + 1.0, -2.4), (IX1, O + 1.0, -2.4), 0.025)
    for z in np.arange(IZ0 + 0.4, IZ1 - 0.6, 0.9):
        for x in np.arange(IX0 + 0.35, 2.4, 0.9):
            h = int(rng.integers(1, 4))
            for k in range(h):
                box("cardboard", x - 0.3, x + 0.3, O + k * 0.45, O + k * 0.45 + 0.42, z - 0.28, z + 0.28)
    for (x, z) in [(3.2, 1.0), (3.3, 3.0), (3.0, 4.8), (3.3, -1.2)]:
        b.rock("sack", 0.5, (x, O + 0.3, z), 0.75)
    b.layer = "OG"

    # =================================================================
    # DACH – EG ceiling clutter (hidden when looking in) + roof
    # =================================================================
    b.layer = "Dach"
    box("dach_decke", IX0, IX1, C - 0.04, C, IZ0, IZ1)
    for z in (-4.0, 0.0, 4.0):                                                          # tube lights
        box("dach_licht", -1.2, 1.2, C - 0.1, C - 0.04, z - 0.08, z + 0.08)
    b.cyl("dach_fan", 0.08, 0.3, (0.0, C - 0.2, -1.8), 8)                               # ceiling fan
    for a in (0, 120, 240):
        b.box("dach_fan", (0.6, 0.02, 0.14), (0.3 * np.cos(np.radians(a)), C - 0.36, -1.8 + 0.3 * np.sin(np.radians(a))), rot_y=-a)
    for z in np.arange(-5.0, 5.8, 0.9):                                                 # hanging garments + bags from the ceiling
        for x in (-1.3, 1.0):
            hang("shirt" if rng.random() < 0.6 else "dress", x + rng.uniform(-0.2, 0.2), C - 0.05, z, 0)
    for z in np.arange(-4.5, 5.5, 2.2):                                                 # paper promo banners
        for k, x in enumerate(np.arange(-2.8, 2.9, 0.4)):
            tri = [(x, C - 0.05), (x + 0.4, C - 0.05), (x + 0.2, C - 0.32)]
            b.hull("price_yellow" if k % 2 else "price_red", [(px, py, z + dz) for px, py in tri for dz in (0.0, 0.01)])
    box("dach", -W2, W2, R, R + 0.25, BZ0, BZ1)
    b.cyl("tank", 0.6, 1.1, (-2.0, R + 0.8, -5.0), 10)
    b.cyl("tank_lid", 0.62, 0.08, (-2.0, R + 1.38, -5.0), 10)
    box("ac", 1.5, 2.6, R + 0.25, R + 1.0, -3.0, -2.2)

    b.layer = None
    b.anchor("Eingang", (0.0, 0, BZ1 + 0.3), 0)
    return b
