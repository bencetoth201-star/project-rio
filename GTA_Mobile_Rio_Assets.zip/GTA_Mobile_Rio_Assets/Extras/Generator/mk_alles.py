"""Alle Rio-Pakete in EINEN Ordner (+ ZIP): pack/GTA_Mobile_Rio_Assets"""
import glob, json, os, shutil

OUT = "pack/GTA_Mobile_Rio_Assets"
PAKETE = [  # (Ordner, Name, Anleitung, Kurzname)
    ("RioHaeuser_Unity", "Häuser & Spezialgebäude", "ANLEITUNG_CLAUDE_CODE.md", "HAEUSER"),
    ("RioStrassen_Unity", "Straßennetz", "ANLEITUNG_CLAUDE_CODE_STRASSEN.md", "STRASSEN"),
    ("RioStrand_Unity", "Strand", "ANLEITUNG_CLAUDE_CODE_STRAND.md", "STRAND"),
    ("RioHafen_Unity", "Hafen", "ANLEITUNG_CLAUDE_CODE_HAFEN.md", "HAFEN"),
    ("RioFahrzeuge_Unity", "Fahrzeuge", "ANLEITUNG_CLAUDE_CODE_FAHRZEUGE.md", "FAHRZEUGE"),
]
shutil.rmtree(OUT, ignore_errors=True)
os.makedirs(f"{OUT}/Docs")
os.makedirs(f"{OUT}/Extras/Generator")
zahlen = []
for ordner, name, doc, kurz in PAKETE:
    src = f"pack/{ordner}"
    shutil.copytree(f"{src}/Assets", f"{OUT}/Assets", dirs_exist_ok=True)
    shutil.copy(f"{src}/{doc}", f"{OUT}/Docs/ANLEITUNG_{kurz}.md")
    if os.path.exists(f"{src}/LIESMICH.md"):
        shutil.copy(f"{src}/LIESMICH.md", f"{OUT}/Docs/LIESMICH_{kurz}.md")
    if os.path.isdir(f"{src}/Extras/OBJ"):
        shutil.copytree(f"{src}/Extras/OBJ", f"{OUT}/Extras/OBJ/{kurz.capitalize()}")
    for f in glob.glob(f"{src}/Extras/Generator/*.py"):
        shutil.copy(f, f"{OUT}/Extras/Generator/")
    n = len(glob.glob(f"{src}/Assets/**/*.glb", recursive=True))
    zahlen.append((name, ordner.replace("_Unity", ""), n, kurz))
shutil.copytree("unity/Gemeinsam", f"{OUT}/Assets/RioGemeinsam", dirs_exist_ok=True)
for f in ("mk_alles.py",):
    shutil.copy(f, f"{OUT}/Extras/Generator/")
gesamt = sum(z[2] for z in zahlen)
tab = "\n".join(f"| {n} | `Assets/{o}/` | {k} | `Docs/ANLEITUNG_{kurz}.md` |" for (n, o, k, kurz) in zahlen)

HITBOXEN = """## Hitboxen (gilt für alle Modelle)
Jedes GLB bringt unsichtbare Zusatz-Nodes mit:
- **`<Ebene>__kollision`** – vereinfachte feste Hitbox pro Ebene: Wände, Böden, Treppen, Geländer-Handläufe, Möbel und Fahrzeuge
  als einfache Blöcke. **Nicht fest:** Kleinkram unter 30 cm (Ringe, Edelsteine, Flaschen, Schrift), flache Teppiche und
  Markierungen, dünne Stäbe (Geländerstäbe, Gitterstäbe, Fensterrahmen, Stuhlbeine), Lichtkegel, Wasserfontänen, Palmwedel.
- **`<Ebene>__trigger_<n>`** – Auslöser ohne feste Wand: Laserstrahlen, Pools, Flutwasser (convex, `isTrigger`).
- **Bewegliche Teile** (Türen, Tore, Vitrinen-Hauben, Laser, Aufzüge, Tresortüren, Boote, Hubschrauber …) sind eigene Nodes
  mit Pivot am Scharnier/Drehpunkt; ihre `…__kollision`/`…__trigger_<n>`-Kinder bewegen sich mit.

**In Unity einrichten:** Menü **Tools ▸ Rio ▸ Hitboxen einrichten (Auswahl | ganze Szene)** (Skripte in `Assets/RioGemeinsam`).
Das macht die Zusatz-Nodes unsichtbar, setzt `MeshCollider` (Trigger: convex + isTrigger), entfernt alte Voll-MeshCollider,
gibt beweglichen Teilen einen kinematischen `Rigidbody` und markiert alles andere als statisch (bewegliche Teile nie – sonst
bewegt sich die Grafik nicht mit). Der Häuser-Platzierer (`Tools ▸ Rio Häuser ▸ Platzhalter ersetzen`) erledigt das automatisch.
- **Wichtig:** keine eigenen MeshCollider auf die Grafik-Meshes legen (teuer und falsch bei Lasern/Lichtkegeln).
- **Zur Laufzeit gespawnt:** `RioKollision.Einrichten(instanz);` aufrufen. Dafür im glTFast-Importer „Read/Write“ der Meshes
  aktivieren (sonst kann Unity die Collider zur Laufzeit nicht bauen). Im Editor platzierte Modelle brauchen das nicht.
- **Heist-Logik:** Laser aus = Laser-Node deaktivieren (Trigger geht mit). Alarm = `OnTriggerEnter` am Trigger
  (der Spieler braucht `CharacterController` oder `Rigidbody`). Tür auf = beweglichen Node drehen/verschieben.
  Bewegliche Teile findet man mit `RioKollision.IstBeweglich(transform)`.
- **Fahrzeuge** (BMW M4) bekommen weiter BoxCollider + WheelCollider wie in ihrer Anleitung.
- **Kosten:** Hitboxen haben zusammen ~50 % der Grafik-Dreiecke (Containerschiff ~28.000, Stadion ~23.000, Kleiderladen ~18.000,
  normale Häuser 700–4.500, Straßenteile meist < 1.500).
"""

readme = f"""# GTA Mobile – Rio-Assets (alles in einem Ordner)

{gesamt} Modelle im Low-Poly-Stil für Rio de Janeiro: Häuser und Spezialgebäude, Straßen, Strand, Hafen mit Containerschiff, Fahrzeuge.
Die Heist-Schauplätze (Casa Império + Megayacht SOBERANA) sind **nicht** mehr hier drin – sie liegen im eigenen Paket **RioHeists**. Einheiten: 1 = 1 m, Y oben. Import über **glTFast**.

## Installation
1. Paket **glTFast** in Unity installieren (Package Manager ▸ `com.unity.cloud.gltfast`).
2. Den Ordner **`Assets`** aus diesem Paket in dein Projekt ziehen (alles landet unter `Assets/Rio…`).
3. **Tools ▸ Rio ▸ Hitboxen einrichten** für platzierte Modelle ausführen (Häuser-Platzierer macht das selbst).

## Inhalt
| Paket | Ordner | Modelle | Anleitung |
|---|---|---|---|
{tab}
| Gemeinsame Skripte (Hitboxen) | `Assets/RioGemeinsam/` | – | dieses Dokument |

`Extras/OBJ/<Paket>/` – dieselben Modelle als .obj/.mtl (ohne Anker, ohne Hitboxen) · `Extras/Generator/` – Python-Generatoren.

{HITBOXEN}"""
open(f"{OUT}/LIESMICH.md", "w").write(readme)
anleitung = f"""# Anleitung für Claude Code: GTA Mobile – Rio-Assets (Gesamtpaket)

Dieses Paket fasst alle Rio-Pakete zusammen. Lies zuerst dieses Dokument, dann die Anleitung des Pakets, mit dem du arbeitest.

## Aufbau
```
Assets/RioGemeinsam/   RioKollision.cs (Laufzeit) + Editor/RioKollisionEditor.cs (Menü Tools ▸ Rio ▸ Hitboxen einrichten)
Assets/RioHaeuser/     {zahlen[0][2]} Gebäude + Platzierer (Tools ▸ Rio Häuser ▸ Platzhalter ersetzen), RioHausFarben, haeuser.json
Assets/RioStrassen/    Straßennetz-Baukasten + strassen.json
Assets/RioStrand/      Strandobjekte + strand.json
Assets/RioHafen/       Hafen-Baukasten, Containerschiff + hafen.json
Assets/RioFahrzeuge/   Fahrzeuge + fahrzeuge.json
Docs/                  Anleitungen pro Paket (Koordinaten, Anker, bewegliche Teile, Heist-Details)
```
| Paket | Modelle | Anleitung |
|---|---|---|
""" + "\n".join(f"| {n} | {k} | `Docs/ANLEITUNG_{kurz}.md` |" for (n, o, k, kurz) in zahlen) + f"""

## Heists (eigenes Paket)
Casa Império („Megabank“) und die Megayacht SOBERANA sind ein **separates Paket** (`RioHeists_fuer_ClaudeCode.zip` → `Assets/RioHeists`,
Anleitung `ANLEITUNG_CLAUDE_CODE_HEISTS.md` mit Ablauf, Beute, Wachen, Fluchtwegen). Es nutzt dieselben Skripte in `Assets/RioGemeinsam`.
Der Häuser-Platzierer überspringt Platzhalter mit `_palast`, `_imperio`, `_megabank`, `_heist` oder `_yacht` – die setzt
**Tools ▸ Rio Heists ▸ Platzhalter ersetzen** aus dem Heist-Paket.

## Gemeinsame Regeln
- 1 Einheit = 1 m, Y oben. glTFast spiegelt X beim Import → Ankerpositionen immer aus den Child-Transforms lesen.
- Node-Namen: `<Ebene>__<Material>` = Grafik, `<Ebene>_Innen__…` = Einrichtung, `<Ebene>__kollision` / `__trigger_<n>` = Hitboxen,
  Nodes ohne `__` mit Kindern = bewegliche Teile (Pivot am Scharnier), leere Nodes = Anker.
- Farben würfeln: `RioHausFarben` auf das Modell (Slots `slot_*`).
- Streaming: Außenhülle immer an, `*_Innen`-Nodes erst aktivieren, wenn der Spieler im Gebäude/an Bord ist.

{HITBOXEN}"""
open(f"{OUT}/ANLEITUNG_CLAUDE_CODE.md", "w").write(anleitung)
if os.path.exists(f"{OUT}.zip"):
    os.remove(f"{OUT}.zip")
z = shutil.make_archive(OUT, "zip", "pack", "GTA_Mobile_Rio_Assets")
print("ok", gesamt, z, os.path.getsize(z) // 1024, "KB")
