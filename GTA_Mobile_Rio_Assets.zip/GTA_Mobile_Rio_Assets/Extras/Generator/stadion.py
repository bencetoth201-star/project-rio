"""Estádio do Rio – großes Fußballstadion nach dem Vorbild des Maracanã (fiktiver Name), Maßstab 1:1.
Oval ~264 x 230 m (Dach), Höhe ~41 m, Grundstück 300 x 264 m mit Vorplatz, 2 lange Zugangsrampen an der Front (+Z).
Spielfeld 105 x 68 m in Längsrichtung X, Mitte = Pivot. Ebenen: Aussen (Vorplatz, Stützen, Fassade, Rampen),
EG (Spielfeld + Unterrang), OG (Oberrang + VIP-Logen), Dach (Membrandach, Flutlicht, Videowände)."""
import numpy as np
import trimesh
from lib import B, PALETTE

PALETTE.update({
    "seat_yellow": "#F2C230", "seat_blue": "#2453A6", "seat_white": "#EDEDE8", "roof_white": "#F4F4F0",
    "dach_membran": "#F4F4F0", "dach_stahl": "#9BA3AA", "pitch_a": "#3E9B3A", "pitch_b": "#348A31", "grass_dark": "#2F6E2C",
    "vip_glass": "#1E2A33", "dach_screen": "#2FE0F0", "plaza": "#CFCAC0", "stand_concrete": "#B8B4AC", "facade_white": "#E9E7E1",
})
for k, v in {"screen": "#2FE0F0", "concrete_white": "#E2DED4", "fence_net": "#E8E8E8"}.items():
    PALETTE.setdefault(k, v)

A0, B0 = 72.0, 56.0          # inner ellipse (front of the lower tier)
N = 96                       # segments around


def stadion():
    b = B(1950)
    rng = np.random.default_rng(1950)

    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def ring(profile, mat_of, ks=None, yoff=None, a0=A0, b0=B0, n=N):
        """Sweep a closed CCW (d, y) profile around the ellipse. mat_of(j, k) → material or None (skip).
        Faces are wound so their normals point away from the profile interior."""
        ks = range(n) if ks is None else ks
        th = np.linspace(0, 2 * np.pi, n + 1)
        acc = {}
        m = len(profile)
        for k in ks:
            for j in range(m):
                mat = mat_of(j, k)
                if mat is None:
                    continue
                (d0, y0), (d1, y1) = profile[j], profile[(j + 1) % m]
                quad = []
                for (kk, d, y) in ((k, d0, y0), (k, d1, y1), (k + 1, d1, y1), (k + 1, d0, y0)):
                    t = th[kk]
                    dy = yoff(kk, d) if yoff else 0.0
                    quad.append(((a0 + d) * np.cos(t), y + dy, (b0 + d) * np.sin(t)))
                q = np.array(quad)
                # expected outward direction for this profile edge
                en = np.array([y1 - y0, -(d1 - d0)])                      # (d-normal, y-normal)
                tm = (th[k] + th[k + 1]) / 2
                radial = np.array([np.cos(tm) / (a0 + 1e-9) * a0, 0, np.sin(tm)])
                radial /= np.linalg.norm(radial)
                want = radial * en[0] + np.array([0, 1, 0]) * en[1]
                n1 = np.cross(q[1] - q[0], q[2] - q[0])
                tris = [(0, 1, 2), (0, 2, 3)] if np.dot(n1, want) >= 0 else [(0, 2, 1), (0, 3, 2)]
                V, F = acc.setdefault(mat, ([], []))
                base = len(V)
                V.extend(q.tolist())
                F.extend([(base + a, base + c, base + e) for a, c, e in tris])
        for mat, (V, F) in acc.items():
            b.add(mat, trimesh.Trimesh(np.array(V), np.array(F), process=False))

    def P(d, t, y=0.0):
        return np.array([(A0 + d) * np.cos(t), y, (B0 + d) * np.sin(t)])

    def seat_mat(frac, k, row):
        if k % 8 == 0:
            return "concrete_light"                                   # aisle stairs
        v = frac + 0.18 * np.sin(k * 2 * np.pi / N * 5 + row * 0.3) + rng.uniform(-0.18, 0.18)
        return "seat_yellow" if v < 0.38 else ("seat_blue" if v < 0.72 else "seat_white")

    def stepped(d0, y0, d1, y1, rows, front_h, back_bottom=None):
        """Closed CCW profile: bottom (optionally sloped) → back → treads/risers down → front parapet."""
        yb0 = y0 - front_h
        yb1 = yb0 if back_bottom is None else back_bottom
        prof = [(d0, yb0), (d1, yb1), (d1, y1)]
        kinds = ["bottom", "back"]
        td, rh = (d1 - d0) / rows, (y1 - y0) / rows
        for i in range(rows):
            d, y = d1 - (i + 1) * td, y1 - i * rh
            prof += [(d, y), (d, y - rh)]
            kinds += [("tread", rows - 1 - i), "riser"]
        kinds.append("front")
        return prof, kinds, rows

    # =================================================================
    # AUSSEN – plaza, colonnade, inner ground wall with gates, facade, ramps, sign, palms
    # =================================================================
    b.layer = "Aussen"
    box("plaza", -150, 150, 0, 0.05, -132, 132)
    for k in range(12):                                                                  # paving bands
        t = k * np.pi / 6
        p0, p1 = P(62, t, 0.051), P(78, t, 0.051)
        b.beam("concrete_dk", tuple(p0), tuple(p1), 0.4)
    ring([(62, 0.0), (78, 0.0), (78, 0.06), (62, 0.06)], lambda j, k: "stone_white" if j == 2 else None)
    # ground floor wall (shops/turnstiles) with 16 gates
    gates = set(range(0, N, 6))
    ring([(44, 0.0), (45, 0.0), (45, 14.0), (44, 14.0)], lambda j, k: "facade_white" if j in (1, 3) else None, ks=[k for k in range(N) if k not in gates])
    ring([(44, 5.0), (45, 5.0), (45, 14.0), (44, 14.0)], lambda j, k: "facade_white" if j in (0, 1, 3) else None, ks=sorted(gates))
    ring([(44.3, 0.0), (44.6, 0.0), (44.6, 5.0), (44.3, 5.0)], lambda j, k: "gate_metal" if j in (1, 3) else None, ks=sorted(gates))
    # 48 big outer columns + compression ring at the top
    for i in range(48):
        t = i * 2 * np.pi / 48
        p = P(61.0, t)
        nrm = np.array([np.cos(t) / (A0 + 61) , 0, np.sin(t) / (B0 + 61)])
        yaw = np.degrees(np.arctan2(nrm[0], nrm[2]))
        b.box("facade_white", (2.2, 40.0, 3.2), (p[0], 20.0, p[2]), rot_y=yaw)
    ring([(59.5, 38.4), (63.5, 38.4), (63.5, 40.8), (59.5, 40.8)], lambda j, k: "facade_white")
    # main entrance sign on the plaza (front)
    box("facade_white", -34, 34, 0.05, 1.2, 124.5, 127.5)
    b.text("ESTÁDIO DO RIO", ["seat_blue"] * 14, (0.0, 3.4, 126.0), 4.0, 1.2, simplify=0.05)
    # two long access ramps (front), ground → concourse level +14 m
    for s in (-1, 1):
        zc, w = 119.0, 6.0
        x_top, x_bot = s * 24.0, s * 104.0
        b.hull("stand_concrete", [(x, y + dy, zc + dz) for (x, y) in ((x_top, 14.0), (x_bot, 0.05)) for dy in (0, -0.7) for dz in (-w / 2, w / 2)])
        for dz in (-w / 2, w / 2):
            b.hull("facade_white", [(x, y + dy, zc + dz + e) for (x, y) in ((x_top, 14.0), (x_bot, 0.05)) for dy in (0, 1.1) for e in (-0.12, 0.12)])
        box("stand_concrete", min(s * 14.0, s * 24.0), max(s * 14.0, s * 24.0), 13.3, 14.0, 108.0, 122.0)   # landing into the facade
        for x in np.arange(30.0, 100.0, 12.0):
            y = 14.0 * (1 - (x - 24.0) / 80.0)
            box("facade_white", s * x - 0.6, s * x + 0.6, 0.05, y - 0.7, zc - 0.6, zc + 0.6)
    for i in range(28):                                                                  # palms around the plaza
        t = (i + 0.5) * 2 * np.pi / 28
        p = P(74.0, t)
        if p[2] > 105 and abs(p[0]) < 110:
            continue
        b.palm(p[0], p[2], 9.0 + (i % 3), (0.4 * np.cos(i), 0.3 * np.sin(i)))
    for (x, z) in [(-140, -120), (140, -120), (-140, 120), (140, 120), (-140, 0), (140, 0)]:
        box("grass", x - 9, x + 9, 0.05, 0.1, z - 10, z + 10)

    # =================================================================
    # EG – pitch, boards, goals, benches, lower tier (14 bands)
    # =================================================================
    b.layer = "EG"
    ring([(-A0, 0.0), (0.0, 0.0), (0.0, 0.08), (-A0 + 0.01, 0.08)], lambda j, k: "grass_dark" if j == 2 else None)
    for i in range(10):                                                                  # mowing stripes
        x0 = -52.5 + i * 10.5
        box("pitch_a" if i % 2 else "pitch_b", x0, x0 + 10.5, 0.08, 0.12, -34, 34)
    L = 0.12
    def line(x0, x1, z0, z1):
        box("paint_white", x0, x1, 0.12, 0.13, z0, z1)
    line(-52.5, 52.5, -34, -34 + L); line(-52.5, 52.5, 34 - L, 34)
    line(-52.5, -52.5 + L, -34, 34); line(52.5 - L, 52.5, -34, 34)
    line(-L / 2, L / 2, -34, 34)
    for s in (-1, 1):
        xg = s * 52.5
        for (dx, hw) in ((16.5, 20.16), (5.5, 9.16)):
            xi = xg - s * dx
            line(min(xg, xi), max(xg, xi), -hw, -hw + L); line(min(xg, xi), max(xg, xi), hw - L, hw)
            line(xi - L / 2, xi + L / 2, -hw, hw)
        b.cyl("paint_white", 0.15, 0.012, (xg - s * 11.0, 0.126, 0.0), 8)
        # goal
        for z in (-3.66, 3.66):
            box("paint_white", xg - 0.06, xg + 0.06, 0.12, 2.56, z - 0.06, z + 0.06)
            b.beam("paint_white", (xg, 2.5, z), (xg + s * 2.0, 0.12, z), 0.05)
        box("paint_white", xg - 0.06, xg + 0.06, 2.44, 2.56, -3.72, 3.72)
        box("fence_net", min(xg, xg + s * 2.0), max(xg, xg + s * 2.0), 0.12, 2.44, -3.66, -3.64)
        box("fence_net", min(xg, xg + s * 2.0), max(xg, xg + s * 2.0), 0.12, 2.44, 3.64, 3.66)
        box("fence_net", xg + s * 1.98, xg + s * 2.0, 0.12, 1.0, -3.66, 3.66)
        b.hull("fence_net", [(xg, 2.44, -3.66), (xg, 2.44, 3.66), (xg, 2.46, -3.66), (xg, 2.46, 3.66),
                             (xg + s * 2.0, 1.0, -3.66), (xg + s * 2.0, 1.0, 3.66)])
    circ = trimesh.creation.annulus(r_min=9.15 - L, r_max=9.15, height=0.01, sections=40)
    circ.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    b.add("paint_white", circ.apply_translation((0, 0.125, 0)))
    b.cyl("paint_white", 0.15, 0.012, (0, 0.126, 0), 8)
    # LED advertising boards around the pitch
    for (x0, x1, z0, z1) in [(-58, 58, -40.2, -40.0), (-58, -4, 40.0, 40.2), (4, 58, 40.0, 40.2), (-58.2, -58, -40, 40), (58, 58.2, -40, 40)]:
        box("screen", x0, x1, 0.12, 1.0, z0, z1)
        box("frame_black", x0, x1, 0.12, 0.2, z0 - 0.05 if z1 - z0 < 1 else z0, z1 + 0.05 if z1 - z0 < 1 else z1)
    # benches (front side) + tunnel exit
    for s in (-1, 1):
        x = s * 12.0
        box("frame_black", x - 6, x + 6, 0.12, 0.25, 44.0, 47.0)
        box("seat_blue", x - 5.8, x + 5.8, 0.25, 0.75, 45.6, 46.8)
        box("glass_shop", x - 6, x + 6, 2.2, 2.3, 43.8, 47.0)
        box("glass_shop", x - 6.0, x + 6.0, 0.25, 2.2, 46.9, 47.0)
    b.anchor("Spielfeld_Mitte", (0, 0.12, 0), 0)
    b.anchor("Tor_West", (-52.5, 0.12, 0), 90)
    b.anchor("Tor_Ost", (52.5, 0.12, 0), -90)
    b.anchor("Spielertunnel", (0, 0.12, B0 - 1.0), 180)

    # lower tier: front parapet 1.2 m, 14 bands up to +12 m at d = 26
    prof, kinds, rows = stepped(0.0, 1.2, 26.0, 12.0, 14, 1.2)
    tunnel_k = {N // 4, N // 4 - 1}
    def lower_mat(j, k):
        kd = kinds[j]
        if kd == "bottom":
            return None
        if isinstance(kd, tuple):
            return seat_mat(kd[1] / rows * 0.6, k, kd[1])
        if kd == "front":
            return "vip_glass" if k in tunnel_k else "facade_white"
        return "stand_concrete"
    ring(prof, lower_mat)

    # =================================================================
    # OG – upper tier (18 bands) + VIP glass band + facade
    # =================================================================
    b.layer = "OG"
    prof2, kinds2, rows2 = stepped(28.0, 16.2, 58.0, 36.0, 18, 2.2, back_bottom=22.0)
    def upper_mat(j, k):
        kd = kinds2[j]
        if kd == "bottom":
            return "stand_concrete"
        if kd == "back":
            return "facade_white"
        if isinstance(kd, tuple):
            return seat_mat(0.35 + kd[1] / rows2 * 0.65, k, kd[1] + 20)
        if kd == "front":
            return "vip_glass"
        return "stand_concrete"
    ring(prof2, upper_mat)
    ring([(58.0, 22.0), (60.0, 22.0), (60.0, 36.0), (58.0, 36.0)], lambda j, k: "stand_concrete" if j == 0 else ("facade_white" if j in (1, 2) else None))
    # upper concourse walkway (+14 m) behind the columns – the ramps arrive here
    ring([(45.0, 13.4), (60.6, 13.4), (60.6, 14.0), (45.0, 14.0)], lambda j, k: "stand_concrete")
    ring([(60.3, 14.0), (60.6, 14.0), (60.6, 15.1), (60.3, 15.1)], lambda j, k: "facade_white" if j in (1, 2, 3) else None,
         ks=[k for k in range(N) if not 19 <= k <= 29])
    for y in (24.0, 28.5, 33.0):                                                         # facade slits
        ring([(60.0, y), (60.15, y), (60.15, y + 0.9), (60.0, y + 0.9)], lambda j, k: "vip_glass" if j == 1 else None)
    ring([(26.0, 12.0), (28.5, 12.0), (28.5, 14.0), (26.0, 14.0)], lambda j, k: "vip_glass" if j == 3 else ("stand_concrete" if j == 2 else None))
    b.anchor("Tribuene_Haupt", tuple(P(14.0, np.pi / 2, 6.5)), 180)
    b.anchor("VIP_Loge", tuple(P(27.0, np.pi / 2, 14.0)), 180)

    # =================================================================
    # DACH – ribbed membrane ring, inner tension ring with floodlights, 2 video screens
    # =================================================================
    b.layer = "Dach"
    zig = lambda kk, d: 1.1 * (kk % 2 == 0) * (d - 20.0) / 42.0
    ring([(20.0, 36.9), (62.0, 39.7), (62.0, 40.1), (20.0, 37.3)], lambda j, k: "dach_membran", yoff=zig)
    ring([(19.4, 36.3), (20.4, 36.3), (20.4, 37.5), (19.4, 37.5)], lambda j, k: "dach_stahl")
    for k in range(0, N, 2):
        t = k * 2 * np.pi / N
        b.beam("dach_stahl", tuple(P(20.0, t, 36.8)), tuple(P(61.0, t, 39.6)), 0.25)
        b.box("dach_licht", (2.4, 0.3, 1.0), tuple(P(19.9, t + np.pi / N, 36.1)), rot_y=-np.degrees(t) + 90)
    for s in (-1, 1):
        x = s * (A0 + 21.0)
        b.beam("dach_stahl", (x, 37.0, -4.0), (x, 32.0, -4.0), 0.12)
        b.beam("dach_stahl", (x, 37.0, 4.0), (x, 32.0, 4.0), 0.12)
        box("frame_black", x - 0.6, x + 0.6, 24.0, 32.5, -11.0, 11.0)
        box("dach_screen", x - s * 0.62, x - s * 0.6, 24.4, 32.1, -10.6, 10.6)

    b.layer = None
    b.anchor("Eingang_Haupt", (0, 0.05, 104.0), 0)
    for name, t in (("Eingang_Ost", 0.0), ("Eingang_Nord", -np.pi / 2), ("Eingang_West", np.pi)):
        b.anchor(name, tuple(P(46.0, t, 0.05)), float(np.degrees(np.arctan2(np.cos(t), np.sin(t)))))
    b.anchor("Rampe_Ost_Unten", (104.0, 0.05, 119.0), 90)
    b.anchor("Rampe_West_Unten", (-104.0, 0.05, 119.0), -90)
    return b
