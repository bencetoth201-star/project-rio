"""15 low-poly Rio houses, poor -> rich.

Run:  python3 houses.py                 -> out/<slug>.glb/.obj/.mtl + out/meta.json
      python3 houses.py --varianten 5   -> additionally out/varianten/<slug>_vN.glb (random colours)

Materials named slot_<kind>_<n> are recolourable (see lib.SLOT_PALETTES).
Y-up, meters, pivot at ground centre, front facade faces +Z.
"""
import json
import os
import sys
import numpy as np
import trimesh
from lib import B, fpos, fsize, export, SLOT_PALETTES
from tankstelle import tankstelle
from luxus import mansao_leblon, mansao_joatinga
from bank import bank
import buildings2
from nightclub import nightclub
from tuning import tuning
from loja import loja
from stadion import stadion
from juwelier import juwelier


def dish(b, pos, r=0.32, mat="cloth_white"):
    m = trimesh.creation.cone(radius=r, height=0.1, sections=8)
    m.apply_transform(trimesh.transformations.rotation_matrix(np.radians(-150), [1, 0, 0]))
    m.apply_translation(pos)
    b.add(mat, m)


# =====================================================================
# SEHR ARM
# =====================================================================
def barraco():
    b = B(11)
    r = b.rng
    w1 = b.slot("wall", 1, "#3FA39A")
    d1 = b.slot("door", 1, "#3E7D4F")
    a1 = b.slot("accent", 1, "#2E5FA8")
    a2 = b.slot("accent", 2, "#C8372D")
    W, D, H, base = 4.2, 4.6, 2.3, 0.35
    yH = base + H
    rise = 0.35
    b.box("brick_raw", (W, base, D), (0, base / 2, 0))
    b.box("wood_dark", (W - 0.1, H, D - 0.1), (0, base + H / 2, 0))
    hw, hd = (W - 0.1) / 2, (D - 0.1) / 2
    b.hull("wood_dark", [(sx * hw, yH, sz * hd) for sx in (-1, 1) for sz in (-1, 1)] +
           [(sx * hw, yH + rise, hd) for sx in (-1, 1)])
    for face, plane, length in [("z+", D / 2 - 0.05, W), ("z-", -(D / 2 - 0.05), W),
                                ("x+", W / 2 - 0.05, D), ("x-", -(W / 2 - 0.05), D)]:
        u = -length / 2
        while u < length / 2 - 0.05:
            w = min(r.uniform(0.8, 1.4), length / 2 - u)
            mat = r.choice(["wood_a", "wood_b", "plywood", "tin_rust", w1, "wood_b"])
            hh = H - r.uniform(0.0, 0.2)
            b.box(mat, fsize(face, w - 0.03, hh, 0.04), fpos(face, plane, u + w / 2, base + hh / 2, 0.02))
            if mat in ("wood_a", "wood_b", w1):
                for k in range(1, int(w / 0.28)):
                    b.box("wood_dark", fsize(face, 0.025, hh, 0.02), fpos(face, plane, u + k * 0.28, base + hh / 2, 0.045))
            u += w
    fz = D / 2 - 0.05 + 0.04
    b.door("z+", fz, 0.95, 0.8, 1.85, d1, y0=base, frame="wood_dark")
    b.window("z+", fz, -0.9, base + 1.35, 0.7, 0.6, bars=False, frame="wood_dark", glass="glass_open", sill=None)
    b.box(a2, (0.36, 0.56, 0.02), (-1.06, base + 1.37, fz + 0.065))
    b.window("x+", W / 2 - 0.05 + 0.04, 0.6, base + 1.3, 0.6, 0.5, bars=False, frame="wood_dark", glass="glass_open", sill=None)
    b.box(a1, (0.02, 0.5, 0.66), (W / 2 + 0.07, base + 1.32, 0.6))
    b.window("z-", -fz, 0.8, base + 1.3, 0.5, 0.45, bars=False, frame="wood_dark", glass="glass_open", sill=None)
    slope = rise / D
    ang = np.degrees(np.arctan(slope))
    z0 = -(D / 2 + 0.25)
    y0 = yH - slope * 0.25 + 0.03
    L = (D + 0.75) / np.cos(np.arctan(slope))
    for i, (x, mat) in enumerate([(-1.55, "tin"), (0.0, "tin_rust"), (1.55, "tin")]):
        b.corrugated(mat, 1.7, L, 6, 0.05, (x, y0 + 0.015 * i, z0), -ang)

    def roofy(z):
        return y0 + (z - z0) * slope + 0.08
    b.box(a1, (1.5, 0.02, 1.9), (-1.3, roofy(-0.7) + 0.02, -0.7), rot_x=-ang)
    for x, z in [(-1.9, 2.2), (-0.5, 2.3), (1.9, -2.2), (0.6, -1.8), (-2.0, -0.2), (1.9, 0.9)]:
        b.rock("stone", 0.17, (x, roofy(z) + 0.08, z))
    b.tire((0.9, roofy(0.7) + 0.08, 0.7), tilt=-ang)
    b.cyl("tank", 0.33, 0.9, (W / 2 + 0.55, 0.45, -1.3), 10)
    b.cyl("tank_lid", 0.35, 0.05, (W / 2 + 0.55, 0.925, -1.3), 10)
    b.cyl("gas", 0.17, 0.45, (1.8, 0.225, D / 2 + 0.35), 8)
    b.cyl("gas", 0.07, 0.12, (1.8, 0.5, D / 2 + 0.35), 6)
    b.cyl("plastic_red", 0.14, 0.3, (-1.9, 0.15, D / 2 + 0.45), 8)
    for x in (-1.5, -0.3):
        b.box("concrete", (0.38, 0.38, 0.2), (x, 0.19, D / 2 + 0.6))
    b.box("wood_b", (1.6, 0.05, 0.3), (-0.9, 0.405, D / 2 + 0.6))
    b.tire((W / 2 + 0.6, 0.1, 0.6))
    b.tire((W / 2 + 0.6, 0.3, 0.6))
    # power hook-up point on the roof edge (cable comes from the map)
    b.box("metal", (0.08, 0.25, 0.08), (-W / 2 + 0.2, yH + rise + 0.15, D / 2 + 0.2))
    b.anchor("Strom_Anschluss", (-W / 2 + 0.2, yH + rise + 0.28, D / 2 + 0.2))
    return b


def palafita():
    """Stilt shack (Maré / mangrove style) with porch, ladder and plank walkway."""
    b = B(61)
    r = b.rng
    w1 = b.slot("wall", 1, "#4F9FD6")
    w2 = b.slot("wall", 2, "#E5664E")
    d1 = b.slot("door", 1, "#ECEAE4")
    W, D, Y, H = 4.6, 4.2, 1.6, 2.3
    P = 1.3                                            # porch depth
    for x in np.linspace(-W / 2 + 0.15, W / 2 - 0.15, 4):
        for z in np.linspace(-D / 2 + 0.15, D / 2 + P - 0.15, 4):
            b.beam("wood_dark", (x + r.uniform(-0.08, 0.08), 0, z + r.uniform(-0.08, 0.08)), (x, Y, z), 0.14)
    for x in np.linspace(-W / 2 + 0.15, W / 2 - 0.15, 4):
        b.beam("wood_dark", (x, 0.4, -D / 2 + 0.15), (x, Y - 0.15, D / 2 + P - 0.15), 0.06)
    b.box("wood_b", (W + 0.1, 0.12, D + P), (0, Y - 0.06, P / 2))
    for z in np.arange(-D / 2 + 0.2, D / 2 + P, 0.3):
        b.box("wood_dark", (W + 0.1, 0.01, 0.02), (0, Y + 0.005, z))
    b.box("wood_dark", (W - 0.1, H, D - 0.1), (0, Y + H / 2, 0))
    for face, plane, length, mat in [("z+", D / 2 - 0.05, W, w1), ("x+", W / 2 - 0.05, D, w2),
                                     ("x-", -(W / 2 - 0.05), D, "wood_a"), ("z-", -(D / 2 - 0.05), W, "wood_b")]:
        b.box(mat, fsize(face, length - 0.1, H, 0.04), fpos(face, plane, 0, Y + H / 2, 0.02))
        for u in np.arange(-length / 2 + 0.3, length / 2 - 0.1, 0.3):
            b.box("wood_dark", fsize(face, 0.02, H, 0.02), fpos(face, plane, u, Y + H / 2, 0.045))
    fz = D / 2 - 0.05 + 0.04
    b.door("z+", fz, 0.9, 0.85, 1.95, d1, y0=Y, frame="wood_dark")
    b.window("z+", fz, -1.0, Y + 1.35, 0.8, 0.65, bars=False, frame="wood_dark", glass="glass_open", sill="wood_dark")
    for sg in (-1, 1):
        b.box("wood_a", (0.42, 0.7, 0.04), (-1.0 + sg * 0.66, Y + 1.35, fz + 0.05))
    b.window("x+", W / 2 - 0.05 + 0.04, 0.3, Y + 1.35, 0.7, 0.6, bars=False, frame="wood_dark", glass="glass_open", sill=None)
    # gable tin roof, ridge along x
    rh = 1.0
    hw, hd = (W - 0.1) / 2, (D - 0.1) / 2
    b.hull("wood_dark", [(sx * hw, Y + H, sz * hd) for sx in (-1, 1) for sz in (-1, 1)] +
           [(sx * hw, Y + H + rh, 0) for sx in (-1, 1)])
    run = D / 2 + 0.45
    ang = np.arctan(rh / (D / 2))
    L = run / np.cos(ang)
    b.corrugated("tin", W + 0.6, L, 10, 0.05, (0, Y + H + rh + 0.03, 0), np.degrees(ang))
    b.corrugated("tin_rust", W + 0.6, L, 10, 0.05, (0, Y + H + rh + 0.03, 0), np.degrees(ang), rot_y=180)
    # porch rail
    pz = D / 2 + P - 0.05
    for x in np.linspace(-W / 2 + 0.05, W / 2 - 0.05, 5):
        if abs(x - 1.7) < 0.3:
            continue
        b.beam("wood_dark", (x, Y, pz), (x, Y + 0.9, pz), 0.06)
    b.beam("wood_a", (-W / 2 + 0.05, Y + 0.9, pz), (1.4, Y + 0.9, pz), 0.06)
    for sx in (-1, 1):
        b.beam("wood_dark", (sx * (W / 2 - 0.05), Y, D / 2), (sx * (W / 2 - 0.05), Y + 0.9, D / 2), 0.06)
        if sx > 0:
            b.beam("wood_a", (W / 2 - 0.05, Y + 0.9, D / 2), (W / 2 - 0.05, Y + 0.9, pz), 0.06)
    # ladder down
    for x in (1.5, 1.95):
        b.beam("wood_b", (x, 0, pz + 0.75), (x, Y + 0.6, pz), 0.06)
    for k in range(1, 6):
        f = k / 6.5
        b.beam("wood_b", (1.5, Y * f * 1.0 + 0.0, pz + 0.75 * (1 - f * 1.08)), (1.95, Y * f, pz + 0.75 * (1 - f * 1.08)), 0.04)
    # plank walkway to the left
    wz = D / 2 + 0.55
    b.box("wood_a", (4.0, 0.08, 0.8), (-W / 2 - 2.0, Y - 0.1, wz))
    for x in np.arange(-W / 2 - 3.9, -W / 2, 0.35):
        b.box("wood_dark", (0.02, 0.01, 0.8), (x, Y - 0.055, wz))
    for x in (-W / 2 - 0.9, -W / 2 - 2.3, -W / 2 - 3.8):
        for dz in (-0.35, 0.35):
            b.beam("wood_dark", (x, 0, wz + dz), (x, Y - 0.12, wz + dz), 0.1)
    # props
    b.cyl("tank", 0.3, 0.8, (-1.6, Y + 0.4, D / 2 + 0.55), 10)
    b.chair(0.0, Y, D / 2 + 0.75, 200, "plastic_white")
    b.beam("wood_dark", (-W / 2 + 0.1, Y + 1.9, pz - 0.05), (W / 2 - 0.1, Y + 1.9, pz - 0.05), 0.015)
    for x, col, w, h in [(-1.4, "cloth_yellow", 0.5, 0.6), (-0.6, "cloth_white", 0.6, 0.45), (0.3, "cloth_red", 0.45, 0.55)]:
        b.box(col, (w, h, 0.02), (x, Y + 1.9 - h / 2 - 0.01, pz - 0.05))
    b.pot_plant(2.0, Y, D / 2 + 0.3)
    b.anchor("Eingang", (1.72, 0, D / 2 + P + 0.9))
    b.box("metal", (0.08, 0.25, 0.08), (-W / 2 + 0.05, Y + H + 0.15, -1.0))
    b.anchor("Strom_Anschluss", (-W / 2 + 0.05, Y + H + 0.28, -1.0))
    return b


# =====================================================================
# ARM
# =====================================================================
def puxadinho():
    b = B(23)
    b1 = b.slot("base", 1, "#B5582F")
    b2 = b.slot("base", 2, "#C4683A")
    d1 = b.slot("door", 1, "#5E6B66")
    W, D, H, S = 4.2, 6.0, 2.65, 0.22
    FH = H + S
    hx, hz = W / 2 - 0.1, D / 2 - 0.1
    for f, mat in enumerate([b1, b2]):
        y0 = f * FH
        b.box(mat, (W - 0.2, H, D - 0.2), (0, y0 + H / 2, 0))
        for x in (-hx, hx):
            for z in (-hz, 0, hz):
                b.box("concrete", (0.28, H, 0.28), (x, y0 + H / 2, z))
        b.box("concrete", (W + 0.2, S, D + 0.2), (0, y0 + H + S / 2, 0))
    b.box("brick_dark", (W - 0.16, 0.3, D - 0.16), (0, 0.15, 0))
    Y3 = 2 * FH
    b.door("z+", hz, 1.1, 0.9, 2.05, d1)
    b.window("z+", hz, -0.9, 1.5, 1.0, 0.95)
    for u in (-0.02, 0.2, 0.42):
        b.box("meter", (0.18, 0.26, 0.12), (u, 2.15, hz + 0.06))
    b.window("x-", -hx, -0.8, 1.5, 1.0, 0.9)
    b.window("z+", hz, -0.7, FH + 1.45, 1.0, 1.0, bars=False, frame=None, glass="glass_open", sill=None)
    b.window("z+", hz, 1.1, FH + 1.45, 0.8, 0.9, bars=False, frame=None, glass="tarp_blue", sill=None)
    b.window("x-", -hx, 1.0, FH + 1.45, 0.8, 0.8, bars=False, frame=None, glass="glass_open", sill=None)
    b.window("z-", -hz, 0.0, FH + 1.45, 0.9, 0.8, bars=False, frame=None, glass="glass_open", sill=None)
    b.window("z-", -hz, -0.6, 1.5, 0.9, 0.8)
    b.beam("metal", (0.25, FH + 2.1, hz + 0.05), (0.25, FH + 2.1, hz + 0.35), 0.04)
    dish(b, (0.25, FH + 2.2, hz + 0.4), 0.3)
    b.box("brick_b", (W - 0.2, H, 0.18), (0, Y3 + H / 2, -hz))
    for h, z0, z1 in [(H, -hz, -1.2), (1.7, -1.2, 0.5), (0.9, 0.5, 1.7)]:
        b.box("brick_b", (0.18, h, z1 - z0), (-hx, Y3 + h / 2, (z0 + z1) / 2))
    for x in (-hx, hx):
        for z, h in ((-hz, H), (0, H * 0.7), (hz, 1.1)):
            b.box("concrete", (0.28, h, 0.28), (x, Y3 + h / 2, z))
            b.rebar(x, Y3 + h, z, 4, 0.5, 0.9)
    b.box("tarp_blue", (W - 0.3, 0.02, 2.2), (0, Y3 + H - 0.1, -hz + 1.1), rot_x=-6)
    for i in range(3):
        b.box("cement_bag", (0.6, 0.16, 0.4), (1.2, Y3 + 0.08 + i * 0.16, -1.6 + 0.03 * i), rot_y=8 * i)
    for i in range(2):
        b.box("brick_b", (0.8, 0.3, 0.5), (0.1 * i, Y3 + 0.15 + 0.3 * i, -2.1))
    b.box("brick_b", (0.5, 0.3, 0.4), (0.7, Y3 + 0.15, -2.2))
    b.tank(-0.6, Y3, 1.5, 0.55, 0.8)
    b.tank(1.0, Y3, 1.9, 0.42, 0.65, "tank_white", "tank_white")
    lz = hz - 0.05
    b.beam("metal", (-hx, Y3 + 1.0, lz), (hx, Y3 + 1.0, lz), 0.015)
    for x, col, w, h in [(-1.2, "cloth_yellow", 0.5, 0.6), (-0.4, "cloth_white", 0.6, 0.4), (0.5, "cloth_red", 0.45, 0.55)]:
        b.box(col, (w, h, 0.02), (x, Y3 + 1.0 - h / 2 - 0.01, lz))
    x0, x1 = W / 2 + 0.05, W / 2 + 0.85
    zs = D / 2 - 0.05
    zt = b.stairs("concrete", x0, x1, zs, 0, FH, 0.26, -1, True, "concrete_dk")
    sxc, sw = (x0 + x1) / 2, x1 - x0
    b.box("concrete", (sw, FH, 1.8), (sxc, FH / 2, zt - 0.9))
    b.door("x+", W / 2, zt - 0.6, 0.85, 2.0, d1, y0=FH)
    rx = x1 - 0.04
    b.beam("metal", (rx, 0.9 + 0.2, zs - 0.1), (rx, FH + 0.9, zt), 0.04)
    for z, hh in ((zs - 0.1, 0.2), (zt, FH)):
        b.beam("metal", (rx, hh, z), (rx, hh + 0.9, z), 0.04)
    for z in (-2.0, -2.38):
        b.beam("wood_b", (x1 - 0.15, FH, z), (W / 2 + 0.12, Y3 + 0.9, z), 0.05)
    for k in range(9):
        f = (k + 1) / 10
        x = x1 - 0.15 + (W / 2 + 0.12 - (x1 - 0.15)) * f
        y = FH + (Y3 + 0.9 - FH) * f
        b.beam("wood_b", (x, y, -2.0), (x, y, -2.38), 0.04)
    # cables: meters -> along the wall -> up the corner column to the roof (fixed at both ends)
    cz = hz + 0.26
    for k, u in enumerate((-0.02, 0.2, 0.42)):
        b.beam("metal", (u, 2.28, hz + 0.1), (u, 2.5 + 0.04 * k, hz + 0.1), 0.025)
        b.beam("metal", (u, 2.5 + 0.04 * k, hz + 0.1), (-hx + 0.2, 2.5 + 0.04 * k, hz + 0.1), 0.025)
    b.beam("metal", (-hx + 0.2, 2.5, hz + 0.1), (-hx + 0.2, 2.5, cz), 0.05)
    b.beam("metal", (-hx + 0.2, 2.5, cz), (-hx + 0.2, Y3 + 1.0, cz), 0.06)
    b.box("metal", (0.12, 0.2, 0.12), (-hx + 0.2, Y3 + 1.05, cz))
    b.anchor("Strom_Anschluss", (-hx + 0.2, Y3 + 1.2, cz))
    return b


def favela_reihe():
    """Three narrow joined houses of different heights (typical favela street)."""
    b = B(67)
    D, H, S = 6.0, 2.65, 0.22
    FH = H + S
    units = [  # width, floors, wall default, door default
        (3.2, 2, "#E07A8C", "#2E5FA8"),
        (3.6, 3, "#8FD0B0", "#7A4E2D"),
        (3.0, 1, "#EBC03F", "#3E7D4F"),
    ]
    total = sum(u[0] for u in units)
    x = -total / 2
    tops = []
    for i, (w, fl, wc, dc) in enumerate(units):
        wm = b.slot("wall", i + 1, wc)
        dm = b.slot("door", i + 1, dc)
        x0, x1 = x, x + w
        xc = (x0 + x1) / 2
        for f in range(fl):
            y0 = f * FH
            mat = "brick_b" if (i == 1 and f == 2) else wm
            b.box(mat, (w, H, D), (xc, y0 + H / 2, 0))
            b.box("concrete", (w + 0.02, S, D + 0.2), (xc, y0 + H + S / 2, 0))
        b.box("concrete_dk", (w + 0.02, 0.3, D + 0.04), (xc, 0.15, 0))
        fz = D / 2
        # ground floor
        b.door("z+", fz, x0 + 0.75, 0.85, 2.0, dm)
        b.window("z+", fz, x0 + w - 0.95, 1.5, 0.9, 0.9)
        for f in range(1, fl):
            yc = f * FH + 1.45
            if i == 1 and f == 2:
                b.window("z+", fz, xc, yc, 1.2, 1.0, bars=False, frame=None, glass="glass_open", sill=None)
            else:
                b.window("z+", fz, xc - 0.5, yc, 0.9, 0.9, bars=(f == 1))
                if w > 3.3:
                    b.window("z+", fz, xc + 0.9, yc, 0.6, 0.6, bars=False)
        top = fl * FH
        tops.append((x0, x1, top))
        x = x1
    # ground floor gate grille on unit 1
    u0 = -total / 2 + 0.75
    b.box("metal", (1.15, 0.05, 0.05), (u0, 2.15, D / 2 + 0.25))
    for k in range(7):
        b.box("metal", (0.03, 2.1, 0.03), (u0 - 0.54 + k * 0.18, 1.05, D / 2 + 0.25))
    # unit 1 small balcony
    x0, x1, top1 = tops[0]
    b.box("concrete", (1.6, 0.12, 0.8), ((x0 + x1) / 2 - 0.5, FH + 0.0, D / 2 + 0.4))
    for k in range(6):
        b.beam("metal", ((x0 + x1) / 2 - 1.25 + k * 0.3, FH, D / 2 + 0.78), ((x0 + x1) / 2 - 1.25 + k * 0.3, FH + 0.9, D / 2 + 0.78), 0.03)
    b.beam("metal", ((x0 + x1) / 2 - 1.3, FH + 0.9, D / 2 + 0.78), ((x0 + x1) / 2 + 0.3, FH + 0.9, D / 2 + 0.78), 0.04)
    b.pot_plant((x0 + x1) / 2 + 0.1, FH + 0.06, D / 2 + 0.5)
    # roofs
    for i, (x0, x1, top) in enumerate(tops):
        xc = (x0 + x1) / 2
        if i == 0:
            b.tank(xc + 0.5, top, -1.5, 0.55, 0.85)
            dish(b, (xc - 0.8, top + 0.75, 1.5), 0.3)
            b.beam("metal", (xc - 0.8, top, 1.4), (xc - 0.8, top + 0.65, 1.4), 0.04)
        elif i == 1:
            b.tank(xc, top, -1.8, 0.62, 0.9)
            for xx in (x0 + 0.15, x1 - 0.15):
                for zz in (-D / 2 + 0.15, D / 2 - 0.15):
                    b.rebar(xx, top, zz, 3)
        else:
            for xx, zz, sx, sz in [(xc, D / 2 + 0.05, x1 - x0, 0.14), (x1 + 0.0, 0.0, 0.14, D), (xc, -D / 2 - 0.05, x1 - x0, 0.14)]:
                b.box("trim", (sx, 0.8, sz), (xx, top + 0.4, zz))
            b.tank(xc + 0.6, top, -1.8, 0.5, 0.8, "tank_white", "tank_white")
            b.beam("metal", (x0 + 0.2, top + 1.8, 1.8), (x1 - 0.2, top + 1.8, 1.8), 0.015)
            for xx in (x0 + 0.2, x1 - 0.2):
                b.beam("metal", (xx, top, 1.8), (xx, top + 1.85, 1.8), 0.04)
            for xx, col in ((x0 + 0.8, "cloth_green"), (x0 + 1.6, "cloth_white"), (x0 + 2.3, "cloth_red")):
                b.box(col, (0.5, 0.55, 0.02), (xx, top + 1.5, 1.8))
            b.chair(xc - 0.6, top, 0.2, 30)
            for zz in (-0.9, -1.3):
                b.beam("metal", (x1 + 0.08, 0, zz), (x1 + 0.08, top + 0.9, zz), 0.04)
            for k in range(1, 10):
                y = k * (top + 0.6) / 10
                b.beam("metal", (x1 + 0.08, y, -0.9), (x1 + 0.08, y, -1.3), 0.03)
    # front wires + meters
    for i, (x0, x1, top) in enumerate(tops):
        b.box("meter", (0.2, 0.28, 0.12), ((x0 + x1) / 2 + 0.1, 2.3, D / 2 + 0.06))
    # cable bundle along the facade, clamped to the wall at both ends and at each meter
    ex = total / 2 - 0.15
    for k, yy in enumerate((2.62, 2.7, 2.78)):
        b.wire((-ex, yy, D / 2 + 0.1 + 0.03 * k), (ex, yy, D / 2 + 0.1 + 0.03 * k), 0.08, 10, 0.02)
    for x in (-ex, ex):
        b.box("metal", (0.1, 0.3, 0.12), (x, 2.7, D / 2 + 0.06))
    for (x0, x1, top) in tops:
        mx = (x0 + x1) / 2 + 0.1
        b.beam("metal", (mx, 2.44, D / 2 + 0.1), (mx, 2.6, D / 2 + 0.1), 0.025)
    b.beam("metal", (-ex, 2.7, D / 2 + 0.06), (-ex, 2.7, D / 2 + 0.18), 0.05)
    b.beam("metal", (-ex, 2.7, D / 2 + 0.18), (-ex, tops[0][2] + 0.6, D / 2 + 0.18), 0.06)
    b.box("metal", (0.12, 0.15, 0.12), (-ex, tops[0][2] + 0.62, D / 2 + 0.18))
    b.anchor("Strom_Anschluss", (-ex, tops[0][2] + 0.72, D / 2 + 0.18))
    return b


def cortico():
    """Run-down colonial tenement split into many rooms."""
    b = B(71)
    r = b.rng
    w1 = b.slot("wall", 1, "#D9A441")
    s1 = b.slot("shutter", 1, "#3E7D4F")
    d1 = b.slot("door", 1, "#7A4E2D")
    ro = b.slot("roof", 1, "#8E3B25")
    W, D, F = 9.0, 8.0, 3.4
    b.box("concrete_dk", (W + 0.1, 0.5, D + 0.1), (0, 0.25, 0))
    b.box(w1, (W, 2 * F - 0.5, D), (0, 0.5 + (2 * F - 0.5) / 2, 0))
    b.box("trim", (W + 0.16, 0.16, D + 0.16), (0, F, 0))
    b.box("trim", (W + 0.4, 0.35, D + 0.4), (0, 2 * F + 0.175, 0))
    yr = 2 * F + 0.35
    b.hull(ro, [(sx * (W / 2 + 0.25), yr, sz * (D / 2 + 0.25)) for sx in (-1, 1) for sz in (-1, 1)] +
           [(-2.4, yr + 2.0, 0), (2.4, yr + 2.0, 0)])
    # roof repair patch + weeds
    hz = D / 2 + 0.25
    ang = np.arctan(2.0 / hz)

    def ry(z):
        return yr + 2.0 * (1 - z / hz)
    b.corrugated("tin_rust", 1.8, 1.9 / np.cos(ang), 6, 0.05, (1.6, ry(1.1) + 0.06, 1.1), np.degrees(ang))
    for x, z in [(-3.6, 2.6), (3.2, 3.0), (-1.0, 3.3)]:
        b.rock("plant", 0.25, (x, ry(z) + 0.05, z), 0.6)
    for x in (-4.4, -1.5, 2.0, 4.4):
        b.rock("plant", 0.18, (x, 2 * F + 0.4, D / 2 + 0.15), 0.6)
    # plaster damage
    for (face, plane, u, y, w, h) in [("z+", D / 2, -2.75, 6.25, 1.0, 0.55), ("z+", D / 2, 2.75, 6.3, 0.8, 0.45),
                                      ("z+", D / 2, -1.2, 1.3, 0.55, 0.8), ("x+", W / 2, -0.5, 2.4, 1.6, 1.2),
                                      ("x+", W / 2, -0.3, 5.6, 1.2, 0.8), ("x-", -W / 2, -0.4, 4.8, 1.4, 1.0),
                                      ("z+", D / 2, 1.2, 4.2, 0.5, 0.6)]:
        b.box("brick_raw", fsize(face, w, h, 0.04), fpos(face, plane, u, y, 0.02))
        for k in range(1, int(h / 0.2)):
            b.box("brick_dark", fsize(face, w, 0.025, 0.02), fpos(face, plane, u, y - h / 2 + k * 0.2, 0.045))
    # ground floor: tall door + tall windows with shutters
    b.box("trim", (1.7, 3.0, 0.03), (0, 1.5 + 0.25, D / 2 + 0.015))
    for sx in (-1, 1):
        b.box(d1, (0.7, 2.6, 0.05), (sx * 0.36, 0.5 + 1.3, D / 2 + 0.04))
    b.box("glass", (1.4, 0.35, 0.03), (0, 3.0, D / 2 + 0.035))
    for i, u in enumerate((-3.6, -2.0, 2.0, 3.6)):
        b.window("z+", D / 2, u, 1.95, 0.9, 1.9, bars=(i % 2 == 0), shutters=(s1 if i != 2 else None))
    # upper floor: 5 french windows with iron balconettes
    for i, u in enumerate(np.linspace(-3.6, 3.6, 5)):
        g = "glass_open" if i in (1, 4) else "glass"
        b.window("z+", D / 2, u, F + 1.35, 0.9, 2.2, bars=False, glass=g, sill=None,
                 shutters=(s1 if i in (0, 2) else None))
        b.balconette("z+", D / 2, u, F + 0.25, 1.1, 0.4, "metal", "concrete")
    # side windows
    for face, plane in (("x+", W / 2), ("x-", -W / 2)):
        for u in (-2.5, 1.5):
            b.window(face, plane, u, 1.95, 0.8, 1.6, bars=True)
            b.window(face, plane, u, F + 1.4, 0.8, 1.6, bars=False, glass="glass_open" if u > 0 else "glass")
    b.window("z-", -D / 2, 0, F + 1.4, 1.0, 1.4, bars=False)
    # laundry everywhere
    for (x0, x1, yy) in [(-4.2, -1.6, F + 2.6), (0.4, 4.2, F + 2.5)]:
        b.beam("metal", (x0, yy, D / 2 + 0.38), (x1, yy, D / 2 + 0.38), 0.015)
        cols = ["cloth_white", "cloth_red", "cloth_yellow", "cloth_green", "cloth_white"]
        for k, xx in enumerate(np.arange(x0 + 0.4, x1 - 0.2, 0.6)):
            hh = r.uniform(0.35, 0.65)
            b.box(cols[k % 5], (0.45, hh, 0.02), (xx, yy - hh / 2, D / 2 + 0.38))
    for p in ((3.8, 2 * F - 0.4, D / 2 + 0.3), (-4.6, F + 2.9, 1.0)):
        dish(b, p, 0.32)
    b.beam("metal", (3.8, 2 * F - 0.5, D / 2), (3.8, 2 * F - 0.5, D / 2 + 0.25), 0.04)
    b.tank(-2.5, 2 * F + 0.35, -1.0, 0.55, 0.8)
    b.box("concrete", (1.4, 0.4, 1.4), (-2.5, 2 * F + 0.55, -1.0))
    b.tank(-2.5, 2 * F + 0.75, -1.0, 0.55, 0.8)
    # dangling wire bundle across facade
    ex = W / 2 - 0.15
    for k in range(3):
        b.wire((-ex, 3.05 + 0.06 * k, D / 2 + 0.1 + 0.03 * k), (ex, 3.05 + 0.06 * k, D / 2 + 0.1 + 0.03 * k), 0.15 + 0.05 * k, 10, 0.02)
    for x in (-ex, ex):
        b.box("metal", (0.1, 0.3, 0.14), (x, 3.12, D / 2 + 0.07))
    b.beam("metal", (-ex, 3.12, D / 2 + 0.07), (-ex, 2 * F - 0.08, D / 2 + 0.07), 0.06)
    b.box("metal", (0.12, 0.12, 0.12), (-ex, 2 * F - 0.1, D / 2 + 0.07))
    b.anchor("Strom_Anschluss", (-ex, 2 * F - 0.1, D / 2 + 0.15))
    b.cyl("gas", 0.17, 0.45, (1.3, 0.725, D / 2 + 0.25), 8)
    b.anchor("Eingang", (0, 0, D / 2 + 0.6))
    return b


# =====================================================================
# EINFACH / MITTEL
# =====================================================================
def casa_rio():
    """The original house (now with colour slots)."""
    b = B(7)
    w_up = b.slot("wall", 1, "#3FA39A")
    w_low = b.slot("wall", 2, "#E2BE5A")
    base = b.slot("base", 1, "#B5582F")
    d1 = b.slot("door", 1, "#2E5FA8")
    d2 = b.slot("door", 2, "#7A4E2D")
    W, D, H1, SLAB = 6.0, 7.0, 2.8, 0.25
    Y1 = H1 + SLAB
    FZ, SX = D / 2 - 0.1, W / 2 - 0.1
    b.box(base, (W - 0.2, H1, D - 0.2), (0, H1 / 2, 0))
    b.box("brick_dark", (W - 0.16, 0.35, D - 0.16), (0, 0.175, 0))
    for x in (-SX, 0.0, SX):
        for z in (-FZ, FZ):
            if x == 0.0 and z == FZ:
                continue
            b.box("concrete", (0.3, H1, 0.3), (x, H1 / 2, z))
    for x in (-SX, SX):
        b.box("concrete", (0.3, H1, 0.3), (x, H1 / 2, 0))
    b.box("concrete", (W + 0.3, SLAB, D + 0.3), (0, H1 + SLAB / 2, 0))
    b.box(w_low, (3.0, 2.3, 0.03), (1.15, 1.15, FZ + 0.015))
    b.door("z+", FZ + 0.03, 1.35, mat=d1)
    b.box("concrete", (1.3, 0.12, 0.45), (1.35, 0.06, FZ + 0.22))
    b.window("z+", FZ, -1.35, 1.55)
    b.corrugated("tin", 1.8, 0.9, 7, 0.05, (1.35, 2.42, FZ + 0.03), 12)
    for dx in (-0.75, 0.75):
        b.beam("metal", (1.35 + dx, 2.0, FZ + 0.03), (1.35 + dx, 2.36, FZ + 0.8), 0.03)
    b.window("x+", SX, -1.2, 1.6, 1.0, 0.9)
    b.window("x+", SX, 1.9, 1.6, 0.8, 0.9)
    b.window("x-", -SX, -2.4, 2.0, 0.6, 0.45, bars=False)
    b.window("z-", -FZ, 0.8, 1.6, 0.9, 0.8)
    sx0, sx1 = -(W / 2 + 0.95), -(W / 2 + 0.05)
    sxc, sw = (sx0 + sx1) / 2, sx1 - sx0
    z_start = D / 2 - 0.05
    z_top = b.stairs("concrete", sx0, sx1, z_start, 0, Y1, 0.27, -1, True, "concrete_dk")
    b.box("concrete", (sw, Y1, 1.0), (sxc, Y1 / 2, z_top - 0.5))
    rx = sx0 + 0.04
    b.beam("metal", (rx, 1.1, z_start - 0.1), (rx, Y1 + 0.9, z_top), 0.045)
    b.beam("metal", (rx, Y1 + 0.9, z_top), (rx, Y1 + 0.9, z_top - 0.9), 0.045)
    for f in (0.0, 0.33, 0.66, 1.0):
        z = z_start - 0.1 + (z_top - z_start + 0.1) * f
        y = 0.2 + (Y1 - 0.2) * f
        b.beam("metal", (rx, y, z), (rx, y + 0.9, z), 0.04)
    b.beam("metal", (rx, Y1, z_top - 0.9), (rx, Y1 + 0.9, z_top - 0.9), 0.04)
    H2 = 2.7
    UX0, UX1, UZ0, UZ1 = -2.2, 2.9, -3.4, 1.3
    ucx, ucz, uw, ud = (UX0 + UX1) / 2, (UZ0 + UZ1) / 2, UX1 - UX0, UZ1 - UZ0
    b.box(w_up, (uw, H2, ud), (ucx, Y1 + H2 / 2, ucz))
    Y2 = Y1 + H2 + 0.2
    b.box("concrete", (uw + 0.3, 0.2, ud + 0.3), (ucx, Y1 + H2 + 0.1, ucz))
    b.box("trim", (uw + 0.02, 0.12, ud + 0.02), (ucx, Y1 + 0.06, ucz))
    b.door("z+", UZ1, 1.8, 0.9, 2.0, d2, y0=Y1)
    b.window("z+", UZ1, -0.6, Y1 + 1.45, 1.3, 1.0, bars=False)
    b.window("x+", UX1, -1.6, Y1 + 1.45, 1.0, 0.9, bars=False)
    b.window("z-", UZ0, 0.3, Y1 + 1.45, 1.0, 0.9)
    b.window("x-", UX0, -0.6, Y1 + 1.5, 0.7, 0.6, bars=False)
    b.box("ac", (0.3, 0.42, 0.75), (UX1 + 0.15, Y1 + 2.15, 0.3))
    b.box("metal", (0.02, 0.32, 0.6), (UX1 + 0.31, Y1 + 2.15, 0.3))
    PH = 0.75
    b.box(base, (W + 0.3, PH, 0.16), (0, Y1 + PH / 2, D / 2 + 0.07))
    b.box("concrete", (W + 0.34, 0.06, 0.22), (0, Y1 + PH + 0.03, D / 2 + 0.07))
    zr0, zr1 = UZ1, D / 2 + 0.15
    b.box(base, (0.16, PH, zr1 - zr0), (W / 2 + 0.07, Y1 + PH / 2, (zr0 + zr1) / 2))
    b.box("concrete", (0.22, 0.06, zr1 - zr0), (W / 2 + 0.07, Y1 + PH + 0.03, (zr0 + zr1) / 2))
    lx = -(W / 2 + 0.07)
    for z in np.linspace(D / 2, -0.2, 5):
        b.beam("metal", (lx, Y1, z), (lx, Y1 + 0.95, z), 0.04)
    b.beam("metal", (lx, Y1 + 0.95, D / 2), (lx, Y1 + 0.95, -0.2), 0.045)
    for x in (-2.2, 2.3):
        b.pot_plant(x, Y1 + PH + 0.06, D / 2 + 0.07)
    ly, lz = Y1 + 1.9, 2.3
    for x in (-2.6, 2.6):
        b.beam("metal", (x, Y1, lz), (x, ly + 0.05, lz), 0.05)
    b.beam("metal", (-2.6, ly, lz), (2.6, ly, lz), 0.015)
    for x, col, w, h in [(-1.7, "cloth_red", 0.55, 0.7), (-0.9, "cloth_white", 0.7, 0.45),
                         (0.1, "cloth_yellow", 0.5, 0.75), (0.9, "cloth_green", 0.6, 0.55), (1.7, "cloth_white", 0.45, 0.6)]:
        b.box(col, (w, h, 0.02), (x, ly - h / 2 - 0.01, lz))
    lx2 = UX0 - 0.1
    for z in (-2.45, -2.95):
        b.beam("metal", (lx2, Y1, z), (lx2, Y2 + 0.6, z), 0.04)
    for y in np.arange(Y1 + 0.3, Y2 + 0.4, 0.3):
        b.beam("metal", (lx2, y, -2.45), (lx2, y, -2.95), 0.03)
    tx, tz = 1.5, -2.2
    b.box("concrete", (1.5, 0.18, 1.5), (tx, Y2 + 0.09, tz))
    b.tank(tx, Y2 + 0.18, tz, 0.65, 0.95)
    b.beam("metal", (tx - 0.6, Y2 + 0.5, tz), (UX0 + 0.4, Y2 + 0.05, tz - 0.4), 0.035)
    for cx, cz in [(UX0, UZ0), (UX1, UZ0), (UX0, UZ1), (UX1, UZ1), (ucx, UZ1), (ucx, UZ0)]:
        b.rebar(np.clip(cx, UX0 + 0.12, UX1 - 0.12), Y2, np.clip(cz, UZ0 + 0.12, UZ1 - 0.12), 3)
    dx, dz = -1.3, UZ1 - 0.3
    b.beam("metal", (dx, Y2, dz), (dx, Y2 + 0.6, dz), 0.04)
    dish(b, (dx, Y2 + 0.72, dz + 0.05), 0.32)
    return b


def boteco():
    b = B(37)
    w1 = b.slot("wall", 1, "#E07A8C")
    w2 = b.slot("wall", 2, "#EBC03F")
    w3 = b.slot("wall", 3, "#6FB3D9")
    s1 = b.slot("shutter", 1, "#3E7D4F")
    a1 = b.slot("accent", 1, "#C8372D")
    d1 = b.slot("door", 1, "#7A4E2D")
    W, D, H1, H2, H3, S = 5.6, 7.0, 3.0, 2.75, 2.6, 0.22
    hx, hz = W / 2 - 0.1, D / 2 - 0.1
    R = 1.6
    ox, ow, oh = -0.7, 3.2, 2.45
    b.box(w1, (W - 0.2, H1, D - 0.2 - R), (0, H1 / 2, -R / 2))
    lx0, lx1 = ox - ow / 2, ox + ow / 2
    b.box(w1, (lx0 + hx, H1, R), ((lx0 - hx) / 2, H1 / 2, hz - R / 2))
    b.box(w1, (hx - lx1, H1, R), ((lx1 + hx) / 2, H1 / 2, hz - R / 2))
    b.box(w1, (ow, H1 - oh, R), (ox, (H1 + oh) / 2, hz - R / 2))
    b.box("concrete_dk", (W - 0.14, 0.3, D - 0.14), (0, 0.15, 0))
    zb = hz - R
    b.box("tile_floor", (ow, 0.04, R), (ox, 0.02, hz - R / 2))
    b.box("tile_blue", (ow, 1.1, 0.03), (ox, 0.55, zb + 0.015))
    b.box("plaster_cream", (ow, oh - 1.1, 0.03), (ox, 1.1 + (oh - 1.1) / 2, zb + 0.015))
    cols = ["cloth_green", "sign_red", "cloth_yellow", "cloth_white", "tank", "cloth_green"]
    for sy in (1.35, 1.85):
        b.box("wood_dark", (ow - 0.4, 0.04, 0.3), (ox, sy, zb + 0.18))
        for k in range(9):
            b.box(cols[(k + int(sy * 10)) % len(cols)], (0.09, 0.26, 0.09), (ox - 1.2 + k * 0.3, sy + 0.15, zb + 0.18))
    b.box("counter", (ow - 0.7, 1.0, 0.45), (ox, 0.5, hz - 0.65))
    b.box("wood_dark", (ow - 0.6, 0.05, 0.55), (ox, 1.025, hz - 0.65))
    b.box("shutter", (ow + 0.1, 0.3, 0.3), (ox, oh - 0.12, hz - 0.15))
    b.box("shutter", (ow, 0.45, 0.04), (ox, oh - 0.45, hz - 0.03))
    for k in range(4):
        b.box("metal", (ow, 0.02, 0.02), (ox, oh - 0.62 + k * 0.1, hz - 0.005))
    b.box(a1, (ow + 0.5, 0.48, 0.08), (ox, oh + 0.28, hz + 0.05))
    b.box("sign_white", (ow + 0.1, 0.1, 0.02), (ox, oh + 0.28, hz + 0.1))
    b.door("z+", hz, 1.85, 0.9, 2.05, d1)
    b.table(-0.8, 0, hz + 1.4)
    for (dx, dz, rot) in [(-0.6, 0, 90), (0.6, 0, -90), (0, 0.6, 180)]:
        b.chair(-0.8 + dx, 0, hz + 1.4 + dz, rot, "plastic_red")
    b.cyl("tank", 0.22, 0.5, (2.2, 0.25, hz + 0.5), 8)
    b.box("concrete", (W + 0.3, S, D + 0.3), (0, H1 + S / 2, 0))
    Y1 = H1 + S
    cz0, cz1 = -hz, hz + 0.6
    b.box(w2, (W - 0.2, H2, cz1 - cz0), (0, Y1 + H2 / 2, (cz0 + cz1) / 2))
    b.box("trim", (W - 0.18, 0.12, cz1 - cz0 + 0.02), (0, Y1 + 0.06, (cz0 + cz1) / 2))
    for x in (-hx + 0.3, hx - 0.3):
        b.hull("concrete", [(x - 0.1, Y1, hz + 0.6), (x + 0.1, Y1, hz + 0.6), (x - 0.1, Y1, hz),
                            (x + 0.1, Y1, hz), (x - 0.1, Y1 - 0.5, hz), (x + 0.1, Y1 - 0.5, hz)])
    for u in (-1.3, 1.2):
        b.window("z+", cz1, u, Y1 + 1.45, 1.0, 1.0, bars=False, shutters=s1)
    b.box("ac", (0.75, 0.42, 0.3), (1.2, Y1 + 0.55, cz1 + 0.15))
    b.window("x+", hx, -1.5, Y1 + 1.45, 1.0, 0.9, bars=False, shutters=s1)
    b.window("z-", -hz, 0.5, Y1 + 1.45, 1.0, 0.9)
    b.box("concrete", (W + 0.3, S, cz1 - cz0 + 0.3), (0, Y1 + H2 + S / 2, (cz0 + cz1) / 2))
    Y2 = Y1 + H2 + S
    tz0, tz1 = -hz, -0.3
    b.box(w3, (W - 0.2, H3, tz1 - tz0), (0, Y2 + H3 / 2, (tz0 + tz1) / 2))
    b.window("z+", tz1, -1.3, Y2 + 1.45, 1.1, 0.9, bars=False)
    b.door("z+", tz1, 1.4, 0.9, 2.0, d1, y0=Y2)
    b.box("concrete", (W + 0.1, 0.18, tz1 - tz0 + 0.2), (0, Y2 + H3 + 0.09, (tz0 + tz1) / 2))
    Y3 = Y2 + H3 + 0.18
    b.tank(1.2, Y3, -2.0)
    b.rebar(-hx + 0.15, Y3, -hz + 0.15, 3)
    b.rebar(-hx + 0.15, Y3, tz1 - 0.15, 3)

    # ---- red metal switchback stair: two side-by-side lanes (fixed) ----
    lane = 0.8
    ix0, ix1 = -W / 2 - 0.15 - lane, -W / 2 - 0.15          # inner lane (flight 1, goes back)
    ox0, ox1 = ix0 - 0.1 - lane, ix0 - 0.1                    # outer lane (flight 2, goes forward)
    zs = D / 2
    zt = b.stairs("metal_red", ix0, ix1, zs, 0, Y1, 0.26, -1, solid=False)
    b.box("metal_red", (ix1 - ox0, 0.06, 1.0), ((ox0 + ix1) / 2, Y1, zt - 0.5))      # mid landing
    for x in (ox0 + 0.05, ix1 - 0.05):
        for z in (zt - 0.95, zt - 0.05):
            b.beam("metal_red", (x, 0, z), (x, Y1, z), 0.07)
    b.door("x-", -hx, zt - 0.5, 0.85, 2.0, d1, y0=Y1)
    ze = b.stairs("metal_red", ox0, ox1, zt, Y1, Y2, 0.22, +1, solid=False)
    b.box("metal_red", (ix1 - ox0, 0.06, 0.9), ((ox0 + ix1) / 2, Y2, ze + 0.45))     # top landing
    for z in (ze + 0.85,):
        b.beam("metal_red", (ox0 + 0.05, 0, z), (ox0 + 0.05, Y2, z), 0.07)
    # handrails on outer edges
    b.beam("metal", (ox0 + 0.02, Y1 + 0.9, zt), (ox0 + 0.02, Y2 + 0.9, ze), 0.04)
    b.beam("metal", (ox0 + 0.02, Y1 + 0.9, zt - 1.0), (ox0 + 0.02, Y1 + 0.9, zt), 0.04)
    b.beam("metal", (ox0 + 0.02, Y1, zt - 1.0), (ox0 + 0.02, Y1 + 0.9, zt - 1.0), 0.04)
    b.beam("metal", (ix0 + 0.02, 0.2 + 0.9, zs), (ix0 + 0.02, Y1 + 0.9, zt), 0.04)
    b.beam("metal", (ox0 + 0.02, Y2 + 0.9, ze), (ox0 + 0.02, Y2 + 0.9, ze + 0.9), 0.04)
    # terrace parapets with gap where the top landing arrives
    PH = 0.9
    fz = cz1 + 0.1
    g0, g1 = ze - 0.05, ze + 0.9
    b.box("trim", (W + 0.3, PH, 0.15), (0, Y2 + PH / 2, fz))
    b.box("trim", (0.15, PH, fz - tz1), (W / 2 + 0.08, Y2 + PH / 2, (fz + tz1) / 2))
    b.box("trim", (0.15, PH, g0 - tz1), (-W / 2 - 0.08, Y2 + PH / 2, (g0 + tz1) / 2))
    if fz - g1 > 0.05:
        b.box("trim", (0.15, PH, fz - g1), (-W / 2 - 0.08, Y2 + PH / 2, (fz + g1) / 2))
    gx, gz = 1.9, 2.2
    b.box("brick", (1.1, 0.9, 0.7), (gx, Y2 + 0.45, gz))
    b.box("metal", (0.9, 0.04, 0.5), (gx, Y2 + 0.92, gz))
    b.hull("brick", [(gx - 0.55, Y2 + 1.6, gz - 0.35), (gx + 0.55, Y2 + 1.6, gz - 0.35), (gx - 0.55, Y2 + 1.6, gz + 0.35),
                     (gx + 0.55, Y2 + 1.6, gz + 0.35), (gx - 0.15, Y2 + 2.0, gz - 0.1), (gx + 0.15, Y2 + 2.0, gz - 0.1),
                     (gx - 0.15, Y2 + 2.0, gz + 0.2), (gx + 0.15, Y2 + 2.0, gz + 0.2)])
    b.box("brick", (0.3, 1.3, 0.3), (gx, Y2 + 2.6, gz + 0.05))
    for sx in (-1, 1):
        b.box("brick", (0.1, 0.7, 0.7), (gx + sx * 0.5, Y2 + 1.25, gz))
    b.table(-0.4, Y2, 1.3, "plastic_white", 0.8)
    for (dx, dz, rot) in [(-0.65, 0, 90), (0.65, 0, -90), (0, 0.65, 180), (0, -0.65, 0)]:
        b.chair(-0.4 + dx, Y2, 1.3 + dz, rot)
    b.parasol(-0.4, Y2, 1.3)
    b.pot_plant(0.6, Y2, 3.7)
    b.pot_plant(-2.2, Y2, 0.0)
    return b


def sobrado():
    """Colonial townhouse (Santa Teresa / Lapa), renovated."""
    b = B(73)
    w1 = b.slot("wall", 1, "#6FB3D9")
    t1 = b.slot("trim", 1, "#F4F2EC")
    d1 = b.slot("door", 1, "#3E7D4F")
    ro = b.slot("roof", 1, "#B2552F")
    W, D, F = 5.6, 9.0, 3.6
    fz = D / 2
    b.box(w1, (W, 2 * F, D), (0, F, 0))
    b.box(t1, (W + 0.06, 0.55, D + 0.06), (0, 0.275, 0))
    b.box(t1, (W + 0.2, 0.18, D + 0.2), (0, F, 0))
    b.box(t1, (W + 0.3, 0.3, D + 0.3), (0, 2 * F + 0.15, 0))
    # platibanda (parapet hiding the roof) + urns
    PH = 0.9
    b.box(w1, (W + 0.1, PH, 0.25), (0, 2 * F + 0.3 + PH / 2, fz + 0.02))
    b.box(t1, (W + 0.3, 0.12, 0.4), (0, 2 * F + 0.3 + PH + 0.06, fz + 0.02))
    for x in (-W / 2, 0, W / 2):
        b.box(t1, (0.4, PH, 0.35), (x, 2 * F + 0.3 + PH / 2, fz + 0.04))
        yb = 2 * F + 0.3 + PH + 0.12
        b.cyl(t1, 0.14, 0.12, (x, yb + 0.06, fz + 0.04), 8)
        b.hull(t1, [(x + 0.22 * np.cos(a), yb + 0.35, fz + 0.04 + 0.22 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 9)[:-1]] +
               [(x + 0.1 * np.cos(a), yb + 0.12, fz + 0.04 + 0.1 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 7)[:-1]] +
               [(x, yb + 0.6, fz + 0.04)])
    b.hull(ro, [(sx * (W / 2 - 0.1), 2 * F + 0.3, sz * (D / 2 - 0.3)) for sx in (-1, 1) for sz in (-1, 1)] +
           [(0, 2 * F + 1.7, D / 2 - 0.3), (0, 2 * F + 1.7, -D / 2 + 0.3)])
    # pilasters
    for x in (-W / 2 + 0.15, W / 2 - 0.15):
        b.box(t1, (0.3, 2 * F, 0.08), (x, F, fz + 0.04))
    # ground: arched door + 2 arched windows
    b.arch_window("z+", fz, 0, 0.55, 1.3, 2.9, glass="glass", frame=t1, sill=None)
    b.box(d1, (1.25, 2.1, 0.06), (0, 0.55 + 1.05, fz + 0.06))
    b.box("metal", (0.04, 0.15, 0.04), (0.2, 1.6, fz + 0.11))
    for u in (-1.75, 1.75):
        b.arch_window("z+", fz, u, 1.0, 1.0, 2.2, glass="glass", frame=t1)
        b.box(d1, (0.48, 1.6, 0.04), (u - 0.25, 1.8, fz + 0.06))
    for u in (-2.1, -1.4, 1.4, 2.1):
        pass
    # upper: 3 french doors + balconettes + small pediments
    for u in (-1.75, 0, 1.75):
        b.window("z+", fz, u, F + 1.45, 0.95, 2.3, bars=False, frame=t1, sill=None, shutters=d1 if u != 0 else None)
        b.balconette("z+", fz, u, F + 0.3, 1.05, 0.5, "frame_black", t1)
        yp = F + 1.45 + 1.15 + 0.1
        b.hull(t1, [fpos("z+", fz, u + sx * 0.65, yp, d) for sx in (-1, 1) for d in (0.0, 0.12)] +
               [fpos("z+", fz, u, yp + 0.35, d) for d in (0.0, 0.12)])
    b.pot_plant(-1.75 + 0.35, F + 0.3, fz + 0.25, 0.14)
    b.pot_plant(1.75 - 0.35, F + 0.3, fz + 0.25, 0.14)
    for sx in (-1, 1):
        b.cyl("frame_black", 0.06, 0.4, (sx * 0.95, 2.9, fz + 0.15), 6)
        b.cyl("lamp", 0.1, 0.22, (sx * 0.95, 2.6, fz + 0.15), 6)
    for face, plane in (("x+", W / 2), ("x-", -W / 2)):
        for u in (-2.0, 1.8):
            b.window(face, plane, u, 1.8, 0.8, 1.4, bars=(u > 0), frame=t1)
            b.window(face, plane, u, F + 1.6, 0.8, 1.4, bars=False, frame=t1)
    b.window("z-", -fz, 0, F + 1.6, 1.0, 1.4, bars=False, frame=t1)
    b.box("ac", (0.3, 0.42, 0.75), (W / 2 + 0.15, F + 2.6, -1.0))
    b.anchor("Eingang", (0, 0, fz + 0.6))
    return b


def mercadinho():
    """Corner grocery with flat above."""
    b = B(79)
    w1 = b.slot("wall", 1, "#EBC03F")
    w2 = b.slot("wall", 2, "#E8893A")
    a1 = b.slot("accent", 1, "#3E7D4F")
    a2 = b.slot("accent", 2, "#C8372D")
    d1 = b.slot("door", 1, "#2E5FA8")
    W, D, H1, H2, S = 8.0, 8.0, 3.2, 2.8, 0.22
    hx, hz = W / 2, D / 2
    t = 0.25
    b.box(w1, (W, H1, t), (0, H1 / 2, -hz + t / 2))
    b.box(w1, (t, H1, D), (-hx + t / 2, H1 / 2, 0))
    b.box(w1, (1.6, H1, t), (-hx + 0.8, H1 / 2, hz - t / 2))
    b.box(w1, (0.2, H1, D - t), (-hx + 1.7, H1 / 2, t / 2))
    sx0 = -hx + 1.8
    b.box(w1, (hx - sx0, 0.6, t), ((sx0 + hx) / 2, H1 - 0.3, hz - t / 2))
    b.box(w1, (t, 0.6, D - t), (hx - t / 2, H1 - 0.3, t / 2))
    for (x, z) in [(hx - 0.15, hz - 0.15), (0.6, hz - 0.15), (hx - 0.15, 0.0), (hx - 0.15, -hz + 0.15)]:
        b.box(w1, (0.3, H1, 0.3), (x, H1 / 2, z))
    b.box("concrete_dk", (W + 0.04, 0.3, D + 0.04), (0, 0.15, 0)) if False else None
    b.box("tile_floor", (hx - sx0, 0.04, D - t), ((sx0 + hx) / 2, 0.02, t / 2))
    b.door("z+", hz, -hx + 0.8, 0.9, 2.05, d1)
    # interior: shelves on back wall, fridge on partition, counter
    goods = ["cloth_red", "cloth_yellow", "cloth_green", "cloth_white", "tank", "gas"]
    for sy in (0.6, 1.2, 1.8):
        b.box("wood_dark", (hx - sx0 - 0.4, 0.04, 0.4), ((sx0 + hx) / 2 - 0.1, sy, -hz + t + 0.2))
        for k in range(12):
            b.box(goods[(k * 3 + int(sy * 5)) % 6], (0.18, 0.3, 0.18), (sx0 + 0.35 + k * 0.45, sy + 0.17, -hz + t + 0.2))
    for k in range(2):
        z = -1.5 + k * 1.0
        b.box("ac", (0.7, 2.0, 0.9), (sx0 + 0.35, 1.0, z))
        b.box("glass_big", (0.02, 1.6, 0.75), (sx0 + 0.71, 1.1, z))
    b.box("counter", (1.6, 1.0, 0.6), (sx0 + 1.0, 0.5, hz - 1.4))
    b.box("metal", (0.35, 0.25, 0.3), (sx0 + 0.6, 1.12, hz - 1.4))
    # fruit stands outside front
    fruit = ["cloth_yellow", "sign_red", "plant", "gas"]
    for i, x in enumerate((1.5, 2.9)):
        b.box("wood_b", (1.2, 0.8, 0.6), (x, 0.4, hz + 0.5))
        b.box("wood_b", (1.2, 0.25, 0.6), (x, 0.92, hz + 0.45), rot_x=15)
        for k in range(4):
            b.rock(fruit[(k + i) % 4], 0.1, (x - 0.45 + k * 0.3, 1.08, hz + 0.45), 0.8)
    # rolled shutters + striped awnings + signs
    b.box("shutter", (hx - sx0, 0.25, 0.25), ((sx0 + hx) / 2, H1 - 0.72, hz - 0.12))
    b.box("shutter", (0.25, 0.25, D - t), (hx - 0.12, H1 - 0.72, t / 2))
    n = int((hx - sx0) / 0.45)
    for k in range(n):
        x = sx0 + (k + 0.5) * (hx - sx0) / n
        b.box(a1 if k % 2 == 0 else "sign_white", ((hx - sx0) / n + 0.005, 0.03, 1.3), (x, H1 - 0.82, hz + 0.6), rot_x=22)
    n2 = int((D - t) / 0.45)
    for k in range(n2):
        z = -hz + t + (k + 0.5) * (D - t) / n2
        b.box(a1 if k % 2 == 0 else "sign_white", (1.3, 0.03, (D - t) / n2 + 0.005), (hx + 0.6, H1 - 0.82, z), rot_z=-22)
    b.box(a2, (hx - sx0 - 0.4, 0.42, 0.06), ((sx0 + hx) / 2, H1 - 0.28, hz + 0.03))
    b.box("sign_white", (hx - sx0 - 1.2, 0.1, 0.02), ((sx0 + hx) / 2, H1 - 0.28, hz + 0.07))
    b.box(a2, (0.06, 0.42, D - 1.0), (hx + 0.03, H1 - 0.28, 0.2))
    b.box("concrete", (W + 0.3, S, D + 0.3), (0, H1 + S / 2, 0))
    Y1 = H1 + S
    b.box(w2, (W, H2, D), (0, Y1 + H2 / 2, 0))
    for u in (-2.6, 0.0, 2.4):
        b.window("z+", hz, u, Y1 + 1.45, 1.1, 1.0, bars=False)
    for u in (-2.6, 0.0, 2.4):
        b.window("x+", hx, u, Y1 + 1.45, 1.1, 1.0, bars=False)
    b.window("x-", -hx, 0.0, Y1 + 1.45, 1.0, 0.9)
    # corner balcony
    b.box("concrete", (2.4, 0.12, 0.7), (hx - 1.2, Y1 + 0.0, hz + 0.35))
    b.box("concrete", (0.7, 0.12, 2.4), (hx + 0.35, Y1 + 0.0, hz - 1.2))
    for p0, p1 in [((hx - 2.4, Y1 + 0.95, hz + 0.68), (hx + 0.68, Y1 + 0.95, hz + 0.68)),
                   ((hx + 0.68, Y1 + 0.95, hz + 0.68), (hx + 0.68, Y1 + 0.95, hz - 2.4))]:
        b.beam("frame_black", p0, p1, 0.05)
    for k in range(7):
        b.beam("frame_black", (hx - 2.35 + k * 0.5, Y1, hz + 0.68), (hx - 2.35 + k * 0.5, Y1 + 0.95, hz + 0.68), 0.03)
        b.beam("frame_black", (hx + 0.68, Y1, hz - 2.35 + k * 0.5), (hx + 0.68, Y1 + 0.95, hz - 2.35 + k * 0.5), 0.03)
    b.pot_plant(hx + 0.3, Y1 + 0.06, hz + 0.3, 0.16)
    b.box("ac", (0.3, 0.42, 0.75), (-hx - 0.15, Y1 + 2.2, -2.0))
    b.box("ac", (0.75, 0.42, 0.3), (-1.3, Y1 + 2.3, hz + 0.15))
    Y2 = Y1 + H2
    b.box("concrete", (W + 0.2, 0.18, D + 0.2), (0, Y2 + 0.09, 0))
    for (sx, sz, cx, cz) in [(W + 0.2, 0.15, 0, hz + 0.02), (W + 0.2, 0.15, 0, -hz - 0.02), (0.15, D, hx + 0.02, 0), (0.15, D, -hx - 0.02, 0)]:
        b.box(w2, (sx, 0.6, sz), (cx, Y2 + 0.48, cz))
    b.tank(-2.0, Y2 + 0.18, -2.0, 0.65, 0.95)
    b.beam("metal", (2.5, Y2 + 0.18, -2.5), (2.5, Y2 + 2.6, -2.5), 0.04)
    for y in (Y2 + 1.8, Y2 + 2.3):
        b.beam("metal", (2.0, y, -2.5), (3.0, y, -2.5), 0.03)
    return b


def predio():
    """Small Copacabana apartment block, 5 floors over a lobby."""
    b = B(83)
    w1 = b.slot("wall", 1, "#EFE1C0")
    n1 = b.slot("nwall", 1, "#E9E4D8")
    d1 = b.slot("door", 1, "#26282A")
    W, D, H0, FH, NF = 10.0, 10.0, 3.5, 2.9, 5
    top = H0 + NF * FH
    hz = D / 2
    b.box(n1, (W, top - H0, D), (0, H0 + (top - H0) / 2, -0.0))
    b.box(n1, (W, H0, D - 2.0), (0, H0 / 2, -1.0))
    b.box("concrete_white", (W + 0.1, 0.3, D + 0.1), (0, H0 - 0.15, 0))
    # lobby: glass, pilotis, gate, guarita, garage
    b.box("glass_big", (4.0, 2.8, 0.05), (-2.5, 1.4, hz - 2.0 + 0.03))
    for x in (-4.5, -2.6, -0.5):
        b.box("frame_black", (0.06, 2.8, 0.08), (x, 1.4, hz - 1.95))
    b.box("gate_metal", (3.0, 2.6, 0.06), (2.8, 1.3, hz - 2.0 + 0.03))
    for k in range(9):
        b.box("metal", (3.0, 0.03, 0.03), (2.8, 0.2 + k * 0.3, hz - 1.94))
    for x in (-4.85, -1.5, 1.2, 4.85):
        b.box("concrete_white", (0.3, H0, 0.3), (x, H0 / 2, hz - 0.2))
    b.box("tile_floor", (W, 0.05, 2.0), (0, 0.025, hz - 1.0))
    xs = np.arange(-4.9, 4.91, 0.35)
    for x in xs:
        if 1.35 < x < 4.3:
            continue
        b.box("metal", (0.03, 2.2, 0.03), (x, 1.1, hz + 0.3))
    b.box("metal", (W, 0.05, 0.05), (0, 2.2, hz + 0.3))
    b.box("metal", (W, 0.05, 0.05), (0, 0.1, hz + 0.3))
    b.box("trim", (1.2, 2.3, 1.2), (-3.8, 1.15, hz - 0.9))
    b.box("glass", (1.0, 0.8, 0.02), (-3.8, 1.6, hz - 0.29))
    b.box("concrete_white", (1.4, 0.1, 1.4), (-3.8, 2.35, hz - 0.9))
    b.door("z+", hz - 2.0, -1.5, 1.2, 2.3, d1)
    # front tile facade + balconies
    b.box(w1, (W - 0.6, top - H0, 0.05), (0, H0 + (top - H0) / 2, hz + 0.025))
    r = b.rng
    for f in range(NF):
        y = H0 + f * FH
        b.box("concrete_white", (W - 0.2, 0.15, 1.2), (0, y + 0.075, hz + 0.6))
        b.box("glass_big", (W - 1.0, 2.2, 0.04), (0, y + 1.25, hz + 0.07))
        for x in np.linspace(-(W - 1.0) / 2, (W - 1.0) / 2, 6):
            b.box("trim", (0.06, 2.2, 0.08), (x, y + 1.25, hz + 0.09))
        b.box(w1, (0.12, 1.1, 1.2), (0, y + 0.7, hz + 0.6))
        if f % 2 == 0:
            b.box(w1, (W - 0.2, 1.0, 0.12), (0, y + 0.65, hz + 1.14))
        else:
            for x in np.linspace(-(W - 0.3) / 2, (W - 0.3) / 2, 9):
                b.beam("frame_black", (x, y + 0.15, hz + 1.15), (x, y + 1.05, hz + 1.15), 0.04)
            for yy in (0.55, 1.05):
                b.beam("frame_black", (-(W - 0.3) / 2, y + yy, hz + 1.15), ((W - 0.3) / 2, y + yy, hz + 1.15), 0.04)
        if f == 3:
            b.box("glass_rail", (W / 2 - 0.2, 1.35, 0.04), (W / 4, y + 1.85, hz + 1.17))
        for x in (-W / 2 - 0.15, W / 2 + 0.15):
            b.box("ac", (0.3, 0.42, 0.75), (x, y + 2.2, 1.5 - 3.0 * (f % 2)))
        for x in (-2.5, 2.5):
            b.window("x+" if x > 0 else "x-", W / 2 if x > 0 else -W / 2, -2.0 if f % 2 else 0.5, y + 1.6, 0.6, 0.6, bars=False)
        if f in (0, 2, 4):
            b.pot_plant(-3.8 + f * 1.4, y + 0.15, hz + 0.75, 0.2)
        if f == 1:
            b.beam("metal", (-4.5, y + 2.0, hz + 0.9), (-1.0, y + 2.0, hz + 0.9), 0.015)
            for k, col in enumerate(("cloth_white", "cloth_red", "cloth_yellow")):
                b.box(col, (0.5, 0.6, 0.02), (-4.0 + k * 1.0, y + 1.68, hz + 0.9))
    # roof
    b.box("concrete_white", (W + 0.2, 0.2, D + 0.2), (0, top + 0.1, 0))
    for (sx, sz, cx, cz) in [(W + 0.2, 0.15, 0, hz + 0.02), (W + 0.2, 0.15, 0, -hz - 0.02), (0.15, D, W / 2 + 0.02, 0), (0.15, D, -W / 2 - 0.02, 0)]:
        b.box(n1, (sx, 0.9, sz), (cx, top + 0.65, cz))
    b.box(n1, (4.0, 2.4, 3.0), (-1.5, top + 0.2 + 1.2, -2.5))
    b.box("concrete_white", (4.3, 0.15, 3.3), (-1.5, top + 2.67, -2.5))
    b.box("door_metal", (0.9, 2.0, 0.05), (-0.5, top + 1.2, -1.0 + 0.03))
    b.beam("metal", (3.0, top + 0.2, -3.0), (3.0, top + 4.5, -3.0), 0.05)
    for y in (top + 3.4, top + 4.0):
        b.beam("metal", (2.3, y, -3.0), (3.7, y, -3.0), 0.03)
    dish(b, (2.5, top + 0.9, 2.0), 0.4)
    b.beam("metal", (2.5, top + 0.2, 1.8), (2.5, top + 0.8, 1.9), 0.04)
    return b


# =====================================================================
# GEHOBEN / REICH
# =====================================================================
def zona_oeste():
    b = B(41)
    n1 = b.slot("nwall", 1, "#EFE1C0")
    n2 = b.slot("nwall", 2, "#D8C7A2")
    ro = b.slot("roof", 1, "#B2552F")
    s1 = b.slot("shutter", 1, "#2F6EA5")
    d1 = b.slot("door", 1, "#7A4E2D")
    LW, LD, WH = 12.0, 13.0, 2.0
    lx, lz = LW / 2, LD / 2
    b.box("tile_floor", (LW, 0.04, LD), (0, 0.02, 0))

    def wall(x0, x1, z0, z1):
        cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
        sx, sz = max(abs(x1 - x0), 0.2), max(abs(z1 - z0), 0.2)
        b.box(n2, (sx, WH, sz), (cx, WH / 2, cz))
        b.box("trim", (sx + 0.06, 0.08, sz + 0.06), (cx, WH + 0.04, cz))
    wall(-lx, -5.2, lz, lz)
    wall(-2.0, 1.0, lz, lz)
    wall(2.0, lx, lz, lz)
    wall(-lx, -lx, -lz, lz)
    wall(lx, lx, -lz, lz)
    wall(-lx, lx, -lz, -lz)
    b.box("gate_metal", (3.2, 1.9, 0.06), (-3.6, 0.97, lz))
    for k in range(13):
        b.box("metal", (0.04, 1.9, 0.08), (-5.1 + k * 0.25, 0.97, lz + 0.02))
    b.box("gate_metal", (1.0, 1.9, 0.06), (1.5, 0.97, lz))
    for x in (-5.25, -1.95, 0.95, 2.05):
        b.box("trim", (0.3, WH + 0.3, 0.3), (x, (WH + 0.3) / 2, lz))
    b.cyl("lamp", 0.12, 0.25, (0.95, WH + 0.42, lz), 8)
    posts = [(x, lz) for x in np.arange(-lx, lx + 0.01, 2.0)] + \
            [(sx * lx, z) for sx in (-1, 1) for z in np.arange(-lz + 1.5, lz - 0.5, 2.0)]
    for x, z in posts:
        b.beam("metal", (x, WH + 0.08, z), (x, WH + 0.6, z), 0.03)
    for hh in (0.25, 0.45):
        b.beam("metal", (-lx, WH + hh, lz), (lx, WH + hh, lz), 0.012)
        for sx in (-1, 1):
            b.beam("metal", (sx * lx, WH + hh, -lz + 1.5), (sx * lx, WH + hh, lz), 0.012)
    HX0, HX1, HZ0, HZ1 = -4.0, 4.0, -6.0, 0.5
    G, U = 3.0, 2.8
    hcz, hw, hd = (HZ0 + HZ1) / 2, HX1 - HX0, HZ1 - HZ0
    b.box(n1, (hw, G, hd), (0, G / 2, hcz))
    b.box("tile_blue", (hw + 0.04, 0.7, hd + 0.04), (0, 0.35, hcz))
    b.box("trim", (hw + 0.1, 0.2, hd + 0.1), (0, G + 0.1, hcz))
    b.box(n1, (hw, U, hd), (0, G + 0.2 + U / 2, hcz))
    YR = G + 0.2 + U
    b.box("trim", (hw + 0.1, 0.15, hd + 0.1), (0, YR + 0.075, hcz))
    YR += 0.15
    ov = 0.55
    rx0, rx1, rz0, rz1 = HX0 - ov, HX1 + ov, HZ0 - ov, HZ1 + ov
    rc = (rz0 + rz1) / 2
    b.hull(ro, [(rx0, YR, rz0), (rx1, YR, rz0), (rx0, YR, rz1), (rx1, YR, rz1), (-1.8, YR + 1.9, rc), (1.8, YR + 1.9, rc)])
    VZ1 = 2.6
    b.box("trim", (hw + 0.2, 0.22, VZ1 - HZ1), (0, G + 0.09, (HZ1 + VZ1) / 2))
    b.box("tile_floor", (hw, 0.06, VZ1 - HZ1), (0, 0.07, (HZ1 + VZ1) / 2))
    for x in (-3.75, -1.25, 1.25, 3.75):
        b.cyl("stone_white", 0.14, G, (x, G / 2, VZ1 - 0.25), 8)
    bal_y = G + 0.2
    for x in np.arange(-3.95, 3.96, 0.26):
        b.cyl("stone_white", 0.045, 0.75, (x, bal_y + 0.375, VZ1 - 0.05), 6)
    for z in np.arange(HZ1 + 0.2, VZ1 - 0.1, 0.26):
        for x in (-4.05, 4.05):
            b.cyl("stone_white", 0.045, 0.75, (x, bal_y + 0.375, z), 6)
    b.box("trim", (hw + 0.2, 0.08, 0.14), (0, bal_y + 0.79, VZ1 - 0.05))
    for x in (-4.05, 4.05):
        b.box("trim", (0.14, 0.08, VZ1 - HZ1), (x, bal_y + 0.79, (HZ1 + VZ1) / 2))
    b.box("trim", (1.7, 2.35, 0.03), (0, 1.175, HZ1 + 0.015))
    for sx in (-1, 1):
        b.box(d1, (0.75, 2.2, 0.05), (sx * 0.39, 1.1, HZ1 + 0.04))
    for u in (-2.6, 2.6):
        b.window("z+", HZ1, u, 1.6, 1.1, 1.1, bars=False, shutters=s1)
    for u in (-1.6, 1.6):
        b.door("z+", HZ1, u, 0.9, 2.1, d1, y0=G + 0.2)
        b.box("glass", (0.6, 1.2, 0.02), (u, G + 0.2 + 1.25, HZ1 + 0.075))
    for face, plane in (("x+", HX1), ("x-", HX0)):
        for u in (-1.5, -4.2):
            b.window(face, plane, u, 1.6, 1.0, 1.0, bars=False, shutters=s1)
            b.window(face, plane, u, G + 0.2 + 1.5, 1.0, 1.0, bars=False, shutters=s1)
    b.window("z-", HZ0, 0, 1.6, 1.4, 1.0, bars=True)
    b.window("z-", HZ0, 0, G + 1.7, 1.4, 1.0, bars=False, shutters=s1)
    b.box("ac", (0.3, 0.42, 0.75), (HX1 + 0.15, G + 2.4, -3.0))
    b.box("ac", (0.3, 0.42, 0.75), (HX0 - 0.15, G + 2.4, -3.0))
    b.palm(4.3, 4.4, 5.8, (0.6, 0.3))
    b.palm(-5.0, -4.5, 5.0, (-0.3, 0.4))
    b.pot_plant(-1.1, 0.08, 1.2, 0.22)
    b.pot_plant(1.1, 0.08, 1.2, 0.22)
    b.box("hedge", (3.0, 0.8, 0.8), (3.8, 0.4, 5.9))
    b.box("hedge", (0.8, 0.8, 4.0), (5.4, 0.4, -2.0))
    dish(b, (3.0, YR + 1.45, -1.0), 0.38)
    b.beam("metal", (3.0, YR + 0.8, -1.2), (3.0, YR + 1.4, -1.05), 0.04)
    b.anchor("Eingang", (1.5, 0, lz + 0.3))
    return b


def villa():
    b = B(53)
    n1 = b.slot("nwall", 1, "#ECEAE4")
    n2 = b.slot("nwall", 2, "#ECEAE4")
    wd = b.slot("wood", 1, "#A86B3C")
    a1 = b.slot("accent", 1, "#EBC03F")
    LX, LZ = 9.0, 8.5
    b.box("grass", (2 * LX, 0.04, 2 * LZ), (0, 0.02, 0))
    GX0, GX1, GZ0, GZ1, GH = -6.0, 5.0, -7.0, -1.0, 3.2
    b.box(n1, (GX1 - GX0, GH, GZ1 - GZ0), ((GX0 + GX1) / 2, GH / 2, (GZ0 + GZ1) / 2))
    gx = np.arange(GX0 + 0.4, GX1 - 0.39, 1.4)
    b.box("glass_big", (GX1 - GX0 - 0.8, GH - 0.5, 0.04), ((GX0 + GX1) / 2, (GH - 0.5) / 2 + 0.15, GZ1 + 0.03))
    for x in list(gx) + [GX1 - 0.4]:
        b.box("frame_black", (0.06, GH - 0.5, 0.08), (x, (GH - 0.5) / 2 + 0.15, GZ1 + 0.05))
    b.box("frame_black", (GX1 - GX0 - 0.8, 0.06, 0.08), ((GX0 + GX1) / 2, GH - 0.35, GZ1 + 0.05))
    UX0, UX1, UZ0, UZ1, UY0, UH = -3.0, 6.5, -6.5, 0.5, 3.4, 3.0
    b.box("concrete_white", (UX1 - UX0 + 0.2, 0.2, UZ1 - UZ0 + 0.2), ((UX0 + UX1) / 2, GH + 0.1, (UZ0 + UZ1) / 2))
    b.box(wd, (UX1 - UX0, UH, UZ1 - UZ0), ((UX0 + UX1) / 2, UY0 + UH / 2, (UZ0 + UZ1) / 2))
    b.box("glass_big", (UX1 - UX0 - 0.8, 1.6, 0.04), ((UX0 + UX1) / 2, UY0 + 1.5, UZ1 + 0.03))
    for x in list(np.arange(UX0 + 0.4, UX1 - 0.39, 1.8)) + [UX1 - 0.4]:
        b.box("frame_black", (0.06, 1.6, 0.08), (x, UY0 + 1.5, UZ1 + 0.05))
    for z in np.arange(UZ0 + 0.15, UZ1 - 0.1, 0.25):
        b.box("wood_dark", (0.06, UH - 0.2, 0.08), (UX1 + 0.04, UY0 + UH / 2, z))
    b.box("glass_big", (0.04, 1.6, 4.0), (UX0 - 0.03, UY0 + 1.5, -2.5))
    b.box("concrete_white", (UX1 - UX0 + 0.6, 0.25, UZ1 - UZ0 + 0.6), ((UX0 + UX1) / 2, UY0 + UH + 0.125, (UZ0 + UZ1) / 2))
    RY = UY0 + UH + 0.25
    for i in range(3):
        for j in range(2):
            x, z = i * 1.6, -5.0 + j * 2.2
            b.box("metal", (1.15, 0.25, 1.75), (x, RY + 0.12, z))
            b.box("solar", (1.1, 0.05, 1.7), (x, RY + 0.35, z), rot_x=-12)
    for (sx, sz, cx, cz) in [(3.0, 0.05, -4.5, GZ1), (0.05, 6.0, GX0, -4.0)]:
        b.box("glass_rail", (sx, 1.0, sz), (cx, GH + 0.5, cz))
    b.lounger(-4.8, -2.4, 180, GH)
    b.pot_plant(-3.5, GH, -1.5, 0.25)
    b.box("deck", (11.0, 0.08, 2.6), (-0.5, 0.06, 0.3))
    for z in np.arange(-0.9, 1.6, 0.3):
        b.box("wood_dark", (11.0, 0.01, 0.02), (-0.5, 0.105, z))
    PX0, PX1, PZ0, PZ1 = -4.5, 3.5, 2.0, 5.2
    b.box("pool", (PX1 - PX0, 0.04, PZ1 - PZ0), ((PX0 + PX1) / 2, 0.05, (PZ0 + PZ1) / 2))
    for (sx, sz, cx, cz) in [(PX1 - PX0 + 0.8, 0.4, (PX0 + PX1) / 2, PZ0 - 0.2), (PX1 - PX0 + 0.8, 0.4, (PX0 + PX1) / 2, PZ1 + 0.2),
                             (0.4, PZ1 - PZ0, PX0 - 0.2, (PZ0 + PZ1) / 2), (0.4, PZ1 - PZ0, PX1 + 0.2, (PZ0 + PZ1) / 2)]:
        b.box("stone_white", (sx, 0.12, sz), (cx, 0.06, cz))
    for x in (4.6, 5.6):
        b.lounger(x, 3.4, 0)
    b.parasol(5.1, 0, 2.2, a1, 1.3, 2.5)
    b.palm(7.0, 5.8, 6.2, (0.5, 0.4))
    b.palm(-7.2, 5.0, 5.6, (-0.4, 0.3))
    b.palm(7.4, -2.0, 6.8, (0.3, -0.3))
    b.box("hedge", (1.0, 1.3, 2 * LZ - 1.0), (-LX + 0.5, 0.65, 0))
    b.box("hedge", (1.0, 1.3, 2 * LZ - 1.0), (LX - 0.5, 0.65, 0))
    b.box(n2, (LX - 1.0, 1.2, 0.3), (-(LX + 1.0) / 2, 0.6, LZ - 0.15))
    b.box(n2, (LX - 3.0, 1.2, 0.3), ((LX + 3.0) / 2, 0.6, LZ - 0.15))
    b.box(wd, (3.0, 1.6, 0.08), (1.5, 0.8, LZ - 0.15))
    for k in range(10):
        b.box("wood_dark", (0.04, 1.6, 0.1), (0.15 + k * 0.3, 0.8, LZ - 0.12))
    for x, z in [(-5.0, 1.5), (-1.0, 1.5), (4.0, 1.5), (-5.6, 6.0), (4.5, 6.5)]:
        b.cyl("frame_black", 0.08, 0.5, (x, 0.25, z), 6)
        b.cyl("lamp", 0.085, 0.1, (x, 0.55, z), 6)
    b.box("hedge", (2.0, 0.9, 0.9), (-6.6, 0.45, -7.5))
    b.anchor("Eingang", (1.5, 0, LZ + 0.3))
    return b


def casa_barra():
    """Mediterranean-style mansion (Barra da Tijuca) with arcade, pool and garage."""
    b = B(89)
    n1 = b.slot("nwall", 1, "#D9C9A8")
    n2 = b.slot("nwall", 2, "#F2F0EA")
    ro = b.slot("roof", 1, "#B2552F")
    d1 = b.slot("door", 1, "#7A4E2D")
    LX, LZ = 11.0, 9.5
    b.box("grass", (2 * LX, 0.04, 2 * LZ), (0, 0.02, 0))
    # main house
    X0, X1, Z0, Z1, G, U = -8.0, 4.0, -8.0, 0.0, 3.3, 3.1
    b.box(n1, (X1 - X0, G, Z1 - Z0 - 2.0), ((X0 + X1) / 2, G / 2, (Z0 + Z1 - 2.0) / 2))
    b.box(n1, (X1 - X0, U, Z1 - Z0), ((X0 + X1) / 2, G + 0.25 + U / 2, (Z0 + Z1) / 2))
    b.box(n2, (X1 - X0 + 0.2, 0.25, Z1 - Z0 + 0.2), ((X0 + X1) / 2, G + 0.125, (Z0 + Z1) / 2))
    b.box(n2, (X1 - X0 + 0.1, 0.4, Z1 - Z0 - 1.9), ((X0 + X1) / 2, 0.2, (Z0 + Z1 - 2.0) / 2))
    # arcade (5 arches) on front, loggia behind
    cols = np.linspace(X0 + 0.2, X1 - 0.2, 6)
    spring = 1.9
    for i in range(5):
        cx = (cols[i] + cols[i + 1]) / 2
        rr = (cols[i + 1] - cols[i]) / 2 - 0.2
        b.arch_spandrel(n1, "z+", Z1 - 0.3, cx, spring, rr, G, 0.0, 0.3)
    for i, x in enumerate(cols):
        b.box(n2, (0.4, spring, 0.4), (x, spring / 2, Z1 - 0.15))
        b.box(n2, (0.5, 0.15, 0.5), (x, spring + 0.07, Z1 - 0.15))
    b.box(n1, (X1 - X0, G - spring - 1.15, 0.3), ((X0 + X1) / 2, G - 0.06, Z1 - 0.15)) if False else None
    b.box("tile_floor", (X1 - X0, 0.06, 2.0), ((X0 + X1) / 2, 0.05, Z1 - 1.0))
    b.box("glass_big", (6.0, 2.4, 0.04), (-2.0, 1.35, Z1 - 2.0 + 0.03))
    for x in np.linspace(-5.0, 1.0, 5):
        b.box("frame_black", (0.06, 2.4, 0.08), (x, 1.35, Z1 - 1.95))
    b.box("trim", (1.6, 2.6, 0.03), (-6.3, 1.3, Z1 - 2.0 + 0.015))
    for sx in (-1, 1):
        b.box(d1, (0.7, 2.45, 0.05), (-6.3 + sx * 0.37, 1.25, Z1 - 1.96))
    # upper floor windows + balconettes
    for u in (-6.8, -4.4, -2.0, 0.4, 2.8):
        b.window("z+", Z1, u, G + 0.25 + 1.45, 1.1, 1.6, bars=False, frame="trim", sill=None)
        b.balconette("z+", Z1, u, G + 0.3, 1.2, 0.5, "frame_black", n2)
    for face, plane in (("x+", X1), ("x-", X0)):
        for u in (-2.0, -5.5):
            b.window(face, plane, u, 1.7, 1.0, 1.3, bars=False)
            b.window(face, plane, u, G + 1.7, 1.0, 1.3, bars=False)
    YR = G + 0.25 + U
    b.box(n2, (X1 - X0 + 0.3, 0.2, Z1 - Z0 + 0.3), ((X0 + X1) / 2, YR + 0.1, (Z0 + Z1) / 2))
    YR += 0.2
    b.hull(ro, [(X0 - 0.6, YR, Z0 - 0.6), (X1 + 0.6, YR, Z0 - 0.6), (X0 - 0.6, YR, Z1 + 0.6), (X1 + 0.6, YR, Z1 + 0.6),
                (X0 + 3.5, YR + 2.2, (Z0 + Z1) / 2), (X1 - 3.5, YR + 2.2, (Z0 + Z1) / 2)])
    b.box(n1, (0.8, 1.6, 0.8), (X0 + 2.5, YR + 1.8, -5.0))
    b.box(n2, (1.0, 0.15, 1.0), (X0 + 2.5, YR + 2.65, -5.0))
    # garage wing
    GX0, GX1, GZ0, GZ1, GHh = 4.0, 10.0, -8.0, -1.0, 3.0
    b.box(n1, (GX1 - GX0, GHh, GZ1 - GZ0), ((GX0 + GX1) / 2, GHh / 2, (GZ0 + GZ1) / 2))
    for x in (5.6, 8.4):
        b.box("trim", (2.6, 2.4, 0.03), (x, 1.2, GZ1 + 0.015))
        b.box("gate_metal", (2.4, 2.25, 0.05), (x, 1.13, GZ1 + 0.04))
        for k in range(7):
            b.box("metal", (2.4, 0.02, 0.02), (x, 0.3 + k * 0.32, GZ1 + 0.07))
    b.box(n2, (GX1 - GX0 + 0.3, 0.2, GZ1 - GZ0 + 0.3), ((GX0 + GX1) / 2, GHh + 0.1, (GZ0 + GZ1) / 2))
    b.hull(ro, [(GX0, GHh + 0.2, GZ0 - 0.4), (GX1 + 0.4, GHh + 0.2, GZ0 - 0.4), (GX0, GHh + 0.2, GZ1 + 0.4),
                (GX1 + 0.4, GHh + 0.2, GZ1 + 0.4), (GX0 + 1.0, GHh + 1.4, (GZ0 + GZ1) / 2), (GX1 - 2.0, GHh + 1.4, (GZ0 + GZ1) / 2)])
    b.box("tile_floor", (6.0, 0.05, 9.5), (7.0, 0.04, 3.75))
    # pool with jacuzzi, deck, loungers, palms
    PX0, PX1, PZ0, PZ1 = -7.0, 1.0, 2.5, 6.5
    b.box("tile_floor", (11.0, 0.06, 6.5), (-3.0, 0.04, 4.5))
    b.box("pool", (PX1 - PX0, 0.04, PZ1 - PZ0), ((PX0 + PX1) / 2, 0.09, (PZ0 + PZ1) / 2))
    for (sx, sz, cx, cz) in [(PX1 - PX0 + 0.8, 0.4, (PX0 + PX1) / 2, PZ0 - 0.2), (PX1 - PX0 + 0.8, 0.4, (PX0 + PX1) / 2, PZ1 + 0.2),
                             (0.4, PZ1 - PZ0, PX0 - 0.2, (PZ0 + PZ1) / 2), (0.4, PZ1 - PZ0, PX1 + 0.2, (PZ0 + PZ1) / 2)]:
        b.box("stone_white", (sx, 0.14, sz), (cx, 0.07, cz))
    b.cyl("stone_white", 1.15, 0.4, (2.3, 0.2, 4.0), 12)
    b.cyl("pool", 0.95, 0.05, (2.3, 0.4, 4.0), 12)
    for x in (-5.5, -4.0, -2.5):
        b.lounger(x, 1.2, 0)
    b.parasol(-1.2, 0.06, 1.3, "parasol_white", 1.2, 2.5)
    for (x, z, h, lean) in [(-9.5, 6.5, 6.4, (-0.4, 0.3)), (3.8, 7.6, 5.8, (0.4, 0.4)), (9.5, 6.5, 6.8, (0.3, 0.2)), (-9.6, -2.0, 5.5, (-0.3, 0))]:
        b.palm(x, z, h, lean)
    # front fence: low wall + bars, gate
    for x0, x1 in ((-LX, 3.5), (8.0, LX)):
        b.box(n2, (x1 - x0, 0.6, 0.3), ((x0 + x1) / 2, 0.3, LZ - 0.15))
        for x in np.arange(x0 + 0.2, x1, 0.5):
            b.beam("frame_black", (x, 0.6, LZ - 0.15), (x, 1.8, LZ - 0.15), 0.035)
        b.beam("frame_black", (x0, 1.75, LZ - 0.15), (x1, 1.75, LZ - 0.15), 0.05)
    b.box("gate_metal", (4.5, 1.8, 0.06), (5.75, 0.9, LZ - 0.15))
    for x in (3.5, 8.0):
        b.box(n2, (0.45, 2.2, 0.45), (x, 1.1, LZ - 0.15))
        b.cyl("lamp", 0.14, 0.3, (x, 2.35, LZ - 0.15), 8)
    for sx in (-1, 1):
        b.box("hedge", (0.9, 1.4, 2 * LZ - 1.0), (sx * (LX - 0.45), 0.7, 0))
    b.anchor("Eingang", (5.75, 0, LZ + 0.3))
    return b


def leblon():
    """High-rise with wrap-around glass balconies and a rooftop-pool penthouse."""
    b = B(97)
    n1 = b.slot("nwall", 1, "#F2F0EA")
    n2 = b.slot("nwall", 2, "#C9C9C4")
    gl = b.slot("glass", 1, "#6F98AE")
    wd = b.slot("wood", 1, "#9C6B42")
    W, D, H0, FH, NF = 12.0, 11.0, 4.0, 3.0, 7
    top = H0 + NF * FH
    b.box(gl, (W - 1.2, top - H0, D - 1.2), (0, H0 + (top - H0) / 2, 0))
    for sx in (-1, 1):
        for sz in (-1, 1):
            b.box(n2, (0.6, top - 0.0, 0.6), (sx * (W / 2 - 0.6), top / 2, sz * (D / 2 - 0.6)))
    for f in range(NF + 1):
        y = H0 + f * FH
        b.box(n1, (W + 0.6, 0.3, D + 0.6), (0, y - 0.15, 0))
        if f == NF:
            break
        for (sx, sz, cx, cz) in [(W + 0.5, 0.04, 0, D / 2 + 0.27), (W + 0.5, 0.04, 0, -D / 2 - 0.27),
                                 (0.04, D + 0.5, W / 2 + 0.27, 0), (0.04, D + 0.5, -W / 2 - 0.27, 0)]:
            b.box("glass_rail", (sx, 1.05, sz), (cx, y + 0.52, cz))
        for x in np.linspace(-(W - 1.2) / 2, (W - 1.2) / 2, 6):
            b.box("frame_black", (0.05, FH - 0.3, 0.06), (x, y + (FH - 0.3) / 2, (D - 1.2) / 2 + 0.02))
        if f % 3 == 1:
            b.box("hedge", (2.4, 0.5, 0.5), (-3.0, y + 0.25, D / 2 - 0.1))
        if f % 3 == 2:
            b.box("hedge", (2.4, 0.5, 0.5), (3.2, y + 0.25, D / 2 - 0.1))
    # lobby
    b.box(n2, (W - 3.0, H0, D - 3.0), (0, H0 / 2, -0.5))
    b.box(gl, (6.0, 3.2, 0.05), (0.5, 1.6, D / 2 - 2.0 + 0.03))
    for x in (-W / 2 + 0.6, W / 2 - 0.6):
        for z in (D / 2 - 0.6,):
            b.box(n1, (0.6, H0, 0.6), (x, H0 / 2, z))
    b.box(n1, (4.0, 0.25, 3.0), (0.5, 3.2, D / 2 + 0.5))
    for x in (-1.2, 2.2):
        b.beam("frame_black", (x, 0, D / 2 + 1.8), (x, 3.1, D / 2 + 1.8), 0.08)
    b.box("trim", (1.6, 2.4, 1.6), (-4.2, 1.2, D / 2 + 1.0))
    b.box(gl, (1.4, 0.9, 0.03), (-4.2, 1.6, D / 2 + 1.81))
    b.box("tile_floor", (W + 4.0, 0.05, 6.0), (0, 0.025, D / 2 + 1.5))
    for x in (-6.5, 6.5):
        b.box("stone_white", (1.6, 0.6, 1.6), (x, 0.3, D / 2 + 3.0))
        b.palm(x, D / 2 + 3.0, 5.5, (0.3 * np.sign(x), 0.2), y=0.6)
    for x0, x1 in ((-W / 2 - 2, -1.5), (3.0, W / 2 + 2)):
        b.box("hedge", (x1 - x0, 1.0, 0.6), ((x0 + x1) / 2, 0.5, D / 2 + 4.2))
    # penthouse (2 setback floors) + rooftop pool
    PW, PD = W - 4.0, D - 4.0
    b.box(gl, (PW, 3.2, PD), (-1.0, top + 1.6, -1.0))
    b.box(n1, (PW + 0.6, 0.3, PD + 0.6), (-1.0, top + 3.35, -1.0))
    b.box(gl, (PW - 3.0, 3.0, PD - 2.0), (-2.0, top + 3.5 + 1.5, -1.5))
    b.box(n1, (PW - 2.4, 0.3, PD - 1.4), (-2.0, top + 6.15, -1.5))
    for sx in (-1, 1):
        b.box(n1, (0.4, 3.2, 0.4), (-1.0 + sx * (PW / 2 - 0.2), top + 1.6, -1.0 + PD / 2 - 0.2))
    # rooftop terrace on main slab
    b.box(wd, (W - 0.4, 0.08, D - 0.4), (0, top + 0.04, 0))
    b.box("pool", (2.0, 0.04, 7.0), (W / 2 - 1.6, top + 0.12, -0.5))
    b.box("stone_white", (2.6, 0.1, 7.6), (W / 2 - 1.6, top + 0.1, -0.5))
    for z in (2.8, -3.8):
        b.box("stone_white", (2.6, 0.12, 0.3), (W / 2 - 1.6, top + 0.16, z + (0.15 if z > 0 else -0.15) * 0 + (0.0)))
    for (sx, sz, cx, cz) in [(W + 0.5, 0.04, 0, D / 2 + 0.27), (W + 0.5, 0.04, 0, -D / 2 - 0.27),
                             (0.04, D + 0.5, W / 2 + 0.27, 0), (0.04, D + 0.5, -W / 2 - 0.27, 0)]:
        b.box("glass_rail", (sx, 1.1, sz), (cx, top + 0.55, cz))
    for k in range(3):
        b.lounger(1.5 + k * 1.0, 4.2, 180, top + 0.08)
    for x in (-4.5, 4.8):
        b.box("stone_white", (1.0, 0.6, 1.0), (x, top + 0.3, D / 2 - 0.8))
        b.palm(x, D / 2 - 0.8, 3.6, (0.2, 0.2), y=top + 0.6)
    # pergola
    for x in (-5.4, -3.0):
        for z in (2.0, 4.6):
            b.beam(wd, (x, top, z), (x, top + 2.6, z), 0.12)
    for z in np.arange(2.0, 4.7, 0.4):
        b.box(wd, (2.8, 0.1, 0.08), (-4.2, top + 2.65, z))
    b.table(-4.2, top + 0.08, 3.3, "stone_white", 1.0)
    b.anchor("Eingang", (0.5, 0, D / 2 + 2.2))
    return b


def joa():
    """Modernist house on pilotis among boulders (Joá / São Conrado)."""
    b = B(101)
    n1 = b.slot("nwall", 1, "#F2F0EA")
    n2 = b.slot("nwall", 2, "#F2F0EA")
    gl = b.slot("glass", 1, "#6F98AE")
    wd = b.slot("wood", 1, "#A86B3C")
    r = b.rng
    X0, X1, Z0, Z1, Y, H = -8.0, 8.0, -3.5, 3.5, 3.0, 3.2
    b.box("grass", (30.0, 0.04, 20.0), (1.5, 0.02, 0.5))
    for x in (-7.2, -2.4, 2.4, 7.2):
        for z in (-2.6, 2.6):
            b.cyl(n1, 0.2, Y, (x, Y / 2, z), 8)
    b.box(n1, (X1 - X0 + 0.4, 0.35, Z1 - Z0 + 0.4), (0, Y + 0.175, 0))
    b.box(wd, (X1 - X0, H, Z1 - Z0), (0, Y + 0.35 + H / 2, 0))
    YT = Y + 0.35 + H
    b.box(n1, (X1 - X0 + 0.8, 0.3, Z1 - Z0 + 0.8), (0, YT + 0.15, 0))
    b.box(gl, (X1 - X0 - 0.6, 2.0, 0.04), (0, Y + 0.35 + 1.4, Z1 + 0.03))
    for x in np.arange(X0 + 0.4, X1 - 0.3, 0.55):
        b.box(n2, (0.08, H - 0.1, 0.35), (x, Y + 0.35 + H / 2, Z1 + 0.2))
    b.box(gl, (X1 - X0 - 0.6, 1.2, 0.04), (0, Y + 0.35 + 1.8, Z0 - 0.03))
    for face, plane in (("x+", X1), ("x-", X0)):
        b.box(gl, fsize(face, Z1 - Z0 - 1.0, 2.2, 0.04), fpos(face, plane, 0, Y + 0.35 + 1.4, 0.03))
    # roof garden
    b.box("grass", (X1 - X0, 0.08, Z1 - Z0), (0, YT + 0.34, 0))
    for (x, z, w, d) in [(-6.0, -2.0, 2.5, 1.0), (3.0, 2.2, 3.5, 0.8), (6.5, -2.0, 1.2, 1.2)]:
        b.box("hedge", (w, 0.7, d), (x, YT + 0.7, z))
    for x in (-2.0, 0.5):
        b.lounger(x, -0.5, 180, YT + 0.38)
    for (sx, sz, cx, cz) in [(X1 - X0 + 0.7, 0.04, 0, Z1 + 0.37), (X1 - X0 + 0.7, 0.04, 0, Z0 - 0.37),
                             (0.04, Z1 - Z0 + 0.7, X1 + 0.37, 0), (0.04, Z1 - Z0 + 0.7, X0 - 0.37, 0)]:
        b.box("glass_rail", (sx, 0.9, sz), (cx, YT + 0.75, cz))
    # entrance: glass box under the house + stair up through the slab
    b.box(gl, (4.0, 2.7, 3.0), (-4.2, 1.35, 0))
    b.box(n1, (4.2, 0.15, 3.2), (-4.2, 2.77, 0))
    b.stairs("concrete_white", 0.4, 1.6, 2.8, 0, Y + 0.35, 0.28, -1, True)
    b.box("tile_floor", (6.0, 0.05, 9.0), (-1.5, 0.04, 0.5))
    # boulders
    for (x, z, rr) in [(-11.5, 5.0, 1.9), (-12.5, -3.0, 2.4), (11.5, -5.5, 2.0), (-9.8, 7.5, 1.2), (5.0, 8.0, 1.0), (-6.0, -6.8, 1.5)]:
        b.rock("stone", rr, (x, rr * 0.35, z), 0.75)
    # infinity pool platform on the right
    PX0, PX1, PZ0, PZ1 = 9.0, 15.0, -3.0, 4.0
    b.box("stone_white", (PX1 - PX0, 0.7, PZ1 - PZ0), ((PX0 + PX1) / 2, 0.35, (PZ0 + PZ1) / 2))
    b.box("pool", (PX1 - PX0 - 1.4, 0.04, PZ1 - PZ0 - 1.4), ((PX0 + PX1) / 2 + 0.3, 0.72, (PZ0 + PZ1) / 2))
    b.box("deck", (5.0, 0.08, 7.0), (6.2, 0.06, 0.5))
    for z in (-1.0, 0.2):
        b.lounger(7.2, z, 90, 0.1)
    b.palm(6.0, 5.6, 6.0, (0.4, 0.4))
    b.palm(-9.0, 2.0, 5.2, (-0.3, 0.2))
    for x, z in [(-6.0, 5.0), (0.0, 5.0), (6.0, 5.0)]:
        b.cyl("frame_black", 0.08, 0.5, (x, 0.25, z), 6)
        b.cyl("lamp", 0.085, 0.1, (x, 0.55, z), 6)
    b.anchor("Eingang", (1.0, 0, 3.2))
    return b


HOUSES = [
    # slug, name, class, builder
    ("01_barraco", "Barraco", "Sehr arm", barraco),
    ("02_palafita", "Palafita", "Sehr arm", palafita),
    ("03_puxadinho", "Puxadinho", "Arm", puxadinho),
    ("04_favela_reihe", "Favela-Reihe", "Arm", favela_reihe),
    ("05_cortico", "Cortiço", "Arm", cortico),
    ("06_casa_rio", "Casa Rio", "Einfach", casa_rio),
    ("07_boteco", "Casa do Boteco", "Mittel", boteco),
    ("08_sobrado", "Sobrado", "Mittel", sobrado),
    ("09_mercadinho", "Mercadinho", "Mittel", mercadinho),
    ("10_predio", "Prédio Copacabana", "Mittel", predio),
    ("11_zona_oeste", "Casa Zona Oeste", "Gehoben", zona_oeste),
    ("12_villa_zona_sul", "Villa Zona Sul", "Reich", villa),
    ("13_casa_barra", "Casa Barra", "Reich", casa_barra),
    ("14_cobertura_leblon", "Cobertura Leblon", "Reich", leblon),
    ("15_casa_joa", "Casa Modernista Joá", "Reich", joa),
    ("16_tankstelle_257", "Tankstelle 257", "Spezial", tankstelle),
    ("17_mansao_leblon", "Mansão Leblon · R$ 20 Mio.", "Luxus", mansao_leblon),
    ("18_mansao_joatinga", "Mansão Joatinga · R$ 50 Mio.", "Luxus", mansao_joatinga),
    ("19_banco_brasilia", "Banco de Brasilia", "Spezial", bank),
] + [(s, n, c, f) for (s, n, c, f) in buildings2.BUILDINGS2] + [
    ("29_clube_subsolo", "Clube Subsolo (Nachtclub)", "Spezial", nightclub),
    ("30_garagem_021", "Garagem 021 (Tuning)", "Spezial", tuning),
    ("31_mega_moda", "Mega Moda Popular (Kleiderladen)", "Spezial", loja),
    ("32_estadio_do_rio", "Estádio do Rio (Stadion)", "Spezial", stadion),
    ("33_esmeralda_joias", "Esmeralda Joias (Juwelier)", "Spezial", juwelier),
]


def randomize(b, rng):
    for name in list(b.colors):
        kind = name.split("_")[1]
        b.colors[name] = rng.choice(SLOT_PALETTES[kind])


if __name__ == "__main__":
    os.makedirs("out", exist_ok=True)
    nvar = int(sys.argv[sys.argv.index("--varianten") + 1]) if "--varianten" in sys.argv else 0
    only = [a for a in sys.argv[1:] if not a.startswith("--") and not a.isdigit()]
    meta = []
    for slug, name, cls, fn in HOUSES:
        if only and not any(o in slug for o in only):
            continue
        bh = fn()
        lot = bh.normalize()
        if cls == "Ecke":                       # corner lots: second street face flush with the +X edge too
            allm = trimesh.util.concatenate([m for ms in bh.parts.values() for m in ms])
            dx = lot[0] / 2 - allm.bounds[1][0]
            for ms in bh.parts.values():
                for m in ms:
                    m.apply_translation((dx, 0, 0))
            bh.anchors = {k: (p + np.array([dx, 0, 0]), yaw) for k, (p, yaw) in bh.anchors.items()}
        tris, mats, bnd, slots = export(bh, f"out/{slug}", name)
        size = bnd[1] - bnd[0]
        combos = int(np.prod([len(SLOT_PALETTES[s.split("_")[1]]) for s in slots]))
        meta.append(dict(slug=slug, name=name, cls=cls, tris=tris, mats=mats, slots=slots, combos=combos,
                         size=[round(float(v), 1) for v in size], lot=[lot[0], lot[1]],
                         anchors={k: [round(float(c), 3) for c in p] + [yaw] for k, (p, yaw) in bh.anchors.items()}))
        print(f"{slug:22s} tris={tris:5d} size={np.round(size, 1)} lot={lot} anchors={list(bh.anchors)} combos={combos}")
        if nvar:
            os.makedirs("out/varianten", exist_ok=True)
            rng = np.random.default_rng(hash(slug) % 2**32)
            for k in range(nvar):
                bv = fn()
                bv.normalize()
                randomize(bv, rng)
                export(bv, f"out/varianten/{slug}_v{k + 1}", f"{name} v{k + 1}")
    if not only:
        json.dump(dict(houses=meta, palettes=SLOT_PALETTES), open("out/meta.json", "w"), indent=1, ensure_ascii=False)
