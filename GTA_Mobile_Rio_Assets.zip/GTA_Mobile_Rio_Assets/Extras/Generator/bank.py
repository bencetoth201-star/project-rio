"""Banco de Brasilia – Spezialgebäude mit 3 Ebenen (UG Tresor, EG Schalterhalle, OG Büros).
Front zeigt nach +Z. Nodes heißen <Ebene>__<Material>: Aussen, UG, EG, OG, Dach."""
import numpy as np
import trimesh
from lib import B

SAND, BROWN = "bank_sand", "bank_brown"
SIGN_TEXT = ("Banco de", "Brasilia")


def bank():
    b = B(1964)
    X0, X1, Z0, Z1 = -10.0, 10.0, -8.0, 6.0        # main body
    VX, VZ1 = 3.5, 8.5                               # central block (x -VX..VX) protrudes to VZ1
    EG0, EG1 = 0.5, 4.5                              # EG floor top / ceiling slab bottom
    OG0, OG1 = 4.9, 8.7                              # OG floor top / roof slab bottom
    UG0 = -4.0                                       # UG floor top
    T = 0.3

    def box(mat, x0, x1, y0, y1, z0, z1, **kw):
        b.box(mat, (abs(x1 - x0), y1 - y0, abs(z1 - z0)), ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), **kw)

    def wall_x(z, x0, x1, y0, y1, holes=(), t=T, mat=SAND):
        """Wall along X (front/back), holes = [(xa, xb, ya, yb)]."""
        z0, z1 = z - t / 2, z + t / 2
        xs = [x0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [x1]
        for a, c in zip(xs[0::2], xs[1::2]):
            if c - a > 1e-3:
                box(mat, a, c, y0, y1, z0, z1)
        for (xa, xb, ya, yb) in holes:
            if ya > y0:
                box(mat, xa, xb, y0, ya, z0, z1)
            if yb < y1:
                box(mat, xa, xb, yb, y1, z0, z1)

    def wall_z(x, z0, z1, y0, y1, holes=(), t=T, mat=SAND):
        x0, x1 = x - t / 2, x + t / 2
        zs = [z0] + [v for h in sorted(holes) for v in (h[0], h[1])] + [z1]
        for a, c in zip(zs[0::2], zs[1::2]):
            if c - a > 1e-3:
                box(mat, x0, x1, y0, y1, a, c)
        for (za, zb, ya, yb) in holes:
            if ya > y0:
                box(mat, x0, x1, y0, ya, za, zb)
            if yb < y1:
                box(mat, x0, x1, yb, y1, za, zb)

    def window_x(z, xa, xb, ya, yb, out=+1, glass="glass_bank"):
        box(glass, xa, xb, ya, yb, z - 0.02, z + 0.02)
        f = 0.09
        for (a, c, d, e) in [(xa, xb, ya, ya + f), (xa, xb, yb - f, yb), (xa, xa + f, ya, yb), (xb - f, xb, ya, yb),
                             ((xa + xb) / 2 - 0.04, (xa + xb) / 2 + 0.04, ya, yb), (xa, xb, ya + (yb - ya) * 0.68, ya + (yb - ya) * 0.68 + 0.07)]:
            box("frame_black", a, c, d, e, z - 0.06 + out * 0.03, z + 0.06 + out * 0.03)
        box(BROWN, xa - 0.1, xb + 0.1, ya - 0.12, ya, z + out * 0.15 - 0.15, z + out * 0.15 + 0.15)

    def window_z(x, za, zb, ya, yb, out=+1, glass="glass_bank"):
        box(glass, x - 0.02, x + 0.02, ya, yb, za, zb)
        f = 0.09
        for (a, c, d, e) in [(za, zb, ya, ya + f), (za, zb, yb - f, yb), (za, za + f, ya, yb), (zb - f, zb, ya, yb),
                             ((za + zb) / 2 - 0.04, (za + zb) / 2 + 0.04, ya, yb)]:
            box("frame_black", x - 0.06 + out * 0.03, x + 0.06 + out * 0.03, d, e, a, c)

    def plant(x, y, z, r=0.3, pot="pot"):
        b.cyl(pot, r * 0.7, r * 1.2, (x, y + r * 0.6, z), 8)
        for k, (dx, dz, s) in enumerate([(0, 0, 1.0), (0.12, 0.08, 0.7), (-0.1, -0.1, 0.75)]):
            b.rock("plant", r * s, (x + dx * r * 3, y + r * 1.2 + r * 0.6 + k * 0.08, z + dz * r * 3), 1.1)

    def desk(x, z, rot=0.0, y=EG0, w=1.4, monitor=True, chair=True):
        c, s = np.cos(np.radians(rot)), np.sin(np.radians(rot))
        b.box("wood_warm", (w, 0.05, 0.75), (x, y + 0.74, z), rot_y=rot)
        for dx in (-w / 2 + 0.05, w / 2 - 0.05):
            b.box("wood_warm", (0.05, 0.72, 0.7), (x + dx * c, y + 0.36, z - dx * s), rot_y=rot)
        if monitor:
            b.box("keypad", (0.55, 0.36, 0.04), (x - 0.2 * s, y + 1.05, z - 0.2 * c), rot_y=rot)
            b.box("keypad", (0.06, 0.2, 0.06), (x - 0.24 * s, y + 0.85, z - 0.24 * c), rot_y=rot)
        if chair:
            b.box("keypad", (0.5, 0.08, 0.5), (x + 0.6 * s, y + 0.48, z + 0.6 * c), rot_y=rot)
            b.box("keypad", (0.5, 0.6, 0.08), (x + 0.85 * s, y + 0.8, z + 0.85 * c), rot_y=rot)
            b.cyl("metal", 0.04, 0.44, (x + 0.6 * s, y + 0.22, z + 0.6 * c), 6)

    def camera(x, y, z, yaw):
        b.box("paint_white", (0.18, 0.18, 0.38), (x, y, z), rot_y=yaw)
        b.box("keypad", (0.12, 0.12, 0.02), (x + 0.19 * np.sin(np.radians(yaw)), y, z + 0.19 * np.cos(np.radians(yaw))), rot_y=yaw)
        b.box("led_red", (0.04, 0.04, 0.02), (x, y + 0.11, z), rot_y=yaw)

    def logo(cx, cy, z, h, mat="sign_dark", depth=0.06, face=+1):
        """Temple icon: pediment, 4 columns, base."""
        w = h * 1.15
        zz = z + face * depth / 2
        b.hull(mat, [(cx - w / 2, cy + h * 0.62, z), (cx + w / 2, cy + h * 0.62, z), (cx, cy + h, z),
                     (cx - w / 2, cy + h * 0.62, z + face * depth), (cx + w / 2, cy + h * 0.62, z + face * depth), (cx, cy + h, z + face * depth)])
        box(mat, cx - w / 2, cx + w / 2, cy + h * 0.52, cy + h * 0.6, min(z, zz * 2 - z), max(z, zz * 2 - z))
        for k in range(4):
            px = cx - w * 0.36 + k * w * 0.24
            box(mat, px - w * 0.06, px + w * 0.06, cy + h * 0.14, cy + h * 0.5, min(z, zz * 2 - z), max(z, zz * 2 - z))
        box(mat, cx - w / 2, cx + w / 2, cy, cy + h * 0.1, min(z, zz * 2 - z), max(z, zz * 2 - z))

    def sign(cx, cy, z, h_text, face=+1):
        """[logo] | Banco de / Brasilia  – centred on cx (front-facing signs only)."""
        lw = h_text * 1.9 * 1.15
        tw = h_text * 0.82 * 5.06                           # width of "Brasilia" (measured)
        total = lw + h_text * 0.7 + tw
        x0 = cx - total / 2
        logo(x0 + lw / 2, cy - h_text * 0.9, z, h_text * 1.9, face=face)
        dx = x0 + lw + h_text * 0.35
        box("sign_dark", dx - 0.035, dx + 0.035, cy - h_text * 1.0, cy + h_text * 1.15, z, z + 0.06)
        tx = dx + h_text * 0.35
        b.text(SIGN_TEXT[0], "sign_dark", (tx, cy + h_text * 0.62, z), h_text * 0.82, 0.06, simplify=0.03, align="left")
        b.text(SIGN_TEXT[1], "sign_dark", (tx, cy - h_text * 0.55, z), h_text * 0.82, 0.06, simplify=0.03, align="left")

    # =================================================================
    # AUSSEN: lot, sidewalk, steps, palms, lamp, planters
    # =================================================================
    b.layer = "Aussen"
    LX0, LX1, LZ0, LZ1 = -13.0, 13.0, -10.0, 14.0
    b.box("concrete_light", (LX1 - LX0, 0.06, LZ1 - LZ0), (0, 0.03, (LZ0 + LZ1) / 2))
    for x in np.arange(LX0 + 1.5, LX1, 1.5):                                            # paving joints
        b.box("concrete", (0.03, 0.005, LZ1 - LZ0 - 0.2), (x, 0.062, (LZ0 + LZ1) / 2))
    box("concrete", LX0, LX1, 0, 0.18, LZ1 - 0.35, LZ1)                                   # curb
    for k in range(3):                                                                    # entrance steps
        box("concrete_light", -2.6, 2.6, 0, EG0 - k * EG0 / 3, VZ1 + k * 0.35, VZ1 + (k + 1) * 0.35)
    for sx in (-1, 1):                                                                    # entrance planters
        box(SAND, sx * 2.7, sx * 4.2, 0, 0.8, VZ1 + 0.1, VZ1 + 1.2)
        box(BROWN, sx * 2.65, sx * 4.25, 0.8, 0.9, VZ1 + 0.05, VZ1 + 1.25)
        plant(sx * 3.45, 0.9, VZ1 + 0.65, 0.32, "hedge")
    for (x, z) in [(-9.0, 7.0), (-6.0, 7.0), (6.0, 7.0), (9.0, 7.6)]:                    # facade planters
        box(SAND, x - 0.9, x + 0.9, 0, 0.6, z - 0.4, z + 0.4)
        box("hedge", x - 0.8, x + 0.8, 0.6, 1.1, z - 0.3, z + 0.3)
    for (x, z) in [(-4.6, 9.4), (4.6, 9.4)]:
        plant(x, 0.06, z, 0.35, "frame_black")
    b.palm(-11.3, 9.5, 8.0, (-0.6, 0.4))
    b.palm(11.3, 9.0, 8.5, (0.5, 0.4))
    lx, lz = -7.8, 11.8                                                                   # old street lamp
    b.cyl("frame_black", 0.25, 0.5, (lx, 0.25, lz), 8)
    b.cyl("frame_black", 0.08, 3.6, (lx, 2.2, lz), 8)
    b.box("frame_black", (0.5, 0.08, 0.5), (lx, 4.0, lz))
    b.box("lamp", (0.36, 0.55, 0.36), (lx, 4.32, lz))
    b.hull("frame_black", [(lx - 0.3, 4.6, lz - 0.3), (lx + 0.3, 4.6, lz - 0.3), (lx - 0.3, 4.6, lz + 0.3),
                           (lx + 0.3, 4.6, lz + 0.3), (lx, 4.9, lz)])
    b.anchor("Eingang", (0, 0, VZ1 + 1.6), 0)

    # =================================================================
    # UG: stairs down, bars (Gitter), antechamber, vault door, vault
    # =================================================================
    b.layer = "UG"
    UZ0, UZ1 = Z0, 5.5
    WT = 0.5
    box("bunker_floor", X0, X1, UG0 - 0.3, UG0, UZ0, UZ1)
    for (a, c, d, e) in [(X0, X0 + WT, UZ0, UZ1), (X1 - WT, X1, UZ0, UZ1)]:
        box("bunker", a, c, UG0, 0, d, e)
    box("bunker", X0, X1, UG0, 0, UZ0, UZ0 + WT)
    box("bunker", X0, X1, UG0, 0, UZ1 - WT, UZ1)
    # stairs from EG (right side) going down towards the back
    SX0, SX1 = 7.9, 9.5
    n, run = 22, 0.28
    rise = (EG0 - UG0) / n
    zs = 4.4
    for i in range(n):
        top = EG0 - (i + 1) * rise
        zc = zs - i * run - run / 2
        box("concrete_dk" if i % 2 else "concrete", SX0, SX1, UG0, top, zc - run / 2, zc + run / 2)
    z_land = zs - n * run
    b.anchor("Treppe_UG", ((SX0 + SX1) / 2, UG0, z_land - 0.6), 180)
    # Gitter (bars) wall with gate at x = 6.5
    GX = 6.5
    gz0, gz1 = z_land - 1.6, z_land - 0.4                                                # gate opening (near the landing)
    for z in np.arange(UZ0 + WT + 0.15, UZ1 - WT, 0.24):
        if gz0 < z < gz1:
            continue
        b.box("metal", (0.05, -UG0, 0.05), (GX, UG0 / 2, z))
    for y in (UG0 + 0.15, UG0 + 1.4, -0.2):                                               # rails stop at the gate opening
        for (za, zb) in (((UZ0 + WT, gz0), (gz1, UZ1 - WT)) if y < -0.3 else ((UZ0 + WT, UZ1 - WT),)):
            box("metal", GX - 0.05, GX + 0.05, y - 0.05, y + 0.05, za, zb)
    b.layer = "UG_Gittertor"                                                             # gate leaf (closed), hinge at gz0
    b.pivots["UG_Gittertor"] = (GX - 0.12, UG0, gz0)
    for z in np.arange(gz0 + 0.1, gz1 - 0.05, 0.16):
        b.box("metal", (0.05, 2.3, 0.05), (GX - 0.12, UG0 + 1.2, z))
    for y in (UG0 + 0.1, UG0 + 1.2, UG0 + 2.3):
        box("metal", GX - 0.16, GX - 0.08, y - 0.04, y + 0.04, gz0, gz1)
    b.layer = "UG"
    b.box("keypad", (0.06, 0.3, 0.2), (GX + 0.08, UG0 + 1.3, gz1 + 0.25))
    b.box("led_red", (0.02, 0.05, 0.05), (GX + 0.12, UG0 + 1.4, gz1 + 0.25))
    b.anchor("Gitter_Tuer", (GX - 0.6, UG0, (gz0 + gz1) / 2), -90)
    # vault wall with round vault door at x = -2
    VWX = -2.0
    dz0 = -2.0
    box("bunker", VWX - 0.4, VWX + 0.4, UG0, 0, UZ0 + WT, dz0 - 1.5)
    box("bunker", VWX - 0.4, VWX + 0.4, UG0, 0, dz0 + 1.5, UZ1 - WT)
    box("bunker", VWX - 0.4, VWX + 0.4, UG0 + 3.0, 0, dz0 - 1.5, dz0 + 1.5)
    box("vault", VWX + 0.4, VWX + 0.55, UG0, UG0 + 3.2, dz0 - 1.7, dz0 + 1.7)          # steel frame
    b.layer = "UG_Tresortuer"                                                            # round vault door, hinge at dz0 - 1.35
    b.pivots["UG_Tresortuer"] = (VWX + 0.65, UG0 + 1.5, dz0 - 1.35)
    door = trimesh.creation.cylinder(radius=1.35, height=0.5, sections=16)
    door.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    door.apply_translation((VWX + 0.65, UG0 + 1.5, dz0))
    b.add("vault", door)
    hub = trimesh.creation.cylinder(radius=0.22, height=0.25, sections=8)
    hub.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [0, 1, 0]))
    hub.apply_translation((VWX + 1.0, UG0 + 1.5, dz0))
    b.add("metal", hub)
    for a in np.radians([0, 60, 120]):                                                   # wheel spokes
        b.beam("metal", (VWX + 1.05, UG0 + 1.5 - 0.7 * np.sin(a), dz0 - 0.7 * np.cos(a)),
               (VWX + 1.05, UG0 + 1.5 + 0.7 * np.sin(a), dz0 + 0.7 * np.cos(a)), 0.07)
    for k in range(6):                                                                   # bolts
        a = k * np.pi / 3
        b.cyl("metal", 0.08, 0.1, (VWX + 0.95, UG0 + 1.5 + 1.1 * np.sin(a), dz0 + 1.1 * np.cos(a)), 6)
    b.layer = "UG"
    b.box("led_red", (0.06, 0.18, 0.18), (VWX + 0.6, UG0 + 2.95, dz0 + 1.9))
    b.box("keypad", (0.06, 0.4, 0.28), (VWX + 0.45, UG0 + 1.4, dz0 + 2.0))
    b.anchor("Tresor_Tuer", (VWX + 1.6, UG0, dz0), 90)
    # vault interior: gold shelves + money pallets ("Geld")
    for (zc,) in [(-6.6,), (-4.6,)]:
        box("metal", X0 + WT, X0 + WT + 0.6, UG0, UG0 + 2.2, zc - 0.9, zc + 0.9)
        for lv in range(3):
            y = UG0 + 0.5 + lv * 0.7
            box("vault", X0 + WT, X0 + WT + 0.65, y - 0.04, y, zc - 0.9, zc + 0.9)
            for k in range(3):
                for j in range(2):
                    b.box("gold", (0.22, 0.09, 0.4), (X0 + WT + 0.18 + j * 0.26, y + 0.05, zc - 0.55 + k * 0.55))
    for (cx, cz, n_st) in [(-8.2, 3.6, 4), (-6.6, 3.6, 3), (-8.2, 2.0, 2)]:
        box("wood_b", cx - 0.6, cx + 0.6, UG0, UG0 + 0.15, cz - 0.5, cz + 0.5)
        for k in range(n_st):
            for i in range(2):
                for j in range(2):
                    b.box("money", (0.5, 0.18, 0.4), (cx - 0.27 + i * 0.54, UG0 + 0.24 + k * 0.19, cz - 0.22 + j * 0.44))
    b.anchor("Tresor", (-7.0, UG0, 1.0), 0)
    for (x, z) in [(-6.0, -3.0), (2.0, -3.0), (2.0, 2.5), (8.7, -5.0)]:
        box("dach_licht", x - 0.6, x + 0.6, -0.06, -0.02, z - 0.15, z + 0.15)
    camera(5.9, -0.5, 4.6, -135)
    camera(VWX + 0.7, -0.5, UZ1 - WT - 0.3, 135)

    # =================================================================
    # EG: shell, vestibule, teller counter, queue, ATM, Gitter + stairwell
    # =================================================================
    b.layer = "EG"
    # floor slab with stairwell hole (also UG ceiling)
    HX0, HZ0, HZ1 = 7.8, z_land - 0.1, 4.55
    box("bank_floor", X0, HX0, 0, EG0, Z0, Z1)
    box("bank_floor", HX0, X1, 0, EG0, Z0, HZ0)
    box("bank_floor", HX0, X1, 0, EG0, HZ1, Z1)
    box("bank_floor", -VX, VX, 0, EG0, Z1, VZ1)
    box(BROWN, X0 - 0.05, X1 + 0.05, 0, EG0, Z0 - 0.05, Z0 + 0.3)
    for sx in (-1, 1):
        box(BROWN, sx * X1 - 0.05, sx * X1 + 0.05 + sx * 0.0, 0, EG0, Z0, Z1)
    # outer walls with windows
    wy0, wy1 = EG0 + 0.6, EG1 - 0.6
    wall_x(Z1, X0, -VX, 0, EG1, [(-9.0, -4.6, wy0, wy1)])
    window_x(Z1, -9.0, -4.6, wy0, wy1)
    wall_x(Z1, VX, X1, 0, EG1, [(4.6, 7.4, wy0, wy1)])
    window_x(Z1, 4.6, 7.4, wy0, wy1)
    # outside ATM in the right facade (through-wall)
    ax = 8.7
    box("atm_grey", ax - 0.5, ax + 0.5, EG0 - 0.5, EG0 + 1.8, Z1 + 0.15, Z1 + 0.45)
    box("keypad", ax - 0.3, ax + 0.3, EG0 + 0.95, EG0 + 1.35, Z1 + 0.45, Z1 + 0.47)
    box("led_green", ax - 0.24, ax + 0.24, EG0 + 1.0, EG0 + 1.3, Z1 + 0.47, Z1 + 0.48)
    box("keypad", ax - 0.25, ax + 0.25, EG0 + 0.6, EG0 + 0.8, Z1 + 0.45, Z1 + 0.55)
    box("atm_blue", ax - 0.5, ax + 0.5, EG0 + 1.85, EG0 + 2.3, Z1 + 0.15, Z1 + 0.5)
    b.text("ATM", "sign_white", (ax, EG0 + 2.07, Z1 + 0.5), 0.26, 0.02)
    b.anchor("ATM_Aussen", (ax, 0, Z1 + 1.2), 0)
    wall_x(Z0, X0, X1, 0, EG1, [(-6.0, -3.0, wy0, wy1), (2.0, 5.0, wy0, wy1)])
    window_x(Z0, -6.0, -3.0, wy0, wy1, -1)
    window_x(Z0, 2.0, 5.0, wy0, wy1, -1)
    for sx, x in ((-1, X0), (1, X1)):
        holes = [(-5.5, -3.5, wy0, wy1), (-1.0, 1.0, wy0, wy1), (3.0, 4.6, wy0, wy1)]
        wall_z(x, Z0, Z1, 0, EG1, holes)
        for (za, zb, ya, yb) in holes:
            window_z(x, za, zb, ya, yb, sx)
    # vestibule (central block EG): side walls + glass entrance front
    for sx in (-1, 1):
        wall_z(sx * VX, Z1 - 0.15, VZ1, 0, EG1)
    box(SAND, -VX - 0.15, -2.6, 0, EG1, VZ1 - 0.15, VZ1 + 0.15)
    box(SAND, 2.6, VX + 0.15, 0, EG1, VZ1 - 0.15, VZ1 + 0.15)
    box("glass_bank", -2.6, 2.6, EG0, 3.9, VZ1 - 0.02, VZ1 + 0.02)
    box(SAND, -2.6, 2.6, 3.9, EG1, VZ1 - 0.15, VZ1 + 0.15)
    for x in (-2.6, -1.3, 0.0, 1.3, 2.6):
        box("frame_black", x - 0.05, x + 0.05, EG0, 3.9, VZ1 - 0.06, VZ1 + 0.08)
    for y in (EG0, 2.9, 3.85):
        box("frame_black", -2.6, 2.6, y, y + 0.08, VZ1 - 0.06, VZ1 + 0.08)
    for sx in (-1, 1):
        box("metal", sx * 0.15 - 0.02, sx * 0.15 + 0.02, EG0 + 0.8, EG0 + 1.8, VZ1 + 0.1, VZ1 + 0.14)
    box(BROWN, -VX - 0.6, VX + 0.6, EG1 - 0.15, EG1 + 0.3, VZ1 - 0.2, VZ1 + 1.4)         # entrance canopy
    # left stair to OG
    SLX0, SLX1 = -9.7, -8.2
    stz = 3.6
    zl = b.stairs("bank_floor", SLX0, SLX1, stz, EG0, OG0, 0.27, -1, True, "concrete_light")
    wall_z(-8.05, zl, stz + 0.3, EG0, EG0 + 1.0, t=0.15)
    box(BROWN, -8.15, -7.95, EG0 + 1.0, EG0 + 1.08, zl, stz + 0.3)
    # inside ATM next to stairs
    box("atm_grey", -7.75, -7.15, EG0, EG0 + 1.9, 0.8, 1.6)
    box("keypad", -7.15, -7.13, EG0 + 1.0, EG0 + 1.35, 0.9, 1.5)
    box("led_green", -7.13, -7.12, EG0 + 1.05, EG0 + 1.3, 0.95, 1.45)
    box("atm_blue", -7.75, -7.1, EG0 + 1.95, EG0 + 2.35, 0.8, 1.6)
    b.text("ATM", "sign_white", (-7.09, EG0 + 2.15, 1.2), 0.22, 0.02, rot_y=90)
    b.anchor("ATM_Innen", (-6.4, EG0, 1.2), 90)
    # teller counter with 3 stations + glass top + back office side
    CZ = -2.2
    box("wood_warm", -4.0, 4.0, EG0, EG0 + 1.1, CZ - 0.35, CZ + 0.35)
    box("bank_brown", -4.1, 4.1, EG0 + 1.1, EG0 + 1.16, CZ - 0.45, CZ + 0.45)
    for k, x in enumerate((-2.7, 0.0, 2.7)):
        box("glass_rail", x - 1.25, x + 1.25, EG0 + 1.16, EG0 + 2.0, CZ + 0.38, CZ + 0.42)
        b.box("keypad", (0.6, 0.4, 0.05), (x, EG0 + 1.45, CZ - 0.15))
        b.box("keypad", (0.07, 0.25, 0.07), (x, EG0 + 1.25, CZ - 0.2))
        b.box("keypad", (0.5, 0.08, 0.5), (x, EG0 + 0.5, CZ - 1.0))
        b.box("keypad", (0.5, 0.55, 0.08), (x, EG0 + 0.8, CZ - 1.25))
    for x in (-4.05, 4.05):
        box("wood_warm", x - 0.05, x + 0.05, EG0, EG0 + 1.1, CZ - 0.35, CZ + 0.35)
    b.anchor("Schalter", (0.0, EG0, CZ + 1.2), 0)
    # queue stanchions with ropes
    qz = 1.4
    posts = [-3.6, -1.2, 1.2, 3.6]
    for x in posts:
        b.cyl("metal", 0.2, 0.05, (x, EG0 + 0.03, qz), 8)
        b.cyl("frame_black", 0.04, 0.95, (x, EG0 + 0.5, qz), 6)
    for a, c in zip(posts[:-1], posts[1:]):
        b.wire((a, EG0 + 0.92, qz), (c, EG0 + 0.92, qz), 0.15, 4, 0.04, "sign_red")
    # interior sign on the back wall
    sign(0.0, EG0 + 2.7, Z0 + T / 2, 0.55, +1)
    # plants
    for (x, z) in [(-6.6, -7.2), (6.0, -7.2), (-3.0, Z1 - 0.6), (3.0, Z1 - 0.6)]:
        plant(x, EG0, z, 0.32)
    # Gitter partition (x = 6) with gate near the front -> stairwell area
    PXg = 6.0
    gz0e, gz1e = 4.55, 5.65
    for z in np.arange(Z0 + 0.2, Z1 - 0.1, 0.24):
        if gz0e < z < gz1e:
            continue
        b.box("metal", (0.05, EG1 - EG0, 0.05), (PXg, (EG0 + EG1) / 2, z))
    for y in (EG0 + 0.1, EG0 + 1.2, EG1 - 0.1):
        box("metal", PXg - 0.05, PXg + 0.05, y - 0.05, y + 0.05, Z0 + 0.15, Z1 - 0.15)
    for z in np.arange(gz0e + 0.08, gz1e - 0.04, 0.16):
        b.box("metal", (0.05, 2.2, 0.05), (PXg - 0.1, EG0 + 1.1, z))
    for y in (EG0 + 0.1, EG0 + 1.1, EG0 + 2.2):
        box("metal", PXg - 0.14, PXg - 0.06, y - 0.04, y + 0.04, gz0e, gz1e)
    b.box("keypad", (0.06, 0.3, 0.2), (PXg - 0.08, EG0 + 1.3, gz0e - 0.25))
    b.box("led_red", (0.02, 0.05, 0.05), (PXg - 0.12, EG0 + 1.4, gz0e - 0.25))
    b.anchor("Gitter_EG", (PXg - 0.7, EG0, (gz0e + gz1e) / 2), -90)
    # railing around the stairwell hole
    for z in np.arange(HZ0 + 0.1, HZ1, 0.35):
        b.box("metal", (0.04, 1.0, 0.04), (HX0 - 0.05, EG0 + 0.5, z))
    box("metal", HX0 - 0.1, HX0, EG0 + 1.0, EG0 + 1.06, HZ0, HZ1)
    for x in np.arange(HX0 + 0.1, X1 - 0.2, 0.35):
        b.box("metal", (0.04, 1.0, 0.04), (x, EG0 + 0.5, HZ0 - 0.05))
    box("metal", HX0, X1 - 0.15, EG0 + 1.0, EG0 + 1.06, HZ0 - 0.1, HZ0)
    camera(X1 - 0.5, EG1 - 0.4, Z0 + 0.5, -45)
    camera(-6.5, EG1 - 0.4, Z1 - 0.5, 160)
    for (x, z) in [(-4.0, -4.5), (0.0, -4.5), (4.0, -4.5), (-4.0, 2.5), (0.0, 2.5), (4.0, 2.5), (8.7, -5.0), (0.0, 7.2)]:
        box("dach_licht", x - 0.7, x + 0.7, EG1 - 0.06, EG1 - 0.02, z - 0.2, z + 0.2)
    OHX, OHZ0, OHZ1 = -8.1, zl - 0.2, stz + 0.1
    # brown cornice at EG top (wings) + terrace railings
    for (a, c) in ((X0 - 0.15, -VX), (VX, X1 + 0.15)):
        box(BROWN, a, c, EG1, OG0 + 0.1, Z1 - 0.1, Z1 + 0.25)
    for sx in (-1, 1):
        box(BROWN, sx * X1 - 0.1, sx * X1 + 0.15 * sx + (0.1 if sx < 0 else 0.0) * 0, EG1, OG0 + 0.1, Z0, Z1)

    # =================================================================
    # OG: offices
    # =================================================================
    b.layer = "OG"
    # OG floor = EG ceiling (with hole over the left stair)
    box("bank_floor", OHX, X1, EG1, OG0, Z0, Z1)
    box("bank_floor", X0, OHX, EG1, OG0, Z0, OHZ0)
    box("bank_floor", X0, OHX, EG1, OG0, OHZ1, Z1)
    box("bank_floor", -VX, VX, EG1, OG0, Z1, VZ1)
    OZ1 = 4.5                                                                            # wings set back -> terraces
    wall_x(OZ1, X0, -VX, OG0, OG1, [(-8.8, -5.0, OG0 + 0.9, OG1 - 0.7)])
    window_x(OZ1, -8.8, -5.0, OG0 + 0.9, OG1 - 0.7)
    wall_x(OZ1, VX, X1, OG0, OG1, [(5.0, 8.8, OG0 + 0.9, OG1 - 0.7)])
    window_x(OZ1, 5.0, 8.8, OG0 + 0.9, OG1 - 0.7)
    wholes = [(-8.0 + k * 2.6, -6.0 + k * 2.6, OG0 + 1.4, OG1 - 0.6) for k in range(4)]
    wall_x(Z0, X0, X1, OG0, OG1, wholes)
    for (xa, xb, ya, yb) in wholes:
        window_x(Z0, xa, xb, ya, yb, -1)
    for sx, x in ((-1, X0), (1, X1)):
        holes = [(-5.5, -3.5, OG0 + 0.9, OG1 - 0.7), (-0.5, 1.5, OG0 + 0.9, OG1 - 0.7)]
        wall_z(x, Z0, OZ1, OG0, OG1, holes)
        for (za, zb, ya, yb) in holes:
            window_z(x, za, zb, ya, yb, sx)
    # central block OG: side walls, solid front with the big sign
    for sx in (-1, 1):
        wall_z(sx * VX, OZ1, VZ1, OG0, OG1 + 1.3, [(5.6, 7.6, OG0 + 0.9, OG1 - 0.7)])
        window_z(sx * VX, 5.6, 7.6, OG0 + 0.9, OG1 - 0.7, sx)
    wall_x(VZ1, -VX - 0.15, VX + 0.15, OG0, OG1 + 1.3)
    sign(0.0, OG0 + 2.4, VZ1 + 0.15, 0.6, +1)
    # terraces on the EG roof (in front of the OG wings): railings + plants
    for (a, c) in ((X0, -VX), (VX, X1)):
        for x in np.arange(a + 0.2, c, 0.4):
            b.box("frame_black", (0.035, 1.0, 0.035), (x, OG0 + 0.5, Z1 + 0.05))
        box("frame_black", a, c, OG0 + 1.0, OG0 + 1.06, Z1 + 0.02, Z1 + 0.1)
        plant((a + c) / 2, OG0, Z1 - 0.6, 0.3)
    for sx in (-1, 1):
        for z in np.arange(OZ1 + 0.2, Z1, 0.4):
            b.box("frame_black", (0.035, 1.0, 0.035), (sx * (X1 - 0.05), OG0 + 0.5, z))
        box("frame_black", sx * (X1 - 0.05) - 0.03, sx * (X1 - 0.05) + 0.03, OG0 + 1.0, OG0 + 1.06, OZ1, Z1)
    # stair hole railing
    for z in np.arange(OHZ0 + 0.1, OHZ1, 0.35):
        b.box("metal", (0.04, 1.0, 0.04), (OHX + 0.05, OG0 + 0.5, z))
    box("metal", OHX, OHX + 0.1, OG0 + 1.0, OG0 + 1.06, OHZ0, OHZ1)
    # open-plan office: 2 x 3 desks
    for i, x in enumerate((-4.2, -2.6, -1.0)):
        desk(x, -4.4, 180, OG0, 1.5)
        desk(x, -2.8, 0, OG0, 1.5)
    box("wood_warm", -5.0, -0.2, OG0 + 0.74, OG0 + 1.1, -3.62, -3.58)
    # copier + filing
    box("paint_white", -7.6, -6.8, OG0, OG0 + 1.1, -7.5, -6.8)
    box("keypad", -7.55, -6.85, OG0 + 1.1, OG0 + 1.2, -7.45, -6.85)
    box("shelf", -7.7, -7.2, OG0, OG0 + 1.8, -6.4, -5.0)
    for (x, z) in [(-7.4, -2.8), (2.4, -7.2), (-4.0, OZ1 - 0.6), (2.6, OZ1 - 0.6)]:
        plant(x, OG0, z, 0.3)
    # reception near the front
    box("wood_warm", -1.2, 1.8, OG0, OG0 + 1.05, 2.4, 2.9)
    box(BROWN, -1.3, 1.9, OG0 + 1.05, OG0 + 1.1, 2.3, 3.0)
    desk(0.3, 1.7, 0, OG0, 1.4)
    # sofa lounge in the central block
    box("keypad", -2.4, 2.4, OG0, OG0 + 0.45, 7.5, 8.2)
    box("keypad", -2.4, 2.4, OG0 + 0.45, OG0 + 0.95, 8.0, 8.25)
    box("wood_warm", -0.8, 0.8, OG0, OG0 + 0.4, 6.2, 6.9)
    # three offices on the right: partition x = 4, back office | 2 front offices
    PXo = 4.0
    wall_z(PXo, Z0 + 0.15, OZ1 - 0.15, OG0, OG1, [(-5.4, -4.4, OG0, OG0 + 2.2), (0.6, 1.6, OG0, OG0 + 2.2)], t=0.15, mat="paint_white")
    wall_x(-2.0, PXo, X1 - 0.15, OG0, OG1, [], t=0.15, mat="paint_white")
    wall_z(7.0, -2.0, OZ1 - 0.15, OG0, OG1, [(-0.2, 0.8, OG0, OG0 + 2.2)], t=0.15, mat="paint_white")
    for (x, z, rot) in [(PXo, -4.9, 90), (PXo, 1.1, 90), (7.0, 0.3, 90)]:
        b.box("door_wood", (0.06, 2.15, 0.95), (x + 0.0, OG0 + 1.08, z))
        b.box("metal", (0.12, 0.05, 0.05), (x - 0.05, OG0 + 1.05, z - 0.35))
    desk(7.0, -5.6, 180, OG0, 1.8)                                                       # director
    box("vault", 9.0, 9.7, OG0, OG0 + 0.9, -7.6, -6.9)
    box("shelf", 9.2, 9.7, OG0, OG0 + 2.0, -4.6, -2.6)
    plant(5.0, OG0, -7.3, 0.3)
    desk(5.5, 2.5, 180, OG0, 1.4)
    box("shelf", 4.2, 4.6, OG0, OG0 + 1.8, -1.6, -0.2)
    desk(8.4, 2.5, 180, OG0, 1.4)
    box("shelf", 9.3, 9.7, OG0, OG0 + 1.8, -1.6, 0.0)
    b.anchor("Buero_Direktor", (7.0, OG0, -4.2), 0)
    for (x, z) in [(-4.0, -5.0), (-1.0, -5.0), (2.0, -5.0), (-4.0, 1.0), (0.0, 1.0), (7.0, -4.5), (5.5, 2.0), (8.4, 2.0), (0.0, 7.0)]:
        box("dach_licht", x - 0.6, x + 0.6, OG1 - 0.06, OG1 - 0.02, z - 0.2, z + 0.2)

    # =================================================================
    # DACH: roof slabs, cornices, parapet, AC units
    # =================================================================
    b.layer = "Dach"
    box("dach", X0, X1, OG1, OG1 + 0.3, Z0, OZ1 + 0.15)
    box("dach", -VX, VX, OG1, OG1 + 0.3, OZ1, VZ1)
    for (a, c, d, e) in [(X0 - 0.2, X1 + 0.2, Z0 - 0.2, Z0 + 0.15), (X0 - 0.2, -VX, OZ1 - 0.1, OZ1 + 0.25),
                         (VX, X1 + 0.2, OZ1 - 0.1, OZ1 + 0.25), (X0 - 0.2, X0 + 0.15, Z0 - 0.2, OZ1 + 0.25),
                         (X1 - 0.15, X1 + 0.2, Z0 - 0.2, OZ1 + 0.25)]:
        box(BROWN, a, c, OG1 + 0.1, OG1 + 0.55, d, e)
    for (a, c, d, e) in [(-VX - 0.25, VX + 0.25, VZ1 - 0.15, VZ1 + 0.3), (-VX - 0.25, -VX + 0.15, OZ1, VZ1 + 0.3),
                         (VX - 0.15, VX + 0.25, OZ1, VZ1 + 0.3)]:
        box(BROWN, a, c, OG1 + 1.3, OG1 + 1.6, d, e)
    box(SAND, -VX + 0.15, VX - 0.15, OG1 + 0.3, OG1 + 1.3, OZ1 - 0.1, OZ1 + 0.15)
    for (x, z) in [(-6.0, -5.0), (5.0, -5.5)]:
        box("dach_technik", x - 1.1, x + 1.1, OG1 + 0.3, OG1 + 1.2, z - 0.7, z + 0.7)
        for k in range(3):
            box("frame_black", x - 1.0, x + 1.0, OG1 + 0.5 + k * 0.2, OG1 + 0.54 + k * 0.2, z + 0.7, z + 0.74)
    b.beam("metal", (8.5, OG1 + 0.3, -6.5), (8.5, OG1 + 3.0, -6.5), 0.06)
    b.layer = None
    return b
